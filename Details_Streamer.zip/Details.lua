
_detalhes_global = {
	["death_recap"] = {
		["enabled"] = true,
		["show_segments"] = false,
		["show_life_percent"] = false,
		["relevance_time"] = 7,
	},
	["spell_pool"] = {
		"Guardian Sentry", -- [1]
		3, -- [2]
		"Environment (Falling)", -- [3]
		[6] = "Environment (Fire)",
		[7] = "Environment (Lava)",
		[206581] = "Gul'dan",
		[15667] = "Coilfang Tempest",
		[203510] = 10,
		[220916] = "[*] Tainted Ground",
		[8122] = 5,
		[114050] = 7,
		[212726] = "Cenarius",
		[198392] = "Ursoc",
		[199416] = 10,
		[192249] = 7,
		[193273] = "Ularogg Cragshaper",
		[195321] = 10,
		[128897] = 11,
		[235253] = "[*] Fel Infusion",
		[228086] = "Phantom Crew",
		[36808] = "Mage Hunter Ascendant",
		[246516] = "Kin'garoth",
		[206585] = "Star Augur Etraeus",
		[128386] = 4,
		[201467] = 12,
		[48583] = "Skarvald the Constructor",
		[114052] = 7,
		[215802] = 7,
		[208635] = 1,
		[85384] = 1,
		[51399] = 6,
		[217851] = "Naraxas",
		[210684] = "Withered Manawraith",
		[22886] = "King Gordok",
		[233210] = "Spectral Stable Hand",
		[236282] = 1,
		[31717] = "The Black Stalker",
		[213757] = 2,
		[176898] = 5,
		[245498] = 10,
		[115078] = 10,
		[183042] = 1,
		[216830] = "High Botanist Tel'arn",
		[210687] = 11,
		[212735] = "Spellblade Aluriel",
		[254714] = 11,
		[239356] = 10,
		[60103] = 7,
		[52424] = 6,
		[210688] = "Withered Manawraith",
		[36554] = 4,
		[196354] = "Archdruid Glaidalis",
		[13748] = "Residual Monstrosity",
		[13812] = 3,
		[230143] = "Mistress Sassz'ine",
		[239358] = "[*] Anguished Outburst",
		[208642] = "Spirit of Ursoc",
		[80780] = "Shrieking Banshee",
		[211714] = 9,
		[196356] = 5,
		[115080] = 10,
		[49609] = 5,
		[14516] = "Riverpaw Slayer",
		[116616] = 4,
		[209667] = "Advisor Melandrus",
		[211715] = 9,
		[212739] = 6,
		[156426] = 8,
		[255742] = 8,
		[15092] = "Doom'rel",
		[194310] = 6,
		[15284] = "Anvilrage Soldier",
		[22887] = "Murkblood Spearman",
		[15668] = "Magmus",
		[54729] = 6,
		[203526] = 1,
		[255744] = 8,
		[234243] = 5,
		[16244] = "Bonechewer Hungerer",
		[195336] = 10,
		[188169] = "Rokmora",
		[239363] = 2,
		[224005] = "Fel Bat",
		[151310] = 5,
		[50378] = "Scourge Reanimator",
		[1079] = 11,
		[212743] = 4,
		[197385] = 7,
		[208648] = 1,
		[185099] = 10,
		[215816] = 5,
		[199435] = 2,
		[208650] = 1,
		[235271] = "Maiden of Vigilance",
		[245510] = "[*] Corrupting Void",
		[230152] = 2,
		[5211] = 11,
		[225033] = 12,
		[226057] = "Chronarch Defender",
		[204556] = 3,
		[172816] = "Lightsworn Anchorite",
		[21992] = 4,
		[209676] = "Advisor Melandrus",
		[203533] = 11,
		[254727] = "Fragmented Voidling <[*] Void Fragment> <[*] Void Fragment>",
		[236298] = 8,
		[31719] = 9,
		[254728] = "Fragmented Voidling <[*] Void Fragment>",
		[31975] = "Phasing Stalker",
		[207630] = "Trilliax",
		[225036] = 2,
		[209678] = "Advisor Melandrus",
		[236299] = 8,
		[49356] = "The Prophet Tharon'ja",
		[206607] = "Chronomatic Anomaly",
		[207631] = "[*] Annihilation",
		[210703] = "Lady Calindris",
		[211727] = 9,
		[158486] = 8,
		[237325] = "[*] Toxic Pollen",
		[206609] = "Chronomatic Anomaly",
		[210705] = 11,
		[1719] = 1,
		[212753] = 6,
		[13877] = 4,
		[206610] = "Chronomatic Anomaly",
		[240398] = "[*] Dark Mark",
		[48333] = 10,
		[129934] = 1,
		[203539] = 2,
		[245518] = "Diima, Mother of Gloom",
		[254733] = "Dark Aberration",
		[49613] = 9,
		[207635] = 2,
		[208659] = "[*] Arcanetic Ring",
		[194325] = "Harbaron",
		[42702] = "Tunneling Ghoul",
		[34767] = 2,
		[230161] = "Abstract Nullifier",
		[214803] = 6,
		[51917] = "Ghoul Tormentor",
		[225042] = "Corrupted Feeler",
		[202517] = 1,
		[236305] = "Captain Yathae Moonstrike",
		[106898] = 11,
		[1943] = 4,
		[225043] = "Terrace Grove-Tender",
		[31464] = "Temporus",
		[236306] = "Captain Yathae Moonstrike",
		[222996] = "Shadowfeather",
		[196376] = "Archdruid Glaidalis",
		[156445] = 9,
		[239379] = "Huntress Kasparian",
		[2094] = 4,
		[226069] = "Duskwatch Adjudicator",
		[194329] = 8,
		[214807] = 6,
		[207640] = 11,
		[52174] = 1,
		[226070] = "Screeching Spiderling",
		[210712] = 7,
		[204569] = 3,
		[191259] = 8,
		[225047] = "Terrace Grove-Tender",
		[226071] = "Duskwatch Adjudicator",
		[19434] = 3,
		[206618] = "Chronomatic Anomaly",
		[224024] = 2,
		[210714] = 7,
		[204571] = 3,
		[115092] = 11,
		[239383] = "Glaive Target",
		[248598] = "Fiery Behemoth",
		[226073] = "Screeching Spiderling",
		[50895] = "Forged Iron Dwarf <Sjonnir The Ironshaper> <Sjonnir The Ironshaper>",
		[204572] = 3,
		[214811] = 9,
		[2782] = 11,
		[204574] = "Oakheart",
		[47568] = 6,
		[216861] = 2,
		[242458] = 10,
		[202527] = "Torturer of the Inquisition",
		[41425] = 8,
		[240411] = 4,
		[42705] = "Ingvar the Plunderer",
		[214815] = 7,
		[199457] = "Harbaron",
		[185123] = 12,
		[211744] = "Wrathguard Felblade",
		[245532] = "Diima, Mother of Gloom",
		[214816] = 7,
		[62415] = "Jormungar Behemoth",
		[193315] = 4,
		[218912] = "Priestess Summerpetal",
		[211745] = "[*] Fel Strike",
		[188196] = 7,
		[225056] = 2,
		[193316] = 4,
		[210722] = 11,
		[228128] = 11,
		[49617] = 10,
		[224033] = 2,
		[258845] = 3,
		[210723] = 11,
		[205604] = 12,
		[29930] = "Phantom Guest",
		[217891] = 7,
		[15286] = 5,
		[213796] = "Unknown",
		[199462] = "Earlnoc the Beastbreaker",
		[212773] = "Duskwatch Reinforcement <Duskwatch Sentry> <Duskwatch Sentry>",
		[31850] = 2,
		[207654] = 7,
		[216869] = 2,
		[193320] = 6,
		[16246] = 7,
		[203559] = 1,
		[204583] = 3,
		[115098] = 10,
		[242467] = 5,
		[202536] = 4,
		[17] = 5,
		[36052] = 11,
		[9143] = "Doomforge Craftsman",
		[204585] = 3,
		[197418] = "Illysanna Ravencrest",
		[62417] = "Jormungar Behemoth",
		[234278] = 4,
		[199467] = "Earlnoc the Beastbreaker",
		[202539] = 1,
		[237351] = "[*] Lunar Barrage",
		[41172] = "Alliance Ranger",
		[182062] = 2,
		[91551] = 9,
		[216874] = 10,
		[5308] = 1,
		[236328] = 2,
		[201517] = "Taintheart Stalker",
		[211756] = "Wrathguard Felblade",
		[131894] = 3,
		[198446] = "Fel Bat",
		[256807] = 9,
		[108446] = 9,
		[145205] = 11,
		[211757] = "Eredar Chaosbringer",
		[11895] = "Antu'sul",
		[216877] = "High Botanist Tel'arn",
		[242474] = 5,
		[235307] = 6,
		[32747] = 12,
		[223021] = "[*] Carrion Plague",
		[12471] = "Sandfury Shadowcaster",
		[108447] = 9,
		[213807] = "[*] Burst of Ice",
		[214831] = 6,
		[208688] = "Rothoof Shadowstalker",
		[218927] = "Naturalist Tel'arn <High Botanist Tel'arn> <High Botanist Tel'arn>",
		[204593] = "Hawkmaster Nurong",
		[45525] = 11,
		[208689] = "Dominator Tentacle",
		[77220] = 9,
		[6940] = 2,
		[191284] = "Hymdall",
		[233263] = "Priestess Lunaspyre",
		[250669] = "Argus the Unmaker",
		[210738] = 6,
		[7164] = "Coilfang Warrior",
		[131900] = 3,
		[248622] = 1,
		[193333] = 4,
		[195381] = 10,
		[204596] = 12,
		[198453] = "Unknown <Diabloux-Darkspear>",
		[240432] = 1,
		[235313] = 8,
		[205621] = "Felstalker",
		[206645] = "Trilliax",
		[150332] = "Splinterbone Warrior",
		[208693] = 4,
		[235314] = 8,
		[204598] = 12,
		[63956] = 10,
		[248625] = 1,
		[8092] = 5,
		[8376] = "Antu'sul",
		[212791] = "Watchful Oculus",
		[9080] = "Vicious Thug",
		[114083] = 7,
		[212792] = 8,
		[18670] = "Ironbark Protector",
		[183100] = "Mightstone Breaker",
		[208697] = "Deathglare Tentacle",
		[211769] = "Felswarm Imp",
		[157504] = 7,
		[225080] = 7,
		[226104] = 11,
		[252725] = 4,
		[206651] = "Xavius",
		[256821] = 12,
		[233272] = "Goroth",
		[211771] = "Dreadborne Seer",
		[230201] = "Mistress Sassz'ine",
		[206652] = "[*] Darkened Tainting",
		[243512] = 7,
		[252727] = 4,
		[196414] = 9,
		[205629] = 12,
		[66987] = 9,
		[209725] = "Judgment's Flame",
		[195391] = 8,
		[256824] = 5,
		[121253] = 10,
		[210750] = "[*] Collapsing Rift",
		[252729] = "Constellar Designate",
		[12472] = 8,
		[193345] = 12,
		[58839] = "Stolen Soul",
		[211775] = "Dreadborne Seer",
		[212799] = 8,
		[206656] = "Nightmare Blades",
		[35546] = 4,
		[122278] = 10,
		[212800] = 12,
		[91562] = "Fetid Ghoul",
		[208705] = 12,
		[76204] = 5,
		[211777] = "Eye of the Beast <Dreadborne Seer> <Dreadborne Seer>",
		[188228] = 11,
		[240446] = "[*] Fel Explosion",
		[195396] = "Restless Tides",
		[29166] = 11,
		[34267] = "Ghaz'an",
		[228161] = "Phantom Crew",
		[207684] = 12,
		[233281] = "Goroth",
		[52697] = 6,
		[114089] = 7,
		[171849] = 9,
		[246592] = "[*] Corrupting Void",
		[115625] = "Khillikad <Lastwhisper-Darkspear>",
		[256831] = 2,
		[242497] = 7,
		[194375] = 10,
		[31598] = "Bleeding Hollow Darkcaster",
		[171850] = 12,
		[233283] = "Goroth",
		[113066] = 11,
		[228164] = "Phantom Crew",
		[16496] = "Captured Mercenary Soldier",
		[256833] = 12,
		[233284] = "[*] Umbra Detonation",
		[100780] = 10,
		[34268] = "Ghaz'an",
		[203592] = "Plagued Rat",
		[52698] = 11,
		[203593] = "Mana Wyrm",
		[256835] = 6,
		[234310] = "Kil'jaeden",
		[194379] = 9,
		[211785] = "Felguard Destroyer",
		[118699] = 9,
		[230215] = 6,
		[198475] = "[*] Strike of the Mountain",
		[256836] = 11,
		[193356] = 4,
		[244550] = 8,
		[125355] = 10,
		[42972] = "Dragonflayer Strategist",
		[78257] = 5,
		[224074] = 11,
		[193358] = 4,
		[202573] = 1,
		[236361] = "Fallen Priestess",
		[215884] = 8,
		[209741] = "Image of Advisor Melandrus",
		[11641] = "Sandfury Shadowhunter",
		[38621] = "Proto-Drake Handler",
		[23920] = 1,
		[233291] = 10,
		[209742] = "Image of Advisor Melandrus",
		[194384] = 5,
		[204623] = 3,
		[222029] = 10,
		[198480] = "Unknown <Diabloux-Darkspear>",
		[33758] = 6,
		[160597] = 6,
		[99] = 11,
		[100] = 1,
		[205648] = 7,
		[225102] = 12,
		[160598] = 10,
		[194386] = 3,
		[230222] = 9,
		[160599] = 10,
		[117679] = 11,
		[211793] = 6,
		[198483] = "Spirit Wolf <Grayuni-Galakrond>",
		[232271] = "Mana-Gorged Wyrm",
		[120751] = 11,
		[193364] = "Ymiron, the Fallen King",
		[211794] = 6,
		[237391] = "Hellblaze Temptress",
		[230224] = 9,
		[239439] = "Eonic Defender",
		[208723] = 7,
		[50653] = "Enslaved Proto-Drake",
		[252750] = 11,
		[116] = 8,
		[198485] = "Spirit Wolf <Diabloux-Darkspear>",
		[207700] = 1,
		[208724] = "Arch-Desecrator Malithar",
		[251727] = 4,
		[7645] = "Magister Kalendris",
		[120] = 8,
		[230226] = 6,
		[206677] = "Krosus",
		[83381] = "Quilen <Peybear-Dalaran>",
		[122] = 8,
		[211797] = 12,
		[237394] = "Nal'asha",
		[7965] = "Lord Cobrahn",
		[198487] = 10,
		[249681] = "Commander Atalaa",
		[251729] = 8,
		[237395] = "Nal'asha",
		[230228] = 9,
		[57821] = 4,
		[133] = 8,
		[211799] = "Elisande",
		[136] = 3,
		[197465] = 3,
		[255826] = "Argus the Unmaker",
		[139] = 5,
		[120754] = 11,
		[195418] = 8,
		[229206] = 1,
		[199514] = "Seacursed Mistmender",
		[37856] = "Coilfang Siren",
		[2383] = 9,
		[93622] = 11,
		[2479] = 7,
		[48095] = "[*] Intense Cold",
		[64733] = "[*] Devouring Flame",
		[205659] = 6,
		[57822] = 11,
		[207707] = "Unknown",
		[201564] = "Taintheart Stalker",
		[252758] = "Garothi Demolisher",
		[245591] = 11,
		[205660] = "Torturer of the Inquisition",
		[240472] = 10,
		[172] = 9,
		[80313] = 11,
		[30449] = 8,
		[228186] = "Lord Korithis",
		[245592] = "Shadowguard Conjurer",
		[222043] = "Creature in the Shadows",
		[206685] = "Spitting Cobra <Lustboyy-Shu'halo>",
		[240473] = 10,
		[250712] = "Commander Atalaa",
		[62942] = "Ancient Rune Giant",
		[211805] = 6,
		[196447] = 9,
		[213853] = "Spellblade Aluriel",
		[198495] = "Helya",
		[23922] = 1,
		[208734] = 11,
		[201567] = "Seacursed Slaver",
		[228188] = "Lord Korithis",
		[196448] = 9,
		[49376] = 11,
		[198496] = "Ularogg Cragshaper",
		[208735] = 11,
		[145255] = 2,
		[252762] = 12,
		[222046] = 8,
		[228190] = "Gul'dan",
		[238429] = "Kil'jaeden",
		[3391] = "Deviate Ravager",
		[242525] = 9,
		[238430] = "Kil'jaeden",
		[47585] = 5,
		[207714] = "Star Augur Etraeus",
		[81340] = 6,
		[3583] = "Shifty Thief",
		[213858] = 1,
		[215906] = "Tichondrius",
		[33763] = 11,
		[50401] = 6,
		[227169] = 9,
		[228193] = "Luminore",
		[85948] = 6,
		[222050] = 8,
		[227170] = 1,
		[252767] = 11,
		[230242] = 3,
		[61920] = "Runemaster Molgeim",
		[22899] = "Immol'thar",
		[216932] = 2,
		[217956] = 1,
		[194407] = 3,
		[252768] = 10,
		[245601] = "Shadowguard Conjurer",
		[222052] = 8,
		[216933] = 8,
		[217957] = 1,
		[221029] = "[*] Unstable Decay",
		[57825] = "Eldreth Apparition",
		[83902] = 11,
		[244579] = "Zuraal the Ascended",
		[34788] = "Dreghood Drudge",
		[207720] = "Thing That Should Not Be <Star Augur Etraeus>",
		[241509] = "Razorjaw Waverunner",
		[202602] = 1,
		[244582] = "[*] Crashing Comet",
		[221033] = "Gelatinized Decay",
		[49379] = 3,
		[241511] = "[*] Drenched",
		[125883] = 10,
		[42724] = "Dragonflayer Weaponsmith",
		[77761] = 11,
		[213867] = "Spellblade Aluriel",
		[191342] = 3,
		[208748] = "Dread Abomination",
		[242536] = 2,
		[11131] = "Gahz'rilla",
		[204653] = 3,
		[45284] = 7,
		[190319] = 8,
		[37605] = "Aeonus",
		[179057] = 12,
		[77762] = 7,
		[370] = 7,
		[11899] = "Sandfury Witch Doctor",
		[225132] = 6,
		[154485] = 5,
		[49380] = "Trollgore",
		[214894] = 2,
		[225133] = 8,
		[17141] = "Risen Priest",
		[12795] = "Ragereaver Golem",
		[222062] = 4,
		[200561] = "Fenryr",
		[36582] = "Tempest-Forge Destroyer",
		[213872] = 2,
		[144249] = 4,
		[210801] = 7,
		[55012] = 11,
		[77764] = 11,
		[438] = 11,
		[48101] = 11,
		[193396] = 9,
		[150394] = "Blindlight Bilefin",
		[233328] = 10,
		[242543] = 11,
		[210803] = 10,
		[253806] = 2,
		[142204] = 8,
		[242544] = 5,
		[114113] = 11,
		[139133] = 5,
		[15547] = "Riverpaw Poacher",
		[202614] = "Grimhorn the Enslaver",
		[246641] = "Void Tear <Shadowguard Conjurer>",
		[255856] = 8,
		[225140] = 2,
		[209782] = 4,
		[170875] = 6,
		[197496] = 4,
		[199544] = 2,
		[528] = 5,
		[209783] = 4,
		[210807] = 2,
		[238452] = 9,
		[190330] = "Farseer Nobundo",
		[209784] = 4,
		[197498] = 4,
		[37864] = "Bog Overlord",
		[9532] = "Druid of the Fang",
		[243573] = 2,
		[228215] = "Babblet",
		[204666] = "Oakheart",
		[238454] = 9,
		[215929] = "Blightshard Skitter <Rokmora>",
		[192380] = 4,
		[121283] = 10,
		[195452] = 4,
		[73673] = 5,
		[238455] = "Kil'jaeden",
		[255861] = 1,
		[242551] = 11,
		[179071] = 11,
		[102342] = 11,
		[688] = 9,
		[217979] = 9,
		[11196] = 6,
		[213884] = 10,
		[37865] = "Coilfang Oracle",
		[242553] = 10,
		[11836] = "Gahz'rilla",
		[182145] = "Impling Pillager",
		[150405] = "Twilight Storm Mender",
		[39913] = 5,
		[160644] = 5,
		[194432] = 8,
		[768] = 11,
		[106951] = 11,
		[199552] = 12,
		[34026] = 3,
		[228221] = "Babblet",
		[17399] = "Balnazzar",
		[222078] = "Felweaver Pharamere",
		[207744] = 12,
		[242556] = 10,
		[252795] = "[*] Decimation",
		[53480] = "Chimaera <Brownfingers-Stormrage>",
		[242557] = 10,
		[210817] = 8,
		[85451] = 11,
		[245629] = "Noura, Mother of Flames",
		[239486] = "Volatile Corruption",
		[224128] = 10,
		[96714] = 8,
		[219009] = "[*] Grace of Nature",
		[195460] = "Night Watch Mariner",
		[256893] = 2,
		[208771] = 5,
		[209795] = 12,
		[42730] = "Ingvar the Plunderer",
		[197509] = "Bloodworm <Octavïa-Elune>",
		[255870] = 8,
		[208772] = 5,
		[217987] = "Lurking Terror <Xavius>",
		[15228] = "Murkblood Oracle",
		[221059] = "Gelatinized Decay",
		[215940] = 2,
		[980] = 9,
		[93644] = 9,
		[78286] = 5,
		[256896] = 2,
		[167819] = "Gul'dan",
		[226180] = "Primal Storm Elemental <Conectado-Ragnaros>",
		[252801] = 7,
		[245634] = "[*] Whirling Saber",
		[222085] = "Nightmare Amalgamation",
		[231300] = "Tower Concubine",
		[215942] = 9,
		[217990] = "Lurking Terror <Xavius>",
		[205704] = 9,
		[239492] = 9,
		[194442] = "Waterlogged Soul Guard",
		[196490] = 5,
		[1160] = 1,
		[194443] = "Waterlogged Soul Guard",
		[228231] = 2,
		[94158] = 3,
		[55530] = "Drakkari Rhino",
		[231303] = "Tower Concubine",
		[48107] = 8,
		[202635] = "Grimhorn the Enslaver",
		[204683] = "Dark Minion <Jakka-Blackhand>",
		[205707] = "[*] Temporal Orb",
		[5215] = 11,
		[50155] = "Keristrasza",
		[205708] = 8,
		[78801] = "Hydromancer Velratha",
		[200589] = "Festerhide Grizzly",
		[30455] = 8,
		[245640] = 4,
		[91088] = "Corpse Eater",
		[241545] = 10,
		[234378] = "Ravenous Felhunter",
		[1464] = 1,
		[102351] = 11,
		[55531] = 8,
		[78802] = "Hydromancer Velratha",
		[248713] = "Tormented Soul",
		[48108] = 8,
		[234379] = "Ravenous Felhunter",
		[80850] = "Thuzadin Necromancer",
		[244618] = "Dark Aberration",
		[196496] = "Fenryr",
		[208783] = 6,
		[242571] = 9,
		[17145] = "Risen Battle Mage",
		[195473] = "Gritslime Snail",
		[196497] = "Fenryr",
		[197521] = "Illysanna Ravencrest",
		[239500] = "Instructor Tarahna",
		[43757] = "Dragonflayer Forge Master",
		[74196] = 6,
		[1680] = 1,
		[240525] = 4,
		[38126] = 11,
		[210833] = 8,
		[228239] = "Shrieking Terror",
		[55276] = "Gal'darah",
		[19577] = 3,
		[190356] = 8,
		[191380] = 4,
		[7039] = 1,
		[218001] = 2,
		[1776] = 4,
		[236431] = 9,
		[73685] = 7,
		[172951] = 5,
		[190357] = 8,
		[250766] = 6,
		[202644] = 12,
		[236432] = "Maiden of Vigilance",
		[245647] = "Shadowguard Trickster",
		[59628] = 4,
		[35311] = "Gatewatcher Gyro-Kill",
		[226194] = "Xavius",
		[186263] = 5,
		[122832] = "The Unforgiven",
		[248720] = "Zorathides",
		[62444] = "Captured Mercenary Captain",
		[210837] = 11,
		[245649] = "Shadowguard Trickster",
		[78294] = 4,
		[231315] = "[*] Flattering Compulsion",
		[2008] = 7,
		[129488] = 11,
		[186265] = 3,
		[48878] = "King Dred",
		[245650] = "Shadowguard Trickster",
		[172955] = 5,
		[123857] = 11,
		[2096] = 5,
		[42223] = 9,
		[245651] = "Shadowguard Trickster",
		[206744] = "Gul'dan",
		[222103] = "Nightmare Amalgamation",
		[182172] = "Felflame Trickster",
		[246677] = "Shadowguard Subjugator",
		[231319] = 10,
		[185245] = 12,
		[186269] = "Blightshard Shaper",
		[147362] = 3,
		[207771] = 12,
		[201628] = 12,
		[186270] = 3,
		[35057] = "Mechanar Tinkerer",
		[199581] = 9,
		[209820] = 8,
		[52719] = "Azure Raider",
		[244632] = 8,
		[245656] = "Shadowguard Trickster",
		[205725] = 6,
		[206749] = "Trilliax",
		[224155] = 10,
		[193439] = 9,
		[236442] = "Captain Yathae Moonstrike",
		[102359] = 11,
		[206750] = "[*] Breaching Flames",
		[233371] = "Razorjaw Wavemender",
		[242586] = 11,
		[195488] = 10,
		[196512] = "Fenryr",
		[150438] = "Razorshell Snapjaw",
		[116694] = 10,
		[226205] = "[*] Slime Pool",
		[34290] = "Ghaz'an",
		[12734] = "Commander Malor",
		[253850] = "Twilight-Harbinger Tharuul",
		[222110] = "Shadow Pounder",
		[240540] = "Razorjaw Swiftfin",
		[208800] = 6,
		[226206] = "Warp Shade",
		[194466] = 8,
		[252827] = 10,
		[45297] = 7,
		[207777] = 4,
		[216992] = 10,
		[201634] = 6,
		[202658] = "Malignant Defiler",
		[252828] = 10,
		[196515] = "Binder Ashioi",
		[207778] = 7,
		[241566] = "Soul Queen Dejahna",
		[201635] = 3,
		[210850] = "[*] Twisting Shadows",
		[211874] = "Priestess of Misery",
		[196516] = "Ritualist Lesha",
		[3600] = "Earthbind Totem <Wazerzzul-Dalaran>",
		[150442] = "Razorshell Snapjaw",
		[33779] = 1,
		[201636] = 8,
		[227233] = "Helya",
		[211875] = "Priestess of Misery",
		[196517] = "[*] Swirling Scythe",
		[35059] = "Talon King Ikiss",
		[223138] = 3,
		[207780] = 1,
		[216995] = 10,
		[201637] = 12,
		[202661] = "Fel Scorcher",
		[236449] = "Soul Queen Dejahna",
		[238497] = 10,
		[206757] = "D'zorykx the Trapper",
		[22907] = "Swamplord Musel'ek",
		[201638] = 6,
		[47346] = "Novos the Summoner",
		[201639] = 3,
		[210854] = 7,
		[244642] = 8,
		[221093] = "Unknown",
		[238499] = 7,
		[57841] = 4,
		[191401] = "Valarjar Marksman",
		[192425] = 4,
		[201640] = 2,
		[238500] = 7,
		[25851] = 10,
		[224166] = 6,
		[201641] = 12,
		[202665] = 4,
		[61425] = 6,
		[246692] = "Garothi Demolisher",
		[239525] = "Dreadwing",
		[217000] = 10,
		[234406] = "Eye of Torment <Grand Inquisitor>",
		[244645] = 8,
		[238502] = "Kil'jaeden",
		[39412] = "Steam Surger",
		[219049] = "Naturalist Tel'arn <High Botanist Tel'arn> <High Botanist Tel'arn>",
		[57330] = 6,
		[57842] = 4,
		[200620] = "Frenzied Nightclaw",
		[242599] = 2,
		[202668] = 4,
		[228265] = "Gul'dan",
		[245671] = "Torment of Khaz'goroth",
		[51699] = 4,
		[224170] = 3,
		[176048] = "Hatecoil Warrior",
		[234409] = "Grand Inquisitor",
		[251815] = "Edge of Obliteration <Argus the Unmaker>",
		[197550] = "King Deepbeard",
		[231338] = 5,
		[116189] = 10,
		[193455] = 3,
		[228267] = "Gul'dan",
		[246697] = "Shadowguard Subjugator",
		[224172] = 5,
		[6016] = "Nerub'enkan",
		[193456] = 12,
		[210862] = 6,
		[245674] = "Torment of Khaz'goroth",
		[199600] = 4,
		[217006] = 10,
		[50420] = "Lava Guard Gordoth",
		[194481] = 1,
		[35062] = "Mechanar Tinkerer",
		[52212] = 6,
		[66021] = "Ebon Champion",
		[223151] = 8,
		[18813] = "Patchwork Horror",
		[209841] = "Judgment's Flame",
		[109536] = 5,
		[244653] = "Zuraal the Ascended",
		[199603] = 4,
		[242606] = 8,
		[214962] = 1,
		[191413] = "Nuthead <Gunforhire-Kel'Thuzad>",
		[109537] = 5,
		[236464] = "[*] Soulbind",
		[217011] = "Angry Crowd",
		[210868] = "Nightborne Spellsword",
		[61684] = "Core Hound <Shaggybeard-Dalaran>",
		[7744] = 9,
		[200630] = "Mindshattered Screecher",
		[242609] = 1,
		[38391] = "Searing Destroyer",
		[252848] = 5,
		[102883] = 5,
		[63988] = 8,
		[208822] = 9,
		[209846] = "Scion of Ice",
		[228276] = "Phantom Guardsman",
		[246706] = "[*] Demolish",
		[224181] = "Astral Defender",
		[116706] = 10,
		[202680] = "Serpentrix",
		[228277] = "Undying Servant",
		[17534] = 4,
		[242612] = 2,
		[227254] = "The Curator",
		[61685] = "Quilen <Shaggybeard-Dalaran>",
		[226231] = "Astral Farseer",
		[251828] = 1,
		[126434] = 12,
		[255924] = 7,
		[228280] = "Spectral Retainer",
		[49143] = 6,
		[57846] = "Dragonflayer Ironhelm",
		[209851] = "Scion of Ice",
		[210875] = "Stormforged Sentinel",
		[244663] = 8,
		[59638] = "Dudette-Baelgun <Dudette-Baelgun>",
		[214971] = 6,
		[224186] = 11,
		[200637] = "Dargrul",
		[209852] = "Scion of Magic",
		[204733] = "Volatile Scorpid",
		[214972] = 6,
		[224187] = 8,
		[217020] = 2,
		[209853] = "Scion of Magic",
		[235450] = 8,
		[126436] = 10,
		[253880] = "Twilight-Harbinger Tharuul",
		[11968] = "Eldreth Darter",
		[104423] = 4,
		[242618] = 2,
		[12160] = "Time-Lost Scryer",
		[197568] = 7,
		[223165] = "Fel Annihilator",
		[150470] = "Twilight Shadow",
		[12544] = "Risen Sorcerer",
		[242619] = 2,
		[17151] = "Risen Inquisitor",
		[17279] = "Willey Hopebreaker",
		[196545] = 6,
		[78315] = 5,
		[78827] = "Gordok Enforcer",
		[257978] = "Kin'garoth",
		[209856] = 8,
		[243644] = 8,
		[196546] = 9,
		[115175] = 10,
		[200642] = "Dreadsoul Ruiner",
		[242621] = 2,
		[228287] = 10,
		[198595] = "Valarjar Thundercaller",
		[241598] = "Felguard Destroyer",
		[242622] = 5,
		[228288] = 2,
		[115176] = 10,
		[20735] = "Illyanna Ravenoak",
		[242623] = 5,
		[178119] = 11,
		[236480] = "[*] Glaive Storm",
		[204740] = "Cat <Shootenu-Thaurissan>",
		[78317] = 5,
		[206788] = "Trilliax",
		[224194] = "Astral Defender",
		[72174] = 11,
		[15232] = "Hate'rel",
		[30846] = "Shadowmoon Technician",
		[214980] = 4,
		[22911] = "Ferra",
		[31230] = 4,
		[201670] = 2,
		[15744] = "Searing Destroyer",
		[253888] = "Twilight-Harbinger Tharuul",
		[205766] = 8,
		[157644] = 8,
		[16128] = "Immol'thar",
		[201671] = 11,
		[164812] = 11,
		[191433] = 3,
		[209863] = "Nexus-Prince Bilaal",
		[203720] = 12,
		[204744] = "[*] Toxic Chitin",
		[206792] = "Trilliax",
		[240580] = "Tidescale Combatant",
		[208840] = 10,
		[226246] = "Withered Fiend",
		[227270] = "Volatile Energy <The Curator>",
		[253891] = "Twilight-Harbinger Tharuul",
		[190411] = 1,
		[100333] = 2,
		[242629] = 1,
		[171982] = 9,
		[238534] = 2,
		[87023] = 8,
		[72177] = 11,
		[227272] = 3,
		[205771] = "Lurking Terror <Xavius> <Xavius>",
		[5185] = 11,
		[5217] = 11,
		[67570] = 9,
		[194509] = 5,
		[253894] = 5,
		[230345] = "[*] Crashing Comet",
		[87024] = 8,
		[51963] = "Ebon Gargoyle <Heoki-Dalaran>",
		[193486] = 6,
		[238537] = 8,
		[214988] = "Spirit of Vengeance",
		[200654] = 2,
		[46588] = "[*] Ice Spear",
		[211917] = "Priestess of Misery",
		[253896] = 8,
		[246729] = 7,
		[206798] = "[*] Toxic Slice",
		[150485] = "Plague-Rotted Webslinger",
		[12097] = "Nightmare Wanderer",
		[202703] = "Soulflayer of the Inquisiton",
		[114158] = 2,
		[131052] = 11,
		[231372] = 2,
		[224205] = "Astral Defender",
		[233420] = "Atrigan",
		[202704] = "Soulflayer of the Inquisiton",
		[188370] = 2,
		[111599] = "Scholomance Acolyte",
		[200657] = 2,
		[201681] = "Jailhound",
		[196562] = "Ivanyr",
		[200658] = "Dreadsoul Ruiner",
		[234446] = "Crushfist",
		[227279] = "The Curator",
		[236494] = "Fallen Avatar",
		[196563] = "Warlord Parjesh",
		[13953] = "Fineous Darkvire",
		[14145] = "Gordok Mage-Lord",
		[153561] = 8,
		[238543] = "Helblaze Soulmender",
		[257997] = "Kin'garoth",
		[68086] = 5,
		[253902] = 12,
		[198613] = 1,
		[240592] = "Tidescale Combatant",
		[35839] = "Auchenai Necromancer",
		[252879] = 12,
		[7713] = "Undead Postman",
		[233426] = "Atrigan",
		[153564] = 8,
		[196567] = "Fenryr",
		[238546] = 10,
		[240594] = "Fallen Avatar",
		[217045] = 12,
		[242642] = 1,
		[48894] = "Drakkari Shaman",
		[8258] = "Fineous Darkvire",
		[214998] = 11,
		[250834] = 7,
		[227285] = "The Curator",
		[93685] = "Commander Springvale",
		[229333] = 2,
		[222166] = 12,
		[51966] = 11,
		[233429] = "Harjatan",
		[52734] = 5,
		[253907] = "Twilight-Harbinger Tharuul",
		[230358] = "Mistress Sassz'ine",
		[233430] = 6,
		[234454] = "Crushfist",
		[222168] = 6,
		[48895] = "Drakkari Shaman",
		[240599] = "Tidescale Seacaller",
		[33793] = "Nazan",
		[2641] = 3,
		[93687] = "Commander Springvale",
		[241624] = "Maiden of Vigilance",
		[193502] = "Glayvianna Soulrender",
		[44544] = 8,
		[138213] = 4,
		[230362] = "Electrifying Jellyfish",
		[37633] = "Abyssal Flamebringer",
		[233434] = "[*] Necrotic Venom",
		[204766] = "Crystalline Scorpid",
		[213981] = 4,
		[32001] = 11,
		[32129] = "Sethekk Oracle",
		[201695] = 4,
		[202719] = 12,
		[24450] = "Cat <Kumasta-EchoIsles>",
		[245722] = "Shadowguard Champion",
		[223197] = "Rothos",
		[232412] = 9,
		[208863] = "Elisande",
		[226269] = "Forgotten Spirit",
		[213983] = 4,
		[240604] = "[*] Embrace of the Tides",
		[217055] = 8,
		[72188] = 11,
		[115191] = 4,
		[231390] = 3,
		[150504] = "Twilight Aquamancer",
		[208865] = "Elisande",
		[3409] = 4,
		[68605] = "Salvaged Demolisher <Emptyrivers>",
		[197603] = 4,
		[95738] = 1,
		[56576] = 9,
		[113656] = 10,
		[228320] = "Arcane Warden",
		[155625] = 11,
		[115192] = 4,
		[223201] = "Rothos",
		[199652] = "King Haldor",
		[33795] = 11,
		[93691] = "[*] Desecration",
		[245727] = "Famished Broken",
		[14914] = 5,
		[206820] = "Trilliax",
		[207844] = 1,
		[233441] = "Atrigan",
		[72190] = 11,
		[15234] = "Coilfang Siren",
		[162794] = 12,
		[204773] = "Aspersius",
		[66047] = "Ebon Champion",
		[124408] = 3,
		[68607] = "Apothecary Hummel",
		[195559] = 5,
		[221156] = "Chaotoid",
		[150509] = "Aqua Guardian",
		[241634] = "Maiden of Vigilance",
		[227300] = "[*] Arcanetic Eruption",
		[236515] = "Fallen Priestess",
		[240611] = "Tidescale Seacaller",
		[208871] = 9,
		[17156] = "Ferra",
		[236516] = "[*] Twilight Volley",
		[25603] = "Ethereal Sorcerer",
		[51714] = 6,
		[241636] = "Maiden of Vigilance",
		[196586] = 9,
		[199658] = 1,
		[62465] = "[*] Runic Smash",
		[38660] = "Coilfang Siren",
		[221160] = "Pulsauron",
		[238566] = "Ghostly Philanthropist",
		[198635] = "Kur'talos Ravencrest",
		[150513] = "Death's Head Arachnomancer",
		[177134] = 8,
		[236519] = "[*] Moon Burn",
		[20484] = 11,
		[258021] = "[*] Purging Protocol",
		[234472] = "Crushfist",
		[84992] = 11,
		[179183] = 5,
		[245735] = "Famished Broken",
		[190446] = 8,
		[224234] = "Celestial Acolyte",
		[200685] = 12,
		[234473] = "Crushfist",
		[210924] = 10,
		[245736] = "Shadow Stalker",
		[207853] = "[*] Blackened Tainting",
		[200686] = "Dreadsoul Poisoner",
		[238570] = "Engine of Souls",
		[11971] = 1,
		[12099] = "Nightmare Scalebane",
		[170995] = "Kethuurath <Philet-Garona>",
		[217070] = 12,
		[12611] = "Eldreth Apparition",
		[12675] = "Seeth'rel",
		[93697] = "Lord Walden",
		[212975] = 6,
		[51460] = 6,
		[17669] = 7,
		[51972] = "Crystalline Tender",
		[202737] = 11,
		[220143] = 6,
		[65541] = "Brienna Nightfell",
		[115199] = "Durnholde Rifleman",
		[248812] = "Maiden of Vigilance",
		[46085] = 11,
		[226287] = "Vileshard Chunk",
		[228335] = "Unknown",
		[188404] = "Storm Drake",
		[214001] = "Risen Lancer",
		[199667] = 1,
		[7042] = 1,
		[7074] = "Wailing Guardsman",
		[137211] = 4,
		[252909] = 5,
		[245742] = "Shadow Stalker",
		[214002] = "Risen Lancer",
		[255981] = 5,
		[199668] = 10,
		[124927] = 11,
		[125439] = 5,
		[210931] = "Eye of Il'gynoth",
		[236528] = "Fallen Avatar",
		[78341] = 5,
		[240624] = 10,
		[129023] = 11,
		[193526] = 3,
		[153595] = 8,
		[220147] = "[*] Arrow Trap",
		[123904] = 10,
		[22917] = "Magister Kalendris",
		[15619] = "Doomforge Craftsman",
		[218100] = 6,
		[153596] = 8,
		[63236] = "Razorscale",
		[221172] = "Fulminant",
		[206838] = 10,
		[192504] = "Tirathon Saltheril",
		[211958] = "Wyrmtongue Scavenger",
		[221173] = "Fulminant",
		[222197] = 8,
		[50182] = "Mage Hunter Ascendant",
		[211959] = "Wyrmtongue Scavenger",
		[197625] = 11,
		[247795] = "L'ura",
		[224246] = "Celestial Acolyte",
		[208888] = 3,
		[193530] = 3,
		[245748] = "Void Discharge",
		[164862] = 11,
		[157695] = 9,
		[199674] = "King Bjorn",
		[178173] = 10,
		[237558] = "Felborne Botanist",
		[119299] = "Adarogg",
		[95750] = 9,
		[167935] = "Gul'dan",
		[226296] = "Vileshard Hulk",
		[203771] = "Defiled Druid Spirit <Ysondre>",
		[238583] = "Felblight Stalker",
		[200700] = "Dargrul",
		[126467] = 11,
		[253942] = "Voidmaw",
		[222202] = 3,
		[30213] = "Shaaghun <Mcwhip-Runetotem>",
		[193534] = 3,
		[212988] = 12,
		[30853] = "Shadowmoon Summoner",
		[78346] = 5,
		[11972] = "Guard Fengus",
		[159748] = 5,
		["DEBUFF"] = 12,
		[32645] = 4,
		[12292] = 1,
		[90633] = 11,
		[224253] = 1,
		[186370] = 11,
		[187394] = "Unstable Tear <Lightninggh-Shu'halo>",
		[246779] = "Kin'garoth",
		[193538] = 4,
		[236541] = "[*] Twilight Glaive",
		[237565] = "Felborne Botanist",
		[13444] = "Skeletal Highborne",
		[54536] = 11,
		[202754] = 4,
		[236542] = "Unknown",
		[253948] = "[*] Dark Slobber",
		[78348] = 5,
		[191492] = 6,
		[226304] = "Vileshard Hulk",
		[236543] = "Domatrax",
		[229376] = 8,
		[222209] = 1,
		[208899] = 7,
		[29574] = "Phantom Hound <Phantom Guardsman> <Phantom Guardsman>",
		[229377] = 5,
		[78349] = 5,
		[240640] = 10,
		[234497] = "Tricky Hellion",
		[228354] = 8,
		[15620] = "Doomforge Dragoon",
		[203782] = 12,
		[212997] = "Tichondrius",
		[242690] = 9,
		[16324] = "Ravaged Cadaver",
		[253953] = "Voidmaw",
		[198664] = 10,
		[143375] = 6,
		[211975] = "Wyrmtongue Scavenger",
		[215047] = 6,
		[150543] = "Twilight Shadowmage",
		[209928] = 8,
		[202761] = 4,
		[228358] = 8,
		[237573] = "Helblaze Felbringer",
		[37132] = "Azure Magus",
		[207881] = "Talixae Flamewreath",
		[152592] = "[*] Executioner's Strike",
		[252932] = 10,
		[27655] = 1,
		[228360] = 5,
		[185358] = 3,
		[1329] = 4,
		[228361] = 5,
		[229385] = 10,
		[132117] = 5,
		[59914] = 11,
		[224266] = 2,
		[249863] = "Unknown",
		[72210] = 11,
		[229386] = 3,
		[132118] = 5,
		[198670] = 3,
		[22920] = "Prince Tortheldrin",
		[208909] = 1,
		[1449] = 8,
		[227339] = "Midnight",
		[31623] = "Swamplord Musel'ek",
		[188432] = 5,
		[132119] = 5,
		[231435] = 2,
		[150549] = "Voidwalker Minion",
		[202767] = 11,
		[203791] = 2,
		[229388] = 1,
		[150550] = "Death's Head Shadowmender",
		[227341] = "Galindre",
		[12741] = "Postmaster Malown",
		[151575] = "Mordresh Fire Eye",
		[226318] = 4,
		[186387] = 3,
		[13445] = "Gordok Hound",
		[124430] = 5,
		[208913] = 3,
		[202770] = 11,
		[203794] = 12,
		[102417] = 11,
		[238606] = "Arcane Warden",
		[191508] = "Valarjar Aspirant",
		[28168] = "Raging Construct",
		[185365] = 3,
		[202771] = 11,
		[244750] = "Viceroy Nezhar",
		[237583] = "[*] Burning Celerity",
		[176151] = 5,
		[1833] = 4,
		[153626] = 8,
		[244751] = "Viceroy Nezhar",
		[213011] = 12,
		[51725] = "Arcane Aberration",
		[88084] = "Jeanette-KhazModan <Jeanette-KhazModan>",
		[250895] = 8,
		[203797] = 2,
		[15493] = "Fineous Darkvire",
		[15621] = "Warbringer Construct",
		[242705] = 4,
		[15749] = "Guard Mol'dar",
		[208918] = 9,
		[129552] = 5,
		[236563] = "Unknown",
		[2050] = 5,
		[239635] = "Ixallon the Soulbreaker",
		[2098] = 4,
		[17162] = "Risen Conjuror",
		[236564] = "Unknown",
		[247827] = 5,
		[188443] = 7,
		[201754] = "Beast <Hyliia-Kargath>",
		[236566] = "Imp",
		[9734] = "Murta Grimgut",
		[9798] = "Irradiated Pillager",
		[194588] = "Shadow Hunter",
		[236567] = "Unknown",
		[189469] = "Spirit of Vengeance",
		[233496] = 9,
		[34321] = 9,
		[236568] = "Unknown",
		[86040] = 9,
		[246807] = 2,
		[208924] = "Trilliax",
		[242712] = 3,
		[2818] = 4,
		[233498] = 9,
		[46352] = 11,
		[47632] = 6,
		[11974] = "Vile'rel",
		[233499] = 9,
		[209950] = 7,
		[186401] = 8,
		[236571] = "Corrupted Blade",
		[12294] = 1,
		[12550] = "Arcane Feedback",
		[34322] = "Nexus Terror",
		[203808] = 1,
		[77851] = 5,
		[194594] = 3,
		[13446] = "Ravaged Cadaver",
		[225311] = 2,
		[153640] = 8,
		[157736] = 9,
		[191524] = "Blade Dancer Illianna",
		[72221] = 11,
		[235551] = 12,
		[237599] = "Helblaze Felbringer",
		[206883] = "D'zorykx the Trapper",
		[207907] = "Talixae Flamewreath",
		[201764] = 7,
		[210979] = 5,
		[203812] = 4,
		[3714] = 6,
		[240672] = 10,
		[210980] = 5,
		[214052] = 7,
		[191527] = "Blade Dancer Illianna",
		[218148] = "High Botanist Tel'arn",
		[227363] = "Midnight",
		[118297] = "Primal Fire Elemental <Futama-Drakkari>",
		[188456] = 10,
		[205862] = "Krosus",
		[208934] = 10,
		[205863] = "Krosus",
		[91677] = "Pustulant Monstrosity",
		[184362] = 1,
		[227365] = "Midnight",
		[231461] = "Pyrestar Demolisher",
		[199721] = 6,
		[210984] = "Nightmare Horror",
		[179244] = 5,
		[184364] = 1,
		[251940] = 10,
		[195627] = 4,
		[148529] = 7,
		[241702] = "Shadowsoul",
		[251941] = 10,
		[203819] = 12,
		[204843] = 12,
		[206891] = 2,
		[203820] = 11,
		[229417] = 12,
		[51475] = "Dark Rune Elementalist",
		[51731] = 5,
		[184367] = 1,
		[218155] = "[*] Solar Collapse",
		[195630] = 10,
		[22924] = "Tendris Warpwood",
		[208941] = 11,
		[226347] = "Stoneclaw Hunter",
		[205870] = "Lethon",
		[47636] = 5,
		[183345] = "Rakeeshi Honor Guard",
		[12039] = "Shadowpriest Sezz'ziz",
		[12167] = "Lord Serpentis",
		[32651] = "Sethekk Ravenguard",
		[245802] = "Darkfang",
		[231468] = "Spore Bomb",
		[176179] = 8,
		[185394] = 8,
		[251946] = 12,
		[196657] = "Shadowy Tear <Lightninggh-Shu'halo>",
		[206896] = "D'zorykx the Trapper",
		[191538] = "Immoliant Fury",
		[208944] = "Elisande",
		[194610] = "Helarjar Mistcaller",
		[236589] = "[*] Chilling Aura",
		[6660] = "Darnassian Scout",
		[190515] = 3,
		[208945] = 11,
		[169014] = 5,
		[194611] = "Unknown",
		[228399] = 2,
		[222256] = 10,
		[191540] = "Immoliant Fury",
		[64531] = "VX-001",
		[169015] = 5,
		[115232] = "Thulnuz <Locrécrio-Gallywix>",
		[7268] = 8,
		[116768] = 10,
		[209971] = "Elisande",
		[228401] = 2,
		[204852] = "Nightmare Dweller",
		[246831] = 8,
		[70694] = 5,
		[235569] = "Maiden of Vigilance",
		[220211] = 6,
		[148540] = 1,
		[15495] = "Doomforge Dragoon",
		[240689] = 8,
		[200758] = 4,
		[209973] = "Elisande",
		[194615] = "Seacursed Swiftblade",
		[246833] = "Kin'garoth",
		[239666] = "Wailing Soul",
		[64532] = "VX-001",
		[8100] = 11,
		[203831] = 8,
		[8264] = "Sandfury Witch Doctor",
		[157757] = 9,
		[191545] = 12,
		[50198] = "Mage Hunter Initiate",
		[17038] = 11,
		[227381] = "The Monkey King",
		[203832] = 8,
		[239668] = "Wailing Soul",
		[240692] = 8,
		[235573] = "Maiden of Vigilance",
		[233526] = "Harjatan",
		[38168] = "Auchenai Monk",
		[203834] = 8,
		[198715] = "Val'kyr Battlemaiden <Juggêrnaut-Ragnaros>",
		[191548] = 12,
		[65301] = "Sara",
		[204859] = "Ursoc",
		[115236] = "Korrothion <Raff-Detheroc>",
		[191549] = 12,
		[193597] = "Lady Hatecoil",
		[195645] = 3,
		[198717] = "Bellowing Idol",
		[191550] = 12,
		[201789] = 12,
		[246840] = "[*] Ruiner",
		[191551] = 12,
		[233530] = "Harjatan",
		[87081] = "Spitebone Guardian",
		[79402] = 11,
		[12040] = "High Interrogator Gerstahn",
		[226364] = 4,
		[212030] = "General Xakal",
		[132168] = 1,
		[115750] = 2,
		[191553] = 12,
		[200768] = "Crazed Razorbeak",
		[211007] = "Nightborne Reclaimer",
		[42777] = 9,
		[132169] = 1,
		[191554] = 12,
		[219199] = 3,
		[196674] = 9,
		[238653] = "Dul'zak",
		[13704] = "Balnazzar",
		[237630] = "Captain Yathae Moonstrike",
		[102953] = 5,
		[198723] = "Rotheart Dryad",
		[207938] = "Inquisitor Vethriz",
		[48153] = 5,
		[115240] = "Korrothion <Raff-Detheroc>",
		[224321] = "Arc Well <Celestial Acolyte> <Celestial Acolyte>",
		[208963] = 7,
		[155722] = 11,
		[238656] = "[*] Shadow Wave",
		[215107] = 3,
		[120360] = 3,
		[186439] = 5,
		[212036] = 5,
		[237633] = "[*] Spectral Glaive",
		[15496] = "Gordok Reaver",
		[224323] = "Arc Well <Celestial Acolyte>",
		[193607] = "Glayvianna Soulrender",
		[202822] = 4,
		[187464] = 5,
		[70191] = "Frenzied Abomination",
		[120361] = 3,
		[193608] = "Glayvianna Soulrender",
		[202823] = 4,
		[32654] = "Sethekk Talon Lord",
		[106539] = 5,
		[8265] = "Lava Spout Totem <Sandfury Witch Doctor>",
		[216134] = "Infinite Drakeling",
		[193609] = "Glayvianna Soulrender",
		[202824] = 4,
		[196681] = 12,
		[246851] = 3,
		[215111] = "Unknown <Mcwhip-Runetotem>",
		[216135] = 5,
		[246852] = 3,
		[206921] = "Star Augur Etraeus",
		[199754] = 4,
		[62489] = "Salvaged Demolisher <Emptyrivers>",
		[193611] = "Lady Hatecoil",
		[246853] = 3,
		[191564] = 5,
		[188493] = "Naraxas",
		[5221] = 11,
		[185422] = 4,
		[194637] = 8,
		[29583] = "Phantom Guest",
		[188494] = "[*] Rancid Maw",
		[148563] = 1,
		[223306] = 2,
		[120876] = 11,
		[162898] = 11,
		[172113] = 5,
		[30991] = "Laughing Skull Rogue",
		[62490] = "Salvaged Demolisher <Emptyrivers>",
		[46620] = 11,
		[203854] = 1,
		[196687] = "T'uure <Elyseia-Proudmoore>",
		[56091] = 4,
		[88625] = 5,
		[130092] = 5,
		[227405] = "Elfyra",
		[203856] = 1,
		[204880] = 7,
		[6533] = "Coilfang Engineer",
		[235597] = "Fallen Avatar",
		[188499] = 12,
		[74292] = 5,
		[207953] = 9,
		[6789] = 9,
		[244813] = 8,
		[13897] = 2,
		[206930] = 6,
		[56092] = 4,
		[235599] = 6,
		[244814] = 4,
		[204883] = 5,
		[206931] = 6,
		[226385] = "Tarspitter Lurker",
		[194645] = 8,
		[212051] = 10,
		[229457] = 2,
		[51485] = 7,
		[150619] = "Voidwalker Minion",
		[225362] = "[*] Slam",
		[226386] = "Felguard",
		[15241] = "Risen Conjuror",
		[15305] = "Golem Lord Argelmach",
		[238673] = "Fulminating Lasher",
		[15497] = "Sorcerous Skeleton",
		[208981] = 7,
		[46366] = 11,
		[238674] = "Fulminating Lasher",
		[223316] = 2,
		[226388] = "[*] Rancid Ooze",
		[188505] = 3,
		[215126] = 1,
		[248914] = 4,
		[233556] = "Containment Pylon",
		[226389] = "Felguard",
		[227413] = 5,
		[221270] = "Searing Infernal",
		[246867] = 2,
		[198745] = "Stormforged Sentinel",
		[241748] = "Ban-Lu",
		[202841] = 12,
		[203865] = 4,
		[215128] = "Il'gynoth",
		[37664] = "Coilfang Siren",
		[233558] = 10,
		[227415] = "[*] Intangible Presence",
		[47391] = 5,
		[191580] = 7,
		[241750] = 8,
		[129586] = 5,
		[227416] = "Galindre",
		[228440] = 10,
		[90679] = 1,
		[206939] = "Gul'dan",
		[199772] = "Valarjar Champion",
		[217178] = "First Arcanist Thalyssra",
		[185438] = 4,
		[110645] = 5,
		[35105] = "Coilfang Warrior",
		[206940] = 6,
		[234585] = "Sludgerax",
		[203869] = 4,
		[215132] = 4,
		[240729] = 11,
		[241753] = 2,
		[211037] = "Nightborne Reclaimer",
		[69179] = 1,
		[199775] = "Naraxas",
		[96312] = 2,
		[228444] = 4,
		[49184] = 6,
		[165988] = 5,
		[193633] = "Risen Archer",
		[235612] = 6,
		[35106] = "Coilfang Siren",
		[225374] = "Sidereal Familiar",
		[211040] = 6,
		[228446] = 6,
		[206945] = 6,
		[191587] = 6,
		[192611] = 12,
		[193635] = "Void Tendril <Velyse-Korgath>",
		[202850] = 6,
		[193636] = "Saltsea Droplet",
		[20243] = 1,
		[246878] = "Conversation Controller",
		[198756] = "Chi-Ji <Chubkins>",
		[150634] = "Subjugator Kor'ul",
		[253022] = 8,
		[246879] = "Conversation Controller",
		[170089] = 5,
		[246880] = "Conversation Controller",
		[15498] = "Shadowforge Senator",
		[54049] = "Sloonom <Benjalum-Zul'jin>",
		[200806] = 4,
		[193639] = "Rockback Gnasher",
		[227427] = "Gul'dan",
		[183401] = "Vileshard Crawler",
		[210022] = "Elisande",
		[97340] = 2,
		[244834] = "Kil'jaeden",
		[240739] = 11,
		[192617] = "Wrath of Azshara",
		[193641] = 4,
		[203880] = 10,
		[163949] = 5,
		[51490] = 7,
		[210024] = "Elisande",
		[97341] = 3,
		[203881] = "Advisor Vandros",
		[223335] = 10,
		[37668] = "Ethereal Spellbinder",
		[241765] = "[*] Jade Orb",
		[203882] = "Advisor Vandros",
		[214121] = 5,
		[104509] = 4,
		[194668] = "Harbaron",
		[245862] = 12,
		[41252] = 3,
		[198764] = "Chi-Ji <Chubkins>",
		[207979] = "Jazshariu",
		[192621] = "Ash'Golm",
		[210027] = 5,
		[194669] = 5,
		[207980] = "Baalgar the Watchful",
		[201837] = "Taintheart Summoner",
		[89152] = 11,
		[196718] = 12,
		[198766] = "Chi-Ji <Chubkins>",
		[207981] = "Baalgar the Watchful",
		[211053] = 12,
		[238698] = 6,
		[207982] = 1,
		[201839] = "Taintheart Summoner",
		[231532] = "Pyrestar Demolisher",
		[12491] = "Antu'sul",
		[241771] = "Ban-Lu",
		[228461] = 11,
		[182387] = 7,
		[95809] = 6,
		[225390] = "[*] Stellar Dust",
		[80451] = 11,
		[194674] = "Seacursed Slaver",
		[13323] = "Gordok Mage-Lord",
		[214128] = 12,
		[6726] = "Shadowmoon Technician",
		[191603] = 2,
		[217200] = 3,
		[201842] = "Taintheart Summoner",
		[202866] = 12,
		[77380] = 11,
		[13899] = "Lord Incendius",
		[191604] = 2,
		[241774] = "Phantom Guardsman",
		[242798] = 3,
		[191605] = 2,
		[14795] = 3,
		[237680] = 6,
		[51493] = "Dark Rune Giant",
		[183415] = 2,
		[15243] = "Fireguard Destroyer",
		[236657] = "Archmage Khadgar",
		[206965] = "Star Augur Etraeus",
		[191607] = 2,
		[7814] = "Vilneth <Cravingdead-ArgentDawn>",
		[117313] = 1,
		[194679] = 6,
		[55077] = "Savage Worg",
		[191608] = 2,
		[214134] = 7,
		[206967] = 6,
		[191609] = 2,
		[192633] = "Wrath of Azshara",
		[224374] = "Unknown <Talixae Flamewreath>",
		[217207] = "Core Hound <Shaggybeard-Dalaran>",
		[211064] = 8,
		[246900] = "Void Discharge",
		[585] = 5,
		[224375] = "Infernal Imp <Talixae Flamewreath> <Talixae Flamewreath>",
		[9484] = 5,
		[210041] = 12,
		[227447] = "Elfyra",
		[77384] = 11,
		[199803] = 3,
		[151681] = "Ghamoo-Ra",
		[210042] = 12,
		[48679] = 5,
		[155777] = 11,
		[173183] = 7,
		[199804] = 4,
		[33833] = "Dread Scryer",
		[117828] = 9,
		[229497] = 3,
		[246903] = "Dark Keeper",
		[239736] = 5,
		[21910] = "Phantom Guest",
		[200829] = 5,
		[697] = 9,
		[236665] = 11,
		[150660] = "Deep Terror",
		[92232] = 3,
		[260215] = "Creeping Void",
		[171138] = "Akkdarr <Feelinya-Greymane>",
		[63526] = "Steelbreaker",
		[215165] = 9,
		[207998] = 7,
		[225404] = "Trained Shadescale",
		[202879] = 11,
		[222333] = 6,
		[49704] = "Darkweb Recluse",
		[12492] = "Jammal'an the Prophet",
		[50216] = 11,
		[68172] = 5,
		[211071] = 7,
		[171140] = 9,
		[51496] = "Dark Rune Shaper",
		[191618] = 11,
		[241788] = "Spectral Attendant",
		[234621] = "[*] Devouring Maw",
		[260218] = "Aruun the Darkener",
		[228478] = 12,
		[239741] = "Ghostly Acolyte",
		[191619] = 11,
		[853] = 2,
		[196739] = 10,
		[222336] = 6,
		[239742] = "[*] Dark Mark",
		[240766] = "Guardian Sentry",
		[241790] = "Ban-Lu",
		[193668] = "God-King Skovald",
		[260220] = "Aruun the Darkener",
		[183430] = "Tarspitter Lurker",
		[209027] = "Duskwatch Guard",
		[921] = 4,
		[212099] = "[*] Temporal Charge",
		[213123] = "Venomous Spiderling",
		[86604] = "Hogger",
		[191622] = 11,
		[225410] = "Withered Skulker",
		[15244] = "Mage Hunter Ascendant",
		[179336] = 11,
		[213124] = "[*] Venomous Pool",
		[223363] = 3,
		[224387] = "Sidereal Familiar",
		[202886] = 5,
		[197767] = 5,
		[191624] = 10,
		[225412] = "Chronowraith",
		[8269] = "Eldreth Seether",
		[247938] = 12,
		[191625] = 10,
		[234628] = "Dread Vizier Gra'tork",
		[227461] = "Winged Assistant",
		[212103] = "Scrubber",
		[1098] = 9,
		[198793] = 12,
		[224390] = "Sidereal Familiar",
		[1122] = 9,
		[18072] = "Gordok Brute",
		[260226] = "Aruun the Darkener",
		[206985] = 11,
		[191627] = 10,
		[18968] = "Eldreth Seether",
		[109132] = 10,
		[227463] = "Lord Robin Daris",
		[203914] = 5,
		[224392] = 11,
		[225416] = "Felguard Annihilator",
		[212106] = 12,
		[196748] = 10,
		[33325] = "Auchenai Necromancer",
		[191629] = 10,
		[227465] = "The Curator",
		[171152] = 9,
		[221322] = 6,
		[43308] = 12,
		[224394] = "Sidereal Familiar",
		[209036] = "Duskwatch Sentry",
		[211084] = 6,
		[30615] = "Bleeding Hollow Scryer",
		[191631] = 10,
		[225419] = "Felguard Annihilator",
		[249993] = 1,
		[202895] = 4,
		[32663] = "Sethekk Shaman",
		[197776] = "General Xakal",
		[123981] = 6,
		[16793] = "Magistrate Barthilas",
		[12557] = "Skeletal Guardian",
		[234636] = "[*] Fel Discharge",
		[6343] = 1,
		[50988] = "[*] Glare of the Tribunal",
		[191634] = 7,
		[193682] = "Lady Hatecoil",
		[211088] = 8,
		[114255] = 5,
		[204945] = 7,
		[239757] = "Redeemed Essence",
		[62507] = "Sif",
		[218256] = 12,
		[200851] = 11,
		[202899] = 12,
		[239759] = "Tricky Hellion",
		[217234] = "Ularogg Cragshaper",
		[227473] = "[*] Whirling Edge",
		[1850] = 11,
		[239760] = "Tricky Hellion",
		[71254] = "Lady Deathwhisper",
		[242832] = "Dreadstalker <Mcwhip-Runetotem>",
		[15245] = "Commander Malor",
		[90708] = 11,
		[15501] = "Sethekk Shaman",
		[209855] = "Scion of Fire",
		[5568] = "Ironbark Protector",
		[242833] = 8,
		[115178] = 10,
		[253072] = 2,
		[221332] = 10,
		[209848] = "Scion of Ice",
		[228477] = 12,
		[206580] = "[*] Resonant Slash",
		[16141] = "Broken Cadaver <Ravaged Cadaver>",
		[242834] = 9,
		[209854] = "Scion of Fire",
		[253073] = 11,
		[49198] = "Novos the Summoner",
		[215461] = 11,
		[223381] = "Dire Shaman",
		[49966] = "Crane <Poptartlove-Trollbane> <Poptartlove-Trollbane>",
		[227736] = "Moroes",
		[44535] = 8,
		[227477] = "Elfyra",
		[32253] = 11,
		[17434] = "Lord Aurius Rivendare",
		[214167] = "Star Augur Etraeus",
		[191326] = "Dresaron",
		[49861] = "Unknown",
		[204175] = "Felguard",
		[199567] = "Image of Latosius",
		[200551] = "Dargrul",
		[29426] = "Risen Gallant",
		[22910] = "Illyanna Ravenoak",
		[55521] = "Drakkari Battle Rider",
		[123986] = 10,
		[102352] = 11,
		[114644] = 11,
		[251028] = "Shadowbound Defiler",
		[200580] = "Festerhide Grizzly",
		[236694] = "Captain Yathae Moonstrike",
		[55342] = 8,
		[214169] = 12,
		[17150] = "Risen Sorcerer",
		[2484] = 7,
		[159904] = 5,
		[210074] = "Skorpyron",
		[128202] = 11,
		[224125] = "Unknown <Diabloux-Darkspear>",
		[233490] = 9,
		[197788] = "Dread Felbat",
		[49711] = "Risen Drakkari Handler",
		[86736] = "Hogger",
		[73427] = 9,
		[232174] = "Harjatan",
		[206577] = "Star Augur Etraeus",
		[236696] = 11,
		[207724] = 5,
		[93675] = "Lord Godfrey",
		[198813] = 12,
		[202098] = "Helya",
		[207685] = 12,
		[201885] = "Taintheart Deadeye",
		[227482] = 8,
		[236697] = "Moontalon <Captain Yathae Moonstrike>",
		[213148] = "Spellblade Aluriel",
		[223038] = "Guardian Rurson",
		[201733] = "Latosius",
		[22938] = "Mana Burst <Residual Monstrosity> <Residual Monstrosity>",
		[196357] = "Ivanyr",
		[38193] = "Cobalt Serpent",
		[225124] = 2,
		[236430] = 5,
		[221340] = "Midnight Siphoner",
		[55599] = "Drakkari Medicine Man",
		[207006] = "Inquisitor Vethriz",
		[208030] = 8,
		[51690] = 4,
		[17253] = "Quilen <Peybear-Dalaran>",
		[211102] = 8,
		[208230] = "Tichondrius",
		[204959] = 6,
		[230297] = "Skeletal Waiter",
		[24858] = 11,
		[167076] = 5,
		[233196] = "Mephistroth",
		[251034] = 3,
		[202912] = 2,
		[17307] = "Ramstein the Gorger",
		[17435] = "Lord Aurius Rivendare",
		[205984] = "Star Augur Etraeus",
		[203750] = "Chronarch Defender",
		[167077] = 5,
		[197558] = "Fenryr",
		[19574] = 3,
		[202913] = "Tirathon Saltheril",
		[114093] = 7,
		[196770] = 6,
		[214170] = 7,
		[61999] = 6,
		[167078] = 5,
		[192675] = "Mystic Tornado",
		[38194] = "Talon King Ikiss",
		[202914] = 3,
		[118459] = "Quilen <Peybear-Dalaran>",
		[196771] = 6,
		[222368] = 5,
		[223392] = "Dire Shaman",
		[14030] = "Anvilrage Warden",
		[241822] = "[*] --unknown spell--",
		[150368] = "Death's Head Necrolyte",
		[252061] = 10,
		[132463] = 10,
		[221345] = "[*] Annihilating Orb",
		[246942] = "Zorathides",
		[193376] = "Ularogg Cragshaper",
		[199844] = 8,
		[191840] = 10,
		[127356] = 11,
		[210872] = 4,
		[244895] = "Disturbing Echo",
		[29722] = 9,
		[246943] = "Saprish",
		[242630] = 1,
		[15230] = "Skul",
		[191620] = 11,
		[72286] = 2,
		[202917] = 7,
		[253087] = 6,
		[180392] = "Rakeeshi Sorcerer",
		[159475] = 11,
		[215204] = "Vigilant Duskwatch",
		[22939] = "Residual Monstrosity",
		[201566] = "Seacursed Slaver",
		[185512] = "Huk'roth the Huntmaster",
		[235682] = "Cenarius",
		[154796] = 12,
		[245921] = "[*] Spectral Army of Norgannon",
		[214181] = "Putrid Sludge",
		[207014] = 12,
		[183465] = "Tarspitter Lurker",
		[8097] = 11,
		[246504] = "Garothi Decimator",
		[227492] = "Unknown",
		[154797] = 12,
		[164012] = 5,
		[197800] = 4,
		[231588] = 2,
		[222031] = 12,
		[127154] = 10,
		[242851] = 8,
		[252066] = 2,
		[50994] = "Crystalline Tender",
		[180395] = "Rakeeshi Sorcerer",
		[43315] = 5,
		[202669] = 4,
		[52419] = 6,
		[241828] = "Spectral Charger",
		[234661] = "Mistress Sassz'ine",
		[260258] = "Void Fragment",
		[208620] = "Corrupted Defender",
		[188587] = "Understone Demolisher",
		[70116] = "Spire Frostwyrm",
		[239781] = "Ghostly Acolyte",
		[45875] = 11,
		[50933] = "Flesheating Ghoul",
		[201898] = 7,
		[202060] = 11,
		[253092] = 9,
		[33743] = 8,
		[55602] = "Unyielding Constrictor",
		[119899] = "Kupjub <Lightninggh-Shu'halo>",
		[22582] = "Coilfang Oracle",
		[79968] = "High Vindicator",
		[162624] = 11,
		[130138] = 5,
		[115151] = 10,
		[196780] = 6,
		[114108] = 11,
		[49715] = "Scourge Brute",
		[124507] = 10,
		[200876] = 1,
		[42292] = 7,
		[211115] = "Warp Shade",
		[236712] = "Priestess Lunaspyre",
		[43060] = 11,
		[5416] = "Carrion Swarmer",
		[113092] = 8,
		[233375] = 1,
		[233641] = 8,
		[249793] = "Noura, Mother of Flames",
		[260262] = "Void Effusion",
		[190225] = "Angerhoof Bull",
		[196782] = 6,
		[5672] = "Healing Stream Totem <Kâiri-Frostmourne>",
		[22812] = 11,
		[199854] = 1,
		[209069] = 7,
		[38197] = "Talon King Ikiss",
		[211117] = "Hati <Mèl-Draenor>",
		[201633] = "Earthen Shield Totem <Kâiri-Frostmourne>",
		[221356] = "Twilight Stardancer",
		[19705] = 11,
		[47668] = "Risen Drakkari Warrior",
		[150709] = "[*] Soul Leech",
		[196528] = 6,
		[193712] = "Lady Hatecoil",
		[11894] = "Antu'sul",
		[253097] = 9,
		[213166] = "[*] Searing Brand",
		[212801] = 8,
		[22940] = "Residual Monstrosity",
		[214964] = 1,
		[241835] = 8,
		[12480] = "Jammal'an the Prophet",
		[68708] = 5,
		[253098] = 10,
		[254122] = "Priestess of Delirium",
		[244657] = "Zuraal the Ascended",
		[198833] = "Latosius",
		[60211] = "Dragonflayer Forge Master",
		[241836] = 8,
		[234669] = "Dread Vizier Gra'tork",
		[82326] = 2,
		[253099] = 1,
		[170823] = 9,
		[32690] = "Sethekk Oracle",
		[13952] = "Anvilrage Officer",
		[224025] = 2,
		[187708] = 3,
		[208683] = 6,
		[260267] = "Void Effusion",
		[203954] = "Timeless Wraith",
		[55348] = "Drakkari Battle Rider",
		[71127] = "Stinky",
		[119903] = "Dark Shaman Acolyte",
		[235237] = "Belac",
		[48181] = 9,
		[193716] = "Lady Hatecoil",
		[5277] = 4,
		[130654] = 10,
		[69041] = 3,
		[48849] = "King Dred",
		[260256] = "Void Fragment",
		[170869] = 7,
		[207693] = 12,
		[193717] = "Lady Hatecoil",
		[68992] = 11,
		[93795] = 8,
		[237744] = 1,
		[59700] = 2,
		[207028] = 2,
		[30108] = 9,
		[202472] = "Helya",
		[217830] = 5,
		[114852] = 2,
		[203957] = "Timeless Wraith",
		[155835] = 11,
		[16346] = "Wretched Belcher",
		[198838] = 7,
		[198376] = "Archdruid Glaidalis",
		[222086] = "Nightmare Amalgamation",
		[139068] = 3,
		[211125] = "Warp Shade",
		[244913] = "Disturbing Echo",
		[203650] = 12,
		[63796] = 7,
		[198839] = "Earthen Shield Totem <Kâiri-Frostmourne>",
		[8040] = "Lady Anacondra",
		[16143] = "Mangled Cadaver",
		[48438] = 11,
		[227508] = "Maiden of Virtue",
		[228532] = 12,
		[49206] = 6,
		[246962] = 9,
		[210662] = "Withered Fiend",
		[224437] = 1,
		[114051] = 7,
		[200423] = 2,
		[225100] = "Guardian Construct",
		[12739] = "Shadowy Attendant",
		[18562] = 11,
		[181435] = "Mana Hunter",
		[223414] = "[*] Parasitic Fetter",
		[195446] = 8,
		[234264] = 2,
		[31458] = "Temporus",
		[15732] = "Risen Battle Mage",
		[244916] = "Umbral Tentacle",
		[208613] = 12,
		[124280] = 10,
		[74856] = 6,
		[498] = 2,
		[212736] = "[*] Pool of Frost",
		[242869] = 2,
		[191397] = "PREDATOR <Thetoro-Feathermoon>",
		[236726] = 7,
		[245941] = 8,
		[245586] = "Diima, Mother of Gloom",
		[194522] = 8,
		[15615] = "Felguard Brute",
		[241846] = 12,
		[191767] = "Tirathon Saltheril",
		[40504] = "Ruby Guardian",
		[253109] = 10,
		[81297] = 2,
		[214202] = 2,
		[223417] = "Grisly Trapper",
		[212886] = "Il'gynoth",
		[98727] = 2,
		[227267] = "The Curator",
		[44235] = 11,
		[194277] = 3,
		[237388] = 5,
		[214203] = 7,
		[62544] = 8,
		[167105] = 1,
		[44088] = 8,
		[14514] = "Mana Remnant",
		[211132] = "Empowered Eye of Gul'dan",
		[30621] = "Bonechewer Ravener",
		[196364] = 9,
		[82537] = 5,
		[223419] = "Dread Spirit <Grisly Trapper> <Grisly Trapper>",
		[11639] = "Ogom the Wretched",
		[239558] = "Dreadwing",
		[215241] = "First Arcanist Thalyssra",
		[202942] = 11,
		[55095] = 6,
		[207112] = 5,
		[111206] = 5,
		[247993] = 3,
		[29928] = "Phantom Guest",
		[200631] = "Mindshattered Screecher",
		[236645] = 8,
		[40505] = "Boneflayer Ghoul",
		[244922] = "Haunting Phantasm",
		[213182] = "Spellblade Aluriel",
		[239326] = "[*] Felblaze Orb",
		[248057] = "Umbral War-Adept",
		[16799] = "Skul",
		[204514] = 3,
		[242875] = 11,
		[32612] = 8,
		[110183] = 11,
		[34874] = "Hungarfen",
		[59703] = 2,
		[210657] = 7,
		[230162] = "Abstract Nullifier",
		[192706] = "Wrath of Azshara",
		[185539] = "Destructor Tentacle",
		[227518] = 12,
		[122470] = 10,
		[232273] = "[*] Loose Mana",
		[114061] = "Jandice Barov",
		[223423] = "Tainted Bloodpetal",
		[208065] = 5,
		[159943] = 5,
		[234686] = "Wrath-Lord Akrazar",
		[66] = 8,
		[65917] = 8,
		[163558] = 1,
		[246973] = 2,
		[215233] = "Dominator Tentacle",
		[14032] = "Sandfury Shadowcaster",
		[192708] = "Arcane Bomb",
		[236740] = "Felblight Stalker",
		[13750] = 4,
		[73325] = 5,
		[196804] = "Ivanyr",
		[206019] = "Lingering Corruption",
		[215234] = "Dominator Tentacle",
		[191685] = 6,
		[198428] = "Ularogg Cragshaper",
		[120694] = "Beast <Hyliia-Kargath>",
		[235712] = 3,
		[51001] = "Dark Matter",
		[198909] = 10,
		[206020] = "[*] Corrupted Touch",
		[239808] = "Eternal Soulguard",
		[257214] = "Khaz'goroth",
		[250047] = 1,
		[206560] = "Trilliax",
		[15248] = "Riverpaw Looter",
		[236737] = "Wrathguard Invader",
		[199646] = 9,
		[211192] = "Rotten Drake",
		[223427] = "[*] Nightmare Spores",
		[35312] = "[*] Raging Flames",
		[116841] = 10,
		[242881] = 10,
		[252096] = 4,
		[216310] = 1,
		[32424] = "Exarch Maladaar",
		[192225] = 10,
		[239810] = "Eternal Soulguard",
		[12466] = "Lord Overheat",
		[195832] = "Skrog Tidestomper",
		[151810] = "Amnennar the Coldbringer",
		[49088] = 6,
		[203975] = 11,
		[32828] = "Unliving Soldier <Auchenai Soulpriest> <Auchenai Soulpriest>",
		[203953] = 11,
		[49722] = "Enslaved Proto-Drake",
		[72593] = 11,
		[30844] = "Shadowmoon Technician",
		[36346] = "Sunseeker Engineer",
		[115315] = 10,
		[93805] = 3,
		[196809] = "T'uure <Elyseia-Proudmoore>",
		[255170] = 9,
		[119914] = 9,
		[83575] = 11,
		[223446] = 5,
		[55605] = "Unyielding Constrictor",
		[243908] = 8,
		[199641] = 10,
		[196810] = "T'uure <Elyseia-Proudmoore>",
		[197834] = 4,
		[204957] = 6,
		[240837] = 4,
		[216303] = 5,
		[234694] = "Wrath-Lord Akrazar",
		[211145] = 3,
		[93806] = 8,
		[196811] = "T'uure <Cerraph>",
		[197835] = 4,
		[119915] = 9,
		[98440] = 4,
		[253108] = 6,
		[251077] = 4,
		[65081] = 5,
		[222939] = "Guardian Gorroc",
		[196812] = "T'uure <Tes-Nesingwary>",
		[115308] = 10,
		[23224] = "Baron Silverlaine",
		[5225] = 11,
		[116844] = 10,
		[234696] = 5,
		[227529] = "Damaged Golem",
		[203980] = 8,
		[196813] = "T'uure <Elyseia-Proudmoore>",
		[12468] = "Jammal'an the Prophet",
		[200940] = 11,
		[227034] = 11,
		[183088] = "Mightstone Breaker",
		[192222] = 7,
		[211148] = 3,
		[203981] = 12,
		[232153] = "Coggleston",
		[181456] = 1,
		[59611] = "Bo'lan the Marked",
		[230105] = 12,
		[202497] = 11,
		[193743] = 11,
		[186576] = "[*] Petrifying Cloud",
		[195791] = "Corstilax",
		[243942] = 8,
		[173266] = 12,
		[11921] = "Hellfire Familiar",
		[240842] = 7,
		[225484] = "Frenzied Nightclaw",
		[210126] = 8,
		[158998] = "Frostwall Goren",
		[220117] = "Lightsworn Anchorite",
		[196816] = "T'uure <Luanei-Azralon>",
		[255177] = 10,
		[239819] = "[*] Dark Mark",
		[240843] = 5,
		[47435] = 11,
		[68212] = 9,
		[109538] = 5,
		[236748] = 11,
		[93830] = 7,
		[115831] = "Khillikad <Lastwhisper-Darkspear>",
		[248011] = 10,
		[253849] = 11,
		[198888] = "Storm Drake",
		[198936] = "[*] Rune of Healing",
		[211152] = "Gul'dan",
		[33623] = "Unknown",
		[199911] = 5,
		[51799] = "Dark Rune Scholar",
		[215248] = 2,
		[208081] = 8,
		[116847] = 10,
		[68213] = 9,
		[211147] = 3,
		[201959] = "Emberhusk Dominator",
		[196819] = 4,
		[196840] = 7,
		[64582] = "VX-001",
		[14033] = "High Interrogator Gerstahn",
		[235222] = "Eredar Bloodmage",
		[218321] = "Army of the Dead <Heoki-Dalaran>",
		[116858] = 9,
		[244906] = "[*] Collapsing Void",
		[26977] = "Lord Incendius",
		[255181] = 10,
		[147367] = 1,
		[111759] = 5,
		[88163] = 1,
		[246688] = "[*] Suppression Field",
		[234385] = "Ravenous Felhunter",
		[93811] = 2,
		[248023] = 10,
		[210659] = 7,
		[70774] = 1,
		[243941] = 8,
		[222934] = "[*] Radiating Nightmare",
		[43199] = 3,
		[72616] = 11,
		[199915] = "Faceless Voidcaster",
		[218838] = "[*] Arcane Eclipse",
		[115313] = 10,
		[226005] = "Trained Shadescale",
		[199894] = 10,
		[116849] = 10,
		[242897] = 10,
		[208599] = "Rothoof Defiler",
		[228563] = 10,
		[215766] = 3,
		[214229] = 12,
		[207062] = 6,
		[208086] = 1,
		[16145] = "Sethekk Initiate",
		[210134] = 8,
		[193318] = 9,
		[125050] = 3,
		[254161] = 10,
		[250097] = "Torment of Aman'Thul",
		[210166] = "[*] Toxic Retch",
		[193375] = "Ularogg Cragshaper",
		[85361] = 11,
		[185562] = 8,
		[235732] = 6,
		[195801] = "Skrog Tidestomper",
		[227257] = "The Curator",
		[255186] = 4,
		[248019] = 10,
		[239409] = "[*] Soul Burst",
		[222932] = "Guardian Gorroc",
		[149851] = "Mushlump",
		[227542] = "Lady Catriona Von'Indi",
		[236757] = 11,
		[51271] = 6,
		[255187] = 12,
		[244433] = "Zuraal the Ascended",
		[224471] = 11,
		[208147] = 8,
		[15605] = "Golem Lord Argelmach",
		[227543] = "Elfyra",
		[62396] = "Flame Leviathan",
		[207573] = "Ysondre",
		[255188] = 12,
		[215257] = 2,
		[118779] = 1,
		[48191] = "Alliance Ranger",
		[185565] = 4,
		[113780] = 4,
		[195804] = "Corstilax",
		[2565] = 1,
		[194392] = 3,
		[248022] = 10,
		[18540] = 9,
		[236241] = "[*] Soul Rot",
		[2645] = 7,
		[227545] = "Baroness Dorothea Millstipe",
		[195805] = 6,
		[108159] = 11,
		[119405] = "Adarogg",
		[207068] = 3,
		[224978] = "[*] Infinite Abyss",
		[60478] = 9,
		[31904] = "Captain Skarloc",
		[67682] = 9,
		[197333] = "Cordana Felsong",
		[205021] = 8,
		[183539] = "Rotdrool Grabber",
		[182496] = 2,
		[22946] = "Arcane Torrent",
		[224483] = "Duskwatch Sentinel",
		[193759] = 8,
		[54847] = "Drakkari Elemental",
		[93816] = 10,
		[205022] = 8,
		[186070] = 3,
		[182497] = 2,
		[157979] = 8,
		[86633] = "Lord Overheat",
		[242906] = "Infernal Chaosbringer",
		[227548] = "Mana Confluence",
		[77451] = 7,
		[106615] = 5,
		[203924] = 3,
		[172944] = 5,
		[257241] = 5,
		[203792] = "Hellwarden Xaphan",
		[12626] = "Patchwork Horror",
		[34370] = "Darkwater Crocolisk",
		[93821] = 8,
		[13584] = "Reanimated Bones",
		[12882] = "Morphaz",
		[51776] = "Dark Rune Elementalist",
		[257242] = 5,
		[215956] = 2,
		[201953] = "Emberhusk Dominator",
		[227550] = "Gul'dan",
		[195810] = 3,
		[205025] = 8,
		[247004] = 8,
		[207073] = 11,
		[257243] = 5,
		[250076] = 3,
		[242909] = "Infernal Chaosbringer",
		[46657] = 11,
		[228575] = "Wholesome Hostess",
		[110113] = 11,
		[119415] = 8,
		[71029] = "Servant of the Throne",
		[257244] = 6,
		[71805] = "Stinky",
		[153867] = 11,
		[187653] = "Skola Greatsword",
		[62276] = "Thorim",
		[3589] = "Shrieking Banshee",
		[255176] = 4,
		[115832] = "Khillikad <Lastwhisper-Darkspear>",
		[183526] = "Understone Drummer",
		[241887] = 8,
		[193765] = 10,
		[137452] = 11,
		[244959] = 8,
		[34790] = 7,
		[193235] = "Hymdall",
		[35395] = 2,
		[228252] = "Forlorn Spirit",
		[232142] = "Silver Forks",
		[150453] = "Blindlight Rotmouth",
		[102280] = 11,
		[195757] = 6,
		[196838] = "Fenryr",
		[16380] = "Eye of Naxxramas",
		[62016] = "Thorim",
		[191719] = 6,
		[152279] = 6,
		[193234] = "[*] Dancing Blade",
		[22950] = "Immol'thar",
		[192794] = "[*] Lightning Strike",
		[118905] = 7,
		[255200] = 2,
		[208860] = "Dread Abomination",
		[224484] = "[*] Falling Star",
		[227255] = 12,
		[210150] = "Naraxas",
		[32546] = 5,
		[32674] = "Sethekk Talon Lord",
		[82046] = 5,
		[255201] = "[*] Aggramar's Sacrifice",
		[239843] = "Spectral Guardian",
		[85874] = 11,
		[33860] = "Cho'Rush the Observer",
		[86620] = "Hogger",
		[72156] = 11,
		[228581] = 6,
		[205032] = 8,
		[156910] = 2,
		[61391] = 11,
		[36348] = "Bloodwarder Physician",
		[241892] = 10,
		[18084] = 7,
		[248522] = 11,
		[222925] = "Venomous Spiderling",
		[53314] = "Dark Rune Elementalist",
		[255203] = 6,
		[248055] = "Umbral War-Adept",
		[204495] = 10,
		[225511] = "Shambling Hungerer",
		[210153] = 12,
		[235750] = 10,
		[222082] = "Nightmare Amalgamation",
		[197937] = 5,
		[58688] = "Cyanigosa",
		[198891] = "Seacursed Slaver",
		[224488] = "Nobleborn Warpcaster",
		[163025] = 8,
		[150229] = "[*] Bubonic Plague",
		[235751] = "Agronox",
		[204011] = 2,
		[48707] = 6,
		[197868] = "Lady Hatecoil",
		[198892] = "Storm Drake",
		[199916] = "Faceless Voidcaster",
		[241895] = 10,
		[58690] = "Cyanigosa",
		[213709] = 11,
		[44614] = 8,
		[180463] = 5,
		[119420] = "Adarogg",
		[252616] = "Constellar Designate",
		[191726] = "Greater Lightning Elemental <Lijiin>",
		[200941] = 11,
		[145109] = 11,
		[125056] = "Core Hound <Shaggybeard-Dalaran>",
		[51010] = 10,
		[48712] = 5,
		[48873] = "King Dred",
		[230090] = 12,
		[199918] = "Faceless Voidcaster",
		[200942] = 11,
		[253639] = 6,
		[210099] = "Nightmare Ichor",
		[243963] = "Varimathras",
		[213229] = 9,
		[134359] = 7,
		[224970] = "Felsworn Shadowblade",
		[199919] = "Faceless Voidcaster",
		[200943] = 11,
		[242922] = 9,
		[232137] = "Silver Forks",
		[30633] = "Crystalline Protector",
		[3408] = 4,
		[236717] = "Priestess Lunaspyre",
		[200901] = "Solsten",
		[191729] = 6,
		[200944] = 11,
		[125565] = 1,
		[82921] = 3,
		[93825] = 3,
		[214226] = "Duskwatch Arcblade",
		[1706] = 5,
		[215279] = "Chaos Tear <Lightninggh-Shu'halo>",
		[191730] = 6,
		[200945] = 11,
		[242924] = "Goroth",
		[115310] = 10,
		[195826] = 10,
		[118] = 8,
		[250761] = 10,
		[198898] = 10,
		[202978] = "Nythendra",
		[205675] = 9,
		[232633] = 5,
		[211185] = "Lady Calindris",
		[204018] = 2,
		[211299] = "Watchful Inquisitor",
		[86659] = 2,
		[208586] = "Rothoof Shadowstalker",
		[191732] = "Greater Lightning Elemental <Yoiyoi-Drakkari>",
		[14099] = "Magistrate Barthilas",
		[121471] = 4,
		[252141] = 7,
		[244974] = "Unsettling Despair",
		[16870] = 11,
		[237825] = 2,
		[22695] = "Petrified Guardian",
		[58180] = 11,
		[204490] = 12,
		[68230] = 9,
		[228333] = "[*] Volatile Charge",
		[93827] = 11,
		[201411] = "Dreadfire Imp",
		[196787] = "Fel-Infused Fury",
		[216776] = 5,
		[14034] = "Fireguard",
		[250095] = "Torment of Aman'Thul",
		[195750] = 6,
		[252143] = 7,
		[204021] = 12,
		[215263] = 11,
		[240671] = 8,
		[15507] = "Golem Lord Argelmach",
		[191735] = "Felsworn Myrmidon",
		[192759] = 4,
		[193783] = 10,
		[153852] = 5,
		[93828] = 8,
		[45278] = 11,
		[213177] = 10,
		[198903] = "[*] Crackling Storm",
		[8042] = 7,
		[192760] = 4,
		[121473] = 4,
		[254210] = 8,
		[228596] = 8,
		[213238] = "Tichondrius",
		[119434] = "Slagmaw",
		[198904] = "Rotheart Dryad",
		[232692] = "Gul'dan",
		[241907] = 6,
		[152830] = "Twilight Storm Mender",
		[235764] = 8,
		[244979] = 8,
		[52042] = 7,
		[81039] = "Irradiated Slime",
		[190714] = 5,
		[60229] = 1,
		[200953] = 1,
		[251123] = 10,
		[203001] = 11,
		[228598] = 8,
		[254195] = "Arcatraz Sentinel",
		[2580] = 9,
		[207097] = "Quilen <Peybear-Dalaran>",
		[183548] = "Stoneclaw Grubmaster",
		[200954] = 1,
		[203961] = 11,
		[211193] = "Captain Naranoth",
		[228599] = 8,
		[18399] = "Gordok Mage-Lord",
		[214265] = 7,
		[19750] = 2,
		[34259] = "Atal'ai Deathwalker",
		[219426] = "Belphiar",
		[56646] = "Enraged Fire Elemental",
		[42780] = "Dragonflayer Ironhelm",
		[228600] = 8,
		[163201] = 1,
		[91522] = "Dark Creeper",
		[204069] = 11,
		[73583] = 9,
		[241911] = 10,
		[116705] = 10,
		[4987] = 2,
		[163073] = 12,
		[254198] = "Arcatraz Sentinel",
		[153489] = 1,
		[157954] = 5,
		[208582] = "Rothoof Shadowstalker",
		[184575] = 2,
		[191758] = "Shambling Horror <Heoki-Dalaran>",
		[252151] = 7,
		[22686] = "King Dred",
		[254199] = "Arcatraz Sentinel",
		[214268] = "Duskwatch Arcblade",
		[124036] = 10,
		[191743] = "Felsworn Myrmidon",
		[245000] = "Coalescing Nightmare",
		[147732] = 7,
		[209033] = "Duskwatch Guard",
		[228603] = "Spectral Charger",
		[115804] = 1,
		[236710] = "Kil'jaeden",
		[47688] = "Chaotic Rift",
		[46010] = 7,
		[151813] = "Twilight Lord Bathiel",
		[201983] = "Emberhusk Dominator",
		[211198] = "Astral Spark <Arcane Anomaly>",
		[32677] = "Time-Lost Shadowmage",
		[188673] = 11,
		[66188] = 6,
		[215294] = 11,
		[249082] = "Unknown",
		[91064] = "Frantic Geist",
		[223179] = "Fiendish Henchman",
		[252154] = 7,
		[187650] = 3,
		[237820] = 1,
		[12884] = "Dreamscythe",
		[221891] = "Gul'dan",
		[158982] = "Frostwall Goren",
		[151815] = "Twilight Lord Bathiel",
		[196294] = "Stormwake Hydra",
		[236518] = "Priestess Lunaspyre",
		[31615] = "Swamplord Musel'ek",
		[130] = 8,
		[255227] = 7,
		[53563] = 2,
		[224511] = "Duskwatch Battle-Magus",
		[143625] = 10,
		[221354] = "Twilight Stardancer",
		[203927] = 3,
		[43194] = 7,
		[73326] = 10,
		[55624] = "Drakkari God Hunter",
		[111752] = "Scholomance Neophyte",
		[191748] = 6,
		[20007] = 4,
		[193796] = 7,
		[211202] = "Arcane Anomaly",
		[204035] = 2,
		[197943] = "Ursoc",
		[247038] = "Zuraal the Ascended",
		[198916] = "Vile Mushroom <Rotheart Keeper>",
		[231454] = "Doomlash",
		[214142] = 5,
		[408] = 4,
		[50761] = "Maiden of Grief",
		[215210] = 5,
		[254206] = "Unknown",
		[214222] = 2,
		[66198] = 6,
		[9791] = "Dragonflayer Bonecrusher",
		[182098] = "Impling Pillager",
		[191610] = 2,
		[252159] = 7,
		[228610] = "[*] Burning Brand",
		[196870] = "Hatecoil Stormweaver",
		[247040] = 6,
		[22823] = "Eldreth Sorcerer",
		[183560] = "Unknown",
		[15636] = "Emperor Dagran Thaurissan",
		[64695] = "Unknown <Linkedon>",
		[252060] = 10,
		[187656] = "Skola Greatsword",
		[196871] = "Hatecoil Stormweaver",
		[119433] = "Slagmaw",
		[193786] = 7,
		[202574] = 1,
		[209158] = "Xavius",
		[32422] = "Exarch Maladaar",
		[48714] = 5,
		[32678] = 3,
		[98444] = 1,
		[214278] = "Elisande",
		[246739] = "Torment of Golganneth",
		[15574] = "Ambassador Flamelash",
		[200898] = "Inquisitor Tormentorum",
		[7947] = "Deviate Viper",
		[1715] = 1,
		[253797] = 6,
		[118922] = 3,
		[255234] = 2,
		[248067] = "Umbral War-Adept",
		[60233] = 4,
		[200969] = "King Tor",
		[88718] = 6,
		[211208] = "Captain Naranoth",
		[253061] = "Constellar Designate",
		[205065] = 5,
		[182422] = 5,
		[199547] = 12,
		[196290] = "Stormwake Hydra",
		[96231] = 2,
		[193803] = "Tarspitter Grub",
		[93326] = 7,
		[211903] = 2,
		[131347] = 12,
		[55626] = "Living Mojo",
		[17962] = 9,
		[114282] = 11,
		[80016] = "Hawkmaster Nurong",
		[201995] = 6,
		[211210] = 2,
		[187661] = 8,
		[187698] = 3,
		[198337] = 1,
		[214240] = 11,
		[183566] = "[*] Rancid Pool",
		[50251] = 5,
		[229053] = 10,
		[14868] = "Guzzling Patron",
		[27243] = 9,
		[152262] = 2,
		[75627] = 5,
		[224425] = "Vicious Manafang",
		[257286] = 10,
		[225583] = "[*] Arcanic Release",
		[131784] = 8,
		[199460] = "Dresaron",
		[204045] = "Doomguard",
		[22568] = 11,
		[22696] = "Petrified Guardian",
		[196299] = "Stormwake Hydra",
		[208141] = 8,
		[89751] = "Erakvegen <Exorcistaa-TolBarad>",
		[72043] = 11,
		[46668] = 4,
		[46924] = 1,
		[102543] = 11,
		[55627] = "Living Mojo",
		[87185] = "Gordok Captain",
		[224126] = "Spirit Wolf <Diabloux-Darkspear>",
		[241930] = 10,
		[249677] = "Commander Atalaa",
		[80987] = 5,
		[245002] = "Distressing Vision",
		[246026] = "[*] Void Trap",
		[66196] = 6,
		[198928] = 8,
		[148135] = 10,
		[1856] = 4,
		[210191] = 2,
		[211079] = "Nightborne Reclaimer",
		[195707] = 1,
		[196881] = 7,
		[85600] = 11,
		[198929] = 8,
		[240908] = "Kil'jaeden",
		[200977] = 1,
		[63560] = 6,
		[17057] = 11,
		[236590] = "Ahunite Hailstone",
		[36340] = "Bloodwarder Physician",
		[222479] = 1,
		[115288] = 10,
		[77478] = 7,
		[6795] = 11,
		[198407] = "Skeletal Sorcerer",
		[211217] = "Arcane Anomaly",
		[245005] = "Void Tentacle",
		[139546] = 4,
		[230671] = 10,
		[223504] = "Dread Spirit <Grisly Trapper>",
		[240910] = "Kil'jaeden",
		[200979] = 1,
		[64843] = 5,
		[260364] = 8,
		[236652] = "Archmage Khadgar",
		[196884] = 7,
		[247054] = 9,
		[157977] = 8,
		[191765] = "Tirathon Saltheril",
		[33871] = "Ethereal Scavenger",
		[202004] = 7,
		[203028] = "Ysondre",
		[31901] = "Omor the Unscarred",
		[196885] = "Skjal",
		[51533] = 7,
		[223506] = "Dread Spirit <Grisly Trapper> <Grisly Trapper>",
		[256828] = 7,
		[239288] = "Felstrider Orbcaster",
		[242960] = 8,
		[50997] = "Keristrasza",
		[80483] = 3,
		[240761] = 10,
		[13585] = "Winterfall Shaman",
		[198934] = "Valarjar Mystic",
		[232722] = "Mistress Sassz'ine",
		[42802] = 11,
		[114074] = 7,
		[162075] = 5,
		[135299] = 3,
		[221460] = "Chaos Mage Beleron",
		[181943] = 11,
		[157980] = 8,
		[232723] = "Piranhado",
		[209174] = "Elisande",
		[64844] = 5,
		[210065] = 11,
		[212246] = 10,
		[203045] = "[*] Infested Ground",
		[208742] = 7,
		[207127] = 6,
		[49998] = 6,
		[160029] = 11,
		[128594] = 3,
		[162077] = 5,
		[40120] = 11,
		[51944] = "Unknown",
		[13895] = "Bael'Gar",
		[157982] = 11,
		[240916] = "Kil'jaeden",
		[104596] = 5,
		[15499] = "Skul",
		[250146] = 11,
		[187675] = 3,
		[247075] = 9,
		[54983] = "Proto-Drake Handler",
		[256816] = 6,
		[257299] = "Argus the Unmaker",
		[200986] = 1,
		[193211] = "Ymiron, the Fallen King",
		[57912] = "Defense System",
		[203524] = 1,
		[221464] = "Chaos Mage Beleron",
		[20473] = 2,
		[248085] = 3,
		[128658] = "Felshadow Seeker",
		[244005] = "[*] Dark Fissure",
		[210202] = "Foul Mother",
		[194844] = 6,
		[187677] = 8,
		[220855] = "[*] Down Draft",
		[197916] = 10,
		[57934] = 4,
		[218903] = 12,
		[251571] = "[*] Soulbomb Detonation",
		[211178] = "Rotten Drake",
		[115356] = 7,
		[235267] = "Maiden of Vigilance",
		[191630] = 10,
		[111446] = 11,
		[68258] = 9,
		[10966] = "Wrath Hammer Construct",
		[119905] = 9,
		[251570] = "Argus the Unmaker",
		[193209] = "Ash'Golm",
		[220443] = "[*] Wake of Shadows",
		[22570] = 11,
		[216758] = 12,
		[248088] = 3,
		[91800] = "Blightcrawler <Yauco-Uldaman>",
		[192799] = "Blightshard Skitter <Rokmora> <Rokmora>",
		[228649] = 10,
		[219823] = "Chronomatic Anomaly",
		[204062] = 12,
		[77978] = "Patchwork Horror",
		[197919] = 10,
		[32363] = "Nexus-Prince Shaffar",
		[183585] = "Lightsworn Anchorite",
		[192800] = "[*] Choking Dust",
		[204471] = "Skorpyron",
		[195256] = 7,
		[89753] = "Erakvegen <Exorcistaa-TolBarad>",
		[16427] = "Crypt Beast",
		[7353] = 10,
		[198944] = "Valarjar Shieldmaiden",
		[232732] = "[*] Slicing Tornado",
		[192801] = "[*] Tidal Wave",
		[17139] = "Risen Priest",
		[93337] = 6,
		[228637] = "Spectral Journeyman",
		[84647] = 2,
		[214303] = 3,
		[232115] = "Backup Singer",
		[77472] = 7,
		[11902] = "Gahz'rilla",
		[193826] = "God-King Skovald",
		[117405] = 3,
		[54965] = "Dragonflayer Runecaster",
		[233297] = 10,
		[13398] = "Leprous Technician",
		[32854] = "Auchenai Vindicator",
		[15570] = "Molten War Golem",
		[196741] = 10,
		[193827] = "God-King Skovald",
		[53] = 4,
		[204066] = 11,
		[110744] = 5,
		[221875] = "Star Augur Etraeus",
		[70813] = 5,
		[252896] = 10,
		[225568] = "Taintheart Summoner",
		[202019] = "Latosius",
		[227616] = "Lady Keira Berrybuck",
		[212258] = "Gul'dan",
		[224189] = 11,
		[12975] = 1,
		[241784] = "Spectral Retainer",
		[208163] = 10,
		[116888] = 6,
		[115129] = 10,
		[243999] = "Varimathras",
		[196570] = "[*] Volatile Magic",
		[110745] = 5,
		[51637] = 4,
		[209202] = 2,
		[15062] = "Anger'rel",
		[196277] = 9,
		[195253] = "Restless Tides",
		[15254] = "Ethereal Beacon",
		[89756] = 11,
		[202420] = "Arbiter of the Inquisiiton",
		[214308] = "[*] Nightmare Brambles",
		[108366] = 9,
		[208165] = "Talixae Flamewreath",
		[250144] = 6,
		[224561] = "[*] Celestial Brand",
		[194855] = 3,
		[253216] = 5,
		[11898] = "Sandfury Blood Drinker",
		[31914] = "Epoch Hunter",
		[47698] = "Crystalline Protector",
		[208166] = 8,
		[64592] = "Algalon the Observer",
		[4054] = 7,
		[198324] = "Skjal",
		[212262] = "Gul'dan",
		[49234] = 11,
		[196917] = 2,
		[157997] = 8,
		[191798] = "[*] Violent Winds",
		[225573] = "Ghostly Councilor",
		[66023] = "Ebon Champion",
		[93341] = 11,
		[228645] = "Rune Weapon <Elrancho-Nagrand>",
		[202419] = "Lord Korithis",
		[25771] = 2,
		[111771] = 9,
		[55090] = 6,
		[224944] = "Felsworn Chaos-Mage",
		[211052] = 12,
		[194858] = 3,
		[206514] = "Gul'dan",
		[254243] = "Eredar Enforcer",
		[32379] = 5,
		[223166] = 5,
		[142641] = 5,
		[233766] = 10,
		[242981] = 2,
		[194859] = 3,
		[228647] = 10,
		[37361] = "Skeletal Guardian",
		[132403] = 2,
		[47699] = "Crystalline Keeper",
		[196733] = 10,
		[30938] = "Keli'dan the Breaker",
		[208052] = 8,
		[244006] = "Varimathras",
		[245030] = 11,
		[32853] = "Auchenai Vindicator",
		[132404] = 1,
		[224347] = 2,
		[185425] = "Steeljaw Grizzly",
		[50259] = 11,
		[202028] = 11,
		[229700] = 8,
		[146739] = 9,
		[193660] = "God-King Skovald",
		[211632] = "Eredar Chaosbringer",
		[218424] = "High Botanist Tel'arn",
		[232745] = "Sarukel",
		[225105] = "Shal'dorei Archmage",
		[191626] = 12,
		[223918] = "Dire Shaman",
		[240735] = "Guardian Sentry",
		[22572] = "Gordok Brute",
		[115357] = 7,
		[148413] = 5,
		[232746] = "Mistress Sassz'ine",
		[201846] = 7,
		[31403] = "Coilfang Warrior",
		[203963] = 5,
		[38741] = "Karzak the Impaler",
		[196911] = 4,
		[55635] = "Drakkari Golem",
		[207150] = 6,
		[194225] = "Sphere of Insanity <Leâ-Stormrage>",
		[250153] = 11,
		[193840] = 12,
		[105421] = 2,
		[204079] = 2,
		[246058] = 8,
		[33110] = 5,
		[231724] = 7,
		[221028] = "Gelatinized Decay",
		[219235] = "Toxic Spore",
		[109128] = 1,
		[252202] = 9,
		[93857] = "Baron Silverlaine",
		[102560] = 11,
		[247083] = "Seething Pyrelord",
		[111775] = "Lilian Voss",
		[50752] = "Maiden of Grief",
		[201009] = 1,
		[6572] = 1,
		[204463] = "Nythendra",
		[204081] = 3,
		[221487] = "Astral Farseer",
		[247084] = "Seething Pyrelord",
		[198962] = "Valarjar Runecarver",
		[216368] = "Dargrul",
		[250156] = 8,
		[239386] = "Glaive Target",
		[239931] = "Kil'jaeden",
		[204082] = "Felbound Wrathlord",
		[13847] = "Anvilrage Soldier",
		[55636] = "Drakkari Golem",
		[198963] = "Naraxas",
		[224560] = "Astrologer Jarin",
		[176438] = 12,
		[252732] = 4,
		[214342] = 4,
		[204083] = "Wrathguard Felstriker",
		[196916] = "Lady Velandras Ravencrest",
		[115360] = 7,
		[83108] = 11,
		[232752] = 6,
		[250158] = 9,
		[228255] = "Forlorn Spirit",
		[55078] = 6,
		[131767] = 11,
		[221490] = "Astral Farseer",
		[31707] = "Water Elemental <Dudette-Baelgun>",
		[231729] = "Razorjaw Wavemender",
		[15063] = "Risen Conjuror",
		[34645] = "Watchkeeper Gargolmar",
		[210228] = "Venomous Spiderling",
		[210253] = 10,
		[30636] = "Shattered Hand Warhound",
		[221491] = "Astral Farseer",
		[197942] = "Ursoc",
		[115181] = 10,
		[232754] = "Mistress Sassz'ine",
		[125088] = 11,
		[213888] = 12,
		[252208] = 10,
		[204086] = "Commander Xovoth",
		[254256] = "Arbiter of the Inquisiiton",
		[31916] = "Epoch Hunter",
		[47702] = 5,
		[65116] = 6,
		[210048] = "Nightmare Ichor",
		[207171] = 6,
		[227636] = "Attumen the Huntsman",
		[204087] = "Felbound Wrathlord",
		[32856] = "Auchenai Soulpriest",
		[222517] = 11,
		[239923] = "Tormented Priestess",
		[232756] = "Mistress Sassz'ine",
		[101546] = 10,
		[228241] = "Shrieking Terror",
		[6136] = "Risen Sorcerer",
		[195897] = 7,
		[254258] = 9,
		[222518] = 11,
		[190778] = 6,
		[232757] = "Mistress Sassz'ine",
		[225962] = "Risen Companion",
		[88742] = 7,
		[227638] = "Attumen the Huntsman",
		[89766] = "Khillikad <Lastwhisper-Darkspear>",
		[234451] = "Crushfist",
		[255283] = 3,
		[223543] = 1,
		[223914] = "Bo'lan the Marked",
		[248660] = "Zorathides",
		[38232] = "Dragonflayer Overseer",
		[245648] = "Shadowguard Trickster",
		[204090] = 3,
		[254260] = 8,
		[222520] = 4,
		[190780] = 6,
		[224568] = "Nighthold Protector",
		[204460] = 3,
		[236200] = 9,
		[22427] = "Nascent Fel Orc",
		[38238] = "Cobalt Serpent",
		[254261] = "Felshadow Seeker",
		[15290] = 5,
		[248486] = "Grolethax",
		[33625] = "Gold Shaman",
		[160065] = "Crabs <Malkavas>",
		[5176] = 11,
		[101542] = 7,
		[212283] = 4,
		[254262] = "Felshadow Seeker",
		[20572] = 1,
		[239928] = "Tormented Priestess",
		[191595] = "Unknown",
		[250167] = 11,
		[212031] = "Bound Energy",
		[13005] = "Captain Skarloc",
		[206151] = 5,
		[254263] = "Eredar Enforcer",
		[42740] = "Dragonflayer Runecaster",
		[207165] = 6,
		[223912] = "Bo'lan the Marked",
		[199451] = 10,
		[23214] = 2,
		[211261] = "Elisande",
		[31661] = 8,
		[180545] = 7,
		[63830] = "Sara",
		[190784] = 2,
		[207694] = 11,
		[210155] = 12,
		[234811] = "Grand Inquisitor",
		[194880] = "Glazer",
		[12248] = "Twilight's Hammer Ambassador",
		[32858] = "Auchenai Soulpriest",
		[197952] = "Destructor Tentacle",
		[166212] = 5,
		[224573] = 3,
		[225597] = 2,
		[194663] = "Helarjar Champion",
		[203836] = "Fei Li",
		[58160] = 5,
		[246832] = 8,
		[214335] = "Star Augur Etraeus",
		[239932] = "Kil'jaeden",
		[224574] = 3,
		[225598] = 12,
		[88746] = 6,
		[209862] = "[*] Volcanic Plume",
		[253243] = 5,
		[206612] = "Chronomatic Anomaly",
		[191678] = "Viletongue Belcher",
		[84516] = 11,
		[224575] = 3,
		[225599] = 6,
		[101033] = 7,
		[101545] = 10,
		[50131] = "Mage Slayer",
		[213313] = 2,
		[36276] = "Rift Keeper",
		[207946] = 5,
		[224576] = 3,
		[225600] = 12,
		[77758] = 11,
		[20271] = 2,
		[220481] = "Corstilax",
		[188741] = 2,
		[57688] = "Unknown",
		[149834] = "Mushlump",
		[224577] = 3,
		[241983] = "Kil'jaeden",
		[202052] = 6,
		[14744] = "Ambassador Flamelash",
		[216251] = 7,
		[197484] = "Illysanna Ravencrest",
		[218164] = 10,
		[149835] = "Mushlump",
		[224578] = 3,
		[225602] = 8,
		[234817] = "Mephistroth",
		[237632] = "Priestess Lunaspyre",
		[197966] = "Odyn",
		[22575] = "Gordok Captain",
		[22703] = 9,
		[248128] = "Rift Warden",
		[231442] = 7,
		[225603] = 6,
		[58840] = "Stolen Soul",
		[12493] = "Ogom the Wretched",
		[225141] = 1,
		[110762] = "Willey Hopebreaker",
		[206503] = "[*] Flames of Sargeras",
		[229439] = 3,
		[216389] = "Spellblade Aluriel",
		[225604] = 4,
		[31224] = 4,
		[43265] = 6,
		[48562] = "Lea Stonepaw",
		[32860] = "Auchenai Soulpriest",
		[74415] = 11,
		[248130] = "Rift Warden",
		[175457] = 9,
		[225605] = 7,
		[243011] = 9,
		[196725] = 10,
		[205875] = "[*] Slam",
		[196937] = 4,
		[197961] = "Odyn",
		[239266] = "Nal'asha",
		[8921] = 11,
		[225606] = 9,
		[208536] = "Gul'dan",
		[228700] = "Mana Confluence",
		[253260] = 8,
		[114859] = "Bored Student",
		[199805] = "Stormforged Sentinel",
		[37468] = 11,
		[200010] = "Unknown <Daiyosin-Korgath>",
		[241989] = "Razorjaw Wavemender",
		[216137] = "Infinite Drakeling",
		[93581] = "Baron Ashbury",
		[126508] = 12,
		[247456] = 12,
		[197963] = "Odyn",
		[248133] = "Rift Warden",
		[179335] = 11,
		[238489] = "Imp",
		[145152] = 11,
		[197546] = "Illysanna Ravencrest",
		[251938] = 6,
		[123051] = "Mindbender <Dêadend-Tichondrius>",
		[642] = 2,
		["BUFF"] = 5,
		[43185] = 11,
		[239264] = "Priestess Lunaspyre",
		[234824] = "Mephistroth",
		[93707] = "Lord Godfrey",
		[77489] = 5,
		[196941] = 2,
		[197965] = "Odyn",
		[204452] = "Hellwarden Xaphan",
		[211619] = "Cleansed Ancient",
		[173184] = 7,
		[243016] = 1,
		[193359] = 4,
		[187727] = 12,
		[196508] = "Deranged Mindflayer",
		[214348] = "Elerethe Renferal",
		[231754] = "Razorjaw Wavemender",
		[78306] = 5,
		[214690] = "Gerenth the Vile",
		[31407] = "Murkblood Spearman",
		[199850] = 1,
		[16172] = "Commander Malor",
		[254280] = "Slavering Devourer",
		[197967] = "Odyn",
		[86603] = "Dusk Lily Agent",
		[240970] = "Fallen Avatar",
		[12057] = "Murkblood Tribesman",
		[9613] = "Skeletal Guardian",
		[244042] = "Varimathras",
		[253257] = 8,
		[62308] = "Salvaged Demolisher <Emptyrivers>",
		[214350] = 5,
		[223565] = "Horrid Eagle",
		[6253] = "Gordok Brute",
		[203538] = 2,
		[84658] = 11,
		[17201] = "Eldreth Spectre",
		[253258] = 8,
		[90626] = 4,
		[197969] = "Ursoc",
		[15096] = "Twilight's Hammer Ambassador",
		[68173] = 5,
		[209232] = 6,
		[210256] = 2,
		[93861] = "Wolf Master Nandos",
		[219808] = "Waning Time Particle",
		[211995] = "Wyrmtongue Scavenger",
		[201378] = 5,
		[37470] = "Ethereal Spellbinder",
		[596] = 5,
		[250188] = "[*] Void Fragment",
		[234830] = "Mephistroth",
		[194899] = "Cove Seagull",
		[204114] = "Dread Houndmaster",
		[196947] = "Helya",
		[239401] = "Belac",
		[214373] = 10,
		[236544] = "Unknown",
		[114738] = 7,
		[161691] = 6,
		[85692] = "Zekrizek <Treshan-Stormrage>",
		[253261] = 8,
		[221521] = "Resolute Courtesan",
		[248165] = "Argus the Unmaker",
		[248142] = 1,
		[159065] = "Stonetooth",
		[58460] = "Azure Enforcer",
		[21169] = 7,
		[203092] = 10,
		[253262] = 8,
		[14873] = "Shifty Thief",
		[29579] = "Phantom Guest",
		[239952] = 11,
		[213833] = 8,
		[17941] = 9,
		[59567] = 6,
		[210279] = "Cenarius",
		[68283] = 9,
		[65719] = "Guardian of Yogg-Saron <Ominous Cloud>",
		[173401] = 1,
		[22833] = "Stomper Kreeg",
		[102793] = 11,
		[67767] = "Ebon Champion",
		[210261] = "Duskwatch Sentry",
		[212784] = "Watchful Inquisitor",
		[220500] = "[*] Destabilized Orb",
		[246690] = "[*] Decimation",
		[122281] = 10,
		[223572] = "Horrid Eagle",
		[32176] = 7,
		[250193] = "Fragmented Voidling <[*] Void Fragment> <[*] Void Fragment>",
		[586] = 5,
		[72887] = 9,
		[130736] = 6,
		[236603] = "[*] Rapid Shot",
		[191621] = 11,
		[223573] = 11,
		[240979] = 10,
		[67768] = 5,
		[197388] = 3,
		[255322] = 4,
		[17330] = 4,
		[221526] = 10,
		[339] = 11,
		[8858] = "Weegli Blastfuse",
		[240980] = 10,
		[205165] = 6,
		[199327] = "Seacursed Swiftblade",
		[219479] = 7,
		[47536] = 5,
		[31405] = "Murkblood Oracle",
		[10060] = 5,
		[231766] = 11,
		[189804] = "Farseer Nobundo",
		[225623] = 2,
		[129597] = 10,
		[54878] = "Drakkari Elemental",
		[69305] = 9,
		[205146] = 9,
		[234550] = "Atrigan",
		[248149] = 8,
		[208218] = 11,
		[225624] = 9,
		[202075] = "Burning Geode",
		[97462] = 1,
		[253269] = 11,
		[191552] = 12,
		[35079] = 3,
		[231768] = "[*] Drenching Waters",
		[191837] = 10,
		[236596] = "Captain Yathae Moonstrike",
		[193440] = 9,
		[170336] = 5,
		[122708] = 8,
		[253278] = 5,
		[45015] = "Abyssal Flamebringer",
		[215387] = 5,
		[216411] = 2,
		[212008] = "Wyrmtongue Scavenger",
		[227575] = "Baroness Dorothea Millstipe",
		[97463] = 1,
		[30641] = "Watchkeeper Gargolmar",
		[196958] = 4,
		[11020] = "Servant of Antu'sul <Antu'sul> <Antu'sul>",
		[191847] = "Serpentrix",
		[240985] = 4,
		[246423] = 10,
		[46432] = 11,
		[203102] = "Ysondre",
		[31665] = 4,
		[213341] = 10,
		[246830] = 8,
		[32049] = 11,
		[240986] = 6,
		[242010] = 6,
		[13787] = "Skeletal Guardian",
		[219485] = 4,
		[32689] = "Time-Lost Scryer",
		[251948] = 12,
		[242327] = 11,
		[202800] = 3,
		[233520] = "Harjatan",
		[206491] = 12,
		[240558] = 6,
		[194913] = 6,
		[220510] = 8,
		[164197] = 8,
		[25778] = "Underbog Lord",
		[246116] = 3,
		[17843] = "Sandfury Witch Doctor",
		[209248] = "Elisande",
		[88762] = 11,
		[227678] = 10,
		[62467] = "Elder Ironbranch",
		[13338] = "Gordok Warlock",
		[53600] = 2,
		[176180] = 8,
		[150679] = "Amnennar the Coldbringer",
		[197995] = 7,
		[93740] = 2,
		[219488] = "Patrol Captain Gerdo",
		[187748] = 11,
		[222519] = 11,
		[255324] = 4,
		[149865] = "Ghamoo-Ra",
		[203858] = 1,
		[242014] = 12,
		[132157] = 5,
		[115746] = "Guzsillin <Milhene-MoonGuard>",
		[253277] = 11,
		[114872] = "Bored Student",
		[245095] = "Amalgam of Torment",
		[207203] = 6,
		[197997] = 7,
		[33891] = 11,
		[119996] = 10,
		[227681] = 10,
		[245087] = "[*] Wake of Shadows",
		[247157] = "Saprish",
		[46379] = 11,
		[239968] = 5,
		[212332] = "Stitchblister <Heoki-Dalaran>",
		[245396] = "L'ura",
		[229738] = "Elisande",
		[211300] = "Watchful Oculus",
		[191855] = "Serpentrix",
		[78530] = "Petrified Treant",
		[115385] = "Hatecoil Warrior",
		[239969] = 2,
		[45922] = 11,
		[258399] = "Argus the Unmaker",
		[31410] = "Wrathfin Myrmidon",
		[68799] = "Apothecary Frye",
		[35760] = "Greater Bogstrok",
		[11978] = "Fineous Darkvire",
		[189800] = 11,
		[149869] = "Ghamoo-Ra",
		[257376] = 5,
		[235559] = 6,
		[211146] = 3,
		[199033] = "Valarjar Aspirant",
		[195944] = "Skrog Wavecrasher",
		[212335] = "Stitchblister <Heoki-Dalaran>",
		[218774] = "Solarist Tel'arn <High Botanist Tel'arn> <High Botanist Tel'arn>",
		[229741] = "Elisande",
		[108219] = 11,
		[243652] = 10,
		[202088] = "Helya",
		[244067] = 1,
		[253282] = 7,
		[246115] = 12,
		[232084] = "Backup Singer",
		[223590] = "Dreadsoul Corruptor",
		[208232] = 5,
		[88254] = 11,
		[18100] = "Eldreth Apparition",
		[149888] = "Domina",
		[220519] = "Unknown",
		[73920] = 7,
		[132466] = 10,
		[194879] = 6,
		[185515] = "Huk'roth the Huntmaster",
		[2676] = "Ahunite Hailstone",
		[202090] = 10,
		[203698] = "Hellwarden Xaphan",
		[253284] = 5,
		[221544] = 10,
		[132467] = 10,
		[256356] = "[*] Chilled Blood",
		[203814] = 1,
		[209258] = 12,
		[32216] = 1,
		[244070] = "Varimathras",
		[70189] = "Spire Gargoyle",
		[73921] = 7,
		[197996] = 2,
		[227985] = "Coggleston",
		[15242] = "Hellfire Imp",
		[29235] = 2,
		[205180] = 9,
		[227689] = 10,
		[77505] = 7,
		[229737] = 11,
		[78529] = 5,
		[248167] = "[*] Death Fog",
		[52067] = "Crystalline Frayer",
		[230261] = 9,
		[17393] = "Lord Aurius Rivendare",
		[227690] = 10,
		[253287] = 7,
		[188783] = 1,
		[355] = 1,
		[190831] = 8,
		[62306] = "Salvaged Demolisher <Emptyrivers>",
		[209261] = 12,
		[38245] = "Talon King Ikiss",
		[227691] = 10,
		[253288] = 7,
		[221548] = 10,
		[247145] = "Saprish",
		[215405] = 8,
		[160124] = "Core Hound <Shaggybeard-Dalaran>",
		[184689] = 2,
		[243050] = "Flame Rift <Lightninggh-Shu'halo>",
		[211310] = "Felsoul Swarmer",
		[211994] = "Wyrmtongue Scavenger",
		[62124] = 2,
		[222573] = "Tricky Hellion",
		[207215] = 11,
		[6254] = "Skum",
		[47920] = 11,
		[123216] = 11,
		[101568] = 6,
		[34662] = "Swamplord Musel'ek",
		[221550] = 10,
		[12891] = "Shade of Eranikus",
		[215407] = 9,
		[241004] = "Volatile Corruption",
		[150451] = "Blindlight Rotmouth",
		[195222] = 7,
		[170357] = 3,
		[546] = 7,
		[13339] = "Highborne Summoner",
		[234129] = "Razorjaw Gladiator",
		[421] = 7,
		[62307] = "Salvaged Demolisher <Emptyrivers>",
		[151928] = "Gelatanized Plague Gunk",
		[234862] = 2,
		[86729] = "Randolph Moloch",
		[212337] = "Stitchblister <Heoki-Dalaran>",
		[79822] = 2,
		[194599] = 3,
		[119999] = "Lava Guard Gordoth",
		[30451] = 8,
		[7054] = "Tormented Officer",
		[113344] = 1,
		[203123] = 11,
		[212338] = "Stitchblister <Heoki-Dalaran>",
		[196980] = 4,
		[205649] = "Coronal Ejection",
		[223601] = "Putrid Sludge",
		[59052] = 6,
		[188802] = 10,
		[210291] = 2,
		[203124] = "Lethon",
		[33967] = "Sethekk Guard",
		[221554] = "Resolute Courtesan",
		[148859] = 5,
		[186406] = 8,
		[71366] = 11,
		[207507] = 10,
		[185719] = 8,
		[203125] = "Emeriss",
		[132764] = 3,
		[116680] = 10,
		[213376] = 10,
		[248176] = 8,
		[241009] = "Guardian Sentry",
		[15643] = "Emperor Dagran Thaurissan",
		[211999] = "Wyrmtongue Scavenger",
		[73822] = 8,
		[201363] = 1,
		[254320] = "Houndmaster",
		[227234] = "Helya",
		[248177] = 8,
		[246139] = "Zuraal the Ascended",
		[209270] = "Gul'dan",
		[245686] = 9,
		[11837] = "Chief Ukorz Sandscalp",
		[220533] = "Dread Felbat",
		[235543] = 12,
		[107203] = 2,
		[149886] = "Domina",
		[982] = 3,
		[211907] = "Scrubber",
		[209553] = 1,
		[211319] = 5,
		[5487] = 11,
		[34920] = "Ethereal Scavenger",
		[86726] = "Randolph Moloch",
		[248179] = 1,
		[118253] = 3,
		[201081] = 3,
		[210296] = 6,
		[208253] = 11,
		[245108] = "Amalgam of Torment",
		[242650] = 10,
		[123586] = 10,
		[199034] = "Valarjar Aspirant",
		[245388] = 4,
		[35570] = "Dragonflayer Overseer",
		[192432] = 4,
		[235894] = 12,
		[49712] = "Risen Drakkari Handler",
		[246133] = "Zuraal the Ascended",
		[86727] = "Randolph Moloch",
		[49256] = 5,
		[224632] = "Astrologer Jarin",
		[88263] = 2,
		[240555] = 8,
		[121820] = 7,
		[73417] = 9,
		[246134] = "Zuraal the Ascended",
		[219432] = 11,
		[68641] = "Apothecary Hummel",
		[108229] = 11,
		[58470] = "Azure Stalker",
		[202108] = "Blightshard Shaper",
		[68948] = "Apothecary Baxter",
		[228729] = "Mrs. Cauldrons",
		[221562] = 6,
		[198013] = 12,
		[174464] = "Chronarch Defender",
		[686] = 9,
		[226406] = "Emberhusk Dominator",
		[191606] = 2,
		[194942] = "Glazer",
		[204157] = 12,
		[205181] = 9,
		[202776] = 4,
		[248184] = "Void Flayer",
		[54119] = 11,
		[84169] = 5,
		[126664] = 1,
		[126481] = 11,
		[1330] = 4,
		[194506] = "Shroud Hound",
		[214397] = 2,
		[207230] = 6,
		[232827] = "Piranhado",
		[184092] = 2,
		[136583] = 4,
		[113862] = 8,
		[32693] = "Dark Rune Elementalist",
		[114886] = "[*] Frigid Grasp",
		[774] = 11,
		[252752] = 11,
		[224637] = 8,
		[39953] = 8,
		[241290] = "Tidescale Witch",
		[194945] = "Glazer",
		[207502] = "Trilliax",
		[34922] = "Nexus Terror",
		[35178] = "Bloodwarder Centurion",
		[78674] = 11,
		[224638] = "[*] Heavenly Crash",
		[184707] = 1,
		[170379] = 7,
		[61031] = 12,
		[253307] = 6,
		[180612] = 6,
		[115399] = 10,
		[252938] = 9,
		[219788] = 6,
		[225052] = "Terrace Grove-Tender",
		[35326] = "Gatewatcher Iron-Hand",
		[252284] = 4,
		[253308] = 6,
		[254332] = 2,
		[63847] = "Flame Leviathan",
		[233098] = "[*] Blazing Charge",
		[1066] = 11,
		[184709] = 1,
		[252744] = "Garothi Annihilator",
		[252285] = 4,
		[106830] = 11,
		[183407] = "[*] Acid Splatter",
		[204166] = 8,
		[209933] = 1,
		[191877] = 7,
		[233856] = "Maiden of Valor",
		[210307] = 10,
		[58984] = 11,
		[198750] = "Stormforged Obliterator",
		[68529] = 5,
		[21687] = "Viscous Fallout",
		[215427] = "Soulfiend Tagerma",
		[108199] = 6,
		[113866] = "Jandice Barov",
		[246407] = 8,
		[163212] = 10,
		[228738] = "Volatile Energy <The Curator>",
		[34477] = 3,
		[214404] = 8,
		[221573] = "Chronarch Defender",
		[15580] = "Anger'rel",
		[215430] = "Valarjar Thundercaller",
		[15708] = "Bloodwarder Slayer",
		[21688] = "Weegli Blastfuse",
		[195975] = 6,
		[202768] = 11,
		[171021] = "Cinderflare <Treshan-Stormrage>",
		[47722] = 5,
		[32182] = 7,
		[199753] = 4,
		[12051] = 8,
		[235907] = "Engine of Souls",
		[1022] = 2,
		[205191] = 2,
		[32175] = 7,
		[1044] = 2,
		[241027] = "Lylth the Silent",
		[209287] = "Wrath Ember",
		[202120] = 12,
		[117962] = 10,
		[12744] = "Abyssal Flamebringer",
		[207690] = 12,
		[213771] = 11,
		[32055] = "Quagmirran",
		[241028] = "Unknown <Lylth the Silent> <Lylth the Silent>",
		[11082] = "Electrocutioner 6000",
		[9053] = "Highborne Summoner",
		[211336] = 5,
		[36716] = "Unknown",
		[131474] = 3,
		[166211] = 5,
		[199050] = "Valarjar Shieldmaiden",
		[191617] = 11,
		[201098] = 8,
		[210320] = 2,
		[31884] = 2,
		[209744] = "Judgment's Flame",
		[197003] = 4,
		[8096] = 8,
		[256388] = "Reorigination Module",
		[89808] = "Imp <Lightninggh-Shu'halo>",
		[198030] = 12,
		[149908] = "Thruk",
		[137619] = 4,
		[45876] = 11,
		[221577] = "Astral Farseer",
		[206219] = "Gul'dan",
		[56814] = 4,
		[248201] = 4,
		[209291] = "Empowered Eye of Gul'dan",
		[210315] = "[*] Nightmare Brambles",
		[69070] = 8,
		[200329] = "Shade of Xavius",
		[205196] = "Dreadstalker <Mcwhip-Runetotem>",
		[247175] = "Saprish",
		[51819] = "Raging Construct",
		[241032] = "[*] Desolation of the Moon",
		[253321] = 3,
		[199786] = 8,
		[69968] = "Skybreaker Hierophant",
		[36717] = "Arcatraz Sentinel",
		[246152] = 3,
		[206221] = "Gul'dan",
		[199054] = 7,
		[108238] = 11,
		[209293] = "Wrath Ember",
		[218508] = "High Botanist Tel'arn",
		[227723] = 2,
		[203982] = "Taoshi",
		[246153] = 3,
		[206222] = "Gul'dan",
		[199055] = 7,
		[17465] = 6,
		[209921] = "Dargrul",
		[234891] = "Maiden of Vigilance",
		[201352] = 11,
		[245130] = "Firelord",
		[246771] = 7,
		[214418] = 10,
		[256393] = "Reorigination Module",
		[201902] = "Taintheart Deadeye",
		[16953] = 11,
		[126476] = 7,
		[27576] = 4,
		[253322] = 7,
		[1604] = "Skybreaker Summoner",
		[86738] = "Vicious Thug",
		[25912] = 2,
		[154253] = 11,
		[150601] = "Death Speaker Blackthorn",
		[202129] = 8,
		[203153] = "Ysondre",
		[201351] = 2,
		[13341] = "Sorcerous Skeleton",
		[198034] = 2,
		[115767] = 1,
		[79870] = "Lea Stonepaw",
		[50977] = 6,
		[189064] = 1,
		[781] = 3,
		[253324] = 6,
		[205202] = 2,
		[214417] = 10,
		[256396] = "Reorigination Module",
		[845] = 1,
		[224239] = 2,
		[20153] = "Cinderflare <Treshan-Stormrage>",
		[193159] = "Unknown",
		[216708] = 9,
		[206840] = "Inquisitor Vethriz",
		[238991] = "Hellblaze Temptress",
		[196543] = "Fenryr",
		[200084] = "Ghostly Retainer",
		[212818] = 12,
		[210323] = 2,
		[194316] = 8,
		[207859] = "[*] Darkened Discharge",
		[213395] = 11,
		[247183] = "Bloodfeast",
		[199061] = "Enslaved Shieldmaiden",
		[191894] = 10,
		[244726] = 8,
		[193942] = "Unstable Amalgamation",
		[22807] = 5,
		[253327] = 4,
		[229778] = 11,
		[214420] = 10,
		[241280] = "Felguard Invader",
		[15581] = "Ribbly's Crony",
		[242066] = 7,
		[188290] = 6,
		[633] = 2,
		[215446] = "Soulfiend Tagerma",
		[7951] = "Deviate Venomwing",
		[196606] = 9,
		[252707] = "Constellar Designate",
		[208278] = 6,
		[209302] = 8,
		[242303] = 1,
		[221175] = 11,
		[253329] = 4,
		[202137] = 12,
		[247186] = "Bloodfeast",
		[248210] = 4,
		[241043] = "Lylth the Silent",
		[2120] = 8,
		[131490] = 3,
		[2584] = 4,
		[229783] = 9,
		[17466] = "Lord Aurius Rivendare",
		[238996] = 2,
		[207256] = 6,
		[605] = 5,
		[238999] = "Kil'jaeden",
		[26297] = 5,
		[170397] = 6,
		[253331] = 2,
		[221591] = "Twilight Stardancer",
		[883] = 3,
		[105174] = 9,
		[62317] = "Captured Mercenary Captain",
		[36383] = "Shirrak the Dead Watcher",
		[202138] = 12,
		[197611] = 4,
		[63341] = "Mimiron",
		[156064] = 3,
		[70361] = "Spire Frostwyrm",
		[242617] = 2,
		[191900] = "Warlord Parjesh",
		[164815] = 11,
		[113141] = "Darkmaster Gandling",
		[235927] = "Reanimated Templar",
		[214423] = 12,
		[206760] = 4,
		[189853] = 11,
		[248214] = "Kin'garoth",
		[33649] = 4,
		[192925] = 4,
		[34161] = "Underbog Lurker",
		[50799] = 10,
		[27094] = 6,
		[206936] = "Coronal Ejection",
		[70362] = "Spire Frostwyrm",
		[70874] = 5,
		[257430] = 11,
		[250263] = 10,
		[243096] = 12,
		[209309] = "Voidtouched Nexus-Stalker",
		[225263] = "Essence of Nightmare",
		[90328] = "Spirit Beast <Dudon-Shandris>",
		[236524] = "Agronox",
		[207261] = "Patrol Captain Gerdo",
		[241049] = "Lylth the Silent",
		[31289] = "Foothill Stalker",
		[193951] = "Barbed Spiderling",
		[205811] = "Huk'roth the Huntmaster",
		[236954] = "Necrotic Spiderling",
		[213405] = 12,
		[55663] = "Drakkari Rhino",
		[156070] = 8,
		[219271] = 7,
		[104264] = 11,
		[121557] = 5,
		[137639] = 10,
		[98008] = 7,
		[115234] = "Thulnuz <Locrécrio-Gallywix>",
		[203097] = 6,
		[51743] = 11,
		[16827] = "Jack <Hyliia-Kargath>",
		[246519] = 5,
		[227965] = "Skeletal Usher",
		[6754] = "Coilfang Slavehandler",
		[234108] = 4,
		[17467] = "Lord Aurius Rivendare",
		[25046] = 4,
		[25914] = 2,
		[185313] = 4,
		[255609] = 6,
		[185763] = 4,
		[227742] = "Moroes",
		[61295] = 7,
		[211000] = "Nightborne Spellsword",
		[207267] = 6,
		[223647] = "Haunting Nightmare",
		[227737] = "Moroes",
		[28858] = "Ironbark Protector",
		[210337] = "[*] Nightmare Brambles",
		[93402] = 11,
		[193152] = "King Deepbeard",
		[215458] = "Spellblade Aluriel",
		[47473] = 11,
		[47729] = "Grand Magus Telestra",
		[59913] = 4,
		[64623] = "VX-001",
		[193956] = 11,
		[227744] = 1,
		[47528] = 6,
		[28730] = 8,
		[148906] = 5,
		[33395] = "Water Elemental <Dudette-Baelgun>",
		[230011] = 1,
		[209315] = "Scion of Magic",
		[210339] = 9,
		[120024] = "Lava Guard Gordoth",
		[234711] = 5,
		[188838] = 7,
		[29882] = "Crazed Mana-Surge",
		[223650] = "Haunting Nightmare",
		[231428] = 7,
		[209316] = 8,
		[185767] = 4,
		[232200] = 4,
		[204197] = 5,
		[197030] = 5,
		[150507] = "Aqua Guardian",
		[256415] = 1,
		[241057] = "Lylth the Silent",
		[31290] = "Riverpaw Poacher",
		[23227] = 1,
		[11436] = "Shadowforge Senator",
		[241672] = "Latosius",
		[221604] = "Twilight Stardancer",
		[88797] = 11,
		[240034] = 4,
		[249249] = "Bloodfeast",
		[188031] = 2,
		[210342] = "Cenarius",
		[127170] = 6,
		[198752] = "Seacursed Slaver",
		[221605] = "Gul'dan",
		[184304] = 10,
		[240673] = 5,
		[241059] = "Lylth the Silent",
		[43688] = 7,
		[243107] = "Unknown",
		[239636] = "Ixallon the Soulbreaker",
		[77535] = 6,
		[205224] = 6,
		[200105] = "Ghostly Protector",
		[248227] = "Grand Shadow-Weaver",
		[257442] = 5,
		[201129] = "Vilethorn Blossom",
		[185771] = "Felbound Infernal <Emptyrivers> <Emptyrivers>",
		[171014] = "Cinderflare <Treshan-Stormrage>",
		[198058] = "Odyn",
		[156079] = 7,
		[239013] = 10,
		[223655] = "Sludgerax",
		[188395] = "[*] Ball Lightning",
		[201123] = "Vilethorn Blossom",
		[233080] = 11,
		[203178] = 1,
		[228775] = 7,
		[107428] = 10,
		[10348] = "Leprous Technician",
		[224378] = "Celestial Acolyte",
		[257444] = 11,
		[154953] = 4,
		[185773] = "Felbound Infernal <Emptyrivers>",
		[185311] = 4,
		[226936] = "Flail of Il'gynoth",
		[225912] = "Horde Wind Rider",
		[219223] = 3,
		[215466] = "Soulfiend Tagerma",
		[39592] = "Summoned Searing Totem <Da'kesh the Elementalist>",
		[201858] = "Taintheart Deadeye",
		[202156] = "Acidic Bile",
		[207849] = "Xavius",
		[188028] = 2,
		[205228] = 2,
		[173488] = 5,
		[1064] = 7,
		[225601] = 2,
		[204774] = "Aspersius",
		[36213] = "Greater Earth Elemental <Yoiyoi-Drakkari>",
		[212396] = 3,
		[89824] = 11,
		[61447] = 7,
		[210999] = 2,
		[66787] = 9,
		[191919] = "Warlord Parjesh",
		[213624] = "[*] Mark of Frost",
		[7139] = "Fel Steed",
		[31547] = "Swamplord Musel'ek",
		[212397] = 3,
		[78050] = 5,
		[15575] = "Wrath Hammer Construct",
		[207278] = "Patrol Captain Gerdo",
		[200111] = "Shade of Xavius",
		[156073] = 4,
		[15550] = "Bog Giant",
		[195386] = 12,
		[228780] = 12,
		[205231] = "Darkglare <Lastwhisper-Darkspear>",
		[192131] = "Warlord Parjesh",
		[237578] = "Helblaze Soulmender",
		[230005] = 4,
		[193969] = "Aranasi Broodmother",
		[202160] = 8,
		[211375] = "Image of Calindris",
		[71225] = 5,
		[149943] = "Executioner Gore",
		[43381] = 11,
		[215471] = "Soulfiend Tagerma",
		[223202] = 10,
		[241267] = "Dresanoth",
		[185779] = 4,
		[35361] = "Lord Klaq",
		[187827] = 12,
		[114911] = 7,
		[59146] = "Willey Hopebreaker",
		[231854] = "Harjatan",
		[92200] = 12,
		[209329] = "Scion of Fire",
		[205223] = 6,
		[146046] = 7,
		[48168] = 2,
		[172017] = "Jibrita",
		[198067] = 7,
		[70885] = 5,
		[249261] = 4,
		[242094] = 5,
		[48920] = "King Dred",
		[236975] = "Felstrider Enforcer",
		[245166] = "Searing Overlord",
		[31956] = "Rokmar the Crackler",
		[189877] = 11,
		[223665] = 4,
		[248239] = "Grand Shadow-Weaver",
		[209331] = 2,
		[202164] = 1,
		[34423] = "Murkblood Healer",
		[245167] = "Searing Overlord",
		[205236] = 8,
		[198069] = 5,
		[199093] = "Runecarver Slave",
		[52341] = "Lightning Construct",
		[209332] = 2,
		[243120] = "Sneaky Snake <Peybear-Dalaran>",
		[215476] = 3,
		[204213] = 5,
		[205237] = 8,
		[214452] = 7,
		[37495] = 11,
		[243121] = "Sneaky Snake <Peybear-Dalaran>",
		[46198] = "Ahune",
		[202166] = 1,
		[15659] = "Darkweaver Syth",
		[245169] = "Seething Pyrelord",
		[205238] = 8,
		[202728] = "Dreadlord Mendacius",
		[11976] = "Skeletal Berserker",
		[11980] = "Twilight's Hammer Ambassador",
		[225716] = 2,
		[243122] = 6,
		[178963] = 12,
		[185782] = "Felbound Infernal <Emptyrivers> <Emptyrivers>",
		[143807] = "Shal'dorei Archmage",
		[193977] = "Ymiron, the Fallen King",
		[85222] = 2,
		[207288] = 7,
		[151998] = "Festering Spiderling",
		[202168] = 1,
		[211383] = "Lady Calindris",
		[209336] = 11,
		[17470] = "Timmy the Cruel",
		[198073] = "Smashspite the Hateful",
		[215479] = 10,
		[232885] = "Sarukel",
		[112867] = 9,
		[98021] = "Spirit Link Totem <Kâiri-Frostmourne>",
		[211384] = "Legion Hound",
		[89830] = 11,
		[53365] = 6,
		[200025] = 2,
		[68934] = "[DND] Valentine Boss - Vial Bunny",
		[245627] = "Noura, Mother of Flames",
		[225719] = 11,
		[68841] = "Apothecary Frye",
		[38520] = "Infinite Assassin",
		[171454] = 3,
		[50085] = 5,
		[209338] = 11,
		[207290] = 6,
		[64373] = 8,
		[225720] = 2,
		[48503] = 11,
		[187837] = 7,
		[196028] = "Hatecoil Arcanist",
		[190909] = 2,
		[198076] = 5,
		[215482] = "Soulfiend Tagerma",
		[212019] = 9,
		[225721] = 4,
		[237561] = "Huntress Kasparian",
		[187131] = 3,
		[157122] = 2,
		[257644] = "Varimathras",
		[198077] = "Odyn",
		[70890] = 6,
		[75192] = 5,
		[71914] = 9,
		[205164] = 6,
		[253367] = 6,
		[171457] = 3,
		[190911] = 7,
		[62326] = "Dark Rune Commoner",
		[215484] = "Soulfiend Tagerma",
		[232890] = 10,
		[225723] = 10,
		[49696] = "Risen Drakkari Soulmage",
		[162243] = 12,
		[46968] = 1,
		[205246] = 9,
		[198079] = "Smashspite the Hateful",
		[230844] = 3,
		[216509] = 10,
		[225724] = 11,
		[48504] = 11,
		[211390] = 11,
		[247226] = 5,
		[211391] = "Legion Hound",
		[198080] = "Smashspite the Hateful",
		[240059] = 2,
		[249274] = 4,
		[225725] = 11,
		[218558] = 7,
		[235964] = 12,
		[254394] = "Lah'zaruun",
		[238012] = 10,
		[114821] = 11,
		[232893] = 12,
		[52088] = "Iceshatter",
		[225726] = 6,
		[218559] = 7,
		[219583] = "Belphiar",
		[204225] = "Felguard",
		[114919] = 2,
		[249276] = "[*] Explosion",
		[85739] = 1,
		[54136] = 11,
		[163272] = 10,
		[17877] = 9,
		[235966] = 11,
		[204226] = 3,
		[69869] = "Skybreaker Sorcerer",
		[199281] = 9,
		[47737] = "Chaotic Rift <Anomalus> <Anomalus>",
		[216513] = 5,
		[242110] = 7,
		[218561] = 12,
		[235967] = 11,
		[204227] = "Felguard",
		[255594] = "Golganneth",
		[249278] = 4,
		[210371] = 2,
		[191941] = "Tirathon Saltheril",
		[225729] = 3,
		[34171] = "Underbat",
		[235968] = "Ghastly Bonewarden",
		[233298] = 10,
		[127207] = 8,
		[171017] = "Cinderflare <Treshan-Stormrage>",
		[235969] = "Fallen Priestess",
		[257470] = 11,
		[225730] = 3,
		[202181] = "Rockback Gnasher",
		[105706] = 2,
		[33702] = 9,
		[183752] = 12,
		[225731] = 3,
		[54649] = 10,
		[45946] = 6,
		[46202] = "Dark Rune Worker",
		[234946] = 5,
		[196208] = "Shadowmoon Warlock",
		[58452] = 5,
		[240066] = "Razorjaw Wavemender",
		[86765] = "Slag Fury",
		[166347] = "Felsoul Swarmer",
		[257472] = 2,
		[225732] = "Lady Velandras Ravencrest",
		[240539] = "Razorjaw Swiftfin",
		[219589] = 8,
		[35058] = "Mechanar Tinkerer",
		[232043] = 11,
		[198088] = "[*] Glowing Fragment",
		[221634] = "Braxas the Fleshcarver",
		[252897] = 10,
		[179825] = 8,
		[226757] = 8,
		[34428] = 1,
		[212423] = "Risen Skulker <Plaguefang-Detheroc>",
		[34940] = "Nexus Stalker",
		[64775] = "Sara",
		[348] = 9,
		[191946] = "Warlord Parjesh",
		[5782] = 9,
		[212236] = 1,
		[113899] = "Demonic Gateway <Flavortown-Feathermoon>",
		[34298] = "Claw",
		[238021] = 10,
		[31422] = "Aeonus",
		[224232] = 7,
		[257475] = 7,
		[196206] = "Shadowmoon Warlock",
		[203373] = "Torturer of the Inquisition",
		[211401] = "Blazing Imp",
		[235974] = "Shaggybeard-Dalaran's Erupting Reflection",
		[199116] = 7,
		[208331] = 11,
		[120043] = 7,
		[191948] = "Tirathon Saltheril",
		[225736] = 4,
		[51875] = "Unknown",
		[113900] = "Demonic Gateway <Kremlinsun-Area52>",
		[253381] = 6,
		[5137] = "Undead Postman",
		[66290] = "Balnazzar",
		[190925] = 3,
		[191949] = "Tirathon Saltheril",
		[33917] = 11,
		[202188] = 7,
		[93423] = "Baron Ashbury",
		[245191] = "Fiery Behemoth",
		[43900] = 3,
		[78578] = "Illyanna Ravenoak",
		[31551] = "Bogstrok",
		[183759] = 7,
		[49020] = 6,
		[210380] = 12,
		[130283] = 10,
		[253383] = 1,
		[53371] = 11,
		[58747] = "Felguard Annihilator",
		[190927] = 3,
		[210383] = 2,
		[225739] = 4,
		[84721] = 8,
		[93424] = "[*] Asphyxiate",
		[253384] = 1,
		[238026] = 8,
		[31935] = 2,
		[190928] = 3,
		[32191] = "Coilfang Observer",
		[239052] = "Nal'asha",
		[40317] = "Murkblood Spearman",
		[211406] = "Blazing Imp",
		[253385] = 1,
		[254409] = 3,
		[214478] = 10,
		[207311] = 6,
		[108271] = 7,
		[209359] = "Unknown",
		[202192] = "Resonance Totem <Lijiin>",
		[219598] = "Belphiar",
		[212431] = 3,
		[34942] = "Ethereal Darkcaster",
		[198097] = 4,
		[242584] = 3,
		[212105] = 12,
		[217551] = 9,
		[225635] = "Umbral Archer",
		[225737] = 12,
		[204241] = 2,
		[45181] = 4,
		[199818] = "[*] Crackle",
		[190931] = 3,
		[83699] = 5,
		[225743] = 11,
		[45524] = 6,
		[247245] = "Saprish",
		[204242] = 2,
		[241254] = "Dresanoth",
		[103153] = 5,
		[198099] = "Ursoc",
		[222824] = "Lurking Horror",
		[7057] = "Haunted Servitor",
		[40062] = "Shadowmoon Technician",
		[162264] = 12,
		[204243] = "Nightmare Dweller",
		[90355] = 3,
		[247246] = "Saprish",
		[223697] = "Rothos",
		[251952] = 12,
		[250318] = "Alleria Windrunner",
		[210387] = "Elisande",
		[118000] = 1,
		[252516] = "Norgannon",
		[252743] = "Garothi Annihilator",
		[243152] = "[*] Demonic Upheaval",
		[166361] = 5,
		[233062] = "Goroth",
		[225746] = 11,
		[194006] = "[*] Ooze Puddle",
		[81141] = 6,
		[212436] = 3,
		[45182] = 4,
		[45438] = 8,
		[207317] = 6,
		[245200] = "Blazing Phoenix",
		[165961] = 11,
		[202198] = "Stoneclaw Hunter",
		[195031] = "Seacursed Soulkeeper",
		[194657] = "Waterlogged Soul Guard",
		[238034] = 10,
		[198103] = 7,
		[207318] = 3,
		[95988] = 1,
		[244588] = "[*] Void Sludge",
		[107913] = 5,
		[213644] = 2,
		[152175] = 10,
		[192985] = "Wrath of Azshara",
		[214486] = "Star Augur Etraeus",
		[207319] = 6,
		[249298] = "Zuraal the Ascended",
		[225749] = 11,
		[50302] = "Crystalline Protector",
		[195033] = "Seacursed Soulkeeper",
		[181867] = 2,
		[34944] = "Coilfang Scale-Healer",
		[68338] = 9,
		[111859] = 9,
		[241108] = "Tidescale Legionnaire",
		[8994] = "Gordok Warlock",
		[205273] = 2,
		[235989] = "Engine of Souls",
		[196058] = "Bitterbrine Slave",
		[36992] = "Pathaleon the Calculator",
		[132578] = 10,
		[200154] = "Understone Demolisher",
		[151008] = "Splinterbone Captain",
		[243299] = "Shadow Council Warlock",
		[243157] = "Domatrax",
		[195035] = "Seacursed Soulkeeper",
		[196059] = "Bitterbrine Slave",
		[223704] = "Grisly Trapper",
		[247253] = 12,
		[231895] = 2,
		[246224] = 8,
		[225752] = 11,
		[66880] = "Acidmaw",
		[227800] = "Maiden of Virtue",
		[196060] = "Bitterbrine Slave",
		[122099] = 9,
		[157153] = 7,
		[2601] = "Shadowforge Senator",
		[151010] = "Splinterbone Warrior",
		[225753] = 11,
		[2649] = "Quilen <Peybear-Dalaran>",
		[34433] = 5,
		[196061] = 10,
		[198109] = "Ursoc",
		[247255] = 10,
		[100784] = 10,
		[249303] = "[*] Flames of Reorigination",
		[243160] = 12,
		[218587] = "Dresaron",
		[219611] = 4,
		[242627] = 10,
		[2825] = 7,
		[16170] = "Gordok Mage-Lord",
		[66811] = 1,
		[11426] = 8,
		[196027] = "Hatecoil Arcanist",
		[195036] = "Seacursed Soulkeeper",
		[221796] = 3,
		[171253] = 5,
		[68927] = "[*] Concentrated Alluring Perfume Spill",
		[70395] = "Spire Minion",
		[32065] = "Bog Giant",
		[213063] = 10,
		[69369] = 11,
		[206933] = "Crane <Poptartlove-Trollbane> <Poptartlove-Trollbane>",
		[211422] = 2,
		[204255] = 12,
		[90361] = "Jack <Hyliia-Kargath>",
		[206303] = "Inquisitor Tormentorum",
		[207327] = "Scrubber",
		[249306] = "Viceroy Nezhar",
		[211412] = "Blazing Imp",
		[16791] = "Magistrate Barthilas",
		[189182] = 5,
		[187874] = 7,
		[207906] = "Talixae Flamewreath",
		[70396] = "Spire Minion",
		[207328] = "Scrubber",
		[241116] = "Tidescale Legionnaire",
		[214692] = "Gerenth the Vile",
		[227977] = "Skeletal Usher",
		[193171] = "Unknown",
		[43649] = "Dalronn the Controller",
		[18499] = 1,
		[37250] = "Tidal Surger",
		[193585] = "Rockbound Trapper",
		[108280] = 7,
		[125174] = 10,
		[109304] = 3,
		[13730] = "Skeletal Berserker",
		[196781] = 5,
		[188389] = 7,
		[217500] = 12,
		[250333] = "Diima, Mother of Gloom",
		[200163] = 3,
		[209378] = "Imacu'tya",
		[211426] = 2,
		[235999] = 8,
		[183433] = "Tarspitter Lurker",
		[214494] = 6,
		[49537] = "The Prophet Tharon'ja",
		[57984] = "Greater Fire Elemental <Lijiin>",
		[108281] = 7,
		[50305] = 3,
		[60503] = 1,
		[227809] = "Maiden of Virtue",
		[187878] = 7,
		[221666] = "Chronarch Defender",
		[224738] = "Duskwatch Ley-Warden",
		[43650] = "Dalronn the Controller",
		[30146] = 9,
		[250335] = "Noura, Mother of Flames",
		[194022] = 5,
		[195046] = "Hatecoil Oracle",
		[196070] = "Corstilax",
		[116095] = 10,
		[30914] = "Unknown <Broggok> <Broggok>",
		[199143] = "Latosius",
		[45954] = "Unknown",
		[192999] = 10,
		[101115] = 11,
		[31554] = "Coilfang Defender",
		[200167] = 3,
		[251485] = 1,
		[230883] = 10,
		[158188] = "Unknown",
		[79614] = 5,
		[201191] = "Hatespawn Slime",
		[225764] = 9,
		[191976] = "Hyrja",
		[33076] = 5,
		[119952] = 2,
		[115450] = 10,
		[41603] = "Legion Flak Cannon",
		[191977] = "Warlord Parjesh",
		[225765] = 2,
		[194025] = 5,
		[248291] = 1,
		[118522] = 7,
		[213479] = 12,
		[198121] = 8,
		[43651] = "Skarvald the Constructor",
		[116267] = 8,
		[222695] = 7,
		[52610] = 11,
		[211432] = 10,
		[196074] = "Corstilax",
		[248292] = 1,
		[37252] = "Steam Surger",
		[199146] = "Gildedfur Stag",
		[13900] = "Lord Incendius",
		[225767] = 10,
		[218600] = "Yigthregor",
		[84714] = 8,
		[94462] = 8,
		[205290] = 2,
		[206433] = "Star Augur Etraeus",
		[150001] = "Mordresh Fire Eye",
		[47747] = "Anomalus",
		[225768] = 2,
		[243174] = 2,
		[224023] = 2,
		[236329] = "[*] Star Burn",
		[32901] = "Avian Darkhawk",
		[12551] = "Weapon Technician",
		[114062] = "Jandice Barov",
		[205292] = 9,
		[176623] = 5,
		[94463] = 1,
		[227817] = "Maiden of Virtue",
		[70460] = "Frost Freeze Trap",
		[5394] = 7,
		[51587] = "Dragonflayer Spiritualist",
		[206316] = 1,
		[171620] = 3,
		[225770] = 5,
		[209569] = 1,
		[196078] = "Amalgam of Souls",
		[30659] = "Bleeding Hollow Scryer",
		[217694] = 8,
		[30915] = "Broggok Poison Cloud <Broggok>",
		[38533] = "Rift Keeper",
		[200174] = 5,
		[225771] = 7,
		[31427] = "Underbog Shambler",
		[63106] = 9,
		[199812] = "Nal'tira",
		[152173] = 10,
		[114942] = 7,
		[199151] = "Angerhoof Bull",
		[200175] = 12,
		[225772] = 7,
		[202223] = "Acidic Bile",
		[236011] = "[*] Tormented Cries",
		[49028] = 6,
		[12323] = 1,
		[16333] = "Spectral Citizen",
		[248298] = "Skyfin",
		[119611] = 10,
		[58499] = 1,
		[202739] = 11,
		[251910] = 8,
		[187890] = 7,
		[156150] = 8,
		[51588] = "Dragonflayer Spiritualist",
		[197105] = "Hatecoil Arcanist",
		[210583] = 11,
		[225774] = 8,
		[202225] = 1,
		[211440] = 5,
		[55711] = 3,
		[18501] = "Bonechewer Ripper",
		[82691] = 8,
		[38534] = "Rift Keeper",
		[45957] = 11,
		[221680] = "Braxas the Fleshcarver",
		[248301] = "Warp Stalker",
		[211441] = 1,
		[243289] = "Inquisitor Sebilus",
		[63619] = "Shadowfiend <Leâ-Stormrage>",
		[132603] = 5,
		[215537] = 1,
		[196587] = "Amalgam of Souls",
		[225776] = 8,
		[20549] = 3,
		[211442] = 5,
		[204275] = "Skorpyron",
		[73989] = 9,
		[20805] = "Lord Pythas",
		[248302] = "Warp Stalker",
		[194037] = "Foul Mother",
		[225777] = 1,
		[29380] = "Captain Skarloc",
		[211443] = 5,
		[240606] = 11,
		[47748] = "Anomalus",
		[199656] = 10,
		[51845] = 11,
		[33111] = "Shadowmoon Warlock",
		[225778] = 2,
		[226802] = 9,
		[15587] = "Magister Kalendris",
		[212468] = "Goopcrush <Sängreal-Blackhand>",
		[192094] = "Warlord Parjesh",
		[30916] = "Broggok",
		[207349] = 6,
		[54149] = 2,
		[200182] = "Shade of Xavius",
		[203254] = "Advisor Vandros",
		[38535] = "Rift Keeper",
		[7922] = 1,
		[39047] = "Karzak the Impaler",
		[127230] = 8,
		[47750] = 5,
		[200183] = 5,
		[157503] = 7,
		[234995] = 6,
		[221158] = "Chaotoid",
		[228852] = "Attumen the Huntsman",
		[199663] = "Ghostly Councilor",
		[22945] = "Arcane Torrent",
		[202232] = "[*] Consume",
		[16838] = "Eldreth Spirit",
		[248406] = 6,
		[234996] = 6,
		[242164] = 4,
		[8676] = 4,
		[229976] = 2,
		[198137] = 2,
		[221688] = "Braxas the Fleshcarver",
		[200185] = "Shade of Xavius",
		[193018] = "King Deepbeard",
		[218615] = 9,
		[72968] = 8,
		[212472] = "Goopcrush <Sängreal-Blackhand>",
		[139777] = "Stone Sentinel",
		[132610] = 11,
		[55430] = 11,
		[246261] = 8,
		[88375] = 11,
		[241238] = "Worshiper of Elune",
		[38536] = "Rift Keeper",
		[253428] = 1,
		[39048] = "Karzak the Impaler",
		[197115] = "Hatecoil Arcanist",
		[47751] = "Anomalus",
		[224760] = 3,
		[129794] = 11,
		[218617] = 1,
		[222711] = 9,
		[186403] = 4,
		[205307] = "Fel Annihilator",
		[211545] = 11,
		[15288] = "Twilight Emissary",
		[258643] = "Kin'garoth",
		[241237] = "Razorjaw Myrmidon",
		[206675] = "Unknown",
		[85256] = 2,
		[69898] = "Skybreaker Hierophant",
		[197117] = "Piercing Tentacle",
		[29893] = 9,
		[202089] = "Burning Geode",
		[30917] = "Broggok",
		[209404] = "Duskwatch Arcanist",
		[185855] = 3,
		[225787] = 11,
		[94472] = 5,
		[73994] = 1,
		[206333] = 1,
		[11428] = "Rift Lord",
		[209406] = 11,
		[263149] = 10,
		[31429] = "Claw",
		[38537] = "Rift Lord",
		[253432] = 11,
		[39049] = "Aeonus",
		[222716] = "Taintheart Befouler",
		[120069] = "Adolescent Flame Hound",
		[32197] = "Shadowmoon Warlock",
		[217597] = 11,
		[195072] = 12,
		[72971] = 9,
		[1953] = 8,
		[64901] = 5,
		[197626] = 11,
		[192001] = 10,
		[75531] = 5,
		[209407] = 11,
		[8618] = 4,
		[211455] = 2,
		[253434] = 11,
		[192002] = 11,
		[183811] = 2,
		[17735] = "Thulnuz <Locrécrio-Gallywix>",
		[159238] = 4,
		[176644] = 10,
		[44425] = 8,
		[219647] = 4,
		[196098] = 9,
		[239101] = "Wyrmtongue Scavenger",
		[222719] = "Taintheart Befouler",
		[208385] = "[*] Tainted Discharge",
		[192003] = "Blazing Hydra Spawn",
		[80354] = 4,
		[57723] = 4,
		[38538] = "Chrono Lord Deja",
		[209410] = "Duskwatch Arcanist",
		[122161] = 11,
		[206339] = "Gul'dan",
		[248317] = "Argus the Unmaker",
		[257532] = 5,
		[233983] = "Belac",
		[200196] = 5,
		[224852] = 7,
		[253437] = 5,
		[47774] = "Alliance Berserker",
		[214530] = 5,
		[63900] = "Quilen <Shaggybeard-Dalaran> <Shaggybeard-Dalaran>",
		[192005] = "Arcane Hydra Spawn",
		[198149] = 8,
		[202244] = 11,
		[162313] = 12,
		[204292] = "Skorpyron",
		[69902] = "Kor'kron Defender",
		[206340] = "Gul'dan",
		[51849] = "Sjonnir The Ironshaper",
		[257534] = 5,
		[205306] = "Fel Annihilator",
		[53385] = 2,
		[97547] = 11,
		[85261] = 11,
		[73998] = 1,
		[38539] = "Chrono Lord Deja",
		[241233] = "Rez the Tombwatcher",
		[15588] = "Phalanx",
		[209413] = "Guardian Construct",
		[15716] = "Gordok Brute",
		[101643] = 10,
		[240209] = "[*] Unstable Soul",
		[205318] = "Aspersius",
		[40075] = "Legion Flak Cannon",
		[190984] = 11,
		[224772] = 6,
		[201223] = 9,
		[40331] = "Coilfang Engineer",
		[48778] = 6,
		[49034] = "Novos the Summoner",
		[32908] = "Proto-Drake Rider",
		[199176] = "Naraxas",
		[158221] = 10,
		[200200] = 5,
		[237137] = 11,
		[215661] = 2,
		[8613] = 4,
		[188016] = 12,
		[205320] = 10,
		[224229] = "Celestial Acolyte",
		[199177] = "Ebonclaw Worg",
		[25504] = 7,
		[88334] = 5,
		[120112] = "Corrupted Flamecaller",
		[211464] = "Felbound Enforcer",
		[2823] = 4,
		[180748] = 11,
		[197205] = 3,
		[62089] = 2,
		[124682] = 10,
		[201226] = "Bloodtainted Fury",
		[214995] = 11,
		[227847] = 1,
		[220680] = 8,
		[180749] = 7,
		[47755] = 5,
		[199179] = "Ebonclaw Worg",
		[227848] = "Maiden of Virtue",
		[201227] = "Bloodtainted Fury",
		[40332] = "Coilfang Engineer",
		[211466] = 10,
		[10341] = "Irradiated Slime",
		[65810] = "Serissa Grimdabbler",
		[230920] = "Razorjaw Waverunner",
		[215562] = 1,
		[57994] = 7,
		[135700] = 11,
		[91213] = "Mindless Horror",
		[208608] = 12,
		[58506] = "Deathstalker Commander Belmont",
		[241155] = "Lieutenant Silvermight",
		[230384] = "Mistress Sassz'ine",
		[120076] = "Mature Flame Hound",
		[120588] = 7,
		[204301] = 2,
		[218635] = "Quilen <Peybear-Dalaran>",
		[203277] = 8,
		[212492] = "Spellblade Aluriel",
		[30151] = "Shaaghun <Mcwhip-Runetotem>",
		[239113] = "Wyrmtongue Scavenger",
		[199182] = "Ebonclaw Worg",
		[88082] = "Fireandice-Zangarmarsh <Fireandice-Zangarmarsh>",
		[225803] = "[*] Sealed Magic",
		[70965] = "Nerub'ar Broodkeeper",
		[227851] = "Moroes",
		[253448] = 10,
		[254472] = 2,
		[69395] = 6,
		[114954] = 8,
		[80658] = 5,
		[225804] = "Duskwatch Weaver",
		[194064] = "Foul Mother",
		[211470] = "Shadow Mistress",
		[212494] = "Spellblade Aluriel",
		[139799] = "[*] Flame Tile",
		[49548] = "The Prophet Tharon'ja",
		[199184] = "Ebonclaw Worg",
		[200208] = "Seacursed Soulkeeper",
		[209423] = 4,
		[248289] = 2,
		[204304] = 3,
		[155158] = 8,
		[254474] = 2,
		[234062] = 1,
		[199185] = "Cursed Falke",
		[192018] = "Hyrja",
		[242188] = 1,
		[211457] = "Talixae Flamewreath",
		[248396] = "Soulblight Orb <Argus the Unmaker> <Argus the Unmaker>",
		[1784] = 4,
		[139801] = "[*] Lightning Tile",
		[247308] = 7,
		[192019] = "Night Watch Mariner",
		[232974] = "[*] Spanning Singularity",
		[225807] = "[*] Pillars of Night",
		[53148] = "Quilen <Shaggybeard-Dalaran>",
		[211473] = "Shadow Mistress",
		[196115] = "Corstilax",
		[228877] = "Elisande",
		[215969] = 6,
		[101649] = 8,
		[240607] = 11,
		[209426] = 12,
		[32911] = "Gold Shaman",
		[231952] = 6,
		[49037] = "Novos the Summoner",
		[65814] = "Serissa Grimdabbler",
		[34974] = "Swamplord Musel'ek",
		[49805] = "Scourge Reanimator",
		[208403] = 4,
		[108817] = 11,
		[225809] = "Nightborne Sage",
		[101650] = 8,
		[38059] = "Avian Warhawk",
		[246287] = 5,
		[221708] = 2,
		[195094] = "Hatecoil Warrior",
		[241168] = "Hippogryph Lord Varah",
		[192081] = 11,
		[88852] = 2,
		[211476] = "Mana Wyrm",
		[116014] = 8,
		[57755] = 1,
		[122128] = 5,
		[22857] = "Captain Kromcrush",
		[15589] = "Bloodwarder Slayer",
		[15653] = "Nightmare Wyrmkin",
		[215572] = 1,
		[211477] = "Legion Hound",
		[127797] = 11,
		[69911] = "Skybreaker Dreadblade",
		[132639] = 10,
		[23881] = 1,
		[241170] = "Hippogryph Lord Varah",
		[234003] = 10,
		[235027] = 4,
		[1725] = 4,
		[20787] = "Blazing Fireguard",
		[16458] = "Plague Ghoul",
		[130830] = 11,
		[214624] = 12,
		[48290] = 5,
		[246345] = 2,
		[68376] = 9,
		[235028] = "Maiden of Vigilance",
		[155166] = 6,
		[69912] = "Skybreaker Dreadblade",
		[234005] = 10,
		[199193] = "Latosius",
		[241172] = "[*] Lunar Bomb",
		[225814] = "Blade Dancer Illianna",
		[211191] = "Unknown <Arcane Anomaly> <Arcane Anomaly>",
		[211480] = "Captain Naranoth",
		[183897] = "High Vindicator",
		[53390] = 7,
		[247316] = 7,
		[193051] = "King Deepbeard",
		[241173] = "Umbral Guard",
		[209433] = "[*] Spanning Singularity",
		[228322] = 6,
		[221699] = 6,
		[155145] = 2,
		[19658] = "Khiidom <Maryla-Kil'jaeden>",
		[230935] = 11,
		[207386] = 11,
		[208410] = 2,
		[184662] = 2,
		[235031] = 10,
		[34914] = 5,
		[16100] = "Durnholde Rifleman",
		[227225] = 12,
		[252921] = 8,
		[199250] = "Seacursed Swiftblade",
		[241175] = "Lunar Guard",
		[254534] = 9,
		[243223] = 1,
		[50831] = "Sjonnir The Ironshaper",
		[204316] = "Skorpyron",
		[213531] = "Tichondrius",
		[247319] = 4,
		[128275] = 11,
		[30153] = "Shaaghun <Mcwhip-Runetotem>",
		[29513] = "Phantom Guest",
		[185887] = 10,
		[227913] = "Felspite Dominator",
		[195561] = "Cove Seagull",
		[186257] = 3,
		[11366] = 8,
		[22858] = "Captain Kromcrush",
		[45195] = "Nethermancer Sepethrea",
		[193055] = "Call the Seas",
		[23242] = 1,
		[195103] = "Wandering Shellback",
		[196127] = "Mak'rana Siltwalker",
		[43664] = "Proto-Drake Handler",
		[206366] = 9,
		[241263] = "Tidescale Witch",
		[24394] = "Nuthead <Gunforhire-Kel'Thuzad>",
		[195104] = "Wandering Shellback",
		[236060] = 8,
		[97560] = 5,
		[106263] = 11,
		[213534] = "Tichondrius",
		[206367] = "Gul'dan",
		[226888] = 7,
		[16843] = "Eldreth Seether",
		[117014] = 7,
		[117526] = 3,
		[195105] = "Wandering Shellback",
		[196129] = "Mak'rana Siltwalker",
		[69916] = "Skybreaker Dreadblade",
		[239132] = "Fallen Avatar",
		[3242] = "Unstable Ravager",
		[208416] = 7,
		[225822] = 1,
		[243228] = 1,
		[236061] = "Maiden of Vigilance",
		[43665] = "Dragonflayer Heartsplitter",
		[205345] = 8,
		[206369] = "Xavius",
		[201979] = 11,
		[32855] = "Auchenai Vindicator",
		[201250] = "Bloodtainted Fury",
		[202274] = 10,
		[72477] = 11,
		[228895] = "Midnight",
		[69917] = "Skybreaker Dreadblade",
		[206370] = "Gul'dan",
		[205386] = 5,
		[48017] = "Ormorok the Tree-Shaper",
		[234015] = "Belac",
		[194084] = 7,
		[195108] = "Hatecoil Stormweaver",
		[202231] = "Stoneclaw Grubmaster",
		[28105] = 10,
		[50833] = 9,
		[91419] = "Spitebone Skeleton",
		[195109] = "Hatecoil Stormweaver",
		[209443] = "Xavius",
		[235040] = 11,
		[29514] = "Phantom Guest",
		[54416] = "Moragg",
		[205348] = "[*] Orb of Destruction",
		[66847] = 8,
		[256542] = "Argus the Unmaker",
		[256544] = "Argus the Unmaker",
		[209444] = "Xavius",
		[164430] = 5,
		[22859] = "Captain Kromcrush",
		[152108] = 9,
		[78622] = 8,
		[111898] = 9,
		[91420] = "Spitebone Skeleton",
		[22987] = "Unknown <Tácolock-Stormrage>",
		[15654] = "Magister Kalendris",
		[23243] = 2,
		[48018] = 9,
		[16166] = 7,
		[243234] = "Quilen <Peybear-Dalaran>",
		[31946] = "Swamplord Musel'ek",
		[64144] = "Unknown",
		[32202] = "Seductress <Shadowmoon Summoner>",
		[32330] = "Lykul Wasp",
		[226852] = 8,
		[16460] = "Plagued Insect",
		[197161] = 3,
		[205351] = 5,
		[99100] = "Lea Stonepaw",
		[207399] = 7,
		[16844] = "Eldreth Seether",
		[193065] = 5,
		[8617] = 3,
		[17228] = "Keli'dan the Breaker",
		[8679] = 4,
		[69920] = "Skybreaker Assassin",
		[206376] = "Krosus",
		[207400] = 7,
		[43667] = "Prince Keleseth",
		[108843] = 8,
		[118038] = 1,
		[82747] = 5,
		[190025] = 2,
		[239966] = 11,
		[230950] = "Abyss Stalker",
		[199210] = "Valarjar Marksman",
		[215198] = 2,
		[209489] = "Empowered Eye of Gul'dan",
		[156000] = 6,
		[64145] = "Crusher Tentacle",
		[204330] = 7,
		[197163] = "Quilen <Peybear-Dalaran>",
		[222760] = "[*] Befoulment",
		[248357] = "Blazing Phoenix",
		[192044] = "Hyrja",
		[40340] = "Bog Overlord",
		[185901] = 3,
		[51723] = 4,
		[241240] = "Razorjaw Myrmidon",
		[90399] = "Farseer Nobundo",
		[49555] = "Trollgore",
		[248358] = "Blazing Phoenix",
		[193069] = "Felsworn Infester",
		[217642] = 10,
		[235048] = "Wrath-Lord Akrazar",
		[236072] = "Soul Queen Dejahna",
		[189998] = 9,
		[197165] = "Wrath of Azshara",
		[239144] = "Tormented Soul",
		[217668] = 11,
		[87840] = 4,
		[143924] = 2,
		[214572] = 11,
		[209477] = "Mana Wyrm",
		[200238] = "Shade of Xavius",
		[68387] = 9,
		[189999] = 7,
		[22860] = "Captain Kromcrush",
		[241193] = "Umbral Priestess",
		[207407] = 12,
		[243241] = 5,
		[211501] = "Enchanted Broodling",
		[245289] = "L'ura",
		[161332] = 5,
		[240171] = "Undersea Custodian",
		[120093] = "Corrupted Houndmaster",
		[48020] = 9,
		[242218] = 2,
		[210478] = 8,
		[236075] = "Soul Queen Dejahna",
		[196144] = "Mak'rana Siltwalker",
		[148022] = 8,
		[152118] = 5,
		[191025] = 4,
		[151094] = "Deep Terror",
		[209455] = 8,
		[228597] = 8,
		[17229] = 3,
		[93985] = 11,
		[43157] = 11,
		[119582] = 10,
		[215599] = 11,
		[192050] = "Serpentrix",
		[88354] = 11,
		[202289] = 1,
		[178740] = 12,
		[44949] = 1,
		[205361] = "Krosus",
		[53652] = 2,
		[150072] = "Aarux",
		[194099] = "The Grimewalker",
		[63891] = "Sara",
		[235054] = 10,
		[178741] = 12,
		[240192] = 2,
		[164407] = 5,
		[230959] = "Abyss Stalker",
		[79140] = 4,
		[28747] = "Sjonnir The Ironshaper",
		[225840] = "Shimmering Manaspine",
		[127271] = 8,
		[219697] = "Torturer of the Inquisition",
		[212530] = "Spellblade Aluriel",
		[106785] = 11,
		[34971] = "Claw",
		[42650] = 6,
		[192053] = "Warlord Parjesh",
		[33943] = 11,
		[194101] = "The Grimewalker",
		[195125] = 8,
		[86820] = "Riverpaw Looter",
		[225857] = "Domesticated Manasaber",
		[119584] = 11,
		[35479] = 6,
		[120096] = "Corrupted Houndmaster",
		[30283] = 9,
		[241169] = "[*] Umbra Destruction",
		[69934] = "Skybreaker Vindicator",
		[206388] = "Star Augur Etraeus",
		[17484] = 2,
		[222771] = "Taintheart Tormenter",
		[236078] = 10,
		[225856] = "[*] Poison Brambles",
		[15655] = "Risen Defender",
		[235058] = "Kil'jaeden",
		[170554] = 11,
		[242209] = 10,
		[69927] = "Skybreaker Vindicator",
		[214581] = 3,
		[200248] = "Risen Arcanist",
		[142910] = 4,
		[225844] = "VFX Bunny",
		[111400] = 9,
		[225845] = "Duskwatch Weaver",
		[245298] = 8,
		[8936] = 11,
		[239155] = "Kil'jaeden",
		[201273] = "Bloodtainted Fury",
		[33688] = "Crystalline Keeper",
		[201272] = "Bloodtainted Fury",
		[76583] = "Anvilrage Footman",
		[195129] = "Hatecoil Crusher",
		[8680] = 4,
		[205369] = 5,
		[214583] = 3,
		[191034] = 11,
		[43927] = 8,
		[225846] = "[*] Chosen Fate",
		[194106] = "The Grimewalker",
		[9128] = "Anvilrage Officer",
		[26573] = 2,
		[246324] = "Viceroy Nezhar",
		[37272] = "Bog Overlord",
		[9512] = 4,
		[241213] = "Lunar Archer",
		[225847] = "Duskwatch Weaver",
		[202298] = 2,
		[252468] = 1,
		[191043] = 3,
		[221752] = 7,
		[205370] = "Krosus",
		[214579] = 3,
		[71465] = "Sister Svalna",
		[225815] = "Blade Dancer Illianna",
		[83243] = 3,
		[196156] = "Shadowmoon Technician",
		[228920] = 1,
		[246326] = "Viceroy Nezhar",
		[150082] = "Aarux",
		[191037] = 11,
		[134723] = 10,
		[196157] = "Shadowmoon Technician",
		[59542] = 2,
		[85288] = 1,
		[245303] = "Asara, Mother of Night",
		[205372] = 5,
		[59543] = 3,
		[248375] = "Kin'garoth",
		[96039] = 10,
		[242232] = 11,
		[43928] = "Dragonflayer Metalworker",
		[209388] = 2,
		[212540] = "Unknown <Nashriel-Area52>",
		[246328] = 10,
		[58517] = "Portal Guardian",
		[108839] = 8,
		[192063] = 7,
		[225851] = "Duskwatch Warden",
		[246329] = "Asara, Mother of Night",
		[206398] = "Star Augur Etraeus",
		[204350] = 7,
		[31821] = 2,
		[239162] = "Wyrmtongue Scavenger",
		[16591] = 7,
		[63894] = "Unknown",
		[193088] = "King Deepbeard",
		[194112] = "God-King Skovald",
		[48792] = 6,
		[50841] = "Sjonnir The Ironshaper",
		[199221] = 9,
		[239163] = "Wyrmtongue Scavenger",
		[83242] = 3,
		[200256] = "Arcane Minion",
		[209471] = "Nightmare Ichor",
		[209469] = "Nightmare Ichor",
		[69930] = "Skybreaker Vindicator",
		[240169] = "Undersea Custodian",
		[34970] = "Rokmar the Crackler",
		[70444] = "[*] Explosion",
		[34969] = "Laughing Skull Rogue",
		[233021] = "[*] Infernal Spike",
		[214502] = 10,
		[33667] = 6,
		[219711] = 6,
		[240176] = "Undersea Custodian",
		[96038] = 10,
		[231363] = "Goroth",
		[231998] = "Harjatan",
		[192067] = "Hyrja",
		[225855] = "Shal'dorei Naturalist",
		[54680] = "TaterThot <Toxicpotato-EmeraldDream>",
		[13736] = "Bloodwarder Slayer",
		[241204] = "Lunar Priestess",
		[208440] = 4,
		[157256] = 5,
		[192058] = 7,
		[48025] = 2,
		[193092] = "Hymdall",
		[225859] = "Shal'dorei Naturalist",
		[243247] = 4,
		[211076] = 8,
		[164424] = 11,
		[210477] = 8,
		[83244] = 3,
		[200723] = "Dargrul",
		[193093] = "King Deepbeard",
		[4042] = 1,
		[227905] = 5,
		[100130] = 1,
		[164425] = 5,
		[222786] = "Taintheart Trickster",
		[199237] = "Ursoc",
		[200261] = "Soul-Torn Champion",
		[225858] = "Shal'dorei Naturalist",
		[212528] = "Unknown <Nashriel-Area52>",
		[215598] = 5,
		[61336] = 11,
		[209454] = "Eye of Gul'dan",
		[30926] = "Nazan",
		[83245] = 3,
		[11431] = "Lord Pythas",
		[160331] = 8,
		[23247] = 1,
		[227907] = 8,
		[239145] = "Wyrmtongue Scavenger",
		[211499] = 10,
		[198188] = "Odyn",
		[64152] = "Corruptor Tentacle",
		[56969] = "Azure Scale-Binder",
		[209478] = 2,
		[17619] = 7,
		[105771] = 1,
		[114474] = "Candlestick Mage",
		[248356] = "Blazing Phoenix",
		[16592] = "Ethereal Darkcaster",
		[242253] = 8,
		[50842] = 6,
		[242243] = 3,
		[39315] = 8,
		[227909] = 7,
		[86814] = "Riverpaw Basher",
		[59545] = 6,
		[190026] = 4,
		[70960] = "The Damned",
		[43931] = "Enslaved Proto-Drake",
		[152143] = "Gelatanized Plague Gunk",
		[157228] = 11,
		[54417] = "Moragg",
		[212552] = 6,
		[205385] = 5,
		[190027] = 11,
		[116011] = 8,
		[211543] = "Vicious Manafang",
		[225825] = "Nightborne Sage",
		[30832] = "Laughing Skull Rogue",
		[210824] = 8,
		[51856] = 11,
		[164431] = 5,
		[227872] = "Moroes",
		[64153] = "Corruptor Tentacle",
		[196111] = "Seaspray Crab",
		[197478] = "Illysanna Ravencrest",
		[202315] = "Stormwake Hydra",
		[28495] = 11,
		[241179] = "Tidescale Legionnaire",
		[113942] = 9,
		[222793] = "Lurking Horror",
		[241259] = "Dresanoth",
		[192077] = 7,
		[257296] = "Argus the Unmaker",
		[199090] = "Angerhoof Bull",
		[50843] = "Krystallus",
		[47666] = 5,
		[221770] = 2,
		[35229] = "Sporelok",
		[258018] = "Diima, Mother of Gloom",
		[19505] = "Sloonom <Benjalum-Zul'jin>",
		[209484] = 1,
		[251463] = 11,
		[226361] = "Rockbound Pelter",
		[51505] = 7,
		[221771] = 10,
		[30927] = "Liquid Fire",
		[223819] = 2,
		[124013] = 5,
		[62618] = 5,
		[200682] = "Solsten",
		[31567] = "Drakkari God Hunter",
		[196175] = "Mak'rana Hardshell",
		[119085] = 10,
		[230987] = 7,
		[15582] = "Durnholde Veteran",
		[241226] = 4,
		[200166] = 12,
		[17165] = "Risen Inquisitor",
		[203343] = 8,
		[194311] = 6,
		[205391] = "Krosus",
		[6197] = 3,
		[66868] = 1,
		[249418] = "Tarneth",
		[152150] = 4,
		[101168] = 7,
		[227917] = "Ghostly Understudy",
		[17353] = "Unknown <Willey Hopebreaker> <Willey Hopebreaker>",
		[59547] = 7,
		[51612] = "Dark Rune Scholar",
		[215570] = 1,
		[192082] = 7,
		[254308] = 7,
		[171845] = 3,
		[122158] = 11,
		[114479] = "Candlestick Mage",
		[209857] = 8,
		[249297] = "Tarneth",
		[215632] = 9,
		[32592] = 5,
		[201298] = "Bloodtainted Burster <Bloodtainted Fury>",
		[12742] = "Gordok Warlock",
		[13737] = "Gordok Reaver",
		[212561] = "Void-Touched Juggernaut",
		[32861] = "Auchenai Vindicator",
		[167898] = 8,
		[55964] = "Randolph Moloch",
		[31687] = 8,
		[248397] = 6,
		[47773] = "Grand Magus Telestra",
		[225800] = "Shal'dorei Archmage",
		[207194] = 6,
		[117418] = 10,
		[740] = 11,
		[62376] = "Flame Leviathan",
		[215127] = 4,
		[5171] = 4,
		[180750] = 8,
		[236303] = 11,
		[38540] = "Chrono Lord Deja",
		[59548] = 8,
		[11975] = "Skeletal Guardian",
		[223826] = 8,
		[159322] = 5,
		[240122] = 10,
		[200684] = "Dreadsoul Poisoner",
		[209785] = 2,
		[212564] = "Tormenting Orb <Inquisitor Tormentorum> <Inquisitor Tormentorum>",
		[197206] = 10,
		[45470] = 6,
		[15529] = "Ironhand Guardian",
		[224851] = 10,
		[69903] = "Kor'kron Defender",
		[22865] = "Gordok Warlock",
		[15593] = "Magmus",
		[196183] = "Mak'rana Hardshell",
		[31117] = 9,
		[55709] = "DEEPS <Chaoticson-BoreanTundra>",
		[64156] = "Corruptor Tentacle",
		[241234] = "Umbral Archer",
		[257533] = 5,
		[196100] = 9,
		[236115] = "Priestess Lunaspyre",
		[237139] = 11,
		[221781] = "Gul'dan",
		[198263] = "Odyn",
		[8362] = "High Priestess of Thaurissan",
		[242570] = 9,
		[209495] = "Guardian Construct",
		[2139] = 8,
		[227925] = "Ghostly Understudy",
		[224765] = 3,
		[197209] = 7,
		[150020] = "Twilight Lord Bathiel",
		[223718] = "[*] Bursting Slime",
		[192090] = 11,
		[236027] = 1,
		[225788] = 8,
		[222715] = 9,
		[107270] = 10,
		[221783] = "Gul'dan",
		[195592] = 7,
		[240213] = "Fallen Avatar",
		[257619] = "Eonar",
		[2379] = 3,
		[16511] = 4,
		[227927] = "Ghostly Understudy",
		[238466] = 10,
		[197211] = 7,
		[113136] = "Darkmaster Gandling",
		[64157] = "Corruptor Tentacle",
		[56222] = 6,
		[112948] = 8,
		[211956] = "Wyrmtongue Scavenger",
		[48719] = 5,
		[188923] = 1,
		[213594] = "Screeching Felspawn",
		[77575] = 6,
		[199260] = 5,
		[33697] = 7,
		[108853] = 8,
		[86771] = "Rumbling Earth",
		[236529] = "Huntress Kasparian",
		[227946] = 10,
		[17291] = 5,
		[70458] = 9,
		[191070] = 3,
		[200285] = 8,
		[52383] = "Lightning Construct",
		[248304] = "Shadowguard Riftstalker",
		[167410] = 5,
		[22482] = 4,
		[197214] = 7,
		[222104] = "Nightmare Amalgamation",
		[91395] = 11,
		[7154] = "Eldreth Spectre",
		[160355] = 11,
		[84793] = 11,
		[63134] = "Sara",
		[228955] = 10,
		[205406] = 10,
		[214621] = 5,
		[6770] = 4,
		[200287] = 1,
		[193536] = 4,
		[240577] = "Tidescale Combatant",
		[209874] = "Nexus-Prince Bilaal",
		[228956] = 2,
		[229980] = 10,
		[198240] = 7,
		[150118] = "Congealed Plague Gunk",
		[241243] = "Worshiper of Elune",
		[16979] = 11,
		[45444] = 11,
		[17235] = "Nerub'enkan",
		[212575] = 3,
		[199948] = "Mystic Ssa'veh",
		[35234] = "Marsh Dredger",
		[248411] = "Shadowguard Riftstalker",
		[200289] = "Shade of Xavius",
		[209387] = "Nightmare Horror",
		[54861] = 2,
		[3110] = "Kupjub <Lightninggh-Shu'halo>",
		[33750] = 7,
		[42729] = "Ingvar the Plunderer",
		[3355] = 3,
		[215648] = 3,
		[249436] = "Dark Keeper",
		[2643] = 3,
		[251484] = 1,
		[13738] = "Fleshflayer Ghoul",
		[193357] = 4,
		[127286] = 5,
		[70461] = "Frost Freeze Trap",
		[203958] = 11,
		[200291] = "Risen Scout",
		[57807] = "Kor'kron Defender",
		[243294] = "[*] Fel Slicer",
		[195172] = "Hatecoil Crusher",
		[228960] = 8,
		[15586] = "Anvilrage Medic",
		[34861] = 5,
		[248414] = "[*] Explode",
		[250334] = "Diima, Mother of Gloom",
		[196064] = "Saltscale Lurker",
		[243295] = "Accusator Gnazh",
		[207066] = 5,
		[222079] = "Felweaver Pharamere",
		[78141] = 5,
		[232698] = 5,
		[64126] = "[*] Squeeze",
		[252907] = 10,
		[217699] = "Mythana's Tentacle",
		[196555] = 12,
		[253382] = 1,
		[121474] = 4,
		[119300] = "Dark Shaman Koranthal",
		[239201] = "Gazerax",
		[15530] = "Azure Magus",
		[195037] = "Hatecoil Oracle",
		[53372] = 11,
		[111854] = "Instructor Chillheart",
		[23379] = "Bael'Gar",
		[113775] = "Jandice Barov",
		[205414] = 10,
		[86740] = "Rowdy Troublemaker",
		[47743] = "Anomalus",
		[48400] = "Frost Tomb",
		[234083] = 7,
		[243298] = "Coercitor Nixa",
		[38110] = "Cobalt Serpent",
		[8078] = "Lord Klaq",
		[246646] = "Kin'garoth",
		[224729] = 3,
		[41635] = 5,
		[129253] = 5,
		[114165] = 2,
		[194153] = 11,
		[8004] = 7,
		[17364] = 7,
		[49678] = "Ghoul Tormentor",
		[198249] = 7,
		[191556] = "Immoliant Fury",
		[232916] = "[*] Befouling Ink",
		[209512] = "Guardian Construct",
		[243300] = "Shadow Council Warlock",
		[36719] = "Arcatraz Sentinel",
		[12438] = 5,
		[32192] = "Wastewalker Slave",
		[202633] = 4,
		[124218] = 9,
		[54178] = 5,
		[38052] = "Fel Annihilator",
		[96499] = 3,
		[211561] = 2,
		[196203] = "Mak'rana Hardshell",
		[57724] = 7,
		[127802] = 8,
		[47779] = "Steward",
		[192108] = "[*] Glaive",
		[121147] = 6,
		[202347] = 11,
		[197422] = "Cordana Felsong",
		[114923] = 8,
		[246374] = "[*] Shadow Blades",
		[214634] = 8,
		[215658] = 12,
		[192109] = 7,
		[227789] = "Maiden of Virtue",
		[5302] = 1,
		[195181] = 6,
		[166355] = 5,
		[205420] = "Krosus",
		[33377] = 10,
		[215659] = 12,
		[159346] = 5,
		[209516] = "Mana Saber",
		[216521] = 10,
		[195182] = 6,
		[114493] = "Reanimated Corpse",
		[247816] = "L'ura",
		[48096] = "Keristrasza",
		[183436] = 2,
		[120517] = 5,
		[62626] = 8,
		[243305] = 10,
		[63138] = "Sara",
		[63394] = 8,
		[221804] = 2,
		[214637] = 5,
		[47780] = "Steward",
		[206220] = "Gul'dan",
		[209518] = "Eye of Gul'dan",
		[227981] = "Spectral Patron",
		[252165] = 12,
		[188017] = 5,
		[221805] = 2,
		[123709] = 11,
		[232044] = 6,
		[6262] = 11,
		[224706] = 11,
		[12169] = "Anvilrage Guardsman",
		[93505] = "Lord Walden",
		[188018] = 9,
		[84204] = 11,
		[247403] = "Harjatan",
		[207472] = 11,
		[79683] = 8,
		[227776] = "Galindre",
		[235117] = "Maiden of Vigilance",
		[81219] = "Bonechewer Beastmaster",
		[222111] = "[*] Roiling Flame",
		[221807] = "Gul'dan",
		[32857] = "Auchenai Monk",
		[6742] = "Twilight's Hammer Ambassador",
		[241261] = "Dresanoth",
		[201330] = 6,
		[101185] = 1,
		[236142] = "Engine of Souls",
		[204402] = "Dreadsoul Ruiner",
		[150377] = "Twilight Disciple",
		[239214] = "Kil'jaeden",
		[20798] = "Sandfury Shadowcaster",
		[241262] = "[*] Felburn",
		[214459] = 12,
		[210546] = "Elisande",
		[124506] = 10,
		[58875] = 7,
		[115008] = 10,
		[14443] = "Weapon Technician",
		[129250] = 5,
		[257645] = "Aman'Thul",
		[201332] = 3,
		[235120] = "Shaggybeard-Dalaran's Erupting Reflection",
		[211571] = "Eredar Chaosbringer",
		[196213] = "Corstilax",
		[197237] = 4,
		[239216] = "Kil'jaeden",
		[211881] = 12,
		[235956] = "Reanimated Templar",
		[211927] = "Chronomatic Anomaly",
		[80353] = 8,
		[214003] = "Risen Swordsman",
		[45323] = 11,
		[403] = 7,
		[9672] = "Skeletal Guardian",
		[698] = 9,
		[208501] = 3,
		[201334] = 12,
		[78054] = 5,
		[23381] = "Druid of the Fang",
		[225119] = 8,
		[221812] = 8,
		[15979] = "Arcane Aberration",
		[207283] = 8,
		[218543] = 11,
		[239022] = "Helblaze Imp",
		[202359] = 11,
		[8150] = "Mutanus the Devourer",
		[242583] = 2,
		[102547] = 11,
		[71160] = "Stinky",
		[8364] = "Skeletal Guardian",
		[527] = 5,
		[225909] = "Rook Spiderling",
		[202360] = 11,
		[201350] = 2,
		[17366] = "Instructor Galford",
		[34984] = "Coilfang Ray",
		[212084] = 12,
		[246751] = 8,
		[216695] = 9,
		[34933] = "Mana Leech",
		[235125] = "[*] Unstable Soul",
		[147891] = 10,
		[188027] = 9,
		[156287] = 1,
		[214648] = 12,
		[119381] = 10,
		[204205] = 3,
		[215871] = 7,
		[199589] = "Helarjar Mistcaller",
		[603] = 9,
		[204410] = 3,
		[225249] = "Deathroot Ancient",
		[197763] = 5,
		[232055] = 10,
		[208506] = "Trilliax",
		[104773] = 9,
		[251509] = 1,
		[227410] = "Galindre",
		[241680] = "Mistress Sassz'ine",
		[205691] = 3,
		[206459] = "Avatar of Shadow",
		[223865] = "Putrid Sludge",
		[216698] = 9,
		[38925] = "Mechanar Tinkerer",
		[251510] = 1,
		[234244] = 12,
		[188030] = 11,
		[237568] = "Felborne Botanist",
		[198269] = "Archdruid Glaidalis",
		[248439] = 1,
		[253952] = "Voidmaw",
		[36107] = 11,
		[202365] = "Runecarver Slave",
		[241663] = 8,
		[703] = 4,
		[107574] = 1,
		[30933] = "Illyanna Ravenoak",
		[240249] = "[*] Molten Fel",
		[62374] = "Flame Leviathan",
		[207887] = "Talixae Flamewreath",
		[212071] = "General Xakal",
		[77130] = 7,
		[589] = 5,
		[11820] = "Mechanized Guardian",
		[70475] = "Putricide's Trap",
		[241635] = "Maiden of Vigilance",
		[209786] = 4,
		[755] = 9,
		[33834] = "Epoch Hunter",
		[164857] = 3,
		[188033] = 4,
		[202147] = 1,
		[49576] = 6,
		[16727] = "King Gordok",
		[783] = 11,
		[225917] = "Rook Spiderling",
		[15043] = "Gordok Mage-Lord",
		[211583] = 9,
		[188034] = 6,
		[63468] = 3,
		[206464] = "Coronal Ejection",
		[193505] = "Vileshard Hulk",
		[241276] = "Dresanoth",
		[242300] = 1,
		[44457] = 8,
		[227966] = "Skeletal Usher",
		[188035] = 11,
		[227493] = "Attumen the Huntsman",
		[228352] = 10,
		[66893] = 1,
		[75596] = 5,
		[225919] = 12,
		[226943] = 5,
		[236158] = "Soul Residue",
		[22842] = 11,
		[69965] = "Kor'kron Defender",
		[871] = 1,
		[64167] = "Unknown",
		[183941] = 2,
		[234111] = 11,
		[12042] = 8,
		[228260] = 5,
		[62318] = "Captured Mercenary Soldier",
		[213634] = 5,
		[197628] = 11,
		[107570] = 1,
		[50089] = "Novos the Summoner",
		[225921] = 12,
		[153226] = "Blindlight Razorjaw",
		[115203] = 10,
		[150528] = "Death's Head Arachnomancer",
		[135029] = "Water Elemental <Dudette-Baelgun>",
		[253939] = "Voidmaw",
		[207813] = "Star Augur Etraeus",
		[200325] = "Risen Scout",
		[209540] = 2,
		[218755] = "Festerhide Grizzly",
		[191615] = 11,
		[192231] = "Liquid Magma Totem <Crispyz-Mal'Ganis>",
		[197721] = 11,
		[22743] = "Eldreth Spirit",
		[80396] = 10,
		[192135] = "Hatecoil Shellbreaker <Warlord Parjesh>",
		[234114] = 7,
		[224001] = 12,
		[118089] = 11,
		[113724] = 8,
		[69967] = "Skybreaker Vicar",
		[239234] = 10,
		[64168] = "Laughing Skull",
		[204779] = "Aspersius",
		[234115] = 2,
		[215443] = "Elerethe Renferal",
		[252545] = 6,
		[17294] = "Fras Siabi",
		[203525] = 3,
		[234896] = "Maiden of Vigilance",
		[207495] = "Unknown <Gudashs-Azralon>",
		[16856] = "King Gordok",
		[33964] = "Sethekk Ravenguard",
		[32682] = "Time-Lost Shadowmage",
		[42772] = "Dragonflayer Strategist",
		[77647] = 5,
		[205448] = 5,
		[30849] = "Mage Slayer",
		[221189] = "Fulminant",
		[192138] = "Hatecoil Crestrider <Warlord Parjesh>",
		[214416] = 10,
		[223057] = "Nightmother",
		[193938] = "Unstable Amalgamation",
		[196234] = 9,
		[195597] = 5,
		[233292] = 10,
		[193941] = "Embershard Scorpion",
		[236548] = "Unknown",
		[238688] = "Stranglevine Lasher",
		[243333] = 11,
		[54954] = "Ticking Bomb <Dragonflayer Strategist> <Dragonflayer Strategist>",
		[18197] = 10,
		[69969] = "Skybreaker Summoner",
		[206474] = "Tichondrius",
		[207498] = 7,
		[208929] = "Corruptor Tentacle",
		[193164] = "Blade Dancer Illianna",
		[29581] = "Phantom Guest",
		[113996] = 5,
		[200721] = "Dargrul",
		[214989] = "Spirit of Vengeance",
		[183416] = 2,
		[199053] = 7,
		[67410] = 5,
		[242735] = "Crane <Poptartlove-Trollbane> <Poptartlove-Trollbane>",
		[236546] = 5,
		[252550] = 6,
		[45334] = 11,
		[69970] = "Skybreaker Luminary",
		[203795] = 12,
		[236547] = "Huntress Kasparian",
		[197637] = 11,
		[192619] = "Wrath of Azshara",
		[203796] = 12,
		[199051] = "Oakheart",
		[253575] = 11,
		[197262] = "Helya",
		[157331] = "Primal Storm Elemental <Conectado-Ragnaros>",
		[61967] = "Dark Rune Acolyte",
		[241289] = "Dresanoth",
		[72226] = 11,
		[1454] = 9,
		[93520] = "Lord Godfrey",
		[212621] = 3,
		[198603] = "Jailhound",
		[70483] = 9,
		[47788] = 5,
		[104271] = 6,
		[209017] = "Burning Ember",
		[194192] = 9,
		[204624] = "Taoshi",
		[226322] = 12,
		[197264] = "Helya",
		[123725] = 10,
		[178207] = 1,
		[181383] = "Mana Hunter",
		[201360] = 6,
		[215429] = "Valarjar Thundercaller",
		[195217] = "Hatecoil Arcanist",
		[204432] = 3,
		[69972] = "Skybreaker Summoner",
		[78675] = 11,
		[243073] = 7,
		[200732] = "Dargrul",
		[201361] = "Tormented Bloodseeker",
		[44461] = 8,
		[113999] = "Rattlegore",
		[196242] = "Dreadlord Mendacius",
		[61611] = 11,
		[59752] = 2,
		[60181] = "Azure Sorceror",
		[200338] = "Dargrul",
		[6807] = 11,
		[67032] = 9,
		[227983] = "Spectral Patron",
		[245389] = 4,
		[69973] = "Skybreaker Summoner",
		[127174] = 5,
		[233497] = 9,
		[233444] = "Atrigan",
		[1766] = 4,
		[14189] = 4,
		[105809] = 2,
		[253581] = 10,
		[220543] = 5,
		[255629] = 5,
		[20825] = "Guzzling Patron",
		[1822] = 11,
		[201364] = 1,
		[202388] = 12,
		[236176] = 9,
		[124081] = 10,
		[69974] = "Skybreaker Marksman",
		[198293] = 7,
		[86949] = 8,
		[224914] = 4,
		[201365] = "Tormented Bloodseeker",
		[190456] = 1,
		[203413] = 3,
		[15341] = "Private Rocknot",
		[213652] = 2,
		[207995] = 7,
		[240273] = "Deep Stalker",
		[240670] = 11,
		[245069] = "Nightmarish Horror",
		[1966] = 4,
		[227987] = "Coggleston",
		[31704] = "The Black Stalker",
		[69975] = "Skybreaker Marksman",
		[19236] = 5,
		[2006] = 5,
		[200343] = "Risen Archer",
		[236479] = 11,
		[97108] = 1,
		[203415] = 3,
		[212630] = "Malfurion Stormrage",
		[2060] = 5,
		[66392] = 9,
		[240275] = "Deep Stalker",
		[200344] = "Risen Archer",
		[186258] = 3,
		[235156] = 9,
		[151684] = "Ghamoo-Ra",
		[196249] = "Dreadlord Mendacius",
		[772] = 1,
		[206488] = "[*] Arcane Seepage",
		[51886] = 7,
		[200345] = "Risen Archer",
		[239745] = "[*] Anguish",
		[207806] = "Patrol Captain Gerdo",
		[24117] = 11,
		[81751] = 5,
		[150665] = "[*] Redeemed Soil",
		[42803] = 11,
		[207513] = "Trilliax",
		[15538] = "Ironhand Guardian",
		[201078] = 3,
		[209839] = "Diffusion",
		[187146] = 1,
		[215864] = 7,
		[197506] = "Creeping Doom",
		[204433] = 3,
		[64173] = "Brain of Yogg-Saron",
		[256826] = 1,
		[201371] = 5,
		[51499] = "Dark Rune Worker",
		[204147] = 3,
		[15285] = "Phalanx",
		[171389] = 5,
		[198300] = 7,
		[240279] = "[*] Fel Strike",
		[102383] = 11,
		[209563] = 8,
		[117588] = "Primal Fire Elemental <Futama-Drakkari>",
		[93527] = "Lord Walden",
		[253590] = 6,
		[197277] = 2,
		[3604] = "Gordok Hound",
		[248471] = "Flame Hound",
		[192158] = "Olmyr the Enlightened",
		[246136] = "Zuraal the Ascended",
		[10444] = 7,
		[211311] = "Felsoul Swarmer",
		[179872] = 9,
		[246424] = 10,
		[30937] = "Shadowmoon Channeler",
		[2948] = 8,
		[241305] = "Razorjaw Acolyte",
		[225947] = 1,
		[218780] = "[*] Plasma Explosion",
		[223596] = "Dreadsoul Corruptor",
		[87091] = 4,
		[216125] = 9,
		[157348] = "Primal Storm Elemental <Conectado-Ragnaros>",
		[248473] = 3,
		[241306] = "Razorjaw Acolyte",
		[201375] = "Seacursed Slaver",
		[126507] = 5,
		[195949] = 12,
		[42776] = 6,
		[106839] = 11,
		[198304] = 1,
		[107863] = 11,
		[228528] = "Reformed Maiden",
		[209567] = 1,
		[12654] = 8,
		[58867] = "Spirit Wolf <Runthejewels-Draenor>",
		[204448] = "Skorpyron",
		[205472] = 8,
		[3716] = "Thulnuz <Locrécrio-Gallywix>",
		[215711] = 6,
		[206920] = "Nightmare Tentacle",
		[209568] = "Expedient Elemental",
		[210652] = 7,
		[236189] = 12,
		[253595] = 6,
		[205473] = 8,
		[214688] = "Gerenth the Vile",
		[231489] = 9,
		[150616] = "Death Speaker Blackthorn",
		[234142] = 2,
		[205741] = "Xavius",
		[227999] = "Ghostly Philanthropist",
		[27285] = 9,
		[54369] = "Zuramat the Obliterator",
		[22835] = "Stomper Kreeg",
		[65490] = "Brienna Nightfell",
		[64431] = 11,
		[234143] = 2,
		[191628] = 10,
		[219809] = 6,
		[253597] = 6,
		[194640] = "Waterlogged Soul Guard",
		[247454] = 12,
		[158377] = 11,
		[192660] = 4,
		[239967] = 10,
		[183218] = 2,
		[228001] = "Ghostly Philanthropist",
		[188070] = 7,
		[29492] = "Phantom Guest",
		[247455] = 12,
		[199486] = 5,
		[241312] = "Razorjaw Acolyte",
		[53209] = 3,
		[235169] = 12,
		[155741] = 3,
		[204453] = "Hellwarden Xaphan",
		[230050] = "Abstract Nullifier",
		[255647] = 2,
		[238523] = 4,
		[203859] = 1,
		[227406] = "Elfyra",
		[211796] = 12,
		[183058] = 1,
		[196263] = 6,
		[189096] = 6,
		[255648] = "Golganneth",
		[227408] = 3,
		[200359] = "Shade of Xavius",
		[32346] = "Exarch Maladaar",
		[194216] = "Harbaron",
		[5384] = 3,
		[175456] = 3,
		[204829] = "Fel Slime",
		[115546] = 10,
		[207527] = 7,
		[158792] = 11,
		[203867] = 4,
		[202408] = "Runecarver Slave",
		[206641] = "Trilliax",
		[245706] = "Shadowguard Champion",
		[245803] = "Darkfang",
		[239268] = "Nal'asha",
		[86636] = "Lord Overheat",
		[114871] = 2,
		[156779] = 2,
		[194218] = "Harbaron",
		[219815] = "Chronomatic Anomaly",
		[212648] = "[*] Mark of Frost Explosion",
		[213672] = 11,
		[206505] = 3,
		[248484] = "Searing Overlord",
		[49708] = "Darkweb Recluse",
		[209577] = 1,
		[204031] = 11,
		[54962] = "Dragonflayer Strategist",
		[55218] = "Gal'darah",
		[221864] = "Recursive Elemental",
		[239270] = 10,
		[182957] = 10,
		[175790] = 6,
		[31602] = "Nerub'enkan",
		[5246] = 1,
		[7384] = 1,
		[204459] = "Skorpyron",
		[221865] = 9,
		[49587] = 5,
		[182958] = 10,
		[211897] = "Scrubber",
		[217770] = "[*] Gaze of Vethriz",
		[205756] = 9,
		[93535] = "Lord Walden",
		[163505] = 11,
		[205484] = 1,
		[255654] = 11,
		[248487] = "Talar Icechill",
		[257702] = 8,
		[234153] = 9,
		[7896] = "Weapon Technician",
		[31467] = "Chrono Lord Deja",
		[15572] = "Gordok Reaver",
		[48082] = "Crystalline Frayer",
		[209043] = 4,
		[22876] = "Wandering Eye of Kilrogg",
		[193702] = "[*] Infernal Flames",
		[225963] = "Risen Companion",
		[194223] = 11,
		[228011] = "Mrs. Cauldrons",
		[212653] = 8,
		[205486] = "Star Augur Etraeus",
		[193659] = "God-King Skovald",
		[53595] = 2,
		[72189] = 11,
		[194675] = "Blazing Imp",
		[31976] = "Infinite Saboteur",
		[114014] = 4,
		[32731] = "Spitebone Flayer",
		[246442] = 9,
		[33206] = 5,
		[24050] = "Sethekk Spirit",
		[185495] = "Huk'roth the Huntmaster",
		[200652] = 2,
		[210607] = 7,
		[50868] = "Krystallus",
		[51124] = 6,
		[17501] = "Crimson Cannon <Mswanenburg-Quel'Thalas>",
		[68947] = "Apothecary Baxter",
		[199345] = "Dresaron",
		[49710] = "Drakkari Gutripper",
		[6552] = 1,
		[195617] = 6,
		[228014] = "Ghostly Philanthropist",
		[245420] = 8,
		[213680] = 11,
		[228200] = "Luminore",
		[255935] = "Constellar Designate",
		[224943] = "Felsworn Chaos-Mage",
		[54452] = 5,
		[153272] = 2,
		[195710] = 11,
		[55220] = "Rhino Spirit <Gal'darah>",
		[69989] = "Skybreaker Marksman",
		[47541] = 6,
		[126393] = "Quilen <Peybear-Dalaran>",
		[48053] = "Crystalline Frayer",
		[121183] = 2,
		[259756] = 1,
		[191616] = 11,
		[196644] = 5,
		[224377] = "Infernal Imp <Talixae Flamewreath>",
		[206515] = "Gul'dan",
		[16414] = 4,
		[195802] = 11,
		[33975] = "Instructor Galford",
		[50613] = 6,
		[228017] = "Ghostly Philanthropist",
		[220850] = 8,
		[214802] = 6,
		[206516] = "Gul'dan",
		[224510] = "Duskwatch Battle-Magus",
		[15087] = "Dope'rel",
		[201397] = "Seacursed Soulkeeper",
		[198590] = 9,
		[195254] = "Amalgam of Souls",
		[196278] = 9,
		[15407] = 5,
		[239281] = "[*] Viscous Webs",
		[223923] = "Corrupted Totem <Dire Shaman>",
		[223176] = 10,
		[235423] = "Fel Cannon <Emptyrivers>",
		[194231] = "Harbaron",
		[228019] = "Mrs. Cauldrons",
		[209700] = 1,
		[189112] = 12,
		[15801] = "Dark Rune Theurgist",
		[79206] = 7,
		[211110] = 11,
		[201399] = "Dreadfire Imp",
		[194232] = "Harbaron",
		[114018] = 4,
		[188089] = 7,
		[205495] = 7,
		[17439] = "Black Guard Sentry",
		[13376] = "Molten War Golem",
		[200376] = 2,
		[201400] = "Dreadfire Imp",
		[218806] = "Unknown <High Botanist Tel'arn>",
		[173958] = 9,
		[213786] = 11,
		[221878] = 2,
		[181947] = "Felbound Imp",
		[248499] = "Argus the Unmaker",
		[208568] = "Blightborn Sludge",
		[193210] = "Ash'Golm",
		[218807] = "High Botanist Tel'arn",
		[17767] = "Korrothion <Raff-Detheroc>",
		[188091] = 9,
		[31900] = "Nascent Fel Orc",
		[198330] = "Skjal",
		[235572] = "Fallen Avatar",
		[208569] = "[*] Corrupting Essence",
		[125282] = 8,
		[251572] = "[*] Soulburst Detonation",
		[54966] = "Dragonflayer Ironhelm",
		[197499] = 5,
		[32375] = 5,
		[203581] = 1,
		[187707] = 3,
		[134851] = 10,
		[88423] = 11,
		[235191] = 9,
		[81256] = 6,
		[224173] = 5,
		[246454] = "[*] Fueled by Torment",
		[260229] = "Aruun the Darkener",
		[255175] = 12,
		[183998] = 2,
		[200656] = 2,
		[210619] = "Corrupted Wisp",
		[75] = 3,
		[92266] = "Irradiated Pillager",
		[164545] = 11,
		[59830] = 2,
		[51125] = "Searing Gaze",
		[96103] = 1,
		[159031] = "Stonetooth",
		[194238] = 5,
		[73066] = 9,
		[204477] = 3,
		[221883] = 2,
		[123040] = 5,
		[22878] = "Netherwalker <Wandering Eye of Kilrogg>",
		[11504] = "Walking Bomb",
		[209597] = "Elisande",
		[124503] = 10,
		[221153] = "Pulsauron",
		[221333] = "Searing Infernal",
		[164547] = 11,
		[195250] = "Skjal",
		[16553] = "Ghoul Ravener",
		[5740] = 9,
		[152261] = 2,
		[11922] = 11,
		[33778] = 11,
		[30639] = "Shattered Hand Warhound",
		[221885] = 2,
		[255673] = 4,
		[1543] = 3,
		[25054] = "Risen Priest",
		[201408] = 11,
		[46406] = "Ahunite Coldwave",
		[190336] = 8,
		[204480] = 3,
		[221886] = 2,
		[157382] = "Primal Storm Elemental <Conectado-Ragnaros>",
		[120166] = "Corrupted Reaver",
		[233149] = 8,
		[13298] = "Undead Scarab <Nerub'enkan>",
		[45242] = 5,
		[46424] = 11,
		[204481] = 10,
		[221887] = 2,
		[71661] = 9,
		[250692] = 10,
		[233150] = 2,
		[201410] = 5,
		[127365] = 11,
		[211649] = 5,
		[229055] = 10,
		[246461] = 2,
		[157384] = 3,
		[71021] = "Deathbound Ward",
		[120679] = 3,
		[209602] = "Advisor Melandrus",
		[222024] = 6,
		[120954] = 10,
		[204483] = "Skorpyron",
		[208637] = "[*] Starfall",
		[234660] = "Dread Vizier Gra'tork",
		[20831] = "Mana Remnant",
		[208579] = 12,
		[244899] = "Noura, Mother of Flames",
		[250148] = 2,
		[236224] = "Captain Yathae Moonstrike",
		[196293] = "Stormwake Hydra",
		[246463] = 2,
		[1752] = 4,
		[207556] = "[*] Heated Ground",
		[200389] = 11,
		[152267] = "[*] Frozen Bomb",
		[25058] = "Mage Hunter Initiate",
		[81261] = 11,
		[30686] = "Omor the Unscarred",
		[246464] = 2,
		[35054] = "Dark Rune Champion",
		[107882] = 11,
		[241345] = "Defensive Countermeasure",
		[201414] = 6,
		[63815] = "Razorscale",
		[252071] = 11,
		[63550] = "Guardian Lasher",
		[207999] = 7,
		[15487] = 5,
		[202663] = "Fel Scorcher",
		[48058] = "Crystalline Frayer",
		[201415] = 10,
		[80750] = "Balnazzar",
		[81262] = "Efflorescence <Lanati-BurningLegion>",
		[196296] = "Stormwake Hydra",
		[180938] = 5,
		[53490] = "Gwen <Löngbow-Barthilas>",
		[199368] = "Soul of Ravencrest",
		[32364] = "Nexus-Prince Shaffar",
		[234180] = "[*] Sear",
		[194249] = 5,
		[91776] = "Blightcrawler <Yauco-Uldaman>",
		[212679] = 3,
		[43195] = 11,
		[7038] = 1,
		[65648] = "Aerial Command Unit",
		[197858] = "Swirling Pool",
		[222997] = "Shadowfeather",
		[18144] = "Avian Warhawk",
		[235188] = 12,
		[212680] = 3,
		[238501] = 7,
		[23972] = "Liquid Fire",
		[57819] = 1,
		[108396] = 9,
		[157898] = 9,
		[207776] = 1,
		[211657] = 5,
		[118635] = 10,
		[197470] = 5,
		[244917] = "[*] Dark Demise",
		[232135] = "Silver Forks",
		[224968] = 8,
		[80240] = 9,
		[202443] = 12,
		[65209] = "Guardian of Yogg-Saron <Ominous Cloud>",
		[196300] = 9,
		[51514] = 7,
		[54850] = "Drakkari Colossus",
		[215754] = "Spawn of Serpentrix <Quinnharper-Dalaran>",
		[167152] = 8,
		[12542] = "Gordok Captain",
		[218826] = 1,
		[211659] = "[*] Arcane Tether",
		[192434] = 4,
		[7067] = 2,
		[35261] = "Sunseeker Netherbinder",
		[199373] = "Army of the Dead <Heoki-Dalaran>",
		[192206] = "[*] Sanctify",
		[168657] = 8,
		[228254] = "Forlorn Spirit",
		[222026] = 6,
		[155347] = 5,
		[213708] = 11,
		[61882] = 7,
		[744] = "Deviate Adder",
		[46012] = 7,
		[210152] = 12,
		[202446] = 12,
		[195279] = "Night Watch Mariner",
		[221036] = "Corrupted Vermin",
		[11825] = "Mechanized Guardian",
		[239306] = 10,
		[182993] = 2,
		[62400] = "Flame Leviathan",
		[152277] = 1,
		[145110] = 11,
		[254176] = "Sister of the Lash",
		[196304] = 9,
		[8599] = "Flame Hound",
		[6201] = 9,
		[240331] = 7,
		[224973] = "[*] Shadow Cleave",
		[209615] = "Elisande",
		[146308] = 11,
		[199888] = 10,
		[188114] = "Rokmora",
		[110959] = 8,
		[51012] = "Dark Matter",
		[240332] = 7,
		[224974] = "Abyss Watcher",
		[225998] = "Soul-Torn Champion",
		[199890] = 9,
		[236237] = 12,
		[11327] = 4,
		[230094] = "Abstract Nullifier",
		[6713] = "Risen Guardsman",
		[13489] = "Burning Spirit",
		[195457] = 4,
		[152280] = 6,
		[235214] = "[*] Light Infusion",
		[211665] = 4,
		[242894] = "Damaged Golem",
		[110960] = 8,
		[196608] = 10,
		[64187] = "Stormcaller Brundir",
		[111762] = "Scholomance Neophyte",
		[201427] = 12,
		[38130] = 11,
		[195284] = "Restless Tides",
		[5116] = 3,
		[205523] = 10,
		[8281] = "Coilfang Oracle",
		[232144] = "Silver Forks",
		[191728] = 6,
		[201428] = 12,
		[210643] = 7,
		[186588] = "Lea Stonepaw",
		[117952] = 10,
		[148187] = 10,
		[214739] = "Shadowmoon Technician",
		[257926] = 9,
		[15089] = 5,
		[16430] = "Thuzadin Necromancer",
		[5374] = 4,
		[81269] = 11,
		[22120] = "Dark Rune Protector",
		[197334] = "Cordana Felsong",
		[222101] = "Felweaver Pharamere",
		[15537] = "High Priestess of Thaurissan",
		[15601] = 1,
		[201430] = 3,
		[210645] = "Withered Fiend",
		[211669] = 4,
		[204502] = "Shade of Xavius",
		[127344] = 6,
		[255696] = 7,
		[243982] = "Kil'jaeden",
		[177380] = "Gul'dan",
		[166646] = 10,
		[235219] = 8,
		[178906] = 12,
		[32736] = "Gold Warrior",
		[2061] = 5,
		[245522] = "Shadowguard Voidbender",
		[124273] = 10,
		[16866] = "Venom Belcher",
		[242387] = 10,
		[50622] = 1,
		[196834] = 7,
		[8690] = "Meteinu",
		[35008] = "Rokmar the Crackler",
		[214743] = 12,
		[211196] = "Rotten Drake",
		[224982] = "Abyss Watcher",
		[88438] = 11,
		[194266] = "Shackled Servitor",
		[211672] = 4,
		[80362] = "Kresh",
		[230102] = 12,
		[45503] = 11,
		[124274] = 10,
		[207076] = 9,
		[232670] = 9,
		[210649] = 11,
		[38592] = "Temporus",
		[107079] = 10,
		[198959] = "Valarjar Runecarver",
		[215267] = 11,
		[199387] = 10,
		[224984] = "Abyss Watcher",
		[242390] = 10,
		[227041] = 9,
		[195292] = 6,
		[184250] = 2,
		[201002] = 5,
		[206555] = "Gul'dan",
		[124275] = 10,
		[192221] = 10,
		[215270] = 11,
		[210651] = 7,
		[216099] = "Mechanical Bomb Squirrel <Shemrahboo-Zul'jin>",
		[220890] = 6,
		[86392] = 4,
		[239320] = "Felstrider Orbcaster",
		[199389] = "Dresaron",
		[120692] = 5,
		[209628] = "Advisor Melandrus",
		[202461] = 11,
		[162530] = 10,
		[191727] = 6,
		[205533] = 7,
		[206557] = "Trilliax",
		[207815] = "Patrol Captain Gerdo",
		[208605] = 12,
		[22574] = "Gordok Captain",
		[124555] = 11,
		[38593] = "Temporus",
		[82061] = 11,
		[198386] = "Archdruid Glaidalis",
		[60234] = 7,
		[204019] = 2,
		[113629] = "Boneweaver",
		[209630] = "[*] Piercing Gale",
		[218845] = 5,
		[238992] = 1,
		[220893] = "Akaari's Soul",
		[213726] = "Ghoulchick-Sargeras",
		[206559] = "Trilliax",
		[16739] = 7,
		[208607] = 12,
		[193249] = 6,
		[210655] = 11,
		[252634] = "Constellar Designate",
		[237276] = "Thrashbite the Scornful",
		[49639] = "Trollgore",
		[35266] = "Sunseeker Astromage",
		[215775] = 8,
		[192226] = "Unknown <Crispyz-Mal'Ganis>",
		[2983] = 4,
		[213243] = 12,
		[216974] = 6,
		[204513] = 12,
		[123254] = 5,
		[198912] = 1,
		[199394] = "Earlnoc the Beastbreaker",
		[201594] = 3,
		[37592] = "Unknown",
		[235230] = "Belac",
		[236507] = "Soul Queen Dejahna",
		[253660] = 11,
		[13874] = "Anvilrage Officer",
		[222944] = 1,
		[228279] = "Spectral Attendant",
		[241374] = "Defensive Countermeasure",
		[224515] = "Nobleborn Warpcaster",
		[210658] = 7,
		[138130] = "Unknown",
		[243968] = "[*] Torment of Flames",
		[89752] = 11,
		[20707] = 9,
		[248542] = "Grolethax",
		[208611] = 12,
		[110740] = 11,
		[235232] = "Eredar Bloodmage",
		[60119] = 1,
		[186289] = 3,
		[157978] = 8,
		[157981] = 8,
		[197908] = 10,
		[120696] = 5,
		[242400] = 10,
		[210660] = 7,
		[32365] = "Nexus-Prince Shaffar",
		[15346] = "Fineous Darkvire",
		[231306] = 12,
		[198374] = "Skeletal Warrior",
		[207589] = 2,
		[224995] = "Dreadguard",
		[173951] = 7,
		[194279] = 3,
		[93564] = "Lord Godfrey",
		[55233] = 6,
		[31842] = 2,
		[193473] = "Void Tendril <Velyse-Korgath>",
		[209191] = "Gul'dan",
		[208614] = 12,
		[149893] = "Domina",
		[235235] = 8,
		[15610] = "Grim Patron",
		[220901] = 4,
		[232378] = 11,
		[190185] = "Unknown <Diabloux-Darkspear>",
		[16740] = "Stomper Kreeg",
		[241379] = "Defensive Countermeasure",
		[50370] = "Steelforged Defender",
		[235236] = "Belac",
		[146159] = 5,
		[230259] = 9,
		[187700] = 3,
		[214985] = 4,
		[88748] = 2,
		[104316] = 9,
		[62042] = "Thorim",
		[210664] = 11,
		[48094] = "Keristrasza",
		[57820] = 6,
		[205545] = 1,
		[214326] = 10,
		[27827] = 5,
		[83839] = 11,
		[217832] = 12,
		[245585] = "Shadowguard Conjurer",
		[148396] = 4,
		[4962] = "Crypt Beast",
		[205546] = 1,
		[198379] = "Archdruid Glaidalis",
		[215785] = 7,
		[228273] = "Spectral Sentry",
		[193260] = "[*] Static Field",
		[129914] = 10,
		[219881] = 11,
		[236380] = 8,
		[205547] = 1,
		[114864] = "Bored Student",
		[72891] = 9,
		[208619] = 1,
		[33989] = "Time-Lost Scryer",
		[108211] = 4,
		[195309] = "[*] Swirling Water",
		[6434] = "Laughing Skull Rogue",
		[230121] = 12,
		[242597] = 2,
		[183633] = "Rockbound Pelter",
		[104318] = "Wild Imp <Mcwhip-Runetotem>",
		[185071] = 10,
		[202477] = 10,
		[73090] = 9,
		[30691] = "Nazan",
		[205549] = "Naraxas",
		[202581] = 11,
		[11443] = "Death's Head Necrolyte",
		[225003] = "Dreadguard",
		[156004] = 6,
		[35946] = "Drakkari God Hunter",
		[234411] = "[*] Dark Bomb",
		[111803] = 11,
		[189168] = 5,
		[206574] = "[*] Resonant Slash",
		[199407] = 10,
		[208622] = "Corrupted Defender",
		[199519] = "Helarjar Mistcaller",
		[210670] = 11,
		[216413] = 2,
		[234397] = "Dread Houndmaster",
		[116670] = 10,
		[109248] = 3,
		[194918] = 6,
		[75651] = 5,
		[191848] = "Serpentrix",
		[243435] = 10,
		[68996] = 11,
		[25572] = 11,
		[121536] = 5,
		[19131] = "Risen Guardsman",
		[35183] = "Bloodwarder Centurion",
		[219498] = "Patrol Captain Gerdo",
		[208828] = 12,
		[191858] = "[*] Toxic Puddle",
		[228078] = 6,
		[190837] = 8,
		[213363] = 3,
		[255723] = 11,
		[142073] = 9,
		[108416] = 9,
		[193267] = "Unknown <Ularogg Cragshaper> <Ularogg Cragshaper>",
		[205179] = 9,
		[89809] = 11,
		[147193] = 5,
		[131476] = 5,
		[255724] = 5,
		[198533] = "Jade Serpent Statue <Lolenah>",
		[36341] = "Sunseeker Engineer",
		[198028] = "[*] Crystalline Ground",
		[62320] = "Dark Rune Warbringer",
		[215433] = "Valarjar Mystic",
		[214411] = 10,
		[115072] = 10,
		[198388] = "Ursoc",
		[207603] = 2,
		[203163] = "Felspite Dominator",
		[208284] = 11,
		[209308] = "Voidtouched Nexus-Stalker",
		[203508] = 10,
		[204532] = 3,
		[231843] = 2,
		[214771] = "Faceless Voidcaster",
		[195509] = 11,
		[208628] = 12,
		[88452] = 11,
		[210873] = 7,
		[195318] = 10,
		[224210] = 7,
	},
	["encounter_spell_pool"] = {
		{
			2052, -- [1]
			"Maiden of Vigilance", -- [2]
		}, -- [1]
		{
			1100, -- [1]
			"Skybreaker Marksman", -- [2]
		}, -- [2]
		[164815] = {
			2054, -- [1]
			11, -- [2]
		},
		[198079] = {
			1834, -- [1]
			"Smashspite the Hateful", -- [2]
		},
		[192706] = {
			1814, -- [1]
			"Wrath of Azshara", -- [2]
		},
		[69902] = {
			1100, -- [1]
			"Skybreaker Protector", -- [2]
		},
		[211897] = {
			1867, -- [1]
			"Scrubber", -- [2]
		},
		[236717] = {
			2050, -- [1]
			"Priestess Lunaspyre", -- [2]
		},
		[198080] = {
			1834, -- [1]
			"Smashspite the Hateful", -- [2]
		},
		[218806] = {
			1886, -- [1]
			"Unknown <High Botanist Tel'arn>", -- [2]
		},
		[22833] = {
			363, -- [1]
			"Stomper Kreeg", -- [2]
		},
		[43667] = {
			2026, -- [1]
			"Prince Keleseth", -- [2]
		},
		[246697] = {
			2066, -- [1]
			"Shadowguard Subjugator", -- [2]
		},
		[244906] = {
			2067, -- [1]
			"[*] Collapsing Void", -- [2]
		},
		[33688] = {
			2011, -- [1]
			"Crystalline Keeper", -- [2]
		},
		[104318] = {
			2052, -- [1]
			"Wild Imp <Exorcistaa-TolBarad> <Exorcistaa-TolBarad>", -- [2]
		},
		[245674] = {
			2073, -- [1]
			"Torment of Khaz'goroth", -- [2]
		},
		[192708] = {
			1814, -- [1]
			"Arcane Bomb", -- [2]
		},
		[69903] = {
			1100, -- [1]
			"Skybreaker Protector", -- [2]
		},
		[228019] = {
			1957, -- [1]
			"Mrs. Cauldrons", -- [2]
		},
		[191941] = {
			1815, -- [1]
			"Tirathon Saltheril", -- [2]
		},
		[220855] = {
			1838, -- [1]
			"[*] Down Draft", -- [2]
		},
		[223414] = {
			1886, -- [1]
			"[*] Parasitic Fetter", -- [2]
		},
		[48849] = {
			1977, -- [1]
			"King Dred", -- [2]
		},
		[42772] = {
			2026, -- [1]
			"Dragonflayer Strategist", -- [2]
		},
		[200898] = {
			1850, -- [1]
			"Inquisitor Tormentorum", -- [2]
		},
		[244653] = {
			2065, -- [1]
			"Zuraal the Ascended", -- [2]
		},
		[227254] = {
			1964, -- [1]
			"The Curator", -- [2]
		},
		[201411] = {
			1838, -- [1]
			"Dreadfire Imp", -- [2]
		},
		[33625] = {
			1143, -- [1]
			"Gold Shaman", -- [2]
		},
		[48082] = {
			2012, -- [1]
			"Crystalline Frayer", -- [2]
		},
		[213182] = {
			1871, -- [1]
			"Spellblade Aluriel", -- [2]
		},
		[32365] = {
			1899, -- [1]
			"Nexus-Prince Shaffar", -- [2]
		},
		[18100] = {
			364, -- [1]
			"Eldreth Apparition", -- [2]
		},
		[232885] = {
			2037, -- [1]
			"Sarukel", -- [2]
		},
		[80780] = {
			480, -- [1]
			"Shrieking Banshee", -- [2]
		},
		[200901] = {
			1806, -- [1]
			"Solsten", -- [2]
		},
		[235956] = {
			2054, -- [1]
			"Reanimated Templar", -- [2]
		},
		[206019] = {
			1850, -- [1]
			"Lingering Corruption", -- [2]
		},
		[243121] = {
			2054, -- [1]
			"Sneaky Snake <Peybear-Dalaran>", -- [2]
		},
		[196296] = {
			1813, -- [1]
			"Stormwake Hydra", -- [2]
		},
		[227257] = {
			1964, -- [1]
			"The Curator", -- [2]
		},
		[248239] = {
			2067, -- [1]
			"Grand Shadow-Weaver", -- [2]
		},
		[209602] = {
			1870, -- [1]
			"Advisor Melandrus", -- [2]
		},
		[244657] = {
			2065, -- [1]
			"Zuraal the Ascended", -- [2]
		},
		[206020] = {
			1850, -- [1]
			"[*] Corrupted Touch", -- [2]
		},
		[30926] = {
			1892, -- [1]
			"Nazan", -- [2]
		},
		[206788] = {
			1867, -- [1]
			"Trilliax", -- [2]
		},
		[196809] = {
			2052, -- [1]
			"T'uure <Aethelstan-Blackhand>", -- [2]
		},
		[15547] = {
			1144, -- [1]
			"Riverpaw Poacher", -- [2]
		},
		[191948] = {
			1815, -- [1]
			"Tirathon Saltheril", -- [2]
		},
		[215233] = {
			1873, -- [1]
			"Dominator Tentacle", -- [2]
		},
		[15659] = {
			1903, -- [1]
			"Darkweaver Syth", -- [2]
		},
		[211907] = {
			1867, -- [1]
			"Scrubber", -- [2]
		},
		[197834] = {
			1864, -- [1]
			4, -- [2]
		},
		[191949] = {
			1815, -- [1]
			"Tirathon Saltheril", -- [2]
		},
		[196811] = {
			1825, -- [1]
			"T'uure <Tes-Nesingwary>", -- [2]
		},
		[31598] = {
			1893, -- [1]
			"Bleeding Hollow Darkcaster", -- [2]
		},
		[244916] = {
			2067, -- [1]
			"Umbral Tentacle", -- [2]
		},
		[151010] = {
			1665, -- [1]
			"Splinterbone Warrior", -- [2]
		},
		[192206] = {
			1806, -- [1]
			"[*] Sanctify", -- [2]
		},
		[114942] = {
			1866, -- [1]
			"Unknown <Deekie-Zul'jin>", -- [2]
		},
		[11837] = {
			600, -- [1]
			"Chief Ukorz Sandscalp", -- [2]
		},
		[207815] = {
			1868, -- [1]
			"Patrol Captain Gerdo", -- [2]
		},
		[119420] = {
			1443, -- [1]
			"Adarogg", -- [2]
		},
		[49555] = {
			1974, -- [1]
			"Trollgore", -- [2]
		},
		[251570] = {
			2092, -- [1]
			"Argus the Unmaker", -- [2]
		},
		[206792] = {
			1867, -- [1]
			"Trilliax", -- [2]
		},
		[196813] = {
			2052, -- [1]
			"T'uure <Aethelstan-Blackhand>", -- [2]
		},
		[188114] = {
			1790, -- [1]
			"Rokmora", -- [2]
		},
		[246454] = {
			2048, -- [1]
			"[*] Fueled by Torment", -- [2]
		},
		[195791] = {
			1825, -- [1]
			"Corstilax", -- [2]
		},
		[34267] = {
			1945, -- [1]
			"Ghaz'an", -- [2]
		},
		[227776] = {
			1957, -- [1]
			"Galindre", -- [2]
		},
		[221891] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[205771] = {
			1864, -- [1]
			"Lurking Terror <Xavius> <Xavius>", -- [2]
		},
		[30639] = {
			1893, -- [1]
			"Shattered Hand Warhound", -- [2]
		},
		[3589] = {
			480, -- [1]
			"Shrieking Banshee", -- [2]
		},
		[5137] = {
			1885, -- [1]
			"Undead Postman", -- [2]
		},
		[34971] = {
			1947, -- [1]
			"Claw", -- [2]
		},
		[193234] = {
			1805, -- [1]
			"[*] Dancing Blade", -- [2]
		},
		[30927] = {
			1892, -- [1]
			"Liquid Fire", -- [2]
		},
		[22835] = {
			363, -- [1]
			"Stomper Kreeg", -- [2]
		},
		[22899] = {
			349, -- [1]
			"Immol'thar", -- [2]
		},
		[150504] = {
			1671, -- [1]
			"Twilight Aquamancer", -- [2]
		},
		[227267] = {
			1964, -- [1]
			"The Curator", -- [2]
		},
		[69911] = {
			1100, -- [1]
			"Skybreaker Dreadblade", -- [2]
		},
		[211659] = {
			1849, -- [1]
			"[*] Arcane Tether", -- [2]
		},
		[34268] = {
			1945, -- [1]
			"Ghaz'an", -- [2]
		},
		[206798] = {
			1867, -- [1]
			"[*] Toxic Slice", -- [2]
		},
		[23379] = {
			235, -- [1]
			"Bael'Gar", -- [2]
		},
		[236224] = {
			2050, -- [1]
			"Captain Yathae Moonstrike", -- [2]
		},
		[236480] = {
			2050, -- [1]
			"[*] Glaive Storm", -- [2]
		},
		[226757] = {
			2038, -- [1]
			8, -- [2]
		},
		[253880] = {
			2067, -- [1]
			"Twilight-Harbinger Tharuul", -- [2]
		},
		[69912] = {
			1100, -- [1]
			"Skybreaker Dreadblade", -- [2]
		},
		[226246] = {
			1825, -- [1]
			"Withered Fiend", -- [2]
		},
		[25778] = {
			1947, -- [1]
			"Underbog Lord", -- [2]
		},
		[107270] = {
			2038, -- [1]
			10, -- [2]
		},
		[227270] = {
			1964, -- [1]
			"Volatile Energy <The Curator>", -- [2]
		},
		[209615] = {
			1872, -- [1]
			"Elisande", -- [2]
		},
		[13005] = {
			1907, -- [1]
			"Captain Skarloc", -- [2]
		},
		[62415] = {
			1130, -- [1]
			"Jormungar Behemoth", -- [2]
		},
		[195031] = {
			1822, -- [1]
			"Seacursed Soulkeeper", -- [2]
		},
		[234180] = {
			2038, -- [1]
			"[*] Sear", -- [2]
		},
		[196567] = {
			1807, -- [1]
			"Fenryr", -- [2]
		},
		[211152] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[240066] = {
			2036, -- [1]
			"Razorjaw Wavemender", -- [2]
		},
		[224970] = {
			1862, -- [1]
			"Felsworn Shadowblade", -- [2]
		},
		[257978] = {
			2088, -- [1]
			"Kin'garoth", -- [2]
		},
		[13341] = {
			1145, -- [1]
			"Enraged Fire Elemental", -- [2]
		},
		[195033] = {
			1822, -- [1]
			"Seacursed Soulkeeper", -- [2]
		},
		[30832] = {
			1920, -- [1]
			"Infinite Assassin", -- [2]
		},
		[194266] = {
			1823, -- [1]
			"Shackled Servitor", -- [2]
		},
		[194522] = {
			2038, -- [1]
			8, -- [2]
		},
		[1943] = {
			1864, -- [1]
			4, -- [2]
		},
		[16791] = {
			482, -- [1]
			"Magistrate Barthilas", -- [2]
		},
		[15580] = {
			243, -- [1]
			"Anger'rel", -- [2]
		},
		[210387] = {
			1872, -- [1]
			"Elisande", -- [2]
		},
		[204502] = {
			1839, -- [1]
			"Shade of Xavius", -- [2]
		},
		[50198] = {
			2010, -- [1]
			"Mage Hunter Initiate", -- [2]
		},
		[195035] = {
			1822, -- [1]
			"Seacursed Soulkeeper", -- [2]
		},
		[207573] = {
			1854, -- [1]
			"Ysondre", -- [2]
		},
		[119299] = {
			1443, -- [1]
			"Adarogg", -- [2]
		},
		[177380] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[224973] = {
			1862, -- [1]
			"[*] Shadow Cleave", -- [2]
		},
		[249793] = {
			2073, -- [1]
			"Noura, Mother of Flames", -- [2]
		},
		[195036] = {
			1822, -- [1]
			"Seacursed Soulkeeper", -- [2]
		},
		[195292] = {
			1866, -- [1]
			"Rune Weapon <Sunara-CenarionCircle>", -- [2]
		},
		[195804] = {
			1825, -- [1]
			"Corstilax", -- [2]
		},
		[200154] = {
			1793, -- [1]
			"Molten Charskin <Dargrul> <Dargrul>", -- [2]
		},
		[17399] = {
			478, -- [1]
			"Balnazzar", -- [2]
		},
		[255935] = {
			2092, -- [1]
			"Constellar Designate", -- [2]
		},
		[69916] = {
			1100, -- [1]
			"Skybreaker Dreadblade", -- [2]
		},
		[119300] = {
			1444, -- [1]
			"Dark Shaman Koranthal", -- [2]
		},
		[11902] = {
			594, -- [1]
			"Gahz'rilla", -- [2]
		},
		[111752] = {
			1426, -- [1]
			"Scholomance Neophyte", -- [2]
		},
		[64144] = {
			1143, -- [1]
			"Unknown", -- [2]
		},
		[8040] = {
			585, -- [1]
			"Lady Anacondra", -- [2]
		},
		[198109] = {
			1841, -- [1]
			"Ursoc", -- [2]
		},
		[62417] = {
			1130, -- [1]
			"Jormungar Behemoth", -- [2]
		},
		[227279] = {
			1964, -- [1]
			"The Curator", -- [2]
		},
		[64592] = {
			1130, -- [1]
			"Algalon the Observer", -- [2]
		},
		[69917] = {
			1100, -- [1]
			"Skybreaker Dreadblade", -- [2]
		},
		[199389] = {
			1838, -- [1]
			"Dresaron", -- [2]
		},
		[211927] = {
			1865, -- [1]
			"Chronomatic Anomaly", -- [2]
		},
		[14189] = {
			1864, -- [1]
			4, -- [2]
		},
		[253891] = {
			2067, -- [1]
			"Twilight-Harbinger Tharuul", -- [2]
		},
		[120069] = {
			1443, -- [1]
			"Adolescent Flame Hound", -- [2]
		},
		[232142] = {
			1957, -- [1]
			"Silver Forks", -- [2]
		},
		[48920] = {
			1977, -- [1]
			"King Dred", -- [2]
		},
		[30641] = {
			1893, -- [1]
			"Watchkeeper Gargolmar", -- [2]
		},
		[206555] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[239819] = {
			2038, -- [1]
			"[*] Dark Mark", -- [2]
		},
		[235214] = {
			2052, -- [1]
			"[*] Light Infusion", -- [2]
		},
		[64145] = {
			1143, -- [1]
			"Crusher Tentacle", -- [2]
		},
		[232144] = {
			1957, -- [1]
			"Silver Forks", -- [2]
		},
		[236494] = {
			2038, -- [1]
			"Fallen Avatar", -- [2]
		},
		[16856] = {
			367, -- [1]
			"King Gordok", -- [2]
		},
		[206557] = {
			1867, -- [1]
			"Trilliax", -- [2]
		},
		[204766] = {
			1849, -- [1]
			"Crystalline Scorpid", -- [2]
		},
		[209628] = {
			1870, -- [1]
			"Advisor Melandrus", -- [2]
		},
		[197858] = {
			1824, -- [1]
			"Swirling Pool", -- [2]
		},
		[12654] = {
			2038, -- [1]
			8, -- [2]
		},
		[36383] = {
			1890, -- [1]
			"Shirrak the Dead Watcher", -- [2]
		},
		[23381] = {
			590, -- [1]
			"Lord Serpentis", -- [2]
		},
		[252616] = {
			2092, -- [1]
			"Constellar Designate", -- [2]
		},
		[42780] = {
			2026, -- [1]
			"Dragonflayer Ironhelm", -- [2]
		},
		[206303] = {
			1850, -- [1]
			"Inquisitor Tormentorum", -- [2]
		},
		[206559] = {
			1867, -- [1]
			"Trilliax", -- [2]
		},
		[227285] = {
			1964, -- [1]
			"The Curator", -- [2]
		},
		[69920] = {
			1100, -- [1]
			"Skybreaker Assassin", -- [2]
		},
		[236241] = {
			2054, -- [1]
			"[*] Soul Rot", -- [2]
		},
		[206560] = {
			1867, -- [1]
			"Trilliax", -- [2]
		},
		[208863] = {
			1872, -- [1]
			"Elisande", -- [2]
		},
		[227542] = {
			1961, -- [1]
			"Lady Catriona Von'Indi", -- [2]
		},
		[207328] = {
			1867, -- [1]
			"Scrubber", -- [2]
		},
		[247245] = {
			2066, -- [1]
			"Saprish", -- [2]
		},
		[190185] = {
			2052, -- [1]
			"Spirit Wolf <Mangolassie-Lightbringer>", -- [2]
		},
		[102417] = {
			2038, -- [1]
			11, -- [2]
		},
		[227543] = {
			1957, -- [1]
			"Elfyra", -- [2]
		},
		[213726] = {
			1143, -- [1]
			"Ghoulchick-Sargeras", -- [2]
		},
		[230358] = {
			2037, -- [1]
			"Mistress Sassz'ine", -- [2]
		},
		[119433] = {
			1445, -- [1]
			"Slagmaw", -- [2]
		},
		[247246] = {
			2066, -- [1]
			"Saprish", -- [2]
		},
		[208865] = {
			1872, -- [1]
			"Elisande", -- [2]
		},
		[227800] = {
			1954, -- [1]
			"Maiden of Virtue", -- [2]
		},
		[240594] = {
			2038, -- [1]
			"Fallen Avatar", -- [2]
		},
		[227545] = {
			1961, -- [1]
			"Baroness Dorothea Millstipe", -- [2]
		},
		[235989] = {
			2054, -- [1]
			"Engine of Souls", -- [2]
		},
		[244433] = {
			2065, -- [1]
			"Zuraal the Ascended", -- [2]
		},
		[195561] = {
			1813, -- [1]
			"Cove Seagull", -- [2]
		},
		[119434] = {
			1445, -- [1]
			"Slagmaw", -- [2]
		},
		[6713] = {
			1885, -- [1]
			"Risen Guardsman", -- [2]
		},
		[198376] = {
			1836, -- [1]
			"Archdruid Glaidalis", -- [2]
		},
		[206820] = {
			1867, -- [1]
			"Trilliax", -- [2]
		},
		[198888] = {
			1807, -- [1]
			"Storm Drake", -- [2]
		},
		[114061] = {
			1427, -- [1]
			"Jandice Barov", -- [2]
		},
		[16793] = {
			482, -- [1]
			"Magistrate Barthilas", -- [2]
		},
		[89753] = {
			2048, -- [1]
			"Felguard <Pocomaxa-Spirestone>", -- [2]
		},
		[241108] = {
			2036, -- [1]
			"Tidescale Legionnaire", -- [2]
		},
		[223197] = {
			1854, -- [1]
			"Rothos", -- [2]
		},
		[193260] = {
			1805, -- [1]
			"[*] Static Field", -- [2]
		},
		[230362] = {
			2037, -- [1]
			"Electrifying Jellyfish", -- [2]
		},
		[202472] = {
			1824, -- [1]
			"Helya", -- [2]
		},
		[257997] = {
			2088, -- [1]
			"Kin'garoth", -- [2]
		},
		[50842] = {
			1866, -- [1]
			"Rune Weapon <Sunara-CenarionCircle>", -- [2]
		},
		[114062] = {
			1427, -- [1]
			"Jandice Barov", -- [2]
		},
		[226269] = {
			1827, -- [1]
			"Forgotten Spirit", -- [2]
		},
		[249298] = {
			2065, -- [1]
			"Zuraal the Ascended", -- [2]
		},
		[198379] = {
			1836, -- [1]
			"Archdruid Glaidalis", -- [2]
		},
		[198635] = {
			1835, -- [1]
			"Kur'talos Ravencrest", -- [2]
		},
		[198891] = {
			1822, -- [1]
			"Seacursed Slaver", -- [2]
		},
		[242390] = {
			2038, -- [1]
			10, -- [2]
		},
		[21687] = {
			378, -- [1]
			"Viscous Fallout", -- [2]
		},
		[221153] = {
			1865, -- [1]
			"Pulsauron", -- [2]
		},
		[198892] = {
			1807, -- [1]
			"Storm Drake", -- [2]
		},
		[150020] = {
			1671, -- [1]
			"Twilight Lord Bathiel", -- [2]
		},
		[4962] = {
			480, -- [1]
			"Crypt Beast", -- [2]
		},
		[14030] = {
			227, -- [1]
			"Anvilrage Warden", -- [2]
		},
		[199916] = {
			1850, -- [1]
			"Faceless Voidcaster", -- [2]
		},
		[196078] = {
			1832, -- [1]
			"Amalgam of Souls", -- [2]
		},
		[64532] = {
			1138, -- [1]
			"VX-001", -- [2]
		},
		[7057] = {
			1070, -- [1]
			"Haunted Servitor", -- [2]
		},
		[236507] = {
			2054, -- [1]
			"Soul Queen Dejahna", -- [2]
		},
		[58839] = {
			1889, -- [1]
			"Stolen Soul", -- [2]
		},
		[253907] = {
			2067, -- [1]
			"Twilight-Harbinger Tharuul", -- [2]
		},
		[151813] = {
			1671, -- [1]
			"Twilight Lord Bathiel", -- [2]
		},
		[91419] = {
			1071, -- [1]
			"Spitebone Skeleton", -- [2]
		},
		[199918] = {
			1850, -- [1]
			"Faceless Voidcaster", -- [2]
		},
		[237276] = {
			2057, -- [1]
			"Thrashbite the Scornful", -- [2]
		},
		[188404] = {
			1805, -- [1]
			"Storm Drake", -- [2]
		},
		[199151] = {
			1807, -- [1]
			"Angerhoof Bull", -- [2]
		},
		[57688] = {
			1143, -- [1]
			"Unknown", -- [2]
		},
		[86814] = {
			1144, -- [1]
			"Riverpaw Basher", -- [2]
		},
		[235230] = {
			2048, -- [1]
			"Belac", -- [2]
		},
		[167935] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[211178] = {
			1877, -- [1]
			"Rotten Drake", -- [2]
		},
		[91420] = {
			1071, -- [1]
			"Spitebone Skeleton", -- [2]
		},
		[193267] = {
			1791, -- [1]
			"Unknown <Ularogg Cragshaper> <Ularogg Cragshaper>", -- [2]
		},
		[241116] = {
			2036, -- [1]
			"Tidescale Legionnaire", -- [2]
		},
		[69927] = {
			1100, -- [1]
			"Skybreaker Vindicator", -- [2]
		},
		[207853] = {
			1864, -- [1]
			"[*] Blackened Tainting", -- [2]
		},
		[58840] = {
			1889, -- [1]
			"Stolen Soul", -- [2]
		},
		[233441] = {
			2048, -- [1]
			"Atrigan", -- [2]
		},
		[91677] = {
			1072, -- [1]
			"Pustulant Monstrosity", -- [2]
		},
		[249306] = {
			2067, -- [1]
			"Viceroy Nezhar", -- [2]
		},
		[221160] = {
			1865, -- [1]
			"Pulsauron", -- [2]
		},
		[17466] = {
			484, -- [1]
			"Lord Aurius Rivendare", -- [2]
		},
		[63894] = {
			1143, -- [1]
			"Unknown", -- [2]
		},
		[198388] = {
			1841, -- [1]
			"Ursoc", -- [2]
		},
		[192759] = {
			1864, -- [1]
			4, -- [2]
		},
		[252634] = {
			2092, -- [1]
			"Constellar Designate", -- [2]
		},
		[206577] = {
			1863, -- [1]
			"Star Augur Etraeus", -- [2]
		},
		[233444] = {
			2048, -- [1]
			"Atrigan", -- [2]
		},
		[192760] = {
			1864, -- [1]
			4, -- [2]
		},
		[236515] = {
			2054, -- [1]
			"Fallen Priestess", -- [2]
		},
		[204275] = {
			1849, -- [1]
			"Skorpyron", -- [2]
		},
		[15230] = {
			1921, -- [1]
			"Unknown", -- [2]
		},
		[250333] = {
			2073, -- [1]
			"Diima, Mother of Gloom", -- [2]
		},
		[193273] = {
			1791, -- [1]
			"Ularogg Cragshaper", -- [2]
		},
		[236516] = {
			2050, -- [1]
			"[*] Twilight Volley", -- [2]
		},
		[703] = {
			1864, -- [1]
			4, -- [2]
		},
		[200182] = {
			1839, -- [1]
			"Shade of Xavius", -- [2]
		},
		[235237] = {
			2048, -- [1]
			"Belac", -- [2]
		},
		[241634] = {
			2052, -- [1]
			"Maiden of Vigilance", -- [2]
		},
		[215279] = {
			2038, -- [1]
			"Chaos Tear <Deán-EarthenRing>", -- [2]
		},
		[250334] = {
			2073, -- [1]
			"Diima, Mother of Gloom", -- [2]
		},
		[7713] = {
			1885, -- [1]
			"Undead Postman", -- [2]
		},
		[207859] = {
			1864, -- [1]
			"[*] Darkened Discharge", -- [2]
		},
		[225003] = {
			1862, -- [1]
			"Dreadguard", -- [2]
		},
		[241635] = {
			2052, -- [1]
			"Maiden of Vigilance", -- [2]
		},
		[20825] = {
			241, -- [1]
			"Guzzling Patron", -- [2]
		},
		[236518] = {
			2050, -- [1]
			"Priestess Lunaspyre", -- [2]
		},
		[16827] = {
			2052, -- [1]
			"MOTA", -- [2]
		},
		[11504] = {
			382, -- [1]
			"Walking Bomb", -- [2]
		},
		[206581] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[241636] = {
			2052, -- [1]
			"Maiden of Vigilance", -- [2]
		},
		[235751] = {
			2055, -- [1]
			"Agronox", -- [2]
		},
		[236519] = {
			2050, -- [1]
			"[*] Moon Burn", -- [2]
		},
		[23224] = {
			1070, -- [1]
			"Baron Silverlaine", -- [2]
		},
		[200185] = {
			1839, -- [1]
			"Shade of Xavius", -- [2]
		},
		[17307] = {
			483, -- [1]
			"Ramstein the Gorger", -- [2]
		},
		[34662] = {
			1947, -- [1]
			"Swamplord Musel'ek", -- [2]
		},
		[214771] = {
			1850, -- [1]
			"Faceless Voidcaster", -- [2]
		},
		[17435] = {
			484, -- [1]
			"Lord Aurius Rivendare", -- [2]
		},
		[210166] = {
			1792, -- [1]
			"[*] Toxic Retch", -- [2]
		},
		[86820] = {
			1144, -- [1]
			"Riverpaw Looter", -- [2]
		},
		[206840] = {
			1866, -- [1]
			"Inquisitor Vethriz", -- [2]
		},
		[55964] = {
			1146, -- [1]
			"Randolph Moloch", -- [2]
		},
		[37605] = {
			1919, -- [1]
			"Aeonus", -- [2]
		},
		[93857] = {
			1070, -- [1]
			"Baron Silverlaine", -- [2]
		},
		[233196] = {
			2039, -- [1]
			"Mephistroth", -- [2]
		},
		[200700] = {
			1793, -- [1]
			"Dargrul", -- [2]
		},
		[213238] = {
			1862, -- [1]
			"Tichondrius", -- [2]
		},
		[236011] = {
			2054, -- [1]
			"[*] Tormented Cries", -- [2]
		},
		[70189] = {
			1100, -- [1]
			"Spire Gargoyle", -- [2]
		},
		[38245] = {
			1902, -- [1]
			"Talon King Ikiss", -- [2]
		},
		[211192] = {
			1877, -- [1]
			"Rotten Drake", -- [2]
		},
		[232174] = {
			2036, -- [1]
			"Harjatan", -- [2]
		},
		[236524] = {
			2055, -- [1]
			"Agronox", -- [2]
		},
		[196608] = {
			1143, -- [1]
			"Lucatiel-BurningBlade", -- [2]
		},
		[69934] = {
			1100, -- [1]
			"Skybreaker Vindicator", -- [2]
		},
		[246504] = {
			2088, -- [1]
			"Garothi Decimator", -- [2]
		},
		[230384] = {
			2037, -- [1]
			"Mistress Sassz'ine", -- [2]
		},
		[192003] = {
			1813, -- [1]
			"Blazing Hydra Spawn", -- [2]
		},
		[221173] = {
			1865, -- [1]
			"Fulminant", -- [2]
		},
		[62042] = {
			1141, -- [1]
			"Thorim", -- [2]
		},
		[64153] = {
			1143, -- [1]
			"Corruptor Tentacle", -- [2]
		},
		[12480] = {
			488, -- [1]
			"Jammal'an the Prophet", -- [2]
		},
		[12544] = {
			474, -- [1]
			"Risen Sorcerer", -- [2]
		},
		[58460] = {
			2010, -- [1]
			"Azure Enforcer", -- [2]
		},
		[70191] = {
			1100, -- [1]
			"Frenzied Abomination", -- [2]
		},
		[242924] = {
			1862, -- [1]
			"Goroth", -- [2]
		},
		[192005] = {
			1813, -- [1]
			"Arcane Hydra Spawn", -- [2]
		},
		[210684] = {
			1825, -- [1]
			"Withered Manawraith", -- [2]
		},
		[258021] = {
			2088, -- [1]
			"[*] Purging Protocol", -- [2]
		},
		[54878] = {
			1983, -- [1]
			"Drakkari Elemental", -- [2]
		},
		[248298] = {
			2066, -- [1]
			"Skyfin", -- [2]
		},
		[42724] = {
			2025, -- [1]
			"Ingvar the Plunderer", -- [2]
		},
		[236528] = {
			2038, -- [1]
			"Fallen Avatar", -- [2]
		},
		[89766] = {
			1877, -- [1]
			"Felguard <Wrysa-Deathwing>", -- [2]
		},
		[228852] = {
			1960, -- [1]
			"Attumen the Huntsman", -- [2]
		},
		[34920] = {
			1900, -- [1]
			"Ethereal Scavenger", -- [2]
		},
		[236529] = {
			2050, -- [1]
			"Huntress Kasparian", -- [2]
		},
		[228597] = {
			1864, -- [1]
			"Mangoman-Thunderlord", -- [2]
		},
		[196357] = {
			1827, -- [1]
			"Ivanyr", -- [2]
		},
		[185099] = {
			2038, -- [1]
			10, -- [2]
		},
		[248812] = {
			2052, -- [1]
			"Maiden of Vigilance", -- [2]
		},
		[232692] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[245742] = {
			2066, -- [1]
			"Darkfang", -- [2]
		},
		[157977] = {
			2038, -- [1]
			8, -- [2]
		},
		[248301] = {
			2066, -- [1]
			"Warp Stalker", -- [2]
		},
		[226296] = {
			1791, -- [1]
			"Vileshard Hulk", -- [2]
		},
		[208385] = {
			1864, -- [1]
			"[*] Tainted Discharge", -- [2]
		},
		[212735] = {
			1871, -- [1]
			"Spellblade Aluriel", -- [2]
		},
		[248302] = {
			2066, -- [1]
			"Warp Stalker", -- [2]
		},
		[201733] = {
			1835, -- [1]
			"Latosius", -- [2]
		},
		[183566] = {
			1792, -- [1]
			"[*] Rancid Pool", -- [2]
		},
		[206339] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[216830] = {
			1886, -- [1]
			"High Botanist Tel'arn", -- [2]
		},
		[211457] = {
			1869, -- [1]
			"Talixae Flamewreath", -- [2]
		},
		[206340] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[250095] = {
			2073, -- [1]
			"Torment of Aman'Thul", -- [2]
		},
		[199176] = {
			1792, -- [1]
			"Naraxas", -- [2]
		},
		[209667] = {
			1870, -- [1]
			"Advisor Melandrus", -- [2]
		},
		[237558] = {
			2057, -- [1]
			"Felborne Botanist", -- [2]
		},
		[199177] = {
			1807, -- [1]
			"Ebonclaw Worg", -- [2]
		},
		[250097] = {
			2073, -- [1]
			"Torment of Aman'Thul", -- [2]
		},
		[209413] = {
			1868, -- [1]
			"Guardian Construct", -- [2]
		},
		[27576] = {
			1864, -- [1]
			4, -- [2]
		},
		[247795] = {
			2067, -- [1]
			"L'ura", -- [2]
		},
		[209158] = {
			1864, -- [1]
			"Xavius", -- [2]
		},
		[199179] = {
			1807, -- [1]
			"Ebonclaw Worg", -- [2]
		},
		[246516] = {
			2088, -- [1]
			"Kin'garoth", -- [2]
		},
		[13952] = {
			239, -- [1]
			"Anvilrage Officer", -- [2]
		},
		[212997] = {
			1862, -- [1]
			"Tichondrius", -- [2]
		},
		[201227] = {
			1838, -- [1]
			"Bloodtainted Fury", -- [2]
		},
		[14032] = {
			594, -- [1]
			"Sandfury Shadowcaster", -- [2]
		},
		[190225] = {
			1807, -- [1]
			"Angerhoof Bull", -- [2]
		},
		[65719] = {
			1143, -- [1]
			"Guardian of Yogg-Saron <Ominous Cloud>", -- [2]
		},
		[207881] = {
			1869, -- [1]
			"Talixae Flamewreath", -- [2]
		},
		[214278] = {
			1872, -- [1]
			"Elisande", -- [2]
		},
		[196111] = {
			1811, -- [1]
			"Seaspray Crab", -- [2]
		},
		[199182] = {
			1807, -- [1]
			"Ebonclaw Worg", -- [2]
		},
		[230143] = {
			2037, -- [1]
			"Mistress Sassz'ine", -- [2]
		},
		[67767] = {
			1143, -- [1]
			"Ebon Champion", -- [2]
		},
		[49380] = {
			1974, -- [1]
			"Trollgore", -- [2]
		},
		[236541] = {
			2050, -- [1]
			"[*] Twilight Glaive", -- [2]
		},
		[221189] = {
			1865, -- [1]
			"Fulminant", -- [2]
		},
		[64157] = {
			1143, -- [1]
			"Corruptor Tentacle", -- [2]
		},
		[22907] = {
			1947, -- [1]
			"Swamplord Musel'ek", -- [2]
		},
		[236542] = {
			2054, -- [1]
			"Unknown", -- [2]
		},
		[52067] = {
			2012, -- [1]
			"Crystalline Frayer", -- [2]
		},
		[200208] = {
			1822, -- [1]
			"Seacursed Soulkeeper", -- [2]
		},
		[243963] = {
			2069, -- [1]
			"Varimathras", -- [2]
		},
		[199185] = {
			1822, -- [1]
			"Cursed Falke", -- [2]
		},
		[64733] = {
			1139, -- [1]
			"[*] Devouring Flame", -- [2]
		},
		[236543] = {
			2053, -- [1]
			"Domatrax", -- [2]
		},
		[191765] = {
			1815, -- [1]
			"Tirathon Saltheril", -- [2]
		},
		[196115] = {
			1825, -- [1]
			"Corstilax", -- [2]
		},
		[62942] = {
			1141, -- [1]
			"Ancient Rune Giant", -- [2]
		},
		[200721] = {
			1793, -- [1]
			"Dargrul", -- [2]
		},
		[213771] = {
			2054, -- [1]
			11, -- [2]
		},
		[246779] = {
			2088, -- [1]
			"Kin'garoth", -- [2]
		},
		[249082] = {
			2067, -- [1]
			"Unknown", -- [2]
		},
		[212492] = {
			1871, -- [1]
			"Spellblade Aluriel", -- [2]
		},
		[206607] = {
			1865, -- [1]
			"Chronomatic Anomaly", -- [2]
		},
		[17470] = {
			474, -- [1]
			"Timmy the Cruel", -- [2]
		},
		[207631] = {
			1867, -- [1]
			"[*] Annihilation", -- [2]
		},
		[207887] = {
			1869, -- [1]
			"Talixae Flamewreath", -- [2]
		},
		[191767] = {
			1815, -- [1]
			"Tirathon Saltheril", -- [2]
		},
		[251571] = {
			2092, -- [1]
			"[*] Soulbomb Detonation", -- [2]
		},
		[221875] = {
			1863, -- [1]
			"Star Augur Etraeus", -- [2]
		},
		[200723] = {
			1793, -- [1]
			"Dargrul", -- [2]
		},
		[32055] = {
			1940, -- [1]
			"Quagmirran", -- [2]
		},
		[195094] = {
			1810, -- [1]
			"Hatecoil Warrior", -- [2]
		},
		[50831] = {
			1998, -- [1]
			"Sjonnir The Ironshaper", -- [2]
		},
		[232153] = {
			1957, -- [1]
			"Coggleston", -- [2]
		},
		[200637] = {
			1793, -- [1]
			"Dargrul", -- [2]
		},
		[212494] = {
			1871, -- [1]
			"Spellblade Aluriel", -- [2]
		},
		[235267] = {
			2052, -- [1]
			"Maiden of Vigilance", -- [2]
		},
		[232137] = {
			1957, -- [1]
			"Silver Forks", -- [2]
		},
		[232135] = {
			1957, -- [1]
			"Silver Forks", -- [2]
		},
		[248317] = {
			2092, -- [1]
			"Argus the Unmaker", -- [2]
		},
		[208860] = {
			1864, -- [1]
			"Dread Abomination", -- [2]
		},
		[236547] = {
			2050, -- [1]
			"Huntress Kasparian", -- [2]
		},
		[247038] = {
			2065, -- [1]
			"Zuraal the Ascended", -- [2]
		},
		[50089] = {
			1976, -- [1]
			"Novos the Summoner", -- [2]
		},
		[206610] = {
			1865, -- [1]
			"Chronomatic Anomaly", -- [2]
		},
		[15248] = {
			1144, -- [1]
			"Riverpaw Looter", -- [2]
		},
		[243968] = {
			2069, -- [1]
			"[*] Torment of Flames", -- [2]
		},
		[227848] = {
			1954, -- [1]
			"Maiden of Virtue", -- [2]
		},
		[42729] = {
			2025, -- [1]
			"Ingvar the Plunderer", -- [2]
		},
		[236548] = {
			2054, -- [1]
			"Unknown", -- [2]
		},
		[32364] = {
			1899, -- [1]
			"Nexus-Prince Shaffar", -- [2]
		},
		[236464] = {
			2054, -- [1]
			"[*] Soulbind", -- [2]
		},
		[196376] = {
			1836, -- [1]
			"Archdruid Glaidalis", -- [2]
		},
		[150001] = {
			1663, -- [1]
			"Mordresh Fire Eye", -- [2]
		},
		[192794] = {
			1812, -- [1]
			"[*] Lightning Strike", -- [2]
		},
		[70444] = {
			1100, -- [1]
			"[*] Explosion", -- [2]
		},
		[191259] = {
			1864, -- [1]
			4, -- [2]
		},
		[224944] = {
			1862, -- [1]
			"Felsworn Chaos-Mage", -- [2]
		},
		[193827] = {
			1808, -- [1]
			"God-King Skovald", -- [2]
		},
		[230920] = {
			2037, -- [1]
			"Razorjaw Waverunner", -- [2]
		},
		[61920] = {
			1140, -- [1]
			"Runemaster Molgeim", -- [2]
		},
		[22812] = {
			1143, -- [1]
			"Néko-Thunderlord", -- [2]
		},
		[33623] = {
			1921, -- [1]
			"Unknown", -- [2]
		},
		[193051] = {
			1812, -- [1]
			"King Deepbeard", -- [2]
		},
		[208659] = {
			1872, -- [1]
			"[*] Arcanetic Ring", -- [2]
		},
		[209862] = {
			1954, -- [1]
			"[*] Volcanic Plume", -- [2]
		},
		[202231] = {
			1792, -- [1]
			"Stoneclaw Grubmaster", -- [2]
		},
		[203028] = {
			1854, -- [1]
			"Ysondre", -- [2]
		},
		[235271] = {
			2052, -- [1]
			"Maiden of Vigilance", -- [2]
		},
		[227339] = {
			1960, -- [1]
			"Midnight", -- [2]
		},
		[15245] = {
			476, -- [1]
			"Commander Malor", -- [2]
		},
		[143924] = {
			1866, -- [1]
			"Healing Stream Totem <Bootszz-Garona>", -- [2]
		},
		[100780] = {
			2038, -- [1]
			10, -- [2]
		},
		[236564] = {
			2054, -- [1]
			"Unknown", -- [2]
		},
		[207630] = {
			1867, -- [1]
			"Trilliax", -- [2]
		},
		[31916] = {
			1906, -- [1]
			"Epoch Hunter", -- [2]
		},
		[15744] = {
			1145, -- [1]
			"Searing Destroyer", -- [2]
		},
		[13899] = {
			232, -- [1]
			"Lord Incendius", -- [2]
		},
		[31467] = {
			1920, -- [1]
			"Chrono Lord Deja", -- [2]
		},
		[227575] = {
			1961, -- [1]
			"Baroness Dorothea Millstipe", -- [2]
		},
		[42730] = {
			2025, -- [1]
			"Ingvar the Plunderer", -- [2]
		},
		[245736] = {
			2066, -- [1]
			"Shadow Stalker", -- [2]
		},
		[246706] = {
			2088, -- [1]
			"[*] Demolish", -- [2]
		},
		[31704] = {
			1948, -- [1]
			"The Black Stalker", -- [2]
		},
		[18968] = {
			349, -- [1]
			"Eldreth Seether", -- [2]
		},
		[227341] = {
			1957, -- [1]
			"Galindre", -- [2]
		},
		[209174] = {
			1872, -- [1]
			"Elisande", -- [2]
		},
		[255201] = {
			2092, -- [1]
			"[*] Aggramar's Sacrifice", -- [2]
		},
		[35054] = {
			1141, -- [1]
			"Dark Rune Champion", -- [2]
		},
		[201754] = {
			2054, -- [1]
			"Beast <Mèl-Draenor>", -- [2]
		},
		[233983] = {
			2048, -- [1]
			"Belac", -- [2]
		},
		[228877] = {
			1872, -- [1]
			"Elisande", -- [2]
		},
		[49639] = {
			1974, -- [1]
			"Trollgore", -- [2]
		},
		[191508] = {
			1806, -- [1]
			"Valarjar Aspirant", -- [2]
		},
		[192799] = {
			1790, -- [1]
			"Blightshard Skitter <Rokmora> <Rokmora>", -- [2]
		},
		[193055] = {
			1812, -- [1]
			"Call the Seas", -- [2]
		},
		[50977] = {
			2038, -- [1]
			6, -- [2]
		},
		[14033] = {
			227, -- [1]
			"High Interrogator Gerstahn", -- [2]
		},
		[93707] = {
			1072, -- [1]
			"Lord Godfrey", -- [2]
		},
		[201226] = {
			1838, -- [1]
			"Bloodtainted Fury", -- [2]
		},
		[16128] = {
			349, -- [1]
			"Immol'thar", -- [2]
		},
		[241672] = {
			1835, -- [1]
			"Latosius", -- [2]
		},
		[192800] = {
			1790, -- [1]
			"[*] Choking Dust", -- [2]
		},
		[202680] = {
			1813, -- [1]
			"Serpentrix", -- [2]
		},
		[14145] = {
			364, -- [1]
			"Gordok Mage-Lord", -- [2]
		},
		[221172] = {
			1865, -- [1]
			"Fulminant", -- [2]
		},
		[64531] = {
			1138, -- [1]
			"VX-001", -- [2]
		},
		[70461] = {
			1100, -- [1]
			"Frost Freeze Trap", -- [2]
		},
		[206618] = {
			1865, -- [1]
			"Chronomatic Anomaly", -- [2]
		},
		[232974] = {
			1872, -- [1]
			"[*] Spanning Singularity", -- [2]
		},
		[192801] = {
			1814, -- [1]
			"[*] Tidal Wave", -- [2]
		},
		[209433] = {
			1872, -- [1]
			"[*] Spanning Singularity", -- [2]
		},
		[228267] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[228011] = {
			1957, -- [1]
			"Mrs. Cauldrons", -- [2]
		},
		[111400] = {
			2038, -- [1]
			9, -- [2]
		},
		[204316] = {
			1849, -- [1]
			"Skorpyron", -- [2]
		},
		[8676] = {
			1864, -- [1]
			4, -- [2]
		},
		[100784] = {
			2038, -- [1]
			10, -- [2]
		},
		[110762] = {
			475, -- [1]
			"Willey Hopebreaker", -- [2]
		},
		[47779] = {
			2010, -- [1]
			"Steward", -- [2]
		},
		[252879] = {
			1144, -- [1]
			4, -- [2]
		},
		[210099] = {
			1873, -- [1]
			"Nightmare Ichor", -- [2]
		},
		[193826] = {
			1808, -- [1]
			"God-King Skovald", -- [2]
		},
		[235253] = {
			2052, -- [1]
			"[*] Fel Infusion", -- [2]
		},
		[35311] = {
			1933, -- [1]
			"Gatewatcher Gyro-Kill", -- [2]
		},
		[249863] = {
			2073, -- [1]
			"Unknown", -- [2]
		},
		[198944] = {
			1806, -- [1]
			"Valarjar Shieldmaiden", -- [2]
		},
		[12466] = {
			1145, -- [1]
			"Lord Overheat", -- [2]
		},
		[193315] = {
			1864, -- [1]
			4, -- [2]
		},
		[191524] = {
			1850, -- [1]
			"Blade Dancer Illianna", -- [2]
		},
		[240908] = {
			2051, -- [1]
			"Kil'jaeden", -- [2]
		},
		[201399] = {
			1838, -- [1]
			"Dreadfire Imp", -- [2]
		},
		[204574] = {
			1837, -- [1]
			"Oakheart", -- [2]
		},
		[208924] = {
			1867, -- [1]
			"Trilliax", -- [2]
		},
		[246026] = {
			2066, -- [1]
			"[*] Void Trap", -- [2]
		},
		[19131] = {
			476, -- [1]
			"Risen Guardsman", -- [2]
		},
		[199457] = {
			1823, -- [1]
			"Harbaron", -- [2]
		},
		[35183] = {
			1933, -- [1]
			"Bloodwarder Centurion", -- [2]
		},
		[246739] = {
			2073, -- [1]
			"Torment of Golganneth", -- [2]
		},
		[206370] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[188395] = {
			1805, -- [1]
			"[*] Ball Lightning", -- [2]
		},
		[203957] = {
			1829, -- [1]
			"Timeless Wraith", -- [2]
		},
		[228265] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[213531] = {
			1862, -- [1]
			"Tichondrius", -- [2]
		},
		[240398] = {
			2038, -- [1]
			"[*] Dark Mark", -- [2]
		},
		[55078] = {
			1866, -- [1]
			"Rune Weapon <Sunara-CenarionCircle>", -- [2]
		},
		[240910] = {
			2051, -- [1]
			"Kil'jaeden", -- [2]
		},
		[206367] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[15581] = {
			240, -- [1]
			"Ribbly's Crony", -- [2]
		},
		[199460] = {
			1838, -- [1]
			"Dresaron", -- [2]
		},
		[196354] = {
			1836, -- [1]
			"Archdruid Glaidalis", -- [2]
		},
		[225814] = {
			1850, -- [1]
			"Blade Dancer Illianna", -- [2]
		},
		[236305] = {
			2050, -- [1]
			"Captain Yathae Moonstrike", -- [2]
		},
		[191527] = {
			1850, -- [1]
			"Blade Dancer Illianna", -- [2]
		},
		[29882] = {
			2009, -- [1]
			"Crazed Mana-Surge", -- [2]
		},
		[196587] = {
			1832, -- [1]
			"Amalgam of Souls", -- [2]
		},
		[35312] = {
			1930, -- [1]
			"[*] Raging Flames", -- [2]
		},
		[210931] = {
			1873, -- [1]
			"Eye of Il'gynoth", -- [2]
		},
		[243982] = {
			2051, -- [1]
			"Kil'jaeden", -- [2]
		},
		[225815] = {
			1850, -- [1]
			"Blade Dancer Illianna", -- [2]
		},
		[236306] = {
			2050, -- [1]
			"Captain Yathae Moonstrike", -- [2]
		},
		[244750] = {
			2067, -- [1]
			"Viceroy Nezhar", -- [2]
		},
		[202019] = {
			1835, -- [1]
			"Latosius", -- [2]
		},
		[206369] = {
			1864, -- [1]
			"Xavius", -- [2]
		},
		[245518] = {
			2073, -- [1]
			"Diima, Mother of Gloom", -- [2]
		},
		[241680] = {
			2036, -- [1]
			"Mistress Sassz'ine", -- [2]
		},
		[188169] = {
			1790, -- [1]
			"Rokmora", -- [2]
		},
		[213534] = {
			1862, -- [1]
			"Tichondrius", -- [2]
		},
		[234661] = {
			2037, -- [1]
			"Mistress Sassz'ine", -- [2]
		},
		[236563] = {
			2054, -- [1]
			"Unknown", -- [2]
		},
		[220443] = {
			1828, -- [1]
			"[*] Wake of Shadows", -- [2]
		},
		[235028] = {
			2052, -- [1]
			"Maiden of Vigilance", -- [2]
		},
		[227550] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[208929] = {
			1873, -- [1]
			"Corruptor Tentacle", -- [2]
		},
		[42705] = {
			2025, -- [1]
			"Ingvar the Plunderer", -- [2]
		},
		[150072] = {
			1662, -- [1]
			"Aarux", -- [2]
		},
		[206609] = {
			1865, -- [1]
			"Chronomatic Anomaly", -- [2]
		},
		[207906] = {
			1869, -- [1]
			"Talixae Flamewreath", -- [2]
		},
		[223201] = {
			1854, -- [1]
			"Rothos", -- [2]
		},
		[13298] = {
			240, -- [1]
			"Ribbly's Crony", -- [2]
		},
		[239379] = {
			2050, -- [1]
			"Huntress Kasparian", -- [2]
		},
		[206883] = {
			1866, -- [1]
			"D'zorykx the Trapper", -- [2]
		},
		[203045] = {
			1853, -- [1]
			"[*] Infested Ground", -- [2]
		},
		[205348] = {
			1842, -- [1]
			"[*] Orb of Destruction", -- [2]
		},
		[5568] = {
			350, -- [1]
			"Tendris Warpwood", -- [2]
		},
		[207907] = {
			1869, -- [1]
			"Talixae Flamewreath", -- [2]
		},
		[205345] = {
			2038, -- [1]
			8, -- [2]
		},
		[30938] = {
			1923, -- [1]
			"Keli'dan the Breaker", -- [2]
		},
		[20735] = {
			347, -- [1]
			"Illyanna Ravenoak", -- [2]
		},
		[198428] = {
			1791, -- [1]
			"Ularogg Cragshaper", -- [2]
		},
		[197117] = {
			1824, -- [1]
			"Piercing Tentacle", -- [2]
		},
		[209443] = {
			1864, -- [1]
			"Xavius", -- [2]
		},
		[22910] = {
			347, -- [1]
			"Illyanna Ravenoak", -- [2]
		},
		[236566] = {
			2053, -- [1]
			"Imp", -- [2]
		},
		[212258] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[193018] = {
			1812, -- [1]
			"King Deepbeard", -- [2]
		},
		[245522] = {
			2067, -- [1]
			"Shadowguard Voidbender", -- [2]
		},
		[33975] = {
			477, -- [1]
			"Instructor Galford", -- [2]
		},
		[31290] = {
			1144, -- [1]
			"Riverpaw Poacher", -- [2]
		},
		[209444] = {
			1864, -- [1]
			"Xavius", -- [2]
		},
		[197418] = {
			1833, -- [1]
			"Illysanna Ravencrest", -- [2]
		},
		[205862] = {
			1842, -- [1]
			"Krosus", -- [2]
		},
		[208165] = {
			1869, -- [1]
			"Talixae Flamewreath", -- [2]
		},
		[213166] = {
			1871, -- [1]
			"[*] Searing Brand", -- [2]
		},
		[34290] = {
			1945, -- [1]
			"Ghaz'an", -- [2]
		},
		[253850] = {
			2067, -- [1]
			"Twilight-Harbinger Tharuul", -- [2]
		},
		[13730] = {
			474, -- [1]
			"Skeletal Berserker", -- [2]
		},
		[199210] = {
			1806, -- [1]
			"Valarjar Marksman", -- [2]
		},
		[194231] = {
			1823, -- [1]
			"Harbaron", -- [2]
		},
		[205863] = {
			1842, -- [1]
			"Krosus", -- [2]
		},
		[85692] = {
			2038, -- [1]
			"Zekrizek", -- [2]
		},
		[123051] = {
			1815, -- [1]
			"Mindbender <Fethnaid-Illidan>", -- [2]
		},
		[239383] = {
			2050, -- [1]
			"Glaive Target", -- [2]
		},
		[48096] = {
			2011, -- [1]
			"Keristrasza", -- [2]
		},
		[12882] = {
			491, -- [1]
			"Morphaz", -- [2]
		},
		[13874] = {
			239, -- [1]
			"Anvilrage Officer", -- [2]
		},
		[213796] = {
			1871, -- [1]
			"Unknown", -- [2]
		},
		[152267] = {
			1666, -- [1]
			"[*] Frozen Bomb", -- [2]
		},
		[214308] = {
			1877, -- [1]
			"[*] Nightmare Brambles", -- [2]
		},
		[198188] = {
			1809, -- [1]
			"Odyn", -- [2]
		},
		[37361] = {
			472, -- [1]
			"Skeletal Guardian", -- [2]
		},
		[200238] = {
			1839, -- [1]
			"Shade of Xavius", -- [2]
		},
		[209191] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[197165] = {
			1814, -- [1]
			"Wrath of Azshara", -- [2]
		},
		[11971] = {
			243, -- [1]
			"Anger'rel", -- [2]
		},
		[14034] = {
			245, -- [1]
			"Shadowforge Senator", -- [2]
		},
		[212262] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[114479] = {
			1427, -- [1]
			"Candlestick Mage", -- [2]
		},
		[50155] = {
			2011, -- [1]
			"Keristrasza", -- [2]
		},
		[199919] = {
			1850, -- [1]
			"Faceless Voidcaster", -- [2]
		},
		[225568] = {
			1838, -- [1]
			"Taintheart Summoner", -- [2]
		},
		[32346] = {
			1889, -- [1]
			"Exarch Maladaar", -- [2]
		},
		[197422] = {
			1818, -- [1]
			"Cordana Felsong", -- [2]
		},
		[218148] = {
			1886, -- [1]
			"High Botanist Tel'arn", -- [2]
		},
		[202028] = {
			2038, -- [1]
			11, -- [2]
		},
		[228895] = {
			1960, -- [1]
			"Midnight", -- [2]
		},
		[198446] = {
			1834, -- [1]
			"Fel Bat", -- [2]
		},
		[210984] = {
			1873, -- [1]
			"Nightmare Horror", -- [2]
		},
		[227616] = {
			1961, -- [1]
			"Lady Keira Berrybuck", -- [2]
		},
		[227872] = {
			1961, -- [1]
			"Moroes", -- [2]
		},
		[218587] = {
			1838, -- [1]
			"Dresaron", -- [2]
		},
		[193585] = {
			1793, -- [1]
			"Rockbound Trapper", -- [2]
		},
		[198903] = {
			1807, -- [1]
			"[*] Crackling Storm", -- [2]
		},
		[192050] = {
			1813, -- [1]
			"Serpentrix", -- [2]
		},
		[226005] = {
			1871, -- [1]
			"Trained Shadescale", -- [2]
		},
		[150549] = {
			1668, -- [1]
			"Voidwalker Minion", -- [2]
		},
		[236449] = {
			2054, -- [1]
			"Soul Queen Dejahna", -- [2]
		},
		[236061] = {
			2052, -- [1]
			"Maiden of Vigilance", -- [2]
		},
		[35059] = {
			1902, -- [1]
			"Talon King Ikiss", -- [2]
		},
		[217770] = {
			1866, -- [1]
			"[*] Gaze of Vethriz", -- [2]
		},
		[257299] = {
			2092, -- [1]
			"Argus the Unmaker", -- [2]
		},
		[241179] = {
			2036, -- [1]
			"Tidescale Legionnaire", -- [2]
		},
		[227789] = {
			1954, -- [1]
			"Maiden of Virtue", -- [2]
		},
		[227493] = {
			1960, -- [1]
			"Attumen the Huntsman", -- [2]
		},
		[219049] = {
			1886, -- [1]
			"Naturalist Tel'arn <High Botanist Tel'arn> <High Botanist Tel'arn>", -- [2]
		},
		[234015] = {
			2048, -- [1]
			"Belac", -- [2]
		},
		[22911] = {
			347, -- [1]
			"Ferra", -- [2]
		},
		[210645] = {
			1825, -- [1]
			"Withered Fiend", -- [2]
		},
		[69969] = {
			1100, -- [1]
			"Skybreaker Summoner", -- [2]
		},
		[16866] = {
			483, -- [1]
			"Venom Belcher", -- [2]
		},
		[207849] = {
			1864, -- [1]
			"Xavius", -- [2]
		},
		[227363] = {
			1960, -- [1]
			"Midnight", -- [2]
		},
		[223697] = {
			1854, -- [1]
			"Rothos", -- [2]
		},
		[248128] = {
			2067, -- [1]
			"Rift Warden", -- [2]
		},
		[2643] = {
			2038, -- [1]
			3, -- [2]
		},
		[38194] = {
			1902, -- [1]
			"Talon King Ikiss", -- [2]
		},
		[199090] = {
			1807, -- [1]
			"Angerhoof Bull", -- [2]
		},
		[192053] = {
			1810, -- [1]
			"Warlord Parjesh", -- [2]
		},
		[12675] = {
			243, -- [1]
			"Seeth'rel", -- [2]
		},
		[200686] = {
			1836, -- [1]
			"Dreadsoul Poisoner", -- [2]
		},
		[31547] = {
			1947, -- [1]
			"Swamplord Musel'ek", -- [2]
		},
		[54954] = {
			2026, -- [1]
			"Ticking Bomb <Dragonflayer Strategist> <Dragonflayer Strategist>", -- [2]
		},
		[12739] = {
			1070, -- [1]
			"Shadowy Attendant", -- [2]
		},
		[150550] = {
			1665, -- [1]
			"Death Speaker Blackthorn", -- [2]
		},
		[1329] = {
			1864, -- [1]
			4, -- [2]
		},
		[31707] = {
			2038, -- [1]
			"Water Elemental", -- [2]
		},
		[245532] = {
			2073, -- [1]
			"Diima, Mother of Gloom", -- [2]
		},
		[63526] = {
			1140, -- [1]
			"Steelbreaker", -- [2]
		},
		[198963] = {
			1792, -- [1]
			"Naraxas", -- [2]
		},
		[108853] = {
			2038, -- [1]
			8, -- [2]
		},
		[192504] = {
			1815, -- [1]
			"Tirathon Saltheril", -- [2]
		},
		[114493] = {
			1427, -- [1]
			"Reanimated Corpse", -- [2]
		},
		[228645] = {
			1866, -- [1]
			"Rune Weapon <Sunara-CenarionCircle>", -- [2]
		},
		[202978] = {
			1853, -- [1]
			"Nythendra", -- [2]
		},
		[205486] = {
			1863, -- [1]
			"Star Augur Etraeus", -- [2]
		},
		[206896] = {
			1866, -- [1]
			"D'zorykx the Trapper", -- [2]
		},
		[196074] = {
			1825, -- [1]
			"Corstilax", -- [2]
		},
		[205361] = {
			1842, -- [1]
			"Krosus", -- [2]
		},
		[20798] = {
			594, -- [1]
			"Sandfury Shadowcaster", -- [2]
		},
		[218155] = {
			1886, -- [1]
			"[*] Solar Collapse", -- [2]
		},
		[10348] = {
			382, -- [1]
			"Leprous Technician", -- [2]
		},
		[209921] = {
			1793, -- [1]
			"Dargrul", -- [2]
		},
		[206641] = {
			1867, -- [1]
			"Trilliax", -- [2]
		},
		[208944] = {
			1872, -- [1]
			"Elisande", -- [2]
		},
		[243999] = {
			2069, -- [1]
			"Varimathras", -- [2]
		},
		[214486] = {
			1863, -- [1]
			"Star Augur Etraeus", -- [2]
		},
		[235968] = {
			2054, -- [1]
			"Ghastly Bonewarden", -- [2]
		},
		[12491] = {
			595, -- [1]
			"Antu'sul", -- [2]
		},
		[197942] = {
			1841, -- [1]
			"Ursoc", -- [2]
		},
		[230950] = {
			2037, -- [1]
			"Abyss Stalker", -- [2]
		},
		[208689] = {
			1873, -- [1]
			"Dominator Tentacle", -- [2]
		},
		[15538] = {
			244, -- [1]
			"Ironhand Guardian", -- [2]
		},
		[47780] = {
			2010, -- [1]
			"Steward", -- [2]
		},
		[209630] = {
			1870, -- [1]
			"[*] Piercing Gale", -- [2]
		},
		[48878] = {
			1977, -- [1]
			"King Dred", -- [2]
		},
		[205875] = {
			1842, -- [1]
			"[*] Slam", -- [2]
		},
		[197943] = {
			1841, -- [1]
			"Ursoc", -- [2]
		},
		[15346] = {
			234, -- [1]
			"Fineous Darkvire", -- [2]
		},
		[221093] = {
			1808, -- [1]
			"Unknown", -- [2]
		},
		[49198] = {
			1976, -- [1]
			"Novos the Summoner", -- [2]
		},
		[34933] = {
			1899, -- [1]
			"Mana Leech", -- [2]
		},
		[231363] = {
			2032, -- [1]
			"Goroth", -- [2]
		},
		[49548] = {
			1975, -- [1]
			"The Prophet Tharon'ja", -- [2]
		},
		[199143] = {
			1835, -- [1]
			"Latosius", -- [2]
		},
		[63847] = {
			1132, -- [1]
			"Flame Leviathan", -- [2]
		},
		[206388] = {
			1863, -- [1]
			"Star Augur Etraeus", -- [2]
		},
		[245303] = {
			2073, -- [1]
			"Asara, Mother of Night", -- [2]
		},
		[49710] = {
			1977, -- [1]
			"Drakkari Gutripper", -- [2]
		},
		[86727] = {
			1146, -- [1]
			"Randolph Moloch", -- [2]
		},
		[64167] = {
			1143, -- [1]
			"Unknown", -- [2]
		},
		[12542] = {
			1885, -- [1]
			"Postmaster Malown", -- [2]
		},
		[209971] = {
			1872, -- [1]
			"Elisande", -- [2]
		},
		[15586] = {
			245, -- [1]
			"High Priestess of Thaurissan", -- [2]
		},
		[62376] = {
			1132, -- [1]
			"Flame Leviathan", -- [2]
		},
		[223021] = {
			1862, -- [1]
			"[*] Carrion Plague", -- [2]
		},
		[205870] = {
			1854, -- [1]
			"Lethon", -- [2]
		},
		[245656] = {
			2067, -- [1]
			"Shadowguard Trickster", -- [2]
		},
		[201272] = {
			1838, -- [1]
			"Bloodtainted Fury", -- [2]
		},
		[196838] = {
			1807, -- [1]
			"Fenryr", -- [2]
		},
		[256544] = {
			2092, -- [1]
			"Argus the Unmaker", -- [2]
		},
		[232745] = {
			2037, -- [1]
			"Sarukel", -- [2]
		},
		[93505] = {
			1073, -- [1]
			"Lord Walden", -- [2]
		},
		[237351] = {
			2050, -- [1]
			"[*] Lunar Barrage", -- [2]
		},
		[197334] = {
			1818, -- [1]
			"Cordana Felsong", -- [2]
		},
		[199193] = {
			1835, -- [1]
			"Latosius", -- [2]
		},
		[201273] = {
			1838, -- [1]
			"Bloodtainted Fury", -- [2]
		},
		[201567] = {
			1822, -- [1]
			"Seacursed Slaver", -- [2]
		},
		[193597] = {
			1811, -- [1]
			"Lady Hatecoil", -- [2]
		},
		[232746] = {
			2037, -- [1]
			"Mistress Sassz'ine", -- [2]
		},
		[196156] = {
			1850, -- [1]
			"Shadowmoon Technician", -- [2]
		},
		[55276] = {
			1981, -- [1]
			"Gal'darah", -- [2]
		},
		[241702] = {
			2051, -- [1]
			"Shadowsoul", -- [2]
		},
		[244005] = {
			2069, -- [1]
			"[*] Dark Fissure", -- [2]
		},
		[211756] = {
			1828, -- [1]
			"Wrathguard Felblade", -- [2]
		},
		[236329] = {
			2032, -- [1]
			"[*] Star Burn", -- [2]
		},
		[248499] = {
			2092, -- [1]
			"Argus the Unmaker", -- [2]
		},
		[204459] = {
			1849, -- [1]
			"Skorpyron", -- [2]
		},
		[196157] = {
			1850, -- [1]
			"Shadowmoon Technician", -- [2]
		},
		[39412] = {
			1943, -- [1]
			"Steam Surger", -- [2]
		},
		[235974] = {
			2051, -- [1]
			"Shaggybeard-Dalaran's Erupting Reflection", -- [2]
		},
		[244006] = {
			2069, -- [1]
			"Varimathras", -- [2]
		},
		[64168] = {
			1143, -- [1]
			"Laughing Skull", -- [2]
		},
		[11972] = {
			364, -- [1]
			"Guard Fengus", -- [2]
		},
		[119405] = {
			1443, -- [1]
			"Adarogg", -- [2]
		},
		[197550] = {
			1812, -- [1]
			"King Deepbeard", -- [2]
		},
		[243152] = {
			2039, -- [1]
			"[*] Demonic Upheaval", -- [2]
		},
		[239401] = {
			2048, -- [1]
			"Belac", -- [2]
		},
		[14099] = {
			482, -- [1]
			"Magistrate Barthilas", -- [2]
		},
		[10341] = {
			378, -- [1]
			"Irradiated Slime", -- [2]
		},
		[193088] = {
			1812, -- [1]
			"King Deepbeard", -- [2]
		},
		[252707] = {
			2092, -- [1]
			"Constellar Designate", -- [2]
		},
		[38197] = {
			1902, -- [1]
			"Talon King Ikiss", -- [2]
		},
		[209678] = {
			1870, -- [1]
			"Advisor Melandrus", -- [2]
		},
		[194112] = {
			1808, -- [1]
			"God-King Skovald", -- [2]
		},
		[208697] = {
			1873, -- [1]
			"Deathglare Tentacle", -- [2]
		},
		[115767] = {
			1144, -- [1]
			1, -- [2]
		},
		[194880] = {
			1817, -- [1]
			"Glazer", -- [2]
		},
		[12468] = {
			488, -- [1]
			"Jammal'an the Prophet", -- [2]
		},
		[198099] = {
			1841, -- [1]
			"Ursoc", -- [2]
		},
		[31946] = {
			1947, -- [1]
			"Swamplord Musel'ek", -- [2]
		},
		[50868] = {
			1994, -- [1]
			"Krystallus", -- [2]
		},
		[230959] = {
			2037, -- [1]
			"Abyss Stalker", -- [2]
		},
		[206651] = {
			1864, -- [1]
			"Xavius", -- [2]
		},
		[238489] = {
			2053, -- [1]
			"Imp", -- [2]
		},
		[197333] = {
			1818, -- [1]
			"Cordana Felsong", -- [2]
		},
		[191043] = {
			2038, -- [1]
			3, -- [2]
		},
		[22876] = {
			364, -- [1]
			"Wandering Eye of Kilrogg", -- [2]
		},
		[215204] = {
			1868, -- [1]
			"Vigilant Duskwatch", -- [2]
		},
		[86726] = {
			1146, -- [1]
			"Randolph Moloch", -- [2]
		},
		[245289] = {
			2067, -- [1]
			"L'ura", -- [2]
		},
		[233263] = {
			2050, -- [1]
			"Priestess Lunaspyre", -- [2]
		},
		[50843] = {
			1994, -- [1]
			"Krystallus", -- [2]
		},
		[47729] = {
			2010, -- [1]
			"Grand Magus Telestra", -- [2]
		},
		[16740] = {
			363, -- [1]
			"Stomper Kreeg", -- [2]
		},
		[233426] = {
			2048, -- [1]
			"Atrigan", -- [2]
		},
		[150616] = {
			1665, -- [1]
			"Death Speaker Blackthorn", -- [2]
		},
		[191919] = {
			1810, -- [1]
			"Warlord Parjesh", -- [2]
		},
		[31914] = {
			1906, -- [1]
			"Epoch Hunter", -- [2]
		},
		[30933] = {
			347, -- [1]
			"Illyanna Ravenoak", -- [2]
		},
		[245802] = {
			2066, -- [1]
			"Darkfang", -- [2]
		},
		[231729] = {
			2036, -- [1]
			"Razorjaw Wavemender", -- [2]
		},
		[69967] = {
			1100, -- [1]
			"Skybreaker Vicar", -- [2]
		},
		[20787] = {
			232, -- [1]
			"Blazing Fireguard", -- [2]
		},
		[151810] = {
			1666, -- [1]
			"Amnennar the Coldbringer", -- [2]
		},
		[218424] = {
			1886, -- [1]
			"High Botanist Tel'arn", -- [2]
		},
		[206398] = {
			1863, -- [1]
			"Star Augur Etraeus", -- [2]
		},
		[17156] = {
			347, -- [1]
			"Ferra", -- [2]
		},
		[245803] = {
			2066, -- [1]
			"Darkfang", -- [2]
		},
		[227636] = {
			1960, -- [1]
			"Attumen the Huntsman", -- [2]
		},
		[209469] = {
			1873, -- [1]
			"Nightmare Ichor", -- [2]
		},
		[195396] = {
			1818, -- [1]
			"Restless Tides", -- [2]
		},
		[227817] = {
			1954, -- [1]
			"Maiden of Virtue", -- [2]
		},
		[232754] = {
			2037, -- [1]
			"Mistress Sassz'ine", -- [2]
		},
		[233526] = {
			2036, -- [1]
			"Harjatan", -- [2]
		},
		[17393] = {
			484, -- [1]
			"Lord Aurius Rivendare", -- [2]
		},
		[235569] = {
			2052, -- [1]
			"Maiden of Vigilance", -- [2]
		},
		[149851] = {
			1664, -- [1]
			"Mushlump", -- [2]
		},
		[69968] = {
			1100, -- [1]
			"Skybreaker Hierophant", -- [2]
		},
		[47346] = {
			1976, -- [1]
			"Novos the Summoner", -- [2]
		},
		[31901] = {
			1891, -- [1]
			"Omor the Unscarred", -- [2]
		},
		[227851] = {
			1961, -- [1]
			"Moroes", -- [2]
		},
		[235058] = {
			2051, -- [1]
			"Kil'jaeden", -- [2]
		},
		[206656] = {
			1864, -- [1]
			"Nightmare Blades", -- [2]
		},
		[246692] = {
			2088, -- [1]
			"Garothi Demolisher", -- [2]
		},
		[227638] = {
			1960, -- [1]
			"Attumen the Huntsman", -- [2]
		},
		[209471] = {
			1873, -- [1]
			"Nightmare Ichor", -- [2]
		},
		[15043] = {
			364, -- [1]
			"Gordok Mage-Lord", -- [2]
		},
		[212030] = {
			1828, -- [1]
			"General Xakal", -- [2]
		},
		[232756] = {
			2037, -- [1]
			"Mistress Sassz'ine", -- [2]
		},
		[226205] = {
			1867, -- [1]
			"[*] Slime Pool", -- [2]
		},
		[239409] = {
			2052, -- [1]
			"[*] Soul Burst", -- [2]
		},
		[62507] = {
			1141, -- [1]
			"Sif", -- [2]
		},
		[219808] = {
			1865, -- [1]
			"Waning Time Particle", -- [2]
		},
		[199237] = {
			1841, -- [1]
			"Ursoc", -- [2]
		},
		[215458] = {
			1871, -- [1]
			"Spellblade Aluriel", -- [2]
		},
		[228335] = {
			1865, -- [1]
			"Unknown", -- [2]
		},
		[86729] = {
			1146, -- [1]
			"Randolph Moloch", -- [2]
		},
		[245651] = {
			2067, -- [1]
			"Shadowguard Trickster", -- [2]
		},
		[38391] = {
			1145, -- [1]
			"Searing Destroyer", -- [2]
		},
		[235572] = {
			2038, -- [1]
			"Fallen Avatar", -- [2]
		},
		[235597] = {
			2038, -- [1]
			"Fallen Avatar", -- [2]
		},
		[256542] = {
			2092, -- [1]
			"Argus the Unmaker", -- [2]
		},
		[250669] = {
			2092, -- [1]
			"Argus the Unmaker", -- [2]
		},
		[207938] = {
			1866, -- [1]
			"Inquisitor Vethriz", -- [2]
		},
		[214335] = {
			1863, -- [1]
			"Star Augur Etraeus", -- [2]
		},
		[30686] = {
			1891, -- [1]
			"Omor the Unscarred", -- [2]
		},
		[6660] = {
			236, -- [1]
			"Anvilrage Reservist", -- [2]
		},
		[235573] = {
			2052, -- [1]
			"Maiden of Vigilance", -- [2]
		},
		[188494] = {
			1792, -- [1]
			"[*] Rancid Maw", -- [2]
		},
		[69970] = {
			1100, -- [1]
			"Skybreaker Luminary", -- [2]
		},
		[12741] = {
			1885, -- [1]
			"Postmaster Malown", -- [2]
		},
		[55599] = {
			1978, -- [1]
			"Drakkari Medicine Man", -- [2]
		},
		[211132] = {
			1866, -- [1]
			"Empowered Eye of Gul'dan", -- [2]
		},
		[206585] = {
			1863, -- [1]
			"Star Augur Etraeus", -- [2]
		},
		[196562] = {
			1827, -- [1]
			"Ivanyr", -- [2]
		},
		[202822] = {
			1864, -- [1]
			4, -- [2]
		},
		[206757] = {
			1866, -- [1]
			"D'zorykx the Trapper", -- [2]
		},
		[225851] = {
			1886, -- [1]
			"Duskwatch Warden", -- [2]
		},
		[230201] = {
			2037, -- [1]
			"Mistress Sassz'ine", -- [2]
		},
		[246833] = {
			2088, -- [1]
			"Kin'garoth", -- [2]
		},
		[15587] = {
			348, -- [1]
			"Magister Kalendris", -- [2]
		},
		[3391] = {
			361, -- [1]
			"Prince Tortheldrin", -- [2]
		},
		[233272] = {
			2032, -- [1]
			"Goroth", -- [2]
		},
		[202823] = {
			1864, -- [1]
			4, -- [2]
		},
		[210750] = {
			1825, -- [1]
			"[*] Collapsing Rift", -- [2]
		},
		[17434] = {
			484, -- [1]
			"Lord Aurius Rivendare", -- [2]
		},
		[62276] = {
			1141, -- [1]
			"Thorim", -- [2]
		},
		[198386] = {
			1836, -- [1]
			"Archdruid Glaidalis", -- [2]
		},
		[31422] = {
			1919, -- [1]
			"Aeonus", -- [2]
		},
		[194232] = {
			1823, -- [1]
			"Harbaron", -- [2]
		},
		[34298] = {
			1947, -- [1]
			"Claw", -- [2]
		},
		[51849] = {
			1998, -- [1]
			"Sjonnir The Ironshaper", -- [2]
		},
		[38520] = {
			1920, -- [1]
			"Infinite Assassin", -- [2]
		},
		[54962] = {
			2026, -- [1]
			"Dragonflayer Strategist", -- [2]
		},
		[211196] = {
			1877, -- [1]
			"Rotten Drake", -- [2]
		},
		[185425] = {
			1807, -- [1]
			"Steeljaw Grizzly", -- [2]
		},
		[200010] = {
			2050, -- [1]
			"Unknown <Daiyosin-Korgath>", -- [2]
		},
		[200359] = {
			1839, -- [1]
			"Shade of Xavius", -- [2]
		},
		[198475] = {
			1791, -- [1]
			"[*] Strike of the Mountain", -- [2]
		},
		[34874] = {
			1946, -- [1]
			"Hungarfen", -- [2]
		},
		[209597] = {
			1872, -- [1]
			"Elisande", -- [2]
		},
		[69972] = {
			1100, -- [1]
			"Skybreaker Summoner", -- [2]
		},
		[212564] = {
			1850, -- [1]
			"Tormenting Orb <Inquisitor Tormentorum> <Inquisitor Tormentorum>", -- [2]
		},
		[86604] = {
			1144, -- [1]
			"Hogger", -- [2]
		},
		[220481] = {
			1825, -- [1]
			"Corstilax", -- [2]
		},
		[63341] = {
			1138, -- [1]
			"Mimiron", -- [2]
		},
		[69974] = {
			1100, -- [1]
			"Skybreaker Marksman", -- [2]
		},
		[206920] = {
			1864, -- [1]
			"Nightmare Tentacle", -- [2]
		},
		[227737] = {
			1961, -- [1]
			"Moroes", -- [2]
		},
		[197965] = {
			1809, -- [1]
			"Odyn", -- [2]
		},
		[11366] = {
			2038, -- [1]
			8, -- [2]
		},
		[207327] = {
			1867, -- [1]
			"Scrubber", -- [2]
		},
		[62317] = {
			1130, -- [1]
			"Captured Mercenary Captain", -- [2]
		},
		[210337] = {
			1877, -- [1]
			"[*] Nightmare Brambles", -- [2]
		},
		[50420] = {
			1446, -- [1]
			"Lava Guard Gordoth", -- [2]
		},
		[206921] = {
			1863, -- [1]
			"Star Augur Etraeus", -- [2]
		},
		[232722] = {
			2037, -- [1]
			"Mistress Sassz'ine", -- [2]
		},
		[69973] = {
			1100, -- [1]
			"Skybreaker Summoner", -- [2]
		},
		[69930] = {
			1100, -- [1]
			"Skybreaker Vindicator", -- [2]
		},
		[236603] = {
			2050, -- [1]
			"[*] Rapid Shot", -- [2]
		},
		[197966] = {
			1809, -- [1]
			"Odyn", -- [2]
		},
		[196175] = {
			1811, -- [1]
			"Mak'rana Hardshell", -- [2]
		},
		[78801] = {
			593, -- [1]
			"Hydromancer Velratha", -- [2]
		},
		[40504] = {
			1940, -- [1]
			"Quagmirran", -- [2]
		},
		[192094] = {
			1810, -- [1]
			"Warlord Parjesh", -- [2]
		},
		[150118] = {
			1662, -- [1]
			"Congealed Plague Gunk", -- [2]
		},
		[207813] = {
			1863, -- [1]
			"Star Augur Etraeus", -- [2]
		},
		[216134] = {
			1872, -- [1]
			"Infinite Drakeling", -- [2]
		},
		[197967] = {
			1809, -- [1]
			"Odyn", -- [2]
		},
		[3583] = {
			1146, -- [1]
			"Shifty Thief", -- [2]
		},
		[245647] = {
			2066, -- [1]
			"Shadowguard Trickster", -- [2]
		},
		[218780] = {
			1886, -- [1]
			"[*] Plasma Explosion", -- [2]
		},
		[239931] = {
			2051, -- [1]
			"Kil'jaeden", -- [2]
		},
		[248375] = {
			2088, -- [1]
			"Kin'garoth", -- [2]
		},
		[236596] = {
			2050, -- [1]
			"Captain Yathae Moonstrike", -- [2]
		},
		[246840] = {
			2088, -- [1]
			"[*] Ruiner", -- [2]
		},
		[242832] = {
			2048, -- [1]
			"Felguard <Pocomaxa-Spirestone>", -- [2]
		},
		[127802] = {
			2038, -- [1]
			8, -- [2]
		},
		[78802] = {
			593, -- [1]
			"Hydromancer Velratha", -- [2]
		},
		[236072] = {
			2054, -- [1]
			"Soul Queen Dejahna", -- [2]
		},
		[239932] = {
			2051, -- [1]
			"Kil'jaeden", -- [2]
		},
		[64173] = {
			1143, -- [1]
			"Brain of Yogg-Saron", -- [2]
		},
		[5221] = {
			2038, -- [1]
			11, -- [2]
		},
		[71254] = {
			1100, -- [1]
			"Lady Deathwhisper", -- [2]
		},
		[62318] = {
			1130, -- [1]
			"Captured Mercenary Soldier", -- [2]
		},
		[25058] = {
			2010, -- [1]
			"Mage Hunter Initiate", -- [2]
		},
		[33833] = {
			2010, -- [1]
			"Crazed Mana-Wraith", -- [2]
		},
		[237630] = {
			2050, -- [1]
			"Captain Yathae Moonstrike", -- [2]
		},
		[149865] = {
			1667, -- [1]
			"Ghamoo-Ra", -- [2]
		},
		[69975] = {
			1100, -- [1]
			"Skybreaker Marksman", -- [2]
		},
		[150377] = {
			1668, -- [1]
			"Twilight Disciple", -- [2]
		},
		[216137] = {
			1872, -- [1]
			"Infinite Drakeling", -- [2]
		},
		[64156] = {
			1143, -- [1]
			"Corruptor Tentacle", -- [2]
		},
		[215234] = {
			1873, -- [1]
			"Dominator Tentacle", -- [2]
		},
		[233281] = {
			2032, -- [1]
			"Goroth", -- [2]
		},
		[8599] = {
			1885, -- [1]
			"Plague Ghoul", -- [2]
		},
		[196947] = {
			1824, -- [1]
			"Helya", -- [2]
		},
		[205391] = {
			1842, -- [1]
			"Krosus", -- [2]
		},
		[31615] = {
			1947, -- [1]
			"Swamplord Musel'ek", -- [2]
		},
		[150634] = {
			1669, -- [1]
			"Subjugator Kor'ul", -- [2]
		},
		[234817] = {
			2039, -- [1]
			"Mephistroth", -- [2]
		},
		[55218] = {
			1981, -- [1]
			"Gal'darah", -- [2]
		},
		[218807] = {
			1886, -- [1]
			"High Botanist Tel'arn", -- [2]
		},
		[237632] = {
			2050, -- [1]
			"Priestess Lunaspyre", -- [2]
		},
		[193505] = {
			1791, -- [1]
			"Vileshard Hulk", -- [2]
		},
		[201298] = {
			1838, -- [1]
			"Bloodtainted Burster <Bloodtainted Fury>", -- [2]
		},
		[252729] = {
			2092, -- [1]
			"Constellar Designate", -- [2]
		},
		[193611] = {
			1811, -- [1]
			"Lady Hatecoil", -- [2]
		},
		[86736] = {
			1144, -- [1]
			"Hogger", -- [2]
		},
		[9143] = {
			232, -- [1]
			"Doomforge Craftsman", -- [2]
		},
		[233283] = {
			2032, -- [1]
			"Goroth", -- [2]
		},
		[237633] = {
			2050, -- [1]
			"[*] Spectral Glaive", -- [2]
		},
		[241983] = {
			2051, -- [1]
			"Kil'jaeden", -- [2]
		},
		[204483] = {
			1849, -- [1]
			"Skorpyron", -- [2]
		},
		[205649] = {
			1863, -- [1]
			"Coronal Ejection", -- [2]
		},
		[191946] = {
			1810, -- [1]
			"Warlord Parjesh", -- [2]
		},
		[246592] = {
			2067, -- [1]
			"[*] Corrupting Void", -- [2]
		},
		[206652] = {
			1864, -- [1]
			"[*] Darkened Tainting", -- [2]
		},
		[233284] = {
			2050, -- [1]
			"[*] Umbra Detonation", -- [2]
		},
		[202658] = {
			1850, -- [1]
			"Malignant Defiler", -- [2]
		},
		[33917] = {
			2054, -- [1]
			11, -- [2]
		},
		[70362] = {
			1100, -- [1]
			"Spire Frostwyrm", -- [2]
		},
		[212561] = {
			1850, -- [1]
			"Void-Touched Juggernaut", -- [2]
		},
		[205984] = {
			1863, -- [1]
			"Star Augur Etraeus", -- [2]
		},
		[70361] = {
			1100, -- [1]
			"Spire Frostwyrm", -- [2]
		},
		[196183] = {
			1811, -- [1]
			"Mak'rana Hardshell", -- [2]
		},
		[194392] = {
			2038, -- [1]
			3, -- [2]
		},
		[219823] = {
			1865, -- [1]
			"Chronomatic Anomaly", -- [2]
		},
		[207806] = {
			1868, -- [1]
			"Patrol Captain Gerdo", -- [2]
		},
		[209489] = {
			1866, -- [1]
			"Empowered Eye of Gul'dan", -- [2]
		},
		[210619] = {
			1877, -- [1]
			"Corrupted Wisp", -- [2]
		},
		[50997] = {
			2011, -- [1]
			"Keristrasza", -- [2]
		},
		[213148] = {
			1871, -- [1]
			"Spellblade Aluriel", -- [2]
		},
		[225100] = {
			1868, -- [1]
			"Guardian Construct", -- [2]
		},
		[206675] = {
			1866, -- [1]
			"Unknown", -- [2]
		},
		[204448] = {
			1849, -- [1]
			"Skorpyron", -- [2]
		},
		[248130] = {
			2067, -- [1]
			"Rift Warden", -- [2]
		},
		[218927] = {
			1886, -- [1]
			"Naturalist Tel'arn <High Botanist Tel'arn> <High Botanist Tel'arn>", -- [2]
		},
		[234310] = {
			2051, -- [1]
			"Kil'jaeden", -- [2]
		},
		[237561] = {
			2050, -- [1]
			"Huntress Kasparian", -- [2]
		},
		[86738] = {
			1146, -- [1]
			"Vicious Thug", -- [2]
		},
		[35261] = {
			1933, -- [1]
			"Sunseeker Netherbinder", -- [2]
		},
		[13445] = {
			362, -- [1]
			"Gordok Hound", -- [2]
		},
		[18399] = {
			364, -- [1]
			"Gordok Mage-Lord", -- [2]
		},
		[20805] = {
			588, -- [1]
			"Lord Pythas", -- [2]
		},
		[1079] = {
			2038, -- [1]
			11, -- [2]
		},
		[253888] = {
			2067, -- [1]
			"Twilight-Harbinger Tharuul", -- [2]
		},
		[15572] = {
			366, -- [1]
			"Gordok Reaver <Captain Kromcrush> <Captain Kromcrush>", -- [2]
		},
		[122] = {
			1864, -- [1]
			"Mangoman-Thunderlord", -- [2]
		},
		[241989] = {
			2036, -- [1]
			"Razorjaw Wavemender", -- [2]
		},
		[15620] = {
			1907, -- [1]
			"Tarren Mill Lookout", -- [2]
		},
		[15636] = {
			245, -- [1]
			"Emperor Dagran Thaurissan", -- [2]
		},
		[64623] = {
			1138, -- [1]
			"VX-001", -- [2]
		},
		[15668] = {
			244, -- [1]
			"Magmus", -- [2]
		},
		[193092] = {
			1805, -- [1]
			"Hymdall", -- [2]
		},
		[211000] = {
			1825, -- [1]
			"Nightborne Spellsword", -- [2]
		},
		[1966] = {
			1864, -- [1]
			"Lëto-Illidan", -- [2]
		},
		[225362] = {
			1842, -- [1]
			"[*] Slam", -- [2]
		},
		[216877] = {
			1886, -- [1]
			"High Botanist Tel'arn", -- [2]
		},
		[17150] = {
			474, -- [1]
			"Risen Sorcerer", -- [2]
		},
		[231754] = {
			2036, -- [1]
			"Razorjaw Wavemender", -- [2]
		},
		[93520] = {
			1072, -- [1]
			"Lord Godfrey", -- [2]
		},
		[191326] = {
			1838, -- [1]
			"Dresaron", -- [2]
		},
		[244042] = {
			2069, -- [1]
			"Varimathras", -- [2]
		},
		[234824] = {
			2039, -- [1]
			"Mephistroth", -- [2]
		},
		[55220] = {
			1981, -- [1]
			"Rhino Spirit <Gal'darah>", -- [2]
		},
		[25603] = {
			1900, -- [1]
			"Ethereal Sorcerer", -- [2]
		},
		[227405] = {
			1957, -- [1]
			"Elfyra", -- [2]
		},
		[114886] = {
			1426, -- [1]
			"[*] Frigid Grasp", -- [2]
		},
		[254728] = {
			2067, -- [1]
			"Lashing Voidling", -- [2]
		},
		[236361] = {
			2054, -- [1]
			"Fallen Priestess", -- [2]
		},
		[31904] = {
			1907, -- [1]
			"Captain Skarloc", -- [2]
		},
		[86740] = {
			1146, -- [1]
			"Rowdy Troublemaker", -- [2]
		},
		[11894] = {
			595, -- [1]
			"Antu'sul", -- [2]
		},
		[35326] = {
			1934, -- [1]
			"Gatewatcher Iron-Hand", -- [2]
		},
		[227406] = {
			1957, -- [1]
			"Elfyra", -- [2]
		},
		[17735] = {
			2054, -- [1]
			"Korrothion <Raff-Detheroc>", -- [2]
		},
		[245510] = {
			2067, -- [1]
			"[*] Corrupting Void", -- [2]
		},
		[193375] = {
			1791, -- [1]
			"Ularogg Cragshaper", -- [2]
		},
		[23972] = {
			1892, -- [1]
			"Liquid Fire", -- [2]
		},
		[202075] = {
			1791, -- [1]
			"Burning Geode", -- [2]
		},
		[149869] = {
			1667, -- [1]
			"Ghamoo-Ra", -- [2]
		},
		[211799] = {
			1872, -- [1]
			"Elisande", -- [2]
		},
		[12492] = {
			488, -- [1]
			"Jammal'an the Prophet", -- [2]
		},
		[248133] = {
			2067, -- [1]
			"Rift Warden", -- [2]
		},
		[193209] = {
			1816, -- [1]
			"Ash'Golm", -- [2]
		},
		[193376] = {
			1791, -- [1]
			"Ularogg Cragshaper", -- [2]
		},
		[226388] = {
			1792, -- [1]
			"[*] Rancid Ooze", -- [2]
		},
		[2098] = {
			1864, -- [1]
			4, -- [2]
		},
		[212530] = {
			1871, -- [1]
			"Spellblade Aluriel", -- [2]
		},
		[236571] = {
			2038, -- [1]
			"Corrupted Blade", -- [2]
		},
		[198750] = {
			1809, -- [1]
			"Stormforged Obliterator", -- [2]
		},
		[40505] = {
			1885, -- [1]
			"Plague Ghoul", -- [2]
		},
		[54965] = {
			2026, -- [1]
			"Dragonflayer Runecaster", -- [2]
		},
		[210074] = {
			1849, -- [1]
			"Skorpyron", -- [2]
		},
		[226385] = {
			1792, -- [1]
			"Tarspitter Lurker", -- [2]
		},
		[240970] = {
			2038, -- [1]
			"Fallen Avatar", -- [2]
		},
		[32736] = {
			1143, -- [1]
			"Gold Warrior", -- [2]
		},
		[198495] = {
			1824, -- [1]
			"Helya", -- [2]
		},
		[206939] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[193093] = {
			1812, -- [1]
			"King Deepbeard", -- [2]
		},
		[227985] = {
			1957, -- [1]
			"Coggleston", -- [2]
		},
		[207707] = {
			1807, -- [1]
			"Unknown", -- [2]
		},
		[199775] = {
			1792, -- [1]
			"Naraxas", -- [2]
		},
		[234830] = {
			2039, -- [1]
			"Mephistroth", -- [2]
		},
		[197952] = {
			1824, -- [1]
			"Destructor Tentacle", -- [2]
		},
		[198496] = {
			1791, -- [1]
			"Ularogg Cragshaper", -- [2]
		},
		[227410] = {
			1957, -- [1]
			"Galindre", -- [2]
		},
		[47737] = {
			2009, -- [1]
			"Chaotic Rift <Anomalus> <Anomalus>", -- [2]
		},
		[8376] = {
			595, -- [1]
			"Antu'sul", -- [2]
		},
		[22917] = {
			348, -- [1]
			"Magister Kalendris", -- [2]
		},
		[6253] = {
			364, -- [1]
			"Gordok Brute", -- [2]
		},
		[246326] = {
			2067, -- [1]
			"Viceroy Nezhar", -- [2]
		},
		[236442] = {
			2050, -- [1]
			"Captain Yathae Moonstrike", -- [2]
		},
		[35839] = {
			1889, -- [1]
			"Auchenai Necromancer", -- [2]
		},
		[215128] = {
			1873, -- [1]
			"Il'gynoth", -- [2]
		},
		[151928] = {
			1664, -- [1]
			"Gelatanized Plague Gunk", -- [2]
		},
		[8264] = {
			593, -- [1]
			"Sandfury Witch Doctor", -- [2]
		},
		[246329] = {
			2073, -- [1]
			"Asara, Mother of Night", -- [2]
		},
		[193636] = {
			1811, -- [1]
			"Saltsea Droplet", -- [2]
		},
		[209387] = {
			1873, -- [1]
			"Nightmare Horror", -- [2]
		},
		[200289] = {
			1839, -- [1]
			"Shade of Xavius", -- [2]
		},
		[198717] = {
			1791, -- [1]
			"Bellowing Idol", -- [2]
		},
		[240916] = {
			2051, -- [1]
			"Kil'jaeden", -- [2]
		},
		[113866] = {
			1427, -- [1]
			"Jandice Barov", -- [2]
		},
		[221783] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[12742] = {
			241, -- [1]
			"Plugger Spazzring", -- [2]
		},
		[235969] = {
			2054, -- [1]
			"Fallen Priestess", -- [2]
		},
		[213807] = {
			1871, -- [1]
			"[*] Burst of Ice", -- [2]
		},
		[183633] = {
			1791, -- [1]
			"Rockbound Pelter", -- [2]
		},
		[246324] = {
			2067, -- [1]
			"Viceroy Nezhar", -- [2]
		},
		[32424] = {
			1889, -- [1]
			"Exarch Maladaar", -- [2]
		},
		[35008] = {
			1941, -- [1]
			"Rokmar the Crackler", -- [2]
		},
		[106830] = {
			2038, -- [1]
			11, -- [2]
		},
		[236568] = {
			2054, -- [1]
			"Unknown", -- [2]
		},
		[14868] = {
			241, -- [1]
			"Guzzling Patron", -- [2]
		},
		[191847] = {
			1813, -- [1]
			"Serpentrix", -- [2]
		},
		[234550] = {
			2048, -- [1]
			"Atrigan", -- [2]
		},
		[212886] = {
			1873, -- [1]
			"Il'gynoth", -- [2]
		},
		[206645] = {
			1867, -- [1]
			"Trilliax", -- [2]
		},
		[32065] = {
			1947, -- [1]
			"Underbog Lord", -- [2]
		},
		[248396] = {
			2092, -- [1]
			"Soulblight Orb <Argus the Unmaker> <Argus the Unmaker>", -- [2]
		},
		[213853] = {
			1871, -- [1]
			"Spellblade Aluriel", -- [2]
		},
		[30153] = {
			2048, -- [1]
			"Felguard <Pocomaxa-Spirestone>", -- [2]
		},
		[191848] = {
			1813, -- [1]
			"Serpentrix", -- [2]
		},
		[206433] = {
			1863, -- [1]
			"Star Augur Etraeus", -- [2]
		},
		[33793] = {
			1892, -- [1]
			"Nazan", -- [2]
		},
		[233556] = {
			2038, -- [1]
			"Containment Pylon", -- [2]
		},
		[209248] = {
			1872, -- [1]
			"Elisande", -- [2]
		},
		[236115] = {
			2050, -- [1]
			"Priestess Lunaspyre", -- [2]
		},
		[197478] = {
			1833, -- [1]
			"Illysanna Ravencrest", -- [2]
		},
		[37668] = {
			1901, -- [1]
			"Ethereal Spellbinder", -- [2]
		},
		[42972] = {
			2026, -- [1]
			"Dragonflayer Strategist", -- [2]
		},
		[9080] = {
			1146, -- [1]
			"Vicious Thug", -- [2]
		},
		[192617] = {
			1814, -- [1]
			"Wrath of Azshara", -- [2]
		},
		[227416] = {
			1957, -- [1]
			"Galindre", -- [2]
		},
		[149886] = {
			1668, -- [1]
			"Domina", -- [2]
		},
		[15285] = {
			239, -- [1]
			"Phalanx", -- [2]
		},
		[207714] = {
			1863, -- [1]
			"Star Augur Etraeus", -- [2]
		},
		[133] = {
			2038, -- [1]
			8, -- [2]
		},
		[196810] = {
			2052, -- [1]
			"Unknown <Aethelstan-Blackhand>", -- [2]
		},
		[51637] = {
			1864, -- [1]
			4, -- [2]
		},
		[206488] = {
			1867, -- [1]
			"[*] Arcane Seepage", -- [2]
		},
		[239155] = {
			2051, -- [1]
			"Kil'jaeden", -- [2]
		},
		[36992] = {
			1931, -- [1]
			"Pathaleon the Calculator", -- [2]
		},
		[200551] = {
			1793, -- [1]
			"Dargrul", -- [2]
		},
		[93527] = {
			1073, -- [1]
			"Lord Walden", -- [2]
		},
		[13398] = {
			380, -- [1]
			"Leprous Technician", -- [2]
		},
		[30914] = {
			1924, -- [1]
			"Unknown <Broggok> <Broggok>", -- [2]
		},
		[196203] = {
			1811, -- [1]
			"Mak'rana Hardshell", -- [2]
		},
		[57846] = {
			2026, -- [1]
			"Dragonflayer Ironhelm", -- [2]
		},
		[192619] = {
			1814, -- [1]
			"Wrath of Azshara", -- [2]
		},
		[149888] = {
			1668, -- [1]
			"Domina", -- [2]
		},
		[22886] = {
			367, -- [1]
			"King Gordok", -- [2]
		},
		[215443] = {
			1876, -- [1]
			"Elerethe Renferal", -- [2]
		},
		[22950] = {
			349, -- [1]
			"Immol'thar", -- [2]
		},
		[241237] = {
			2036, -- [1]
			"Razorjaw Myrmidon", -- [2]
		},
		[15605] = {
			237, -- [1]
			"Golem Lord Argelmach", -- [2]
		},
		[15621] = {
			232, -- [1]
			"Warbringer Construct", -- [2]
		},
		[11639] = {
			488, -- [1]
			"Ogom the Wretched", -- [2]
		},
		[233098] = {
			1871, -- [1]
			"[*] Blazing Charge", -- [2]
		},
		[240213] = {
			2038, -- [1]
			"Fallen Avatar", -- [2]
		},
		[66021] = {
			1143, -- [1]
			"Ebon Champion", -- [2]
		},
		[151681] = {
			1667, -- [1]
			"Ghamoo-Ra", -- [2]
		},
		[202088] = {
			1824, -- [1]
			"Helya", -- [2]
		},
		[31458] = {
			1921, -- [1]
			"Temporus", -- [2]
		},
		[15749] = {
			362, -- [1]
			"Guard Mol'dar", -- [2]
		},
		[194668] = {
			1823, -- [1]
			"Harbaron", -- [2]
		},
		[219488] = {
			1868, -- [1]
			"Patrol Captain Gerdo", -- [2]
		},
		[38592] = {
			1921, -- [1]
			"Temporus", -- [2]
		},
		[215906] = {
			1862, -- [1]
			"Tichondrius", -- [2]
		},
		[202089] = {
			1791, -- [1]
			"Burning Geode", -- [2]
		},
		[17353] = {
			475, -- [1]
			"Unknown <Willey Hopebreaker> <Willey Hopebreaker>", -- [2]
		},
		[245396] = {
			2067, -- [1]
			"L'ura", -- [2]
		},
		[203881] = {
			1829, -- [1]
			"Advisor Vandros", -- [2]
		},
		[38540] = {
			1920, -- [1]
			"Chrono Lord Deja", -- [2]
		},
		[35266] = {
			1930, -- [1]
			"Sunseeker Astromage", -- [2]
		},
		[113999] = {
			1428, -- [1]
			"Rattlegore", -- [2]
		},
		[197484] = {
			1833, -- [1]
			"Illysanna Ravencrest", -- [2]
		},
		[210022] = {
			1872, -- [1]
			"Elisande", -- [2]
		},
		[191855] = {
			1813, -- [1]
			"Serpentrix", -- [2]
		},
		[11895] = {
			595, -- [1]
			"Antu'sul", -- [2]
		},
		[31464] = {
			1921, -- [1]
			"Temporus", -- [2]
		},
		[86771] = {
			1145, -- [1]
			"Rumbling Earth", -- [2]
		},
		[207720] = {
			1863, -- [1]
			"Thing That Should Not Be <Star Augur Etraeus>", -- [2]
		},
		[195182] = {
			1866, -- [1]
			"Rune Weapon <Sunara-CenarionCircle>", -- [2]
		},
		[228190] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[203882] = {
			1829, -- [1]
			"Advisor Vandros", -- [2]
		},
		[210279] = {
			1877, -- [1]
			"Cenarius", -- [2]
		},
		[196206] = {
			1850, -- [1]
			"Shadowmoon Warlock", -- [2]
		},
		[12039] = {
			598, -- [1]
			"Shadowpriest Sezz'ziz", -- [2]
		},
		[219235] = {
			1886, -- [1]
			"Toxic Spore", -- [2]
		},
		[149893] = {
			1668, -- [1]
			"Domina", -- [2]
		},
		[69989] = {
			1100, -- [1]
			"Skybreaker Marksman", -- [2]
		},
		[150405] = {
			1668, -- [1]
			"Twilight Storm Mender", -- [2]
		},
		[210024] = {
			1872, -- [1]
			"Elisande", -- [2]
		},
		[209973] = {
			1872, -- [1]
			"Elisande", -- [2]
		},
		[215754] = {
			1864, -- [1]
			"Spawn of Serpentrix <Acc-Illidan>", -- [2]
		},
		[12167] = {
			590, -- [1]
			"Lord Serpentis", -- [2]
		},
		[254727] = {
			2067, -- [1]
			"Lashing Voidling", -- [2]
		},
		[150332] = {
			1665, -- [1]
			"Splinterbone Warrior", -- [2]
		},
		[38593] = {
			1921, -- [1]
			"Temporus", -- [2]
		},
		[245634] = {
			2073, -- [1]
			"[*] Whirling Saber", -- [2]
		},
		[201837] = {
			1838, -- [1]
			"Taintheart Summoner", -- [2]
		},
		[191858] = {
			1813, -- [1]
			"[*] Toxic Puddle", -- [2]
		},
		[196208] = {
			1850, -- [1]
			"Shadowmoon Warlock", -- [2]
		},
		[15493] = {
			234, -- [1]
			"Fineous Darkvire", -- [2]
		},
		[155722] = {
			2038, -- [1]
			11, -- [2]
		},
		[245586] = {
			2073, -- [1]
			"Diima, Mother of Gloom", -- [2]
		},
		[205420] = {
			1842, -- [1]
			"Krosus", -- [2]
		},
		[8265] = {
			593, -- [1]
			"Lava Spout Totem <Sandfury Witch Doctor>", -- [2]
		},
		[207979] = {
			1869, -- [1]
			"Jazshariu", -- [2]
		},
		[93581] = {
			1069, -- [1]
			"Baron Ashbury", -- [2]
		},
		[205549] = {
			1792, -- [1]
			"Naraxas", -- [2]
		},
		[93423] = {
			1069, -- [1]
			"Baron Ashbury", -- [2]
		},
		[194674] = {
			1822, -- [1]
			"Seacursed Slaver", -- [2]
		},
		[62016] = {
			1141, -- [1]
			"Thorim", -- [2]
		},
		[12471] = {
			594, -- [1]
			"Sandfury Shadowcaster", -- [2]
		},
		[238429] = {
			2051, -- [1]
			"Kil'jaeden", -- [2]
		},
		[195309] = {
			1824, -- [1]
			"[*] Swirling Water", -- [2]
		},
		[62326] = {
			1141, -- [1]
			"Dark Rune Commoner", -- [2]
		},
		[227427] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[208748] = {
			1864, -- [1]
			"Dread Abomination", -- [2]
		},
		[33860] = {
			367, -- [1]
			"Cho'Rush the Observer", -- [2]
		},
		[150660] = {
			1672, -- [1]
			"Deep Terror", -- [2]
		},
		[111775] = {
			1429, -- [1]
			"Lilian Voss", -- [2]
		},
		[238430] = {
			2051, -- [1]
			"Kil'jaeden", -- [2]
		},
		[244751] = {
			2067, -- [1]
			"Viceroy Nezhar", -- [2]
		},
		[220519] = {
			1837, -- [1]
			"Unknown", -- [2]
		},
		[199250] = {
			1824, -- [1]
			"Seacursed Swiftblade", -- [2]
		},
		[17162] = {
			476, -- [1]
			"Risen Conjuror", -- [2]
		},
		[233530] = {
			2036, -- [1]
			"Harjatan", -- [2]
		},
		[188493] = {
			1792, -- [1]
			"Naraxas", -- [2]
		},
		[227809] = {
			1954, -- [1]
			"Maiden of Virtue", -- [2]
		},
		[213867] = {
			1871, -- [1]
			"Spellblade Aluriel", -- [2]
		},
		[204292] = {
			1849, -- [1]
			"Skorpyron", -- [2]
		},
		[212332] = {
			2054, -- [1]
			"Stitchscab <Heoki-Dalaran>", -- [2]
		},
		[5374] = {
			1864, -- [1]
			4, -- [2]
		},
		[75] = {
			2038, -- [1]
			3, -- [2]
		},
		[233021] = {
			2032, -- [1]
			"[*] Infernal Spike", -- [2]
		},
		[150507] = {
			1671, -- [1]
			"Aqua Guardian", -- [2]
		},
		[209518] = {
			1866, -- [1]
			"Eye of Gul'dan", -- [2]
		},
		[47668] = {
			1974, -- [1]
			"Drakkari Guardian", -- [2]
		},
		[201842] = {
			1838, -- [1]
			"Taintheart Summoner", -- [2]
		},
		[202098] = {
			1824, -- [1]
			"Helya", -- [2]
		},
		[196213] = {
			1825, -- [1]
			"Corstilax", -- [2]
		},
		[227415] = {
			1960, -- [1]
			"[*] Intangible Presence", -- [2]
		},
		[251572] = {
			2092, -- [1]
			"[*] Soulburst Detonation", -- [2]
		},
		[219498] = {
			1868, -- [1]
			"Patrol Captain Gerdo", -- [2]
		},
		[227477] = {
			1957, -- [1]
			"Elfyra", -- [2]
		},
		[15244] = {
			2010, -- [1]
			"Mage Hunter Ascendant", -- [2]
		},
		[15062] = {
			243, -- [1]
			"Anger'rel", -- [2]
		},
		[30636] = {
			1893, -- [1]
			"Shattered Hand Warhound", -- [2]
		},
		[13953] = {
			234, -- [1]
			"Fineous Darkvire", -- [2]
		},
		[257286] = {
			1864, -- [1]
			4, -- [2]
		},
		[194216] = {
			1823, -- [1]
			"Harbaron", -- [2]
		},
		[235907] = {
			2054, -- [1]
			"Engine of Souls", -- [2]
		},
		[227463] = {
			1961, -- [1]
			"Lord Robin Daris", -- [2]
		},
		[227365] = {
			1960, -- [1]
			"Midnight", -- [2]
		},
		[15096] = {
			245, -- [1]
			"Twilight's Hammer Ambassador", -- [2]
		},
		[212335] = {
			2054, -- [1]
			"Stitchscab <Heoki-Dalaran>", -- [2]
		},
		[22860] = {
			366, -- [1]
			"Captain Kromcrush", -- [2]
		},
		[48894] = {
			1974, -- [1]
			"Drakkari Shaman", -- [2]
		},
		[15254] = {
			1899, -- [1]
			"Ethereal Beacon", -- [2]
		},
		[203124] = {
			1854, -- [1]
			"Lethon", -- [2]
		},
		[7645] = {
			348, -- [1]
			"Magister Kalendris", -- [2]
		},
		[228200] = {
			1957, -- [1]
			"Luminore", -- [2]
		},
		[192633] = {
			1814, -- [1]
			"Wrath of Azshara", -- [2]
		},
		[198263] = {
			1809, -- [1]
			"Odyn", -- [2]
		},
		[233062] = {
			2032, -- [1]
			"Goroth", -- [2]
		},
		[122832] = {
			472, -- [1]
			"The Unforgiven", -- [2]
		},
		[16427] = {
			480, -- [1]
			"Crypt Beast", -- [2]
		},
		[203125] = {
			1854, -- [1]
			"Emeriss", -- [2]
		},
		[28747] = {
			1998, -- [1]
			"Sjonnir The Ironshaper", -- [2]
		},
		[212337] = {
			2051, -- [1]
			"Foulgut <Heoki-Dalaran>", -- [2]
		},
		[15574] = {
			242, -- [1]
			"Ambassador Flamelash", -- [2]
		},
		[30916] = {
			1924, -- [1]
			"Broggok", -- [2]
		},
		[210546] = {
			1872, -- [1]
			"Elisande", -- [2]
		},
		[47743] = {
			2009, -- [1]
			"Anomalus", -- [2]
		},
		[253022] = {
			1864, -- [1]
			4, -- [2]
		},
		[43649] = {
			2024, -- [1]
			"Dalronn the Controller", -- [2]
		},
		[93535] = {
			1073, -- [1]
			"Lord Walden", -- [2]
		},
		[22920] = {
			361, -- [1]
			"Prince Tortheldrin", -- [2]
		},
		[193659] = {
			1808, -- [1]
			"God-King Skovald", -- [2]
		},
		[212338] = {
			2054, -- [1]
			"Stitchscab <Heoki-Dalaran>", -- [2]
		},
		[229738] = {
			1872, -- [1]
			"Elisande", -- [2]
		},
		[222062] = {
			1864, -- [1]
			4, -- [2]
		},
		[206965] = {
			1863, -- [1]
			"Star Augur Etraeus", -- [2]
		},
		[15654] = {
			348, -- [1]
			"Magister Kalendris", -- [2]
		},
		[211571] = {
			1862, -- [1]
			"Felsworn Chaos-Mage", -- [2]
		},
		[244579] = {
			2065, -- [1]
			"Zuraal the Ascended", -- [2]
		},
		[193660] = {
			1808, -- [1]
			"God-King Skovald", -- [2]
		},
		[200732] = {
			1793, -- [1]
			"Dargrul", -- [2]
		},
		[227300] = {
			1866, -- [1]
			"[*] Arcanetic Eruption", -- [2]
		},
		[241509] = {
			2037, -- [1]
			"Razorjaw Waverunner", -- [2]
		},
		[63550] = {
			1133, -- [1]
			"Guardian Lasher", -- [2]
		},
		[199034] = {
			1806, -- [1]
			"Valarjar Aspirant", -- [2]
		},
		[221807] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[48895] = {
			1974, -- [1]
			"Drakkari Shaman", -- [2]
		},
		[202913] = {
			1815, -- [1]
			"Tirathon Saltheril", -- [2]
		},
		[233520] = {
			2036, -- [1]
			"Harjatan", -- [2]
		},
		[19434] = {
			2038, -- [1]
			3, -- [2]
		},
		[149908] = {
			1675, -- [1]
			"Thruk", -- [2]
		},
		[54850] = {
			1983, -- [1]
			"Drakkari Colossus", -- [2]
		},
		[209270] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[7965] = {
			586, -- [1]
			"Lord Cobrahn", -- [2]
		},
		[13895] = {
			235, -- [1]
			"Bael'Gar", -- [2]
		},
		[31623] = {
			1947, -- [1]
			"Swamplord Musel'ek", -- [2]
		},
		[258399] = {
			2092, -- [1]
			"Argus the Unmaker", -- [2]
		},
		[38538] = {
			1920, -- [1]
			"Chrono Lord Deja", -- [2]
		},
		[167819] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[14744] = {
			242, -- [1]
			"Ambassador Flamelash", -- [2]
		},
		[194942] = {
			1817, -- [1]
			"Glazer", -- [2]
		},
		[244582] = {
			2032, -- [1]
			"[*] Crashing Comet", -- [2]
		},
		[11976] = {
			1885, -- [1]
			"Skeletal Berserker", -- [2]
		},
		[199804] = {
			1864, -- [1]
			4, -- [2]
		},
		[30213] = {
			2048, -- [1]
			"Felguard <Pocomaxa-Spirestone>", -- [2]
		},
		[198269] = {
			1836, -- [1]
			"Archdruid Glaidalis", -- [2]
		},
		[12040] = {
			227, -- [1]
			"High Interrogator Gerstahn", -- [2]
		},
		[232757] = {
			2037, -- [1]
			"Mistress Sassz'ine", -- [2]
		},
		[248165] = {
			2092, -- [1]
			"Argus the Unmaker", -- [2]
		},
		[246374] = {
			2073, -- [1]
			"[*] Shadow Blades", -- [2]
		},
		[43650] = {
			2024, -- [1]
			"Dalronn the Controller", -- [2]
		},
		[199033] = {
			1806, -- [1]
			"Valarjar Aspirant", -- [2]
		},
		[202108] = {
			1791, -- [1]
			"Blightshard Shaper", -- [2]
		},
		[149834] = {
			1664, -- [1]
			"Mushlump", -- [2]
		},
		[206459] = {
			1818, -- [1]
			"Avatar of Shadow", -- [2]
		},
		[209017] = {
			1842, -- [1]
			"Burning Ember", -- [2]
		},
		[202365] = {
			1822, -- [1]
			"Runecarver Slave", -- [2]
		},
		[248167] = {
			2092, -- [1]
			"[*] Death Fog", -- [2]
		},
		[30917] = {
			1924, -- [1]
			"Broggok", -- [2]
		},
		[12248] = {
			245, -- [1]
			"Twilight's Hammer Ambassador", -- [2]
		},
		[210315] = {
			1877, -- [1]
			"[*] Nightmare Brambles", -- [2]
		},
		[235117] = {
			2052, -- [1]
			"Maiden of Vigilance", -- [2]
		},
		[22857] = {
			366, -- [1]
			"Captain Kromcrush", -- [2]
		},
		[65648] = {
			1138, -- [1]
			"Aerial Command Unit", -- [2]
		},
		[194945] = {
			1817, -- [1]
			"Glazer", -- [2]
		},
		[213624] = {
			1871, -- [1]
			"[*] Mark of Frost", -- [2]
		},
		[197521] = {
			1833, -- [1]
			"Illysanna Ravencrest", -- [2]
		},
		[150679] = {
			1666, -- [1]
			"Amnennar the Coldbringer", -- [2]
		},
		[220533] = {
			1828, -- [1]
			"Dread Felbat", -- [2]
		},
		[192131] = {
			1810, -- [1]
			"Warlord Parjesh", -- [2]
		},
		[236158] = {
			2054, -- [1]
			"Soul Residue", -- [2]
		},
		[22859] = {
			366, -- [1]
			"Captain Kromcrush", -- [2]
		},
		[43651] = {
			2024, -- [1]
			"Skarvald the Constructor", -- [2]
		},
		[236142] = {
			2054, -- [1]
			"Engine of Souls", -- [2]
		},
		[16172] = {
			476, -- [1]
			"Commander Malor", -- [2]
		},
		[6254] = {
			589, -- [1]
			"Skum", -- [2]
		},
		[247145] = {
			2066, -- [1]
			"Saprish", -- [2]
		},
		[199567] = {
			1835, -- [1]
			"Image of Latosius", -- [2]
		},
		[235120] = {
			2051, -- [1]
			"Shaggybeard-Dalaran's Erupting Reflection", -- [2]
		},
		[78578] = {
			347, -- [1]
			"Illyanna Ravenoak", -- [2]
		},
		[197776] = {
			1828, -- [1]
			"General Xakal", -- [2]
		},
		[195473] = {
			1811, -- [1]
			"Gritslime Snail", -- [2]
		},
		[80362] = {
			587, -- [1]
			"Kresh", -- [2]
		},
		[193668] = {
			1808, -- [1]
			"God-King Skovald", -- [2]
		},
		[31429] = {
			1947, -- [1]
			"Claw", -- [2]
		},
		[239214] = {
			2051, -- [1]
			"Kil'jaeden", -- [2]
		},
		[247403] = {
			2036, -- [1]
			"Harjatan", -- [2]
		},
		[50752] = {
			1996, -- [1]
			"Maiden of Grief", -- [2]
		},
		[17228] = {
			1923, -- [1]
			"Keli'dan the Breaker", -- [2]
		},
		[65209] = {
			1143, -- [1]
			"Guardian of Yogg-Saron <Ominous Cloud>", -- [2]
		},
		[244588] = {
			2065, -- [1]
			"[*] Void Sludge", -- [2]
		},
		[224374] = {
			1869, -- [1]
			"Unknown <Talixae Flamewreath>", -- [2]
		},
		[39049] = {
			1919, -- [1]
			"Aeonus", -- [2]
		},
		[31717] = {
			1948, -- [1]
			"The Black Stalker", -- [2]
		},
		[240209] = {
			2052, -- [1]
			"[*] Unstable Soul", -- [2]
		},
		[257296] = {
			2092, -- [1]
			"Argus the Unmaker", -- [2]
		},
		[31551] = {
			1941, -- [1]
			"Bogstrok", -- [2]
		},
		[49537] = {
			1975, -- [1]
			"The Prophet Tharon'ja", -- [2]
		},
		[192135] = {
			1810, -- [1]
			"Hatecoil Shellbreaker <Warlord Parjesh>", -- [2]
		},
		[224375] = {
			1869, -- [1]
			"Infernal Imp <Talixae Flamewreath> <Talixae Flamewreath>", -- [2]
		},
		[66290] = {
			478, -- [1]
			"Balnazzar", -- [2]
		},
		[239216] = {
			2051, -- [1]
			"Kil'jaeden", -- [2]
		},
		[150438] = {
			1667, -- [1]
			"Razorshell Snapjaw", -- [2]
		},
		[228738] = {
			1964, -- [1]
			"Volatile Energy <The Curator>", -- [2]
		},
		[120024] = {
			1446, -- [1]
			"Lava Guard Gordoth", -- [2]
		},
		[193159] = {
			1812, -- [1]
			"Unknown", -- [2]
		},
		[238502] = {
			2051, -- [1]
			"Kil'jaeden", -- [2]
		},
		[199812] = {
			1826, -- [1]
			"Nal'tira", -- [2]
		},
		[8362] = {
			245, -- [1]
			"High Priestess of Thaurissan", -- [2]
		},
		[3604] = {
			364, -- [1]
			"Gordok Hound", -- [2]
		},
		[210868] = {
			1825, -- [1]
			"Nightborne Spellsword", -- [2]
		},
		[227447] = {
			1957, -- [1]
			"Elfyra", -- [2]
		},
		[210048] = {
			1873, -- [1]
			"Nightmare Ichor", -- [2]
		},
		[212103] = {
			1867, -- [1]
			"Scrubber", -- [2]
		},
		[228215] = {
			1957, -- [1]
			"Babblet", -- [2]
		},
		[86633] = {
			1145, -- [1]
			"Lord Overheat", -- [2]
		},
		[239386] = {
			2050, -- [1]
			"Glaive Target", -- [2]
		},
		[197262] = {
			1824, -- [1]
			"Helya", -- [2]
		},
		[207278] = {
			1868, -- [1]
			"Patrol Captain Gerdo", -- [2]
		},
		[54847] = {
			1983, -- [1]
			"Drakkari Elemental", -- [2]
		},
		[111762] = {
			1426, -- [1]
			"Scholomance Neophyte", -- [2]
		},
		[15063] = {
			476, -- [1]
			"Risen Conjuror", -- [2]
		},
		[12884] = {
			486, -- [1]
			"Dreamscythe", -- [2]
		},
		[256356] = {
			2073, -- [1]
			"[*] Chilled Blood", -- [2]
		},
		[235125] = {
			2052, -- [1]
			"[*] Unstable Soul", -- [2]
		},
		[192138] = {
			1810, -- [1]
			"Hatecoil Crestrider <Warlord Parjesh>", -- [2]
		},
		[221781] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[34970] = {
			1941, -- [1]
			"Rokmar the Crackler", -- [2]
		},
		[246133] = {
			2065, -- [1]
			"Zuraal the Ascended", -- [2]
		},
		[183430] = {
			1792, -- [1]
			"Tarspitter Lurker", -- [2]
		},
		[119999] = {
			1446, -- [1]
			"Lava Guard Gordoth", -- [2]
		},
		[209676] = {
			1870, -- [1]
			"Advisor Melandrus", -- [2]
		},
		[228729] = {
			1957, -- [1]
			"Mrs. Cauldrons", -- [2]
		},
		[232827] = {
			2037, -- [1]
			"Piranhado", -- [2]
		},
		[246900] = {
			2065, -- [1]
			"Void Discharge", -- [2]
		},
		[209027] = {
			1868, -- [1]
			"Duskwatch Guard", -- [2]
		},
		[22858] = {
			366, -- [1]
			"Captain Kromcrush", -- [2]
		},
		[64187] = {
			1140, -- [1]
			"Stormcaller Brundir", -- [2]
		},
		[31289] = {
			1906, -- [1]
			"Foothill Stalker", -- [2]
		},
		[15575] = {
			237, -- [1]
			"Wrath Hammer Construct", -- [2]
		},
		[197506] = {
			1818, -- [1]
			"Creeping Doom", -- [2]
		},
		[257644] = {
			2069, -- [1]
			"Varimathras", -- [2]
		},
		[15537] = {
			245, -- [1]
			"High Priestess of Thaurissan", -- [2]
		},
		[225404] = {
			1871, -- [1]
			"Trained Shadescale", -- [2]
		},
		[50370] = {
			1139, -- [1]
			"Steelforged Defender", -- [2]
		},
		[193164] = {
			1850, -- [1]
			"Blade Dancer Illianna", -- [2]
		},
		[34974] = {
			1947, -- [1]
			"Swamplord Musel'ek", -- [2]
		},
		[212099] = {
			1865, -- [1]
			"[*] Temporal Charge", -- [2]
		},
		[80750] = {
			478, -- [1]
			"Balnazzar", -- [2]
		},
		[11641] = {
			600, -- [1]
			"Sandfury Shadowhunter", -- [2]
		},
		[13704] = {
			478, -- [1]
			"Balnazzar", -- [2]
		},
		[213123] = {
			1876, -- [1]
			"Venomous Spiderling", -- [2]
		},
		[199050] = {
			1806, -- [1]
			"Valarjar Shieldmaiden", -- [2]
		},
		[254733] = {
			2065, -- [1]
			"Dark Aberration", -- [2]
		},
		[238455] = {
			2051, -- [1]
			"Kil'jaeden", -- [2]
		},
		[206464] = {
			1863, -- [1]
			"Coronal Ejection", -- [2]
		},
		[215929] = {
			1790, -- [1]
			"Blightshard Skitter <Rokmora>", -- [2]
		},
		[200329] = {
			1839, -- [1]
			"Shade of Xavius", -- [2]
		},
		[219009] = {
			1886, -- [1]
			"[*] Grace of Nature", -- [2]
		},
		[213124] = {
			1876, -- [1]
			"[*] Venomous Pool", -- [2]
		},
		[199051] = {
			1837, -- [1]
			"Oakheart", -- [2]
		},
		[62396] = {
			1132, -- [1]
			"Flame Leviathan", -- [2]
		},
		[228221] = {
			1957, -- [1]
			"Babblet", -- [2]
		},
		[86636] = {
			1145, -- [1]
			"Lord Overheat", -- [2]
		},
		[198028] = {
			1790, -- [1]
			"[*] Crystalline Ground", -- [2]
		},
		[47747] = {
			2009, -- [1]
			"Anomalus", -- [2]
		},
		[15507] = {
			237, -- [1]
			"Golem Lord Argelmach", -- [2]
		},
		[34914] = {
			1144, -- [1]
			5, -- [2]
		},
		[47748] = {
			2009, -- [1]
			"Anomalus", -- [2]
		},
		[244070] = {
			2069, -- [1]
			"Varimathras", -- [2]
		},
		[217987] = {
			1864, -- [1]
			"Lurking Terror <Xavius>", -- [2]
		},
		[234891] = {
			2052, -- [1]
			"Maiden of Vigilance", -- [2]
		},
		[247157] = {
			2066, -- [1]
			"Saprish", -- [2]
		},
		[220500] = {
			1825, -- [1]
			"[*] Destabilized Orb", -- [2]
		},
		[224377] = {
			1869, -- [1]
			"Infernal Imp <Talixae Flamewreath>", -- [2]
		},
		[211079] = {
			1825, -- [1]
			"Nightborne Reclaimer", -- [2]
		},
		[246134] = {
			2065, -- [1]
			"Zuraal the Ascended", -- [2]
		},
		[240249] = {
			2038, -- [1]
			"[*] Molten Fel", -- [2]
		},
		[246646] = {
			2088, -- [1]
			"Kin'garoth", -- [2]
		},
		[32422] = {
			1889, -- [1]
			"Exarch Maladaar", -- [2]
		},
		[86765] = {
			1145, -- [1]
			"Slag Fury", -- [2]
		},
		[206474] = {
			1862, -- [1]
			"Tichondrius", -- [2]
		},
		[12169] = {
			245, -- [1]
			"Anvilrage Captain", -- [2]
		},
		[209033] = {
			1868, -- [1]
			"Duskwatch Guard", -- [2]
		},
		[241624] = {
			2052, -- [1]
			"Maiden of Vigilance", -- [2]
		},
		[231768] = {
			2036, -- [1]
			"[*] Drenching Waters", -- [2]
		},
		[205707] = {
			1865, -- [1]
			"[*] Temporal Orb", -- [2]
		},
		[234621] = {
			2037, -- [1]
			"[*] Devouring Maw", -- [2]
		},
		[206219] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[57984] = {
			1818, -- [1]
			"Greater Fire Elemental", -- [2]
		},
		[196496] = {
			1807, -- [1]
			"Fenryr", -- [2]
		},
		[16430] = {
			480, -- [1]
			"Thuzadin Necromancer", -- [2]
		},
		[246136] = {
			2065, -- [1]
			"Zuraal the Ascended", -- [2]
		},
		[197264] = {
			1824, -- [1]
			"Helya", -- [2]
		},
		[217990] = {
			1864, -- [1]
			"Lurking Terror <Xavius>", -- [2]
		},
		[193682] = {
			1811, -- [1]
			"Lady Hatecoil", -- [2]
		},
		[206220] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[183433] = {
			1792, -- [1]
			"Tarspitter Lurker", -- [2]
		},
		[196497] = {
			1807, -- [1]
			"Fenryr", -- [2]
		},
		[239144] = {
			2048, -- [1]
			"Tormented Soul", -- [2]
		},
		[248184] = {
			2067, -- [1]
			"Void Flayer", -- [2]
		},
		[193171] = {
			1812, -- [1]
			"Unknown", -- [2]
		},
		[93675] = {
			1072, -- [1]
			"Lord Godfrey", -- [2]
		},
		[209291] = {
			1866, -- [1]
			"Empowered Eye of Gul'dan", -- [2]
		},
		[206221] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[208506] = {
			1867, -- [1]
			"Trilliax", -- [2]
		},
		[157331] = {
			2038, -- [1]
			"Primal Storm Elemental", -- [2]
		},
		[202895] = {
			1864, -- [1]
			4, -- [2]
		},
		[233856] = {
			2038, -- [1]
			"Maiden of Valor", -- [2]
		},
		[193152] = {
			1812, -- [1]
			"King Deepbeard", -- [2]
		},
		[69869] = {
			1100, -- [1]
			"Skybreaker Sorcerer", -- [2]
		},
		[1604] = {
			1100, -- [1]
			"Skybreaker Summoner", -- [2]
		},
		[206222] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[204666] = {
			1837, -- [1]
			"Oakheart", -- [2]
		},
		[245627] = {
			2073, -- [1]
			"Noura, Mother of Flames", -- [2]
		},
		[239742] = {
			2038, -- [1]
			"[*] Dark Mark", -- [2]
		},
		[246139] = {
			2065, -- [1]
			"Zuraal the Ascended", -- [2]
		},
		[207502] = {
			1867, -- [1]
			"Trilliax", -- [2]
		},
		[150442] = {
			1667, -- [1]
			"Razorshell Snapjaw", -- [2]
		},
		[241511] = {
			2036, -- [1]
			"[*] Drenched", -- [2]
		},
		[229741] = {
			1872, -- [1]
			"Elisande", -- [2]
		},
		[200338] = {
			1793, -- [1]
			"Dargrul", -- [2]
		},
		[3716] = {
			2054, -- [1]
			"Korrothion <Raff-Detheroc>", -- [2]
		},
		[227461] = {
			1957, -- [1]
			"Winged Assistant", -- [2]
		},
		[203153] = {
			1854, -- [1]
			"Ysondre", -- [2]
		},
		[93691] = {
			1071, -- [1]
			"[*] Desecration", -- [2]
		},
		[211007] = {
			1825, -- [1]
			"Nightborne Reclaimer", -- [2]
		},
		[214739] = {
			1850, -- [1]
			"Shadowmoon Technician", -- [2]
		},
		[244834] = {
			2051, -- [1]
			"Kil'jaeden", -- [2]
		},
		[31975] = {
			1890, -- [1]
			"Phasing Stalker", -- [2]
		},
		[245629] = {
			2073, -- [1]
			"Noura, Mother of Flames", -- [2]
		},
		[13737] = {
			366, -- [1]
			"Gordok Reaver <Captain Kromcrush>", -- [2]
		},
		[64126] = {
			1143, -- [1]
			"[*] Squeeze", -- [2]
		},
		[9128] = {
			239, -- [1]
			"Anvilrage Officer", -- [2]
		},
		[51972] = {
			2012, -- [1]
			"Crystalline Tender", -- [2]
		},
		[70116] = {
			1100, -- [1]
			"Spire Frostwyrm", -- [2]
		},
		[29380] = {
			1907, -- [1]
			"Captain Skarloc", -- [2]
		},
		[241280] = {
			1862, -- [1]
			"Felguard Invader", -- [2]
		},
		[13489] = {
			242, -- [1]
			"Burning Spirit", -- [2]
		},
		[225416] = {
			1850, -- [1]
			"Felguard Annihilator", -- [2]
		},
		[199061] = {
			1822, -- [1]
			"Enslaved Shieldmaiden", -- [2]
		},
		[47699] = {
			2012, -- [1]
			"Crystalline Keeper", -- [2]
		},
		[11082] = {
			380, -- [1]
			"Electrocutioner 6000", -- [2]
		},
		[233420] = {
			2048, -- [1]
			"Atrigan", -- [2]
		},
		[218508] = {
			1886, -- [1]
			"High Botanist Tel'arn", -- [2]
		},
		[77758] = {
			2054, -- [1]
			11, -- [2]
		},
		[209454] = {
			1866, -- [1]
			"Eye of Gul'dan", -- [2]
		},
		[232723] = {
			2037, -- [1]
			"Piranhado", -- [2]
		},
		[38539] = {
			1920, -- [1]
			"Chrono Lord Deja", -- [2]
		},
		[201365] = {
			1839, -- [1]
			"Tormented Bloodseeker", -- [2]
		},
		[196804] = {
			1827, -- [1]
			"Ivanyr", -- [2]
		},
		[253098] = {
			1864, -- [1]
			"Mangoman-Thunderlord", -- [2]
		},
		[86620] = {
			1144, -- [1]
			"Hogger", -- [2]
		},
		[193364] = {
			1822, -- [1]
			"Ymiron, the Fallen King", -- [2]
		},
		[186269] = {
			1791, -- [1]
			"Blightshard Shaper", -- [2]
		},
		[227465] = {
			1964, -- [1]
			"The Curator", -- [2]
		},
		[210150] = {
			1792, -- [1]
			"Naraxas", -- [2]
		},
		[255826] = {
			2092, -- [1]
			"Argus the Unmaker", -- [2]
		},
		[193235] = {
			1805, -- [1]
			"Hymdall", -- [2]
		},
		[17366] = {
			477, -- [1]
			"Instructor Galford", -- [2]
		},
		[196570] = {
			1827, -- [1]
			"[*] Volatile Magic", -- [2]
		},
		[18670] = {
			350, -- [1]
			"Ironbark Protector", -- [2]
		},
		[15496] = {
			366, -- [1]
			"Gordok Reaver <Captain Kromcrush>", -- [2]
		},
		[225419] = {
			1850, -- [1]
			"Felguard Annihilator", -- [2]
		},
		[47751] = {
			2009, -- [1]
			"Anomalus", -- [2]
		},
		[258643] = {
			2088, -- [1]
			"Kin'garoth", -- [2]
		},
		[22924] = {
			350, -- [1]
			"Tendris Warpwood", -- [2]
		},
		[228193] = {
			1957, -- [1]
			"Luminore", -- [2]
		},
		[191900] = {
			1810, -- [1]
			"Warlord Parjesh", -- [2]
		},
		[62400] = {
			1132, -- [1]
			"Flame Leviathan", -- [2]
		},
		[50182] = {
			2010, -- [1]
			"Mage Hunter Ascendant", -- [2]
		},
		[30691] = {
			1892, -- [1]
			"Nazan", -- [2]
		},
		[196563] = {
			1810, -- [1]
			"Warlord Parjesh", -- [2]
		},
		[198752] = {
			1822, -- [1]
			"Seacursed Slaver", -- [2]
		},
		[8258] = {
			234, -- [1]
			"Fineous Darkvire", -- [2]
		},
		[212071] = {
			1828, -- [1]
			"General Xakal", -- [2]
		},
		[70395] = {
			1100, -- [1]
			"Spire Minion", -- [2]
		},
		[48583] = {
			2024, -- [1]
			"Skarvald the Constructor", -- [2]
		},
		[151684] = {
			1667, -- [1]
			"Ghamoo-Ra", -- [2]
		},
		[64152] = {
			1143, -- [1]
			"Corruptor Tentacle", -- [2]
		},
		[93424] = {
			1069, -- [1]
			"[*] Asphyxiate", -- [2]
		},
		[239132] = {
			2038, -- [1]
			"Fallen Avatar", -- [2]
		},
		[196543] = {
			1807, -- [1]
			"Fenryr", -- [2]
		},
		[208230] = {
			1862, -- [1]
			"Tichondrius", -- [2]
		},
		[192621] = {
			1816, -- [1]
			"Ash'Golm", -- [2]
		},
		[192158] = {
			1806, -- [1]
			"Olmyr the Enlightened", -- [2]
		},
		[196508] = {
			1850, -- [1]
			"Deranged Mindflayer", -- [2]
		},
		[217234] = {
			1791, -- [1]
			"Ularogg Cragshaper", -- [2]
		},
		[32911] = {
			1143, -- [1]
			"Gold Shaman", -- [2]
		},
		[192108] = {
			1815, -- [1]
			"[*] Glaive", -- [2]
		},
		[11431] = {
			588, -- [1]
			"Lord Pythas", -- [2]
		},
		[197788] = {
			1828, -- [1]
			"Dread Felbat", -- [2]
		},
		[70396] = {
			1100, -- [1]
			"Spire Minion", -- [2]
		},
		[11898] = {
			600, -- [1]
			"Sandfury Blood Drinker", -- [2]
		},
		[206744] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[47688] = {
			2009, -- [1]
			"Chaotic Rift <Anomalus> <Anomalus>", -- [2]
		},
		[232732] = {
			2037, -- [1]
			"[*] Slicing Tornado", -- [2]
		},
		[26977] = {
			232, -- [1]
			"Lord Incendius", -- [2]
		},
		[11978] = {
			234, -- [1]
			"Fineous Darkvire", -- [2]
		},
		[191284] = {
			1805, -- [1]
			"Hymdall", -- [2]
		},
		[185763] = {
			1864, -- [1]
			4, -- [2]
		},
		[208536] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[62465] = {
			1141, -- [1]
			"[*] Runic Smash", -- [2]
		},
		[224995] = {
			1862, -- [1]
			"Dreadguard", -- [2]
		},
		[31602] = {
			480, -- [1]
			"Nerub'enkan", -- [2]
		},
		[207513] = {
			1867, -- [1]
			"Trilliax", -- [2]
		},
		[66047] = {
			1143, -- [1]
			"Ebon Champion", -- [2]
		},
		[150709] = {
			1666, -- [1]
			"[*] Soul Leech", -- [2]
		},
		[236567] = {
			2054, -- [1]
			"Unknown", -- [2]
		},
		[17279] = {
			475, -- [1]
			"Willey Hopebreaker", -- [2]
		},
		[48017] = {
			2012, -- [1]
			"Ormorok the Tree-Shaper", -- [2]
		},
		[36582] = {
			1930, -- [1]
			"Tempest-Forge Destroyer", -- [2]
		},
		[8150] = {
			592, -- [1]
			"Mutanus the Devourer", -- [2]
		},
		[54966] = {
			2026, -- [1]
			"Dragonflayer Strategist", -- [2]
		},
		[50841] = {
			1998, -- [1]
			"Sjonnir The Ironshaper", -- [2]
		},
		[214167] = {
			1863, -- [1]
			"Star Augur Etraeus", -- [2]
		},
		[247175] = {
			2066, -- [1]
			"Saprish", -- [2]
		},
		[48095] = {
			2011, -- [1]
			"[*] Intense Cold", -- [2]
		},
		[196512] = {
			1807, -- [1]
			"Fenryr", -- [2]
		},
		[227473] = {
			1961, -- [1]
			"[*] Whirling Edge", -- [2]
		},
		[149943] = {
			1670, -- [1]
			"Executioner Gore", -- [2]
		},
		[199327] = {
			1824, -- [1]
			"Seacursed Swiftblade", -- [2]
		},
		[226194] = {
			1864, -- [1]
			"Xavius", -- [2]
		},
		[253061] = {
			2092, -- [1]
			"Constellar Designate", -- [2]
		},
		[16592] = {
			1900, -- [1]
			"Ethereal Darkcaster", -- [2]
		},
		[218774] = {
			1886, -- [1]
			"Solarist Tel'arn <High Botanist Tel'arn> <High Botanist Tel'arn>", -- [2]
		},
		[15529] = {
			244, -- [1]
			"Ironhand Guardian", -- [2]
		},
		[192675] = {
			1814, -- [1]
			"Mystic Tornado", -- [2]
		},
		[256388] = {
			2092, -- [1]
			"Reorigination Module", -- [2]
		},
		[120166] = {
			1445, -- [1]
			"Corrupted Reaver", -- [2]
		},
		[244618] = {
			2065, -- [1]
			"Dark Aberration", -- [2]
		},
		[12734] = {
			476, -- [1]
			"Commander Malor", -- [2]
		},
		[204859] = {
			1841, -- [1]
			"Ursoc", -- [2]
		},
		[258018] = {
			2073, -- [1]
			"Diima, Mother of Gloom", -- [2]
		},
		[206749] = {
			1867, -- [1]
			"Trilliax", -- [2]
		},
		[203102] = {
			1854, -- [1]
			"Ysondre", -- [2]
		},
		[207261] = {
			1868, -- [1]
			"Patrol Captain Gerdo", -- [2]
		},
		[227987] = {
			1957, -- [1]
			"Coggleston", -- [2]
		},
		[248713] = {
			2048, -- [1]
			"Tormented Soul", -- [2]
		},
		[183465] = {
			1792, -- [1]
			"Tarspitter Lurker", -- [2]
		},
		[234896] = {
			2052, -- [1]
			"Maiden of Vigilance", -- [2]
		},
		[186576] = {
			1791, -- [1]
			"[*] Petrifying Cloud", -- [2]
		},
		[256396] = {
			2092, -- [1]
			"Reorigination Module", -- [2]
		},
		[207006] = {
			1866, -- [1]
			"Inquisitor Vethriz", -- [2]
		},
		[63106] = {
			2054, -- [1]
			9, -- [2]
		},
		[234129] = {
			2036, -- [1]
			"Razorjaw Gladiator", -- [2]
		},
		[236432] = {
			2052, -- [1]
			"Maiden of Vigilance", -- [2]
		},
		[210228] = {
			1876, -- [1]
			"Screeching Spiderling", -- [2]
		},
		[253073] = {
			2038, -- [1]
			10, -- [2]
		},
		[245388] = {
			1864, -- [1]
			4, -- [2]
		},
		[245650] = {
			2067, -- [1]
			"Shadowguard Trickster", -- [2]
		},
		[14873] = {
			1146, -- [1]
			"Shifty Thief", -- [2]
		},
		[45195] = {
			1930, -- [1]
			"Nethermancer Sepethrea", -- [2]
		},
		[86392] = {
			1864, -- [1]
			4, -- [2]
		},
		[62320] = {
			1141, -- [1]
			"Dark Rune Warbringer", -- [2]
		},
		[193702] = {
			1808, -- [1]
			"[*] Infernal Flames", -- [2]
		},
		[206677] = {
			1842, -- [1]
			"Krosus", -- [2]
		},
		[198088] = {
			1809, -- [1]
			"[*] Glowing Fragment", -- [2]
		},
		[196517] = {
			1832, -- [1]
			"[*] Swirling Scythe", -- [2]
		},
		[15716] = {
			364, -- [1]
			"Gordok Brute", -- [2]
		},
		[33325] = {
			1890, -- [1]
			"Auchenai Necromancer", -- [2]
		},
		[197961] = {
			1809, -- [1]
			"Odyn", -- [2]
		},
		[93685] = {
			1071, -- [1]
			"Commander Springvale", -- [2]
		},
		[206936] = {
			1863, -- [1]
			"Coronal Ejection", -- [2]
		},
		[211261] = {
			1872, -- [1]
			"Elisande", -- [2]
		},
		[62374] = {
			1132, -- [1]
			"Flame Leviathan", -- [2]
		},
		[62467] = {
			1133, -- [1]
			"Elder Ironbranch", -- [2]
		},
		[197963] = {
			1809, -- [1]
			"Odyn", -- [2]
		},
		[256393] = {
			2092, -- [1]
			"Reorigination Module", -- [2]
		},
		[209568] = {
			1872, -- [1]
			"Expedient Elemental", -- [2]
		},
		[191401] = {
			1806, -- [1]
			"Valarjar Marksman", -- [2]
		},
		[56646] = {
			1145, -- [1]
			"Enraged Fire Elemental", -- [2]
		},
		[195256] = {
			2054, -- [1]
			11, -- [2]
		},
		[11131] = {
			594, -- [1]
			"Gahz'rilla", -- [2]
		},
		[15241] = {
			476, -- [1]
			"Risen Conjuror", -- [2]
		},
		[50761] = {
			1996, -- [1]
			"Maiden of Grief", -- [2]
		},
		[227736] = {
			1961, -- [1]
			"Moroes", -- [2]
		},
		[196816] = {
			2052, -- [1]
			"T'uure <Aethelstan-Blackhand>", -- [2]
		},
		[15305] = {
			237, -- [1]
			"Golem Lord Argelmach", -- [2]
		},
		[13900] = {
			232, -- [1]
			"Lord Incendius", -- [2]
		},
		[49034] = {
			1976, -- [1]
			"Novos the Summoner", -- [2]
		},
		[246688] = {
			2065, -- [1]
			"[*] Suppression Field", -- [2]
		},
		[245648] = {
			2067, -- [1]
			"Shadowguard Trickster", -- [2]
		},
		[13338] = {
			1885, -- [1]
			"Postmaster Malown", -- [2]
		},
		[151998] = {
			1662, -- [1]
			"Festering Spiderling", -- [2]
		},
		[236075] = {
			2054, -- [1]
			"Soul Queen Dejahna", -- [2]
		},
		[227508] = {
			1954, -- [1]
			"Maiden of Virtue", -- [2]
		},
		[209742] = {
			1870, -- [1]
			"Image of Advisor Melandrus", -- [2]
		},
		[12493] = {
			488, -- [1]
			"Ogom the Wretched", -- [2]
		},
		[194218] = {
			1823, -- [1]
			"Harbaron", -- [2]
		},
		[245649] = {
			2067, -- [1]
			"Shadowguard Trickster", -- [2]
		},
		[152830] = {
			1668, -- [1]
			"Twilight Storm Mender", -- [2]
		},
		[111854] = {
			1426, -- [1]
			"Instructor Chillheart", -- [2]
		},
		[203254] = {
			1829, -- [1]
			"Advisor Vandros", -- [2]
		},
		[93687] = {
			1071, -- [1]
			"Commander Springvale", -- [2]
		},
		[236694] = {
			2050, -- [1]
			"Captain Yathae Moonstrike", -- [2]
		},
		[15593] = {
			244, -- [1]
			"Magmus", -- [2]
		},
		[205370] = {
			1842, -- [1]
			"Krosus", -- [2]
		},
		[202663] = {
			1850, -- [1]
			"Fel Scorcher", -- [2]
		},
		[192985] = {
			1814, -- [1]
			"Wrath of Azshara", -- [2]
		},
		[235927] = {
			2054, -- [1]
			"Reanimated Templar", -- [2]
		},
		[9532] = {
			585, -- [1]
			"Druid of the Fang", -- [2]
		},
		[197546] = {
			1833, -- [1]
			"Illysanna Ravencrest", -- [2]
		},
		[57807] = {
			1100, -- [1]
			"Skybreaker Protector", -- [2]
		},
		[198058] = {
			1809, -- [1]
			"Odyn", -- [2]
		},
		[202408] = {
			1822, -- [1]
			"Runecarver Slave", -- [2]
		},
		[111599] = {
			1426, -- [1]
			"Scholomance Acolyte", -- [2]
		},
		[216389] = {
			1871, -- [1]
			"Spellblade Aluriel", -- [2]
		},
		[13738] = {
			482, -- [1]
			"Fleshflayer Ghoul", -- [2]
		},
		[42702] = {
			2026, -- [1]
			"Vrykul Skeleton", -- [2]
		},
		[63236] = {
			1139, -- [1]
			"Razorscale", -- [2]
		},
		[31956] = {
			1941, -- [1]
			"Rokmar the Crackler", -- [2]
		},
		[238999] = {
			2051, -- [1]
			"Kil'jaeden", -- [2]
		},
		[206503] = {
			1866, -- [1]
			"[*] Flames of Sargeras", -- [2]
		},
		[151815] = {
			1671, -- [1]
			"Twilight Lord Bathiel", -- [2]
		},
		[16496] = {
			1130, -- [1]
			"Captured Mercenary Soldier", -- [2]
		},
		[251815] = {
			2092, -- [1]
			"Edge of Obliteration <Argus the Unmaker>", -- [2]
		},
		[250335] = {
			2073, -- [1]
			"Noura, Mother of Flames", -- [2]
		},
		[214348] = {
			1876, -- [1]
			"Elerethe Renferal", -- [2]
		},
		[236697] = {
			2050, -- [1]
			"Moontalon <Captain Yathae Moonstrike>", -- [2]
		},
		[210342] = {
			1877, -- [1]
			"Cenarius", -- [2]
		},
		[194615] = {
			1824, -- [1]
			"Seacursed Swiftblade", -- [2]
		},
		[233371] = {
			2036, -- [1]
			"Razorjaw Wavemender", -- [2]
		},
		[113775] = {
			1427, -- [1]
			"Jandice Barov", -- [2]
		},
		[227742] = {
			1961, -- [1]
			"Moroes", -- [2]
		},
		[199915] = {
			1850, -- [1]
			"Faceless Voidcaster", -- [2]
		},
		[246677] = {
			2066, -- [1]
			"Shadowguard Subjugator", -- [2]
		},
		[52042] = {
			1866, -- [1]
			"Healing Stream Totem <Bootszz-Garona>", -- [2]
		},
		[231998] = {
			2036, -- [1]
			"Harjatan", -- [2]
		},
		[22686] = {
			1977, -- [1]
			"King Dred", -- [2]
		},
		[217851] = {
			1792, -- [1]
			"Naraxas", -- [2]
		},
		[150543] = {
			1668, -- [1]
			"Twilight Shadowmage", -- [2]
		},
		[14516] = {
			1144, -- [1]
			"Riverpaw Slayer", -- [2]
		},
		[201566] = {
			1822, -- [1]
			"Seacursed Slaver", -- [2]
		},
		[113136] = {
			1430, -- [1]
			"Darkmaster Gandling", -- [2]
		},
		[193712] = {
			1811, -- [1]
			"Lady Hatecoil", -- [2]
		},
		[197969] = {
			1841, -- [1]
			"Ursoc", -- [2]
		},
		[34259] = {
			488, -- [1]
			"Atal'ai Deathwalker", -- [2]
		},
		[15619] = {
			234, -- [1]
			"Doomforge Craftsman", -- [2]
		},
		[62444] = {
			1130, -- [1]
			"Captured Mercenary Captain", -- [2]
		},
		[248214] = {
			2088, -- [1]
			"Kin'garoth", -- [2]
		},
		[15643] = {
			245, -- [1]
			"Emperor Dagran Thaurissan", -- [2]
		},
		[191977] = {
			1810, -- [1]
			"Warlord Parjesh", -- [2]
		},
		[152592] = {
			1670, -- [1]
			"[*] Executioner's Strike", -- [2]
		},
		[196070] = {
			1825, -- [1]
			"Corstilax", -- [2]
		},
		[212648] = {
			1871, -- [1]
			"[*] Mark of Frost Explosion", -- [2]
		},
		[227233] = {
			1824, -- [1]
			"Helya", -- [2]
		},
		[3110] = {
			2038, -- [1]
			"Yazrot", -- [2]
		},
		[209741] = {
			1870, -- [1]
			"Image of Advisor Melandrus", -- [2]
		},
		[49356] = {
			1975, -- [1]
			"The Prophet Tharon'ja", -- [2]
		},
		[8269] = {
			362, -- [1]
			"Guard Mol'dar", -- [2]
		},
		[201902] = {
			1839, -- [1]
			"Taintheart Deadeye", -- [2]
		},
		[200111] = {
			1839, -- [1]
			"Shade of Xavius", -- [2]
		},
		[230345] = {
			2032, -- [1]
			"[*] Crashing Comet", -- [2]
		},
		[227234] = {
			1824, -- [1]
			"Helya", -- [2]
		},
		[2601] = {
			245, -- [1]
			"Shadowforge Senator", -- [2]
		},
		[221605] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[218838] = {
			1886, -- [1]
			"[*] Arcane Eclipse", -- [2]
		},
		[205741] = {
			1864, -- [1]
			"Xavius", -- [2]
		},
		[33834] = {
			1906, -- [1]
			"Epoch Hunter", -- [2]
		},
		[8994] = {
			241, -- [1]
			"Plugger Spazzring", -- [2]
		},
		[61967] = {
			1133, -- [1]
			"Dark Rune Acolyte", -- [2]
		},
		[200682] = {
			1806, -- [1]
			"Solsten", -- [2]
		},
		[198833] = {
			1835, -- [1]
			"Latosius", -- [2]
		},
		[2818] = {
			1864, -- [1]
			4, -- [2]
		},
		[219815] = {
			1865, -- [1]
			"Chronomatic Anomaly", -- [2]
		},
		[206376] = {
			1842, -- [1]
			"Krosus", -- [2]
		},
		[193716] = {
			1811, -- [1]
			"Lady Hatecoil", -- [2]
		},
		[28858] = {
			350, -- [1]
			"Ironbark Protector", -- [2]
		},
		[204463] = {
			1853, -- [1]
			"Nythendra", -- [2]
		},
		[47773] = {
			2010, -- [1]
			"Grand Magus Telestra", -- [2]
		},
		[227492] = {
			1863, -- [1]
			"Unknown", -- [2]
		},
		[56969] = {
			2010, -- [1]
			"Azure Scale-Binder", -- [2]
		},
		[93564] = {
			1072, -- [1]
			"Lord Godfrey", -- [2]
		},
		[15588] = {
			239, -- [1]
			"Phalanx", -- [2]
		},
		[193717] = {
			1811, -- [1]
			"Lady Hatecoil", -- [2]
		},
		[49037] = {
			1976, -- [1]
			"Novos the Summoner", -- [2]
		},
		[12795] = {
			237, -- [1]
			"Ragereaver Golem", -- [2]
		},
		[241566] = {
			2054, -- [1]
			"Soul Queen Dejahna", -- [2]
		},
		[241822] = {
			2051, -- [1]
			"[*] --unknown spell--", -- [2]
		},
		[232916] = {
			2037, -- [1]
			"[*] Befouling Ink", -- [2]
		},
		[221864] = {
			1872, -- [1]
			"Recursive Elemental", -- [2]
		},
		[5416] = {
			365, -- [1]
			"Carrion Swarmer", -- [2]
		},
		[12891] = {
			493, -- [1]
			"Shade of Eranikus", -- [2]
		},
		[233429] = {
			2036, -- [1]
			"Harjatan", -- [2]
		},
		[239264] = {
			2050, -- [1]
			"Priestess Lunaspyre", -- [2]
		},
		[210705] = {
			2038, -- [1]
			11, -- [2]
		},
		[198392] = {
			1841, -- [1]
			"Ursoc", -- [2]
		},
		[16727] = {
			367, -- [1]
			"King Gordok", -- [2]
		},
		[195254] = {
			1832, -- [1]
			"Amalgam of Souls", -- [2]
		},
		[6016] = {
			480, -- [1]
			"Nerub'enkan", -- [2]
		},
		[203954] = {
			1829, -- [1]
			"Timeless Wraith", -- [2]
		},
		[81039] = {
			378, -- [1]
			"Irradiated Slime", -- [2]
		},
		[241312] = {
			2036, -- [1]
			"Razorjaw Acolyte", -- [2]
		},
		[11020] = {
			595, -- [1]
			"Servant of Antu'sul <Antu'sul> <Antu'sul>", -- [2]
		},
		[64582] = {
			1138, -- [1]
			"VX-001", -- [2]
		},
		[199093] = {
			1822, -- [1]
			"Runecarver Slave", -- [2]
		},
		[32363] = {
			1899, -- [1]
			"Nexus-Prince Shaffar", -- [2]
		},
		[197558] = {
			1807, -- [1]
			"Fenryr", -- [2]
		},
		[9053] = {
			349, -- [1]
			"Highborne Summoner", -- [2]
		},
		[206580] = {
			1868, -- [1]
			"[*] Resonant Slash", -- [2]
		},
		[206514] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[233434] = {
			1876, -- [1]
			"[*] Necrotic Venom", -- [2]
		},
		[113780] = {
			1144, -- [1]
			4, -- [2]
		},
		[69965] = {
			1100, -- [1]
			"Skybreaker Protector", -- [2]
		},
		[201397] = {
			1822, -- [1]
			"Seacursed Soulkeeper", -- [2]
		},
		[150082] = {
			1662, -- [1]
			"Aarux", -- [2]
		},
		[34645] = {
			1893, -- [1]
			"Watchkeeper Gargolmar", -- [2]
		},
		[193977] = {
			1822, -- [1]
			"Ymiron, the Fallen King", -- [2]
		},
		[206515] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[13323] = {
			364, -- [1]
			"Gordok Mage-Lord", -- [2]
		},
		[13339] = {
			349, -- [1]
			"Highborne Summoner", -- [2]
		},
		[243157] = {
			2053, -- [1]
			"Domatrax", -- [2]
		},
		[193210] = {
			1816, -- [1]
			"Ash'Golm", -- [2]
		},
		[113141] = {
			1430, -- [1]
			"Darkmaster Gandling", -- [2]
		},
		[63815] = {
			1139, -- [1]
			"Razorscale", -- [2]
		},
		[152143] = {
			1664, -- [1]
			"Gelatanized Plague Gunk", -- [2]
		},
		[206516] = {
			1866, -- [1]
			"Gul'dan", -- [2]
		},
		[206574] = {
			1868, -- [1]
			"[*] Resonant Slash", -- [2]
		},
		[245921] = {
			2073, -- [1]
			"[*] Spectral Army of Norgannon", -- [2]
		},
		[11436] = {
			245, -- [1]
			"Shadowforge Senator", -- [2]
		},
		[193211] = {
			1822, -- [1]
			"Ymiron, the Fallen King", -- [2]
		},
		[212726] = {
			1877, -- [1]
			"Cenarius", -- [2]
		},
		[236710] = {
			2051, -- [1]
			"Kil'jaeden", -- [2]
		},
		[198073] = {
			1834, -- [1]
			"Smashspite the Hateful", -- [2]
		},
		[201250] = {
			1838, -- [1]
			"Bloodtainted Fury", -- [2]
		},
		[151575] = {
			1663, -- [1]
			"Mordresh Fire Eye", -- [2]
		},
		[149835] = {
			1664, -- [1]
			"Mushlump", -- [2]
		},
		[235236] = {
			2048, -- [1]
			"Belac", -- [2]
		},
		[201400] = {
			1838, -- [1]
			"Dreadfire Imp", -- [2]
		},
		[246690] = {
			2088, -- [1]
			"[*] Decimation", -- [2]
		},
		[244899] = {
			2073, -- [1]
			"Noura, Mother of Flames", -- [2]
		},
		[35760] = {
			1941, -- [1]
			"Greater Bogstrok", -- [2]
		},
		[204471] = {
			1849, -- [1]
			"Skorpyron", -- [2]
		},
		[9613] = {
			472, -- [1]
			"Skeletal Guardian", -- [2]
		},
		[18072] = {
			364, -- [1]
			"Gordok Brute", -- [2]
		},
		[17235] = {
			480, -- [1]
			"Nerub'enkan", -- [2]
		},
		[210688] = {
			1825, -- [1]
			"Withered Manawraith", -- [2]
		},
		[59146] = {
			475, -- [1]
			"Willey Hopebreaker", -- [2]
		},
		[236712] = {
			2050, -- [1]
			"Priestess Lunaspyre", -- [2]
		},
		[212736] = {
			1871, -- [1]
			"[*] Pool of Frost", -- [2]
		},
		[115746] = {
			2038, -- [1]
			"Guzsillin", -- [2]
		},
		[194325] = {
			1823, -- [1]
			"Harbaron", -- [2]
		},
		[7951] = {
			590, -- [1]
			"Deviate Venomwing", -- [2]
		},
		[248227] = {
			2067, -- [1]
			"Grand Shadow-Weaver", -- [2]
		},
		[11836] = {
			594, -- [1]
			"Gahz'rilla", -- [2]
		},
		[164812] = {
			2054, -- [1]
			11, -- [2]
		},
		[33111] = {
			1922, -- [1]
			"Shadowmoon Warlock", -- [2]
		},
		[238570] = {
			2054, -- [1]
			"Engine of Souls", -- [2]
		},
		[224943] = {
			1862, -- [1]
			"Felsworn Chaos-Mage", -- [2]
		},
		[217011] = {
			1792, -- [1]
			"Angry Crowd", -- [2]
		},
		[150601] = {
			1665, -- [1]
			"Death Speaker Blackthorn", -- [2]
		},
		[206612] = {
			1865, -- [1]
			"Chronomatic Anomaly", -- [2]
		},
		[203771] = {
			1854, -- [1]
			"Defiled Druid Spirit <Ysondre>", -- [2]
		},
		[93697] = {
			1073, -- [1]
			"Lord Walden", -- [2]
		},
		[185539] = {
			1824, -- [1]
			"Destructor Tentacle", -- [2]
		},
		[198077] = {
			1809, -- [1]
			"Odyn", -- [2]
		},
		[52174] = {
			1144, -- [1]
			1, -- [2]
		},
		[48873] = {
			1977, -- [1]
			"King Dred", -- [2]
		},
		[245748] = {
			2066, -- [1]
			"Void Discharge", -- [2]
		},
		[16170] = {
			364, -- [1]
			"Gordok Mage-Lord", -- [2]
		},
		[150229] = {
			1664, -- [1]
			"[*] Bubonic Plague", -- [2]
		},
		[48400] = {
			2026, -- [1]
			"Frost Tomb", -- [2]
		},
		[239358] = {
			2048, -- [1]
			"[*] Anguished Outburst", -- [2]
		},
		[236544] = {
			2054, -- [1]
			"Unknown", -- [2]
		},
		[17843] = {
			593, -- [1]
			"Sandfury Witch Doctor", -- [2]
		},
		[245671] = {
			2073, -- [1]
			"Torment of Khaz'goroth", -- [2]
		},
		[199345] = {
			1838, -- [1]
			"Dresaron", -- [2]
		},
		[231854] = {
			2036, -- [1]
			"Harjatan", -- [2]
		},
		[50895] = {
			1998, -- [1]
			"Forged Iron Dwarf <Sjonnir The Ironshaper> <Sjonnir The Ironshaper>", -- [2]
		},
		[247816] = {
			2067, -- [1]
			"L'ura", -- [2]
		},
	},
	["report_where"] = "SAY",
	["got_first_run"] = true,
	["report_pos"] = {
		568.999877929688, -- [1]
		-3.99993896484375, -- [2]
	},
	["latest_report_table"] = {
		{
			1, -- [1]
			1, -- [2]
			4, -- [3]
			5, -- [4]
			"RAID", -- [5]
		}, -- [1]
		{
			1, -- [1]
			2, -- [2]
			1, -- [3]
			5, -- [4]
			"OFFICER", -- [5]
		}, -- [2]
		{
			1, -- [1]
			1, -- [2]
			1, -- [3]
			9, -- [4]
			"PARTY", -- [5]
		}, -- [3]
		{
			1, -- [1]
			4, -- [2]
			4, -- [3]
			5, -- [4]
			"RAID", -- [5]
		}, -- [4]
		{
			1, -- [1]
			1, -- [2]
			1, -- [3]
			5, -- [4]
			"GUILD", -- [5]
		}, -- [5]
		{
			1, -- [1]
			2, -- [2]
			4, -- [3]
			9, -- [4]
			"OFFICER", -- [5]
		}, -- [6]
		{
			1, -- [1]
			1, -- [2]
			3, -- [3]
			2, -- [4]
			"OFFICER", -- [5]
		}, -- [7]
		{
			1, -- [1]
			1, -- [2]
			3, -- [3]
			6, -- [4]
			"GUILD", -- [5]
		}, -- [8]
		{
			1, -- [1]
			1, -- [2]
			8, -- [3]
			5, -- [4]
			"OFFICER", -- [5]
		}, -- [9]
		{
			1, -- [1]
			4, -- [2]
			3, -- [3]
			5, -- [4]
			"GUILD", -- [5]
		}, -- [10]
	},
	["always_use_profile"] = true,
	["boss_mods_timers"] = {
		["encounter_timers_bw"] = {
			["231854"] = {
				"Harjatan the Bludger", -- [1]
				"231854", -- [2]
				"Unchecked Rage", -- [3]
				20.7, -- [4]
				132344, -- [5]
				["id"] = 2036,
			},
			["210296"] = {
				"Gul'dan", -- [1]
				"210296", -- [2]
				"Resonant Barrier: Sunara*", -- [3]
				6, -- [4]
				1022950, -- [5]
				["id"] = 1866,
			},
			["206641"] = {
				"Trilliax", -- [1]
				"206641", -- [2]
				"Arcane Slash", -- [3]
				7.5, -- [4]
				1041233, -- [5]
				["id"] = 1867,
			},
			["206883"] = {
				"Gul'dan", -- [1]
				"206883", -- [2]
				"<Cast: Soul Vortex>", -- [3]
				9, -- [4]
				607512, -- [5]
				["id"] = 1866,
			},
			["236544"] = {
				"The Desolate Host", -- [1]
				"236544", -- [2]
				"Doomed Sundering", -- [3]
				28, -- [4]
				1033912, -- [5]
				["id"] = 2054,
			},
			["218304"] = {
				"High Botanist Tel'arn", -- [1]
				"218304", -- [2]
				"Parasitic Fetter", -- [3]
				30, -- [4]
				538515, -- [5]
				["id"] = 1886,
			},
			["fear"] = {
				"Nighthold Trash", -- [1]
				"fear", -- [2]
				"Fear: Paithan*", -- [3]
				10, -- [4]
				1386549, -- [5]
				["id"] = 1862,
			},
			["214529"] = {
				"Cenarius", -- [1]
				"214529", -- [2]
				"Spear of Nightmares", -- [3]
				23, -- [4]
				1357799, -- [5]
				["id"] = 1877,
			},
			["213853"] = {
				"Spellblade Aluriel", -- [1]
				"213853", -- [2]
				"Animate: Mark of Frost", -- [3]
				75, -- [4]
				135862, -- [5]
				["id"] = 1871,
			},
			["200551"] = {
				"Dargrul", -- [1]
				"200551", -- [2]
				"Crystal Spikes", -- [3]
				21, -- [4]
				132780, -- [5]
				["id"] = 1793,
			},
			["210022"] = {
				"Grand Magistrix Elisande", -- [1]
				"210022", -- [2]
				"Epocheric Orb", -- [3]
				18, -- [4]
				429383, -- [5]
				["id"] = 1872,
			},
			["206464"] = {
				"Star Augur Etraeus", -- [1]
				"206464", -- [2]
				"Coronal Ejection", -- [3]
				12.5, -- [4]
				1029591, -- [5]
				["id"] = 1863,
			},
			["209270"] = {
				"Gul'dan", -- [1]
				"209270", -- [2]
				"Eye of Gul'dan (1)", -- [3]
				50.4, -- [4]
				136210, -- [5]
				["id"] = 1866,
			},
			["222761"] = {
				"Star Augur Etraeus", -- [1]
				"222761", -- [2]
				"Big Bang", -- [3]
				231.5, -- [4]
				1029583, -- [5]
				["id"] = 1863,
			},
			["206896"] = {
				"Gul'dan", -- [1]
				"206896", -- [2]
				"Torn Soul on YOU!", -- [3]
				30, -- [4]
				607512, -- [5]
				["id"] = 1866,
			},
			["248165"] = {
				"Argus the Unmaker", -- [1]
				"248165", -- [2]
				"Cone of Death (1)", -- [3]
				39, -- [4]
				348565, -- [5]
				["id"] = 2092,
			},
			["252616"] = {
				"Argus the Unmaker", -- [1]
				"252616", -- [2]
				"Cosmic Beacon", -- [3]
				53, -- [4]
				525024, -- [5]
				["id"] = 2092,
			},
			["204463"] = {
				"Nythendra", -- [1]
				"204463", -- [2]
				"Volatile Rot", -- [3]
				22.8, -- [4]
				236271, -- [5]
				["id"] = 1853,
			},
			["208910"] = {
				"Trilliax", -- [1]
				"208910", -- [2]
				"Linked with |cffff7c0aEthël*|r", -- [3]
				30, -- [4]
				607854, -- [5]
				["id"] = 1867,
			},
			["240910"] = {
				"Kil'jaeden", -- [1]
				"240910", -- [2]
				"Armageddon (1)", -- [3]
				10, -- [4]
				136186, -- [5]
				["id"] = 2051,
			},
			["207573"] = {
				"Dragons of Nightmare", -- [1]
				"207573", -- [2]
				"Call Defiled Spirit", -- [3]
				30, -- [4]
				1022944, -- [5]
				["id"] = 1854,
			},
			["209011"] = {
				"Gul'dan", -- [1]
				"209011", -- [2]
				"Bonds of Fel (1)", -- [3]
				22.8, -- [4]
				1117883, -- [5]
				["id"] = 1866,
			},
			["recursive_elemental"] = {
				"Grand Magistrix Elisande", -- [1]
				"recursive_elemental", -- [2]
				"Recursive Elemental", -- [3]
				5, -- [4]
				653221, -- [5]
				["id"] = 1872,
			},
			["-12527"] = {
				"Naraxas", -- [1]
				"-12527", -- [2]
				"Wormspeaker Devout", -- [3]
				10, -- [4]
				136189, -- [5]
				["id"] = 1792,
			},
			["204316"] = {
				"Skorpyron", -- [1]
				"204316", -- [2]
				"Shockwave", -- [3]
				59, -- [4]
				1029595, -- [5]
				["id"] = 1849,
			},
			["224508"] = {
				"Xavius", -- [1]
				"224508", -- [2]
				"Corruption Meteor: Ninür*", -- [3]
				5, -- [4]
				1396970, -- [5]
				["id"] = 1864,
			},
			["211192"] = {
				"Cenarius", -- [1]
				"211192", -- [2]
				"Rotten Breath (1)", -- [3]
				20, -- [4]
				1357794, -- [5]
				["id"] = 1877,
			},
			["212364"] = {
				"Elerethe Renferal", -- [1]
				"212364", -- [2]
				"Feeding Time", -- [3]
				16, -- [4]
				132196, -- [5]
				["id"] = 1876,
			},
			["236694"] = {
				"Sisters of the Moon", -- [1]
				"236694", -- [2]
				"Call Moontalon", -- [3]
				7.3, -- [4]
				132150, -- [5]
				["id"] = 2050,
			},
			["203888"] = {
				"Dragons of Nightmare", -- [1]
				"203888", -- [2]
				"Siphon Spirit", -- [3]
				25, -- [4]
				136122, -- [5]
				["id"] = 1854,
			},
			["213275"] = {
				"Spellblade Aluriel", -- [1]
				"213275", -- [2]
				"Detonate: Searing Brand", -- [3]
				48, -- [4]
				135811, -- [5]
				["id"] = 1871,
			},
			["199178"] = {
				"Naraxas", -- [1]
				"199178", -- [2]
				"Spiked Tongue", -- [3]
				50, -- [4]
				136113, -- [5]
				["id"] = 1792,
			},
			["warmup"] = {
				"Gul'dan", -- [1]
				"warmup", -- [2]
				"Active", -- [3]
				66, -- [4]
				"Interface\\Icons\\achievement_thenighthold_guldan", -- [5]
				["id"] = 1866,
			},
			["235117"] = {
				"Maiden of Vigilance", -- [1]
				"235117", -- [2]
				"Unstable Soul on YOU!", -- [3]
				8, -- [4]
				841221, -- [5]
				["id"] = 2052,
			},
			["205420"] = {
				"Krosus", -- [1]
				"205420", -- [2]
				"Burning Pitch (1)", -- [3]
				38, -- [4]
				135804, -- [5]
				["id"] = 1842,
			},
			["stages"] = {
				"Kil'jaeden", -- [1]
				"stages", -- [2]
				"Nether Gale", -- [3]
				60.2, -- [4]
				236222, -- [5]
				["id"] = 2051,
			},
			["239132"] = {
				"Fallen Avatar", -- [1]
				"239132", -- [2]
				"Rupture Realities", -- [3]
				37, -- [4]
				135801, -- [5]
				["id"] = 2038,
			},
			["206219"] = {
				"Gul'dan", -- [1]
				"206219", -- [2]
				"Liquid Hellfire (2)", -- [3]
				15, -- [4]
				135803, -- [5]
				["id"] = 1866,
			},
			["212587"] = {
				"Spellblade Aluriel", -- [1]
				"212587", -- [2]
				"Mark of Frost", -- [3]
				18, -- [4]
				609814, -- [5]
				["id"] = 1871,
			},
			["229945"] = {
				"Gul'dan", -- [1]
				"229945", -- [2]
				"Fel Obelisk", -- [3]
				10, -- [4]
				1118739, -- [5]
				["id"] = 1866,
			},
			["expedient_elemental"] = {
				"Grand Magistrix Elisande", -- [1]
				"expedient_elemental", -- [2]
				"Expedient Elemental", -- [3]
				8, -- [4]
				648208, -- [5]
				["id"] = 1872,
			},
			["206609"] = {
				"Chronomatic Anomaly", -- [1]
				"206609", -- [2]
				"Time Release", -- [3]
				5, -- [4]
				413594, -- [5]
				["id"] = 1865,
			},
			["berserk"] = {
				"Maiden of Vigilance", -- [1]
				"berserk", -- [2]
				"Berserk", -- [3]
				480, -- [4]
				136224, -- [5]
				["id"] = 2052,
			},
			["233263"] = {
				"Sisters of the Moon", -- [1]
				"233263", -- [2]
				"Embrace of the Eclipse", -- [3]
				44.8559999999998, -- [4]
				236151, -- [5]
				["id"] = 2050,
			},
			["240735"] = {
				"Tomb of Sargeras Trash", -- [1]
				"240735", -- [2]
				"Polymorph Bomb: Peybear*", -- [3]
				9.99900000006892, -- [4]
				575586, -- [5]
				["id"] = 2054,
			},
			["235907"] = {
				"The Desolate Host", -- [1]
				"235907", -- [2]
				"Collapsing Fissure", -- [3]
				6, -- [4]
				136160, -- [5]
				["id"] = 2054,
			},
			["233556"] = {
				"Fallen Avatar", -- [1]
				"233556", -- [2]
				"Corrupted Matrix", -- [3]
				50, -- [4]
				1097741, -- [5]
				["id"] = 2038,
			},
			["216290"] = {
				"Ularogg Cragshaper", -- [1]
				"216290", -- [2]
				"Strike of the Mountain", -- [3]
				15, -- [4]
				136025, -- [5]
				["id"] = 1791,
			},
			["214167"] = {
				"Star Augur Etraeus", -- [1]
				"214167", -- [2]
				"Gravitational Pull", -- [3]
				28, -- [4]
				1041234, -- [5]
				["id"] = 1863,
			},
			["215443"] = {
				"Elerethe Renferal", -- [1]
				"215443", -- [2]
				"Necrotic Venom", -- [3]
				22, -- [4]
				132107, -- [5]
				["id"] = 1876,
			},
			["248812"] = {
				"Maiden of Vigilance", -- [1]
				"248812", -- [2]
				"Blowback", -- [3]
				42.5, -- [4]
				236256, -- [5]
				["id"] = 2052,
			},
			["218927"] = {
				"High Botanist Tel'arn", -- [1]
				"218927", -- [2]
				"Grace of Nature", -- [3]
				13.4, -- [4]
				136074, -- [5]
				["id"] = 1886,
			},
			["230358"] = {
				"Mistress Sassz'ine", -- [1]
				"230358", -- [2]
				"Thundering Shock", -- [3]
				10.5, -- [4]
				839974, -- [5]
				["id"] = 2037,
			},
			["198006"] = {
				"Ursoc", -- [1]
				"198006", -- [2]
				"Focused Gaze (1)", -- [3]
				19, -- [4]
				571585, -- [5]
				["id"] = 1841,
			},
			["204471"] = {
				"Skorpyron", -- [1]
				"204471", -- [2]
				"Focused Blast", -- [3]
				16, -- [4]
				135739, -- [5]
				["id"] = 1849,
			},
			["210264"] = {
				"Xavius", -- [1]
				"210264", -- [2]
				"Manifest Corruption (1)", -- [3]
				59, -- [4]
				1357796, -- [5]
				["id"] = 1864,
			},
			["238505"] = {
				"Kil'jaeden", -- [1]
				"238505", -- [2]
				"Focused Dreadflame", -- [3]
				23.5, -- [4]
				236216, -- [5]
				["id"] = 2051,
			},
			["235059"] = {
				"Kil'jaeden", -- [1]
				"235059", -- [2]
				"Rupturing Singularity (1)", -- [3]
				58, -- [4]
				1041232, -- [5]
				["id"] = 2051,
			},
			["202977"] = {
				"Nythendra", -- [1]
				"202977", -- [2]
				"Infested Breath", -- [3]
				37, -- [4]
				538518, -- [5]
				["id"] = 1853,
			},
			["236542"] = {
				"The Desolate Host", -- [1]
				"236542", -- [2]
				"Sundering Doom", -- [3]
				17, -- [4]
				1120185, -- [5]
				["id"] = 2054,
			},
			["234059"] = {
				"Fallen Avatar", -- [1]
				"234059", -- [2]
				"Unbound Chaos", -- [3]
				7, -- [4]
				135795, -- [5]
				["id"] = 2038,
			},
			["204372"] = {
				"Skorpyron", -- [1]
				"204372", -- [2]
				"Call of the Scorpid", -- [3]
				20, -- [4]
				620833, -- [5]
				["id"] = 1849,
			},
			["209170"] = {
				"Grand Magistrix Elisande", -- [1]
				"209170", -- [2]
				"Spanning Singularity (1)", -- [3]
				23, -- [4]
				135735, -- [5]
				["id"] = 1872,
			},
			["214505"] = {
				"Cenarius", -- [1]
				"214505", -- [2]
				"Entangling Nightmares", -- [3]
				35, -- [4]
				1357814, -- [5]
				["id"] = 1877,
			},
			["204859"] = {
				"Ursoc", -- [1]
				"204859", -- [2]
				"Rend Flesh", -- [3]
				15, -- [4]
				1033474, -- [5]
				["id"] = 1841,
			},
			["bomb_explosions"] = {
				"Argus the Unmaker", -- [1]
				"bomb_explosions", -- [2]
				"Bomb Explosions", -- [3]
				15, -- [4]
				1778228, -- [5]
				["id"] = 2092,
			},
			["208689"] = {
				"Il'gynoth", -- [1]
				"208689", -- [2]
				"Ground Slam", -- [3]
				11.5, -- [4]
				254105, -- [5]
				["id"] = 1873,
			},
			["212735"] = {
				"Spellblade Aluriel", -- [1]
				"212735", -- [2]
				"Detonate: Mark of Frost", -- [3]
				71, -- [4]
				609814, -- [5]
				["id"] = 1871,
			},
			["233983"] = {
				"Demonic Inquisition", -- [1]
				"233983", -- [2]
				"Echoing Anguish", -- [3]
				22, -- [4]
				136181, -- [5]
				["id"] = 2048,
			},
			["210290"] = {
				"Cenarius", -- [1]
				"210290", -- [2]
				"Nightmare Brambles", -- [3]
				28, -- [4]
				1357815, -- [5]
				["id"] = 1877,
			},
			["257296"] = {
				"Argus the Unmaker", -- [1]
				"257296", -- [2]
				"Tortured Rage (1)", -- [3]
				13.5, -- [4]
				136146, -- [5]
				["id"] = 2092,
			},
			["winds"] = {
				"Gul'dan", -- [1]
				"winds", -- [2]
				"Violent Winds (1)", -- [3]
				11.5, -- [4]
				1029595, -- [5]
				["id"] = 1866,
			},
			["198108"] = {
				"Ursoc", -- [1]
				"198108", -- [2]
				"Momentum on YOU", -- [3]
				50, -- [4]
				132096, -- [5]
				["id"] = 1841,
			},
			["206820"] = {
				"Trilliax", -- [1]
				"206820", -- [2]
				"Cleansing Rage", -- [3]
				10.5, -- [4]
				132345, -- [5]
				["id"] = 1867,
			},
			["203552"] = {
				"Nythendra", -- [1]
				"203552", -- [2]
				"Heart of the Swarm", -- [3]
				90, -- [4]
				136128, -- [5]
				["id"] = 1853,
			},
			["236072"] = {
				"The Desolate Host", -- [1]
				"236072", -- [2]
				"Wailing Souls", -- [3]
				60, -- [4]
				136194, -- [5]
				["id"] = 2054,
			},
			["206480"] = {
				"Tichondrius", -- [1]
				"206480", -- [2]
				"Carrion Plague (1)", -- [3]
				7, -- [4]
				1029009, -- [5]
				["id"] = 1862,
			},
			["203787"] = {
				"Dragons of Nightmare", -- [1]
				"203787", -- [2]
				"Volatile Infection", -- [3]
				20, -- [4]
				135914, -- [5]
				["id"] = 1854,
			},
			["236604"] = {
				"Fallen Avatar", -- [1]
				"236604", -- [2]
				"Shadowy Blades", -- [3]
				30, -- [4]
				1035040, -- [5]
				["id"] = 2038,
			},
			["226194"] = {
				"Xavius", -- [1]
				"226194", -- [2]
				"Writhing Deep", -- [3]
				2.0703933747412, -- [4]
				1357812, -- [5]
				["id"] = 1864,
			},
			["214335"] = {
				"Star Augur Etraeus", -- [1]
				"214335", -- [2]
				"Gravitational Pull", -- [3]
				20, -- [4]
				1041234, -- [5]
				["id"] = 1863,
			},
			["236603"] = {
				"Sisters of the Moon", -- [1]
				"236603", -- [2]
				"Rapid Shot", -- [3]
				15.8, -- [4]
				1035040, -- [5]
				["id"] = 2050,
			},
			["233062"] = {
				"Goroth", -- [1]
				"233062", -- [2]
				"Infernal Burning", -- [3]
				54, -- [4]
				135802, -- [5]
				["id"] = 2032,
			},
			["206939"] = {
				"Gul'dan", -- [1]
				"206939", -- [2]
				"Well of Souls", -- [3]
				15.2, -- [4]
				136194, -- [5]
				["id"] = 1866,
			},
			["235924"] = {
				"The Desolate Host", -- [1]
				"235924", -- [2]
				"Spear of Anguish", -- [3]
				6, -- [4]
				135131, -- [5]
				["id"] = 2054,
			},
			["200404"] = {
				"Dargrul", -- [1]
				"200404", -- [2]
				"Magma Wave", -- [3]
				60, -- [4]
				237583, -- [5]
				["id"] = 1793,
			},
			["248499"] = {
				"Argus the Unmaker", -- [1]
				"248499", -- [2]
				"Sweeping Scythe", -- [3]
				7, -- [4]
				1692685, -- [5]
				["id"] = 2092,
			},
			["197943"] = {
				"Ursoc", -- [1]
				"197943", -- [2]
				"Overwhelm", -- [3]
				10, -- [4]
				132358, -- [5]
				["id"] = 1841,
			},
			["203147"] = {
				"Dragons of Nightmare", -- [1]
				"203147", -- [2]
				"Nightmare Blast", -- [3]
				16, -- [4]
				237561, -- [5]
				["id"] = 1854,
			},
			["205549"] = {
				"Naraxas", -- [1]
				"205549", -- [2]
				"Rancid Maw", -- [3]
				7, -- [4]
				136007, -- [5]
				["id"] = 1792,
			},
			["205984"] = {
				"Star Augur Etraeus", -- [1]
				"205984", -- [2]
				"Gravitational Pull", -- [3]
				30, -- [4]
				1041234, -- [5]
				["id"] = 1863,
			},
			["203028"] = {
				"Dragons of Nightmare", -- [1]
				"203028", -- [2]
				"Corrupted Breath", -- [3]
				17, -- [4]
				136123, -- [5]
				["id"] = 1854,
			},
			["-12809"] = {
				"Dragons of Nightmare", -- [1]
				"-12809", -- [2]
				"Mark of Ysondre (1) on YOU", -- [3]
				35, -- [4]
				1354172, -- [5]
				["id"] = 1854,
			},
			["206675"] = {
				"Gul'dan", -- [1]
				"206675", -- [2]
				"Shatter Essence", -- [3]
				18.3, -- [4]
				1109118, -- [5]
				["id"] = 1866,
			},
			["212726"] = {
				"Cenarius", -- [1]
				"212726", -- [2]
				"Forces of Nightmare (1)", -- [3]
				10, -- [4]
				1357812, -- [5]
				["id"] = 1877,
			},
			["238570"] = {
				"The Desolate Host", -- [1]
				"238570", -- [2]
				"Tormented Cries", -- [3]
				120, -- [4]
				463286, -- [5]
				["id"] = 2054,
			},
			["233279"] = {
				"Goroth", -- [1]
				"233279", -- [2]
				"Shattering Star (1)", -- [3]
				24, -- [4]
				517112, -- [5]
				["id"] = 2032,
			},
			["219815"] = {
				"Chronomatic Anomaly", -- [1]
				"219815", -- [2]
				"Temporal Orbs", -- [3]
				48, -- [4]
				610472, -- [5]
				["id"] = 1865,
			},
			["255826"] = {
				"Argus the Unmaker", -- [1]
				"255826", -- [2]
				"Edge of Obliteration", -- [3]
				24, -- [4]
				1778227, -- [5]
				["id"] = 2092,
			},
			["236480"] = {
				"Sisters of the Moon", -- [1]
				"236480", -- [2]
				"Glaive Storm", -- [3]
				22.8110000000015, -- [4]
				132330, -- [5]
				["id"] = 2050,
			},
			["-17077"] = {
				"Argus the Unmaker", -- [1]
				"-17077", -- [2]
				"The Stellar Armory", -- [3]
				30.5, -- [4]
				"Interface\\Icons\\inv_sword_2h_pandaraid_d_01", -- [5]
				["id"] = 2092,
			},
			["235271"] = {
				"Maiden of Vigilance", -- [1]
				"235271", -- [2]
				"Infusion", -- [3]
				2, -- [4]
				1122135, -- [5]
				["id"] = 2052,
			},
			["209165"] = {
				"Grand Magistrix Elisande", -- [1]
				"209165", -- [2]
				"Slow Time Zone (1)", -- [3]
				70, -- [4]
				653221, -- [5]
				["id"] = 1872,
			},
			["209166"] = {
				"Grand Magistrix Elisande", -- [1]
				"209166", -- [2]
				"Fast Time Zone (1)", -- [3]
				35, -- [4]
				648208, -- [5]
				["id"] = 1872,
			},
			["248317"] = {
				"Argus the Unmaker", -- [1]
				"248317", -- [2]
				"Soulblight Orb", -- [3]
				36, -- [4]
				1778225, -- [5]
				["id"] = 2092,
			},
			["236712"] = {
				"Sisters of the Moon", -- [1]
				"236712", -- [2]
				"Lunar Beacon", -- [3]
				18.2, -- [4]
				429383, -- [5]
				["id"] = 2050,
			},
			["forces"] = {
				"Il'gynoth", -- [1]
				"forces", -- [2]
				"Deathglare Tentacle (1)", -- [3]
				26, -- [4]
				462324, -- [5]
				["id"] = 1873,
			},
			["207720"] = {
				"Star Augur Etraeus", -- [1]
				"207720", -- [2]
				"Witness the Void (1)", -- [3]
				14.5, -- [4]
				895885, -- [5]
				["id"] = 1863,
			},
			["236378"] = {
				"Kil'jaeden", -- [1]
				"236378", -- [2]
				"Reflection: Wailing", -- [3]
				48.4, -- [4]
				463284, -- [5]
				["id"] = 2051,
			},
			["209973"] = {
				"Grand Magistrix Elisande", -- [1]
				"209973", -- [2]
				"Ablating Explosion", -- [3]
				12.1, -- [4]
				135728, -- [5]
				["id"] = 1872,
			},
			["233441"] = {
				"Demonic Inquisition", -- [1]
				"233441", -- [2]
				"Bone Saw", -- [3]
				60.5, -- [4]
				999952, -- [5]
				["id"] = 2048,
			},
			["252516"] = {
				"Argus the Unmaker", -- [1]
				"252516", -- [2]
				"The Discs of Norgannon", -- [3]
				27.3, -- [4]
				574567, -- [5]
				["id"] = 2092,
			},
			["232249"] = {
				"Goroth", -- [1]
				"232249", -- [2]
				"Crashing Comet", -- [3]
				8.5, -- [4]
				135797, -- [5]
				["id"] = 2032,
			},
			["232913"] = {
				"Mistress Sassz'ine", -- [1]
				"232913", -- [2]
				"Befouling Ink", -- [3]
				11, -- [4]
				1500933, -- [5]
				["id"] = 2037,
			},
			["210346"] = {
				"Cenarius", -- [1]
				"210346", -- [2]
				"Aura of Dread Thorns", -- [3]
				6, -- [4]
				1357798, -- [5]
				["id"] = 1877,
			},
			["218809"] = {
				"High Botanist Tel'arn", -- [1]
				"218809", -- [2]
				"Call of Night", -- [3]
				26.8, -- [4]
				135752, -- [5]
				["id"] = 1886,
			},
			["205588"] = {
				"Xavius", -- [1]
				"205588", -- [2]
				"Call of Nightmares", -- [3]
				26, -- [4]
				1357812, -- [5]
				["id"] = 1864,
			},
			["211261"] = {
				"Grand Magistrix Elisande", -- [1]
				"211261", -- [2]
				"Permeliative Torment (1)", -- [3]
				23, -- [4]
				1041232, -- [5]
				["id"] = 1872,
			},
			["188169"] = {
				"Rokmora", -- [1]
				"188169", -- [2]
				"Razor Shards", -- [3]
				25, -- [4]
				135857, -- [5]
				["id"] = 1790,
			},
			["smashingBridge"] = {
				"Krosus", -- [1]
				"smashingBridge", -- [2]
				"Smashing Bridge (1)", -- [3]
				93, -- [4]
				135906, -- [5]
				["id"] = 1842,
			},
			["215234"] = {
				"Il'gynoth", -- [1]
				"215234", -- [2]
				"Nightmarish Fury", -- [3]
				10, -- [4]
				530806, -- [5]
				["id"] = 1873,
			},
			["214348"] = {
				"Elerethe Renferal", -- [1]
				"214348", -- [2]
				"Vile Ambush", -- [3]
				8.2, -- [4]
				132089, -- [5]
				["id"] = 1876,
			},
			["215300"] = {
				"Elerethe Renferal", -- [1]
				"215300", -- [2]
				"Web of Pain", -- [3]
				6, -- [4]
				237431, -- [5]
				["id"] = 1876,
			},
			["230345"] = {
				"Goroth", -- [1]
				"230345", -- [2]
				"Crashing Comet", -- [3]
				8.5, -- [4]
				840194, -- [5]
				["id"] = 2032,
			},
			["205741"] = {
				"Xavius", -- [1]
				"205741", -- [2]
				"Lurking Eruption", -- [3]
				18, -- [4]
				1396977, -- [5]
				["id"] = 1864,
			},
			["206005"] = {
				"Xavius", -- [1]
				"206005", -- [2]
				"Dream Simulacrum on YOU!", -- [3]
				180, -- [4]
				1396974, -- [5]
				["id"] = 1864,
			},
			["212492"] = {
				"Spellblade Aluriel", -- [1]
				"212492", -- [2]
				"Annihilate", -- [3]
				8, -- [4]
				135642, -- [5]
				["id"] = 1871,
			},
			["206365"] = {
				"Tichondrius", -- [1]
				"206365", -- [2]
				"Illusionary Night (1)", -- [3]
				130, -- [4]
				607852, -- [5]
				["id"] = 1862,
			},
			["206617"] = {
				"Chronomatic Anomaly", -- [1]
				"206617", -- [2]
				"Time Bomb", -- [3]
				36.5, -- [4]
				609814, -- [5]
				["id"] = 1865,
			},
			["213166"] = {
				"Spellblade Aluriel", -- [1]
				"213166", -- [2]
				"Searing Brand", -- [3]
				18, -- [4]
				135811, -- [5]
				["id"] = 1871,
			},
			["232061"] = {
				"Harjatan the Bludger", -- [1]
				"232061", -- [2]
				"Draw In", -- [3]
				58, -- [4]
				893777, -- [5]
				["id"] = 2036,
			},
			["208230"] = {
				"Tichondrius", -- [1]
				"208230", -- [2]
				"Feast of Blood (1)", -- [3]
				20, -- [4]
				538039, -- [5]
				["id"] = 1862,
			},
			["206744"] = {
				"Gul'dan", -- [1]
				"206744", -- [2]
				"Black Harvest (1)", -- [3]
				71.2, -- [4]
				537517, -- [5]
				["id"] = 1866,
			},
			["239739"] = {
				"Fallen Avatar", -- [1]
				"239739", -- [2]
				"Dark Mark", -- [3]
				21.5, -- [4]
				633004, -- [5]
				["id"] = 2038,
			},
			["255199"] = {
				"Argus the Unmaker", -- [1]
				"255199", -- [2]
				"Avatar of Aggramar (1)", -- [3]
				20.8, -- [4]
				135947, -- [5]
				["id"] = 2092,
			},
			["236519"] = {
				"Sisters of the Moon", -- [1]
				"236519", -- [2]
				"Moon Burn", -- [3]
				9.4, -- [4]
				136057, -- [5]
				["id"] = 2050,
			},
			["236305"] = {
				"Sisters of the Moon", -- [1]
				"236305", -- [2]
				"Incorporeal Shot", -- [3]
				48.3, -- [4]
				959793, -- [5]
				["id"] = 2050,
			},
			["218774"] = {
				"High Botanist Tel'arn", -- [1]
				"218774", -- [2]
				"Summon Plasma Spheres", -- [3]
				16.3, -- [4]
				525024, -- [5]
				["id"] = 1886,
			},
			["234621"] = {
				"Mistress Sassz'ine", -- [1]
				"234621", -- [2]
				"Devouring Maw", -- [3]
				42.2, -- [4]
				463487, -- [5]
				["id"] = 2037,
			},
			["232192"] = {
				"Harjatan the Bludger", -- [1]
				"232192", -- [2]
				"Commanding Roar", -- [3]
				17.5, -- [4]
				642418, -- [5]
				["id"] = 2036,
			},
			["221875"] = {
				"Star Augur Etraeus", -- [1]
				"221875", -- [2]
				"Nether Traversal", -- [3]
				20, -- [4]
				1041232, -- [5]
				["id"] = 1863,
			},
			["188114"] = {
				"Rokmora", -- [1]
				"188114", -- [2]
				"Shatter", -- [3]
				24, -- [4]
				451165, -- [5]
				["id"] = 1790,
			},
			["212681"] = {
				"Cenarius", -- [1]
				"212681", -- [2]
				"Cleansed Ground", -- [3]
				11, -- [4]
				136074, -- [5]
				["id"] = 1877,
			},
			["205298"] = {
				"Dragons of Nightmare", -- [1]
				"205298", -- [2]
				"Essence of Corruption", -- [3]
				29, -- [4]
				134438, -- [5]
				["id"] = 1854,
			},
			["218438"] = {
				"High Botanist Tel'arn", -- [1]
				"218438", -- [2]
				"Controlled Chaos", -- [3]
				50, -- [4]
				429383, -- [5]
				["id"] = 1886,
			},
			["197969"] = {
				"Ursoc", -- [1]
				"197969", -- [2]
				"Roaring Cacophony (1)", -- [3]
				40, -- [4]
				136195, -- [5]
				["id"] = 1841,
			},
			["232722"] = {
				"Mistress Sassz'ine", -- [1]
				"232722", -- [2]
				"Slicing Tornado", -- [3]
				30.3, -- [4]
				999952, -- [5]
				["id"] = 2037,
			},
			["235230"] = {
				"Demonic Inquisition", -- [1]
				"235230", -- [2]
				"Fel Squall", -- [3]
				35, -- [4]
				841219, -- [5]
				["id"] = 2048,
			},
			["nil"] = {
				"Pull", -- [1]
				"nil", -- [2]
				"Pull", -- [3]
				10, -- [4]
				132337, -- [5]
				["id"] = 2052,
			},
			["241636"] = {
				"Maiden of Vigilance", -- [1]
				"241636", -- [2]
				"Hammer of Obliteration", -- [3]
				32, -- [4]
				1038844, -- [5]
				["id"] = 2052,
			},
			["212258"] = {
				"Gul'dan", -- [1]
				"212258", -- [2]
				"Hand of Gul'dan", -- [3]
				7, -- [4]
				535592, -- [5]
				["id"] = 1866,
			},
			["206936"] = {
				"Star Augur Etraeus", -- [1]
				"206936", -- [2]
				"Icy Ejection (1)", -- [3]
				25, -- [4]
				612394, -- [5]
				["id"] = 1863,
			},
			["205370"] = {
				"Krosus", -- [1]
				"205370", -- [2]
				"Beam (1)", -- [3]
				9.5, -- [4]
				841219, -- [5]
				["id"] = 1842,
			},
			["205344"] = {
				"Krosus", -- [1]
				"205344", -- [2]
				"Orb of Destruction (1)", -- [3]
				70, -- [4]
				135800, -- [5]
				["id"] = 1842,
			},
			["236442"] = {
				"Sisters of the Moon", -- [1]
				"236442", -- [2]
				"Twilight Volley", -- [3]
				16.6, -- [4]
				1391677, -- [5]
				["id"] = 2050,
			},
			["213238"] = {
				"Tichondrius", -- [1]
				"213238", -- [2]
				"Seeker Swarm (1)", -- [3]
				27, -- [4]
				136128, -- [5]
				["id"] = 1862,
			},
			["236710"] = {
				"Kil'jaeden", -- [1]
				"236710", -- [2]
				"Reflection: Erupting", -- [3]
				20, -- [4]
				1357814, -- [5]
				["id"] = 2051,
			},
			["nightmare_horror"] = {
				"Il'gynoth", -- [1]
				"nightmare_horror", -- [2]
				"Nightmare Horror", -- [3]
				65, -- [4]
				463569, -- [5]
				["id"] = 1873,
			},
			["228877"] = {
				"Grand Magistrix Elisande", -- [1]
				"228877", -- [2]
				"Arcanetic Ring (1)", -- [3]
				34, -- [4]
				1033906, -- [5]
				["id"] = 1872,
			},
			["236459"] = {
				"The Desolate Host", -- [1]
				"236459", -- [2]
				"Soulbind", -- [3]
				16, -- [4]
				607854, -- [5]
				["id"] = 2054,
			},
			["233426"] = {
				"Demonic Inquisition", -- [1]
				"233426", -- [2]
				"Scythe Sweep", -- [3]
				5.8, -- [4]
				1060569, -- [5]
				["id"] = 2048,
			},
			["212530"] = {
				"Spellblade Aluriel", -- [1]
				"212530", -- [2]
				"Replicate: Mark of Frost", -- [3]
				41, -- [4]
				135732, -- [5]
				["id"] = 1871,
			},
			["232827"] = {
				"Mistress Sassz'ine", -- [1]
				"232827", -- [2]
				"Crashing Wave", -- [3]
				32.5, -- [4]
				135861, -- [5]
				["id"] = 2037,
			},
			["204459"] = {
				"Skorpyron", -- [1]
				"204459", -- [2]
				"<Cast: Vulnerability>", -- [3]
				14, -- [4]
				132358, -- [5]
				["id"] = 1849,
			},
			["205862"] = {
				"Krosus", -- [1]
				"205862", -- [2]
				"Slam (1)", -- [3]
				33, -- [4]
				135906, -- [5]
				["id"] = 1842,
			},
			["224982"] = {
				"Nighthold Trash", -- [1]
				"224982", -- [2]
				"Fel Glare: Unclegaycub*", -- [3]
				10, -- [4]
				135798, -- [5]
				["id"] = 1862,
			},
			["248671"] = {
				"Demonic Inquisition", -- [1]
				"248671", -- [2]
				"Unbridled Torment", -- [3]
				480, -- [4]
				1344654, -- [5]
				["id"] = 2048,
			},
			["boss_active"] = {
				"Grand Magistrix Elisande", -- [1]
				"boss_active", -- [2]
				"Elisande Active", -- [3]
				68, -- [4]
				"Interface\\Icons\\achievement_thenighthold_grandmagistrixelisande", -- [5]
				["id"] = 1872,
			},
			["234891"] = {
				"Maiden of Vigilance", -- [1]
				"234891", -- [2]
				"Wrath of the Creators", -- [3]
				43.5, -- [4]
				135922, -- [5]
				["id"] = 2052,
			},
			["215128"] = {
				"Il'gynoth", -- [1]
				"215128", -- [2]
				"Cursed Blood", -- [3]
				15, -- [4]
				237515, -- [5]
				["id"] = 1873,
			},
			["207630"] = {
				"Trilliax", -- [1]
				"207630", -- [2]
				"Annihilation", -- [3]
				20.5, -- [4]
				135734, -- [5]
				["id"] = 1867,
			},
			["233856"] = {
				"Fallen Avatar", -- [1]
				"233856", -- [2]
				"<Cast: Cleansing Protocol>", -- [3]
				18, -- [4]
				135802, -- [5]
				["id"] = 2038,
			},
			["250669"] = {
				"Argus the Unmaker", -- [1]
				"250669", -- [2]
				"Soulburst", -- [3]
				30, -- [4]
				1778229, -- [5]
				["id"] = 2092,
			},
			["238430"] = {
				"Kil'jaeden", -- [1]
				"238430", -- [2]
				"Bursting Dreadflame", -- [3]
				7.7, -- [4]
				460698, -- [5]
				["id"] = 2051,
			},
			["-13022"] = {
				"Chronomatic Anomaly", -- [1]
				"-13022", -- [2]
				"Add", -- [3]
				28, -- [4]
				135739, -- [5]
				["id"] = 1865,
			},
			["adds"] = {
				"Tichondrius", -- [1]
				"adds", -- [2]
				"Adds (1)", -- [3]
				185.7, -- [4]
				1100041, -- [5]
				["id"] = 1862,
			},
			["211152"] = {
				"Gul'dan", -- [1]
				"211152", -- [2]
				"(E) Eye of Gul'dan (2)", -- [3]
				16.8310000000056, -- [4]
				971290, -- [5]
				["id"] = 1866,
			},
			["210984"] = {
				"Il'gynoth", -- [1]
				"210984", -- [2]
				"Eye of Fate", -- [3]
				13.8, -- [4]
				1357799, -- [5]
				["id"] = 1873,
			},
			["255594"] = {
				"Argus the Unmaker", -- [1]
				"255594", -- [2]
				"Sky and Sea", -- [3]
				16, -- [4]
				1385912, -- [5]
				["id"] = 2092,
			},
			["206788"] = {
				"Trilliax", -- [1]
				"206788", -- [2]
				"Toxic Slice", -- [3]
				11, -- [4]
				237360, -- [5]
				["id"] = 1867,
			},
			["204275"] = {
				"Skorpyron", -- [1]
				"204275", -- [2]
				"Arcanoslash", -- [3]
				6, -- [4]
				655172, -- [5]
				["id"] = 1849,
			},
			["252729"] = {
				"Argus the Unmaker", -- [1]
				"252729", -- [2]
				"Cosmic Ray", -- [3]
				38, -- [4]
				429383, -- [5]
				["id"] = 2092,
			},
			["235572"] = {
				"Fallen Avatar", -- [1]
				"235572", -- [2]
				"Rupture Realities (1)", -- [3]
				38, -- [4]
				135801, -- [5]
				["id"] = 2038,
			},
			["200700"] = {
				"Dargrul", -- [1]
				"200700", -- [2]
				"Landslide", -- [3]
				15, -- [4]
				451165, -- [5]
				["id"] = 1793,
			},
			["210150"] = {
				"Naraxas", -- [1]
				"210150", -- [2]
				"Toxic Retch", -- [3]
				12, -- [4]
				136016, -- [5]
				["id"] = 1792,
			},
			["205649"] = {
				"Star Augur Etraeus", -- [1]
				"205649", -- [2]
				"Fel Ejection (1)", -- [3]
				17, -- [4]
				841218, -- [5]
				["id"] = 1863,
			},
			["203096"] = {
				"Nythendra", -- [1]
				"203096", -- [2]
				"Rot", -- [3]
				5.8, -- [4]
				136134, -- [5]
				["id"] = 1853,
			},
			["221606"] = {
				"Gul'dan", -- [1]
				"221606", -- [2]
				"Flames of Sargeras", -- [3]
				29.3, -- [4]
				1035051, -- [5]
				["id"] = 1866,
			},
			["241635"] = {
				"Maiden of Vigilance", -- [1]
				"241635", -- [2]
				"Hammer of Creation", -- [3]
				14, -- [4]
				135875, -- [5]
				["id"] = 2052,
			},
			["234015"] = {
				"Demonic Inquisition", -- [1]
				"234015", -- [2]
				"Tormenting Burst", -- [3]
				17.1, -- [4]
				136123, -- [5]
				["id"] = 2048,
			},
			["213567"] = {
				"Spellblade Aluriel", -- [1]
				"213567", -- [2]
				"Animate: Searing Brand", -- [3]
				65, -- [4]
				135811, -- [5]
				["id"] = 1871,
			},
			["206514"] = {
				"Gul'dan", -- [1]
				"206514", -- [2]
				"Fel Efflux", -- [3]
				11, -- [4]
				841219, -- [5]
				["id"] = 1866,
			},
			["251570"] = {
				"Argus the Unmaker", -- [1]
				"251570", -- [2]
				"Soulbomb (1)", -- [3]
				30, -- [4]
				1778228, -- [5]
				["id"] = 2092,
			},
			["236541"] = {
				"Sisters of the Moon", -- [1]
				"236541", -- [2]
				"Twilight Glaive", -- [3]
				18.1, -- [4]
				132330, -- [5]
				["id"] = 2050,
			},
			["167935"] = {
				"Gul'dan", -- [1]
				"167935", -- [2]
				"Storm of the Destroyer", -- [3]
				94, -- [4]
				651097, -- [5]
				["id"] = 1866,
			},
			["211802"] = {
				"Xavius", -- [1]
				"211802", -- [2]
				"Nightmare Blades", -- [3]
				19.2, -- [4]
				1396975, -- [5]
				["id"] = 1864,
			},
			["230139"] = {
				"Mistress Sassz'ine", -- [1]
				"230139", -- [2]
				"Hydra Shot (1)", -- [3]
				25, -- [4]
				133578, -- [5]
				["id"] = 2037,
			},
			["209244"] = {
				"Grand Magistrix Elisande", -- [1]
				"209244", -- [2]
				"Delphuric Beam", -- [3]
				59, -- [4]
				135730, -- [5]
				["id"] = 1872,
			},
			["209597"] = {
				"Grand Magistrix Elisande", -- [1]
				"209597", -- [2]
				"Conflexive Burst (1)", -- [3]
				48, -- [4]
				1044088, -- [5]
				["id"] = 1872,
			},
			["218148"] = {
				"High Botanist Tel'arn", -- [1]
				"218148", -- [2]
				"Solar Collapse", -- [3]
				14.3, -- [4]
				135981, -- [5]
				["id"] = 1886,
			},
			["233514"] = {
				"Goroth", -- [1]
				"233514", -- [2]
				"Infernal Spike", -- [3]
				4.8, -- [4]
				1118739, -- [5]
				["id"] = 2032,
			},
			["213531"] = {
				"Tichondrius", -- [1]
				"213531", -- [2]
				"Echoes of the Void (1)", -- [3]
				57.5, -- [4]
				1022950, -- [5]
				["id"] = 1862,
			},
			["235267"] = {
				"Maiden of Vigilance", -- [1]
				"235267", -- [2]
				"Mass Instability", -- [3]
				22, -- [4]
				535593, -- [5]
				["id"] = 2052,
			},
			["230384"] = {
				"Mistress Sassz'ine", -- [1]
				"230384", -- [2]
				"Consuming Hunger", -- [3]
				20.5, -- [4]
				237395, -- [5]
				["id"] = 2037,
			},
		},
		["encounter_timers_dbm"] = {
		},
	},
	["spell_school_cache"] = {
		["Feed Pool"] = 8,
		["Shadow Word: Pain"] = 32,
		["Crush"] = 1,
		["Shadowstrike"] = 1,
		["Electrical Shock"] = 8,
		["Heroic Strike"] = 1,
		["Infrared Light"] = 4,
		["Gravity Lapse"] = 64,
		["Angered Earth"] = 8,
		["Sinister Strike"] = 1,
		["Energy Bolt"] = 64,
		["Dread Screech Waves"] = 1,
		["Blazing Barrier"] = 4,
		["Blazing Swipe"] = 4,
		["Chaotic Tempest"] = 8,
		["Pulse"] = 64,
		["Explosive Shot"] = 4,
		["Bomb Squirrel Bomb"] = 1,
		["Jagged Tear"] = 1,
		["Poison Knives"] = 8,
		["Chi Burst"] = 8,
		["Jade Fire"] = 4,
		["Dread Strike"] = 32,
		["Huddle in Terror"] = 32,
		["Firebloom"] = 4,
		["Aura of Sacrifice"] = 2,
		["Burden of the Necromancer"] = 32,
		["Expose Weakness"] = 1,
		["Glittering Sparks"] = 4,
		["Ground Slam"] = 1,
		["Cave In"] = 1,
		["Festering Strike"] = 1,
		["Burning Magma"] = 4,
		["Windfury Attack"] = 1,
		["Incendiary Shot"] = 4,
		["Molten Torrent"] = 4,
		["Arcing Void"] = 32,
		["Arcane Torrent"] = 64,
		["Chaotic Energy"] = 4,
		["Heat Wave"] = 4,
		["Barbed Rebuke"] = 1,
		["Consuming Shadows"] = 32,
		["Taint of the Sea"] = 16,
		["Ragged Slash"] = 1,
		["Detonation"] = 4,
		["Defiled Vines"] = 32,
		["New Plan!"] = 4,
		["Blazing Trail"] = 4,
		["Savage Claws"] = 1,
		["Pierce"] = 1,
		["Remorseless Winter"] = 16,
		["Ice Bomb"] = 16,
		["Unleashed Flame"] = 4,
		["Fel Flamestrike"] = 4,
		["Chronometric Overload"] = 64,
		["Stinging Swarm"] = 1,
		["Charge"] = 1,
		["Poison Bomb"] = 8,
		["Arcane Field"] = 64,
		["Wrath of Elune"] = 2,
		["Freeze"] = 16,
		["Lodestone Spike"] = 8,
		["Magma Splash"] = 4,
		["Bubonic Plague"] = 8,
		["Waterspout"] = 16,
		["Dancing Flames"] = 4,
		["Soul Rip"] = 32,
		["Flame Vents"] = 4,
		["Cursed Blood"] = 32,
		["Rocket Fuel Leak"] = 4,
		["Dark Rune"] = 32,
		["Bloodthirst"] = 1,
		["Meteor"] = 4,
		["Strike from the Shadows"] = 1,
		["Sundering Crash"] = 4,
		["Severing Swipe"] = 1,
		["Sweeping Kick"] = 32,
		["Penetrating Shot"] = 1,
		["Thunderstomp"] = 8,
		["Aura of Darkness"] = 32,
		["Intangible Presence"] = 32,
		["Stone Disc"] = 8,
		["Caustic Webs"] = 8,
		["Empowered Singularity"] = 32,
		["Burning Rush"] = 1,
		["Arcane Rebound"] = 64,
		["Explosive Round"] = 4,
		["Whirlwind"] = 1,
		["Festering Wound"] = 32,
		["Icy Ground"] = 16,
		["Infernal Power"] = 4,
		["Blood Plague"] = 32,
		["Salve of Toxic Fumes"] = 8,
		["Agitated Water"] = 16,
		["Entangling Nightmares"] = 32,
		["Duskbolt"] = 32,
		["Rune-Etched Axe"] = 32,
		["Leave the Nightwell"] = 64,
		["Will of the Legion"] = 127,
		["Collapsing Rift"] = 64,
		["Scorching Swipe"] = 4,
		["Fel Chakram"] = 4,
		["Emblazoned Swipe"] = 4,
		["Killing Spree"] = 1,
		["Soulbomb Detonation"] = 32,
		["Crashing Wave"] = 16,
		["Serrated Slash"] = 1,
		["Crackle"] = 8,
		["Crushing Singularity"] = 32,
		["Crashing Storm"] = 8,
		["Inferno Bolt"] = 4,
		["Explosive Spear"] = 4,
		["Blood Boil"] = 32,
		["Bore"] = 8,
		["Cauterize"] = 4,
		["Gore"] = 1,
		["Skin Like Wax"] = 4,
		["Shadow Wreath"] = 32,
		["Pin Down"] = 1,
		["Force Detonation"] = 64,
		["Mortar Blast"] = 4,
		["Nightmare Reverberations"] = 32,
		["Arcane Tear"] = 64,
		["Feedback Overload"] = 4,
		["Mauling Brew"] = 8,
		["Tiger Palm"] = 1,
		["Pursuit"] = 1,
		["Burning Breath"] = 4,
		["Counterspell"] = 64,
		["Cloven Soul"] = 32,
		["Sear"] = 4,
		["Molten Amber"] = 4,
		["Burning Arrows"] = 4,
		["Mutilated Flesh"] = 1,
		["Fragment"] = 32,
		["Flaming Weapon"] = 4,
		["Bone Bash"] = 1,
		["Titanic Smash"] = 1,
		["Storm Bolt"] = 1,
		["Stone Breath"] = 8,
		["Collapsing Shadows"] = 32,
		["Get Away!"] = 32,
		["Witness the Void"] = 32,
		["Tainted Essence"] = 16,
		["Snap Shot"] = 1,
		["Twilight Glaive"] = 32,
		["Gravity Well"] = 32,
		["Doom Blade"] = 4,
		["Lash of Pain"] = 32,
		["Dancing Blade"] = 1,
		["Solar Chakram"] = 4,
		["Fel Burn"] = 4,
		["Netherbomb"] = 64,
		["Slimed"] = 8,
		["Ember Blast"] = 4,
		["Demonic Power"] = 32,
		["Bramble Patch"] = 8,
		["Immolation Aura"] = 4,
		["Felclaws"] = 1,
		["Intimidating Shout"] = 1,
		["Excess Mana"] = 64,
		["Soul Cleave"] = 1,
		["Void Sludge"] = 32,
		["Delayed Siege Bomb"] = 4,
		["Plasma Explosion"] = 4,
		["Aggramar's Sacrifice"] = 1,
		["Ravage Armor"] = 1,
		["Dominator Blast"] = 4,
		["Incinerate"] = 4,
		["Embrace of the Eclipse"] = 64,
		["Volatile Charge"] = 64,
		["Shadow Word: Death"] = 32,
		["Rapid Burst"] = 68,
		["Gorge"] = 1,
		["Aqua Spout"] = 16,
		["Zap"] = 8,
		["Dark Eruption"] = 32,
		["Felfire Volley"] = 4,
		["Shadowbind"] = 32,
		["Mannoroth's Gaze"] = 32,
		["Mark of Anguish"] = 32,
		["Creeping Nightmares"] = 32,
		["Overhead Slash"] = 1,
		["Source of Chaos"] = 4,
		["Blue Rays"] = 16,
		["Frost Fever"] = 16,
		["Sanguine Strikes"] = 8,
		["Mark of Shadowmoon"] = 8,
		["Corrosive Bite"] = 8,
		["Left Hook"] = 32,
		["Demon's Bite"] = 1,
		["Naaru's Lament"] = 32,
		["Aegwynn's Ascendance"] = 64,
		["Incorporeal Shot"] = 32,
		["Elemental Blast Overload"] = 28,
		["Beguiling Burst"] = 64,
		["Shadow Shield"] = 32,
		["Dark Discharge"] = 32,
		["Butchery"] = 1,
		["Electrified Waters"] = 8,
		["Rending Beak"] = 1,
		["Gloom"] = 32,
		["Acidic Wound"] = 8,
		["Aqueous Burst"] = 16,
		["Abandoned Hope"] = 32,
		["Wailing Horror"] = 32,
		["Doomed Sundering"] = 32,
		["Swashbuckling Slice"] = 1,
		["Defiled Ground"] = 32,
		["Apocalyptic Fire"] = 4,
		["Ferocious Bite"] = 1,
		["Rend"] = 1,
		["Arcane Explosion"] = 64,
		["Nightmare Blast"] = 32,
		["Collapsing Fissure"] = 32,
		["Wild Cleave"] = 1,
		["Intercept"] = 1,
		["Superheated"] = 4,
		["Felblaze Flurry"] = 4,
		["Shiver"] = 32,
		["Corruption Siphon"] = 32,
		["Molten Hide"] = 4,
		["Flash Fire"] = 4,
		["Felflame"] = 4,
		["Rocket Launch"] = 4,
		["Fists of Arcane Fury"] = 64,
		["Empowered Chains of Fel"] = 4,
		["Throat Rip"] = 1,
		["Drenched"] = 16,
		["Jaws of Thunder"] = 8,
		["Volatile Concoction"] = 8,
		["Destabilized Orb"] = 64,
		["Wound Poison"] = 8,
		["Acid Rain"] = 8,
		["Bubbling Pus"] = 8,
		["Clobbering Claws"] = 1,
		["Tar Trap"] = 8,
		["Whirlwind Off-Hand"] = 1,
		["Melee"] = 1,
		["Tainted Eruption"] = 32,
		["Fiery Burst"] = 4,
		["Storm Unleashed"] = 8,
		["Thunderstrike"] = 8,
		["Femoral Tear"] = 1,
		["Sear Beam"] = 4,
		["Burning Amber"] = 4,
		["Lesser Purified Residue"] = 16,
		["Cleansing Rage"] = 64,
		["Dread Inferno"] = 4,
		["Hungering Blows"] = 64,
		["Claw Strike"] = 1,
		["Twilight Instability"] = 32,
		["Dark Outbreak"] = 32,
		["Jagged Claws"] = 1,
		["Shield Bash"] = 1,
		["Ricochet"] = 1,
		["Fel Vomitus"] = 4,
		["Corpse Explode"] = 8,
		["Infected Wounds"] = 8,
		["Defiled Consecration"] = 32,
		["Conflagrate"] = 4,
		["Metamorphosis"] = 124,
		["Seeping Fog"] = 8,
		["Between the Eyes"] = 1,
		["Archmage's Greater Incandescence"] = 64,
		["Dark Surge"] = 32,
		["Nether Venom"] = 64,
		["Doom Bolt"] = 32,
		["Annihilation"] = 64,
		["Vile Rake"] = 1,
		["Drain the Living"] = 32,
		["Discharged Energy"] = 8,
		["Mark of Frost Explosion"] = 16,
		["Molten Slag"] = 4,
		["Maalus"] = 64,
		["Tidal Wave"] = 16,
		["Arcanetic Eruption"] = 64,
		["Unstable Orb"] = 4,
		["Strike of the Mountain"] = 8,
		["Bomb Impact"] = 4,
		["Acid Spit"] = 8,
		["Fel Lightning"] = 40,
		["Mind Flay"] = 32,
		["Burning Barrage"] = 1,
		["Uldgar's Vengence"] = 32,
		["Shadow Crash"] = 32,
		["Nightblade"] = 32,
		["Deep Wounds"] = 1,
		["Impactful Pulse"] = 64,
		["Chain Lightning"] = 8,
		["Slagged"] = 4,
		["Absorb Vitality"] = 32,
		["Shattering Charge"] = 1,
		["Rune of Crushing Earth"] = 8,
		["Epidemic"] = 32,
		["Unchecked Rage"] = 1,
		["Diffused Energy"] = 8,
		["Doom Guard's Curse"] = 32,
		["High Voltage"] = 8,
		["Colossus Smash"] = 1,
		["Infernal Strike"] = 4,
		["Felburst"] = 4,
		["Mojo Volley"] = 8,
		["Magma Eruption"] = 4,
		["Thrust"] = 1,
		["Stellagosa's Breath"] = 4,
		["Vampyr's Kiss"] = 1,
		["Chain Lightning Overload"] = 8,
		["Doom Well"] = 32,
		["Toxic Slice"] = 8,
		["Fel Fireball"] = 4,
		["Tide Crush"] = 16,
		["Tempest"] = 8,
		["Haunting Gaze"] = 32,
		["Foul Tempest"] = 32,
		["Fiery Globule"] = 4,
		["Radiant Smite"] = 2,
		["Nether Zone"] = 64,
		["Trample"] = 1,
		["Crashing Star"] = 64,
		["Thunderclap"] = 8,
		["Throw Glaive"] = 1,
		["Putrify"] = 8,
		["Soul Harvest"] = 4,
		["Spit Lightning"] = 8,
		["Foul Globule"] = 8,
		["Crystalline Swords"] = 16,
		["Searing Light"] = 2,
		["Rebounding Blade"] = 1,
		["Aimed Shot"] = 1,
		["Defiant Blow"] = 1,
		["Swirling Vortex"] = 8,
		["Fel Eruption"] = 32,
		["Impact"] = 1,
		["Blackrock Barrage"] = 1,
		["Cannonball Barrage"] = 1,
		["Black Harvest"] = 32,
		["Soul Explulsion"] = 32,
		["Breath of Fire"] = 4,
		["Harvested Soul"] = 32,
		["Marrowrend"] = 1,
		["Divine Star"] = 2,
		["Unstable Magic"] = 4,
		["Demolish"] = 32,
		["Monstrous Swipe"] = 1,
		["Throw Boulder"] = 1,
		["Cannon"] = 1,
		["Lava Bolt"] = 4,
		["Maim"] = 1,
		["Mad Dash"] = 1,
		["Sunfire"] = 4,
		["Meteor Strike"] = 4,
		["Unholy Aegis"] = 32,
		["Lunar Strike"] = 64,
		["Throw Dynamite"] = 4,
		["Devilsaur's Bite"] = 1,
		["Chimaera Shot"] = 8,
		["Phantasmal Fel Bomb"] = 1,
		["Bloody Arc"] = 1,
		["Darkstrikes"] = 32,
		["Flash of Steel"] = 1,
		["Chaotic Felblaze"] = 4,
		["Fiery Residue"] = 4,
		["Bladestorm"] = 1,
		["Arcane Barrage"] = 64,
		["Cry of Terror"] = 32,
		["Corruption Kick"] = 32,
		["Frostbolt"] = 16,
		["Crushing Grip"] = 8,
		["Pistol Shot"] = 1,
		["Eviscerate"] = 1,
		["Necrotic Venom"] = 8,
		["Flametongue"] = 4,
		["Trampling Slam"] = 1,
		["Demolisher Cannons"] = 4,
		["Dart"] = 1,
		["Gouge"] = 1,
		["Battering Ram"] = 1,
		["Odyn's Fury"] = 4,
		["Double Swipe"] = 1,
		["Tormenting Swipe"] = 32,
		["Bilewater Breath"] = 16,
		["Lumbering Swipe"] = 1,
		["Hydra Shot"] = 1,
		["Fel Lash"] = 32,
		["Blaze"] = 4,
		["Lava"] = 4,
		["Withering Consumption"] = 64,
		["Stormlash"] = 8,
		["Burst of Ice"] = 16,
		["Poisonous Molt"] = 8,
		["Soulburst"] = 32,
		["Grievous Leap"] = 1,
		["Burrowing Grubs"] = 8,
		["Touch of Doom"] = 32,
		["Choking Ashes"] = 4,
		["Explosive Tar"] = 8,
		["Swirl"] = 32,
		["Soul Leech"] = 32,
		["Cheep"] = 1,
		["Call Lightning"] = 8,
		["Ball Lightning"] = 8,
		["Fel Imp-losion"] = 4,
		["Shambling Strike"] = 1,
		["Foul Residue"] = 8,
		["Six Pound Barrel"] = 16,
		["Nether Rip"] = 32,
		["Fel Corruption"] = 4,
		["Focused Lightning"] = 8,
		["Flame Patch"] = 4,
		["Fel Blood Surge"] = 32,
		["Quills"] = 1,
		["Boulder Toss"] = 1,
		["Electrified Chakram"] = 1,
		["Blood Swarm"] = 32,
		["Smite"] = 2,
		["Divine Storm"] = 2,
		["Ruin"] = 40,
		["Foul Crush"] = 1,
		["Dark Hunt: Execution"] = 1,
		["Face Punch"] = 1,
		["Frozen Resilience"] = 16,
		["Cleaver"] = 1,
		["Tormenting Fixation"] = 1,
		["Jade Serpent Wave"] = 4,
		["Odyn's Glory"] = 4,
		["Shock Blast"] = 8,
		["Whispers of the Dark Star"] = 32,
		["Wither"] = 32,
		["Shadow Hunter"] = 32,
		["Fel Efflux"] = 4,
		["Call of the Hunter"] = 1,
		["Arc Blade"] = 64,
		["Proximity Bomb Explode"] = 4,
		["Arcane Sphere"] = 64,
		["Decimation"] = 4,
		["Creeping Doom"] = 4,
		["Aftershocks"] = 4,
		["Fire Bolt"] = 4,
		["Poisonous Stab"] = 8,
		["Void Impact"] = 1,
		["Desecrate"] = 32,
		["Felblaze Cleave"] = 4,
		["Crashing Comet"] = 4,
		["Blackrock Grenade"] = 4,
		["Rune Whirl"] = 32,
		["Chaos Bolt"] = 127,
		["Firebomb Vulnerability"] = 4,
		["Mana Discharge"] = 64,
		["Brambles"] = 8,
		["Crystalline Ground"] = 8,
		["Infected"] = 8,
		["Nether Corruption"] = 32,
		["Mind Rot"] = 32,
		["Unstable Soul"] = 4,
		["Dark Fissure"] = 32,
		["Localized Storm"] = 8,
		["Nightmares"] = 32,
		["Soul Burn"] = 4,
		["Throw Trickster Imp"] = 32,
		["Poison"] = 8,
		["Flame Shock"] = 4,
		["Infected Slash"] = 1,
		["Caustic Energy"] = 64,
		["Pool of Frost"] = 16,
		["Corrupting Void"] = 32,
		["Cannonball"] = 1,
		["Torment Bolt"] = 32,
		["Fel Barbs"] = 4,
		["Heavy Handed"] = 1,
		["Greed"] = 1,
		["Pheromones"] = 8,
		["Sonic Pulse"] = 1,
		["Serrated Spear"] = 1,
		["Crackling Slice"] = 64,
		["Pool of Souls"] = 32,
		["Eye of the Tiger"] = 8,
		["Fel Devastation"] = 4,
		["Fel Glare"] = 32,
		["Shell Shocked"] = 1,
		["Vile Rupture"] = 4,
		["Harpy's Scream"] = 1,
		["Felblade"] = 4,
		["Mana Rupture"] = 64,
		["Massive Demolition"] = 1,
		["Mind Daggers"] = 64,
		["Serrated Blade"] = 1,
		["Solar Wrath"] = 8,
		["Hammer of Obliteration"] = 4,
		["Rancid Maw"] = 8,
		["Roaring Flames"] = 4,
		["Shadow Wave"] = 32,
		["Mangle"] = 1,
		["Overpower"] = 1,
		["Dark Bindings"] = 32,
		["Stone Block"] = 1,
		["Explosion"] = 4,
		["Epocheric Orb Falloff"] = 64,
		["Heart of Fear"] = 32,
		["Power Overwhelming"] = 64,
		["Tainted Shadows"] = 32,
		["Ripple of Darkness"] = 32,
		["Howling Gale"] = 16,
		["Total Annihilation"] = 64,
		["Divine Hammer"] = 2,
		["Drain"] = 32,
		["Runic Brand"] = 2,
		["Rancid Ooze"] = 8,
		["Arcane Torment"] = 64,
		["Collapse"] = 32,
		["Earthshaking Roar"] = 8,
		["Absolute Zero"] = 16,
		["Implosion"] = 8,
		["Living Bomb"] = 4,
		["Tectonic Upheaval"] = 8,
		["Demon Blades"] = 32,
		["Burning Intensity"] = 4,
		["Mutilate"] = 1,
		["Dark Reckoning"] = 32,
		["Berserker Leap"] = 8,
		["Shadow Bite"] = 32,
		["Explosive Trap"] = 4,
		["Meteor Burn"] = 4,
		["Living Blaze"] = 1,
		["Colossal Slam"] = 1,
		["Nightmare Javelin"] = 32,
		["Cobra Shot"] = 1,
		["Wrath of the Creators"] = 4,
		["Explode"] = 4,
		["Ground Stomp"] = 1,
		["Shoot"] = 1,
		["Chosen Fate"] = 64,
		["Flurry of Feathers"] = 8,
		["Feltouched"] = 4,
		["Detonate: Mark of Frost"] = 16,
		["Shadowflame Nova"] = 36,
		["Scales of Earth"] = 1,
		["Searing Glare"] = 4,
		["Empowered Glaive Thrust"] = 1,
		["Deathwing Simulator"] = 4,
		["Tainted Explosion"] = 16,
		["Felflame Implosion"] = 4,
		["Thunderous Bolt"] = 8,
		["Cleansed Drake's Breath"] = 8,
		["Toxic Puddle"] = 8,
		["Crashing Thunder"] = 8,
		["Disrupting Energy"] = 64,
		["Hammer of Creation"] = 2,
		["Club"] = 1,
		["Shadow Blades"] = 32,
		["Seeker Swarm"] = 32,
		["Bursting Pustule"] = 8,
		["Ground Pound"] = 1,
		["Conflexive Burst"] = 64,
		["Cannon Shot"] = 4,
		["Bursting Ulcer"] = 32,
		["Shadows in the Dark"] = 32,
		["Shadow Residue"] = 32,
		["Massive Siege Nova"] = 4,
		["Wail"] = 32,
		["Gripping Fog"] = 32,
		["Scatter Shot"] = 1,
		["Searing Wound"] = 4,
		["Penetrating Bolt"] = 32,
		["Raging Blow"] = 1,
		["Knocked Down"] = 4,
		["Energy Void"] = 32,
		["Quicksand"] = 8,
		["Desecrated"] = 32,
		["Death Plane"] = 64,
		["Banshee's Blight"] = 8,
		["Dread Swing"] = 1,
		["Armageddon Hail"] = 1,
		["Fists of Stone"] = 1,
		["Gripping Vines"] = 1,
		["Rampage"] = 1,
		["Entangling Roots"] = 8,
		["Focused Light"] = 2,
		["Hammer of the Righteous"] = 1,
		["Dreadful Poison"] = 8,
		["Pillars of Night"] = 64,
		["Hallowed Ground"] = 2,
		["Lob Lightning"] = 8,
		["Blast"] = 4,
		["Rockbiter"] = 8,
		["Purging Protocol"] = 4,
		["Burning Bite"] = 4,
		["Swirling Muck"] = 8,
		["Fury of the Maw"] = 16,
		["Decisive Strike"] = 1,
		["Swipe"] = 1,
		["Energy Conduit"] = 64,
		["Eerie Skull"] = 32,
		["Potion of the Old War"] = 1,
		["Holy Shield"] = 2,
		["Arise, Fallen"] = 32,
		["Arcane Slicer"] = 64,
		["Fists of Fury"] = 1,
		["Cascadent Star"] = 64,
		["Spellbreaker"] = 1,
		["Arcane Orb"] = 64,
		["Dust Field"] = 8,
		["Tentacle Slam"] = 8,
		["Symbiote Strike"] = 33,
		["Puncture"] = 1,
		["Arcane Velocity"] = 64,
		["Demolition"] = 1,
		["Claw"] = 1,
		["Bonds of Terror"] = 32,
		["Artillery Blast"] = 4,
		["Soulblight"] = 32,
		["Bursting Dreadflame"] = 4,
		["Capsule Impact"] = 4,
		["Ablating Explosion"] = 64,
		["Moon Burn"] = 64,
		["Arcane Bomb"] = 64,
		["Ice Lance"] = 16,
		["Word of Anguish"] = 16,
		["Mighty Stomp"] = 4,
		["Stagger"] = 1,
		["Aura of Regeneration"] = 8,
		["Thorns"] = 8,
		["End of Night"] = 32,
		["Judgment"] = 2,
		["Gripping Shadows"] = 32,
		["Vileblood"] = 4,
		["Wretched Frostbolt"] = 16,
		["Blight"] = 8,
		["Swirling Water"] = 16,
		["Dark Obliteration"] = 32,
		["Empowered Liquid Hellfire"] = 4,
		["Megaera's Rage"] = 8,
		["Felfire Munitions"] = 4,
		["Fel Stomp"] = 4,
		["Corrupt"] = 32,
		["Expel Light"] = 2,
		["Fel Infusion"] = 4,
		["Tainted Discharge"] = 32,
		["Winter's Chill"] = 16,
		["Caustic Pitch"] = 8,
		["Shadow Breath"] = 32,
		["Sunfire Rays"] = 4,
		["Toxic Storm"] = 8,
		["Corrupted Blood"] = 32,
		["Raging Flames"] = 4,
		["Foul Pool"] = 8,
		["Axe to the Head"] = 1,
		["Drain Future"] = 64,
		["Ignite"] = 4,
		["Bloody Pin"] = 1,
		["Apocalypse"] = 32,
		["Nightmare Essence"] = 32,
		["Arcane Tether"] = 64,
		["Orb of Chaos"] = 64,
		["Lightning Diffusion"] = 8,
		["Dread Impact"] = 1,
		["Dire Stomp"] = 1,
		["Frozen Core"] = 16,
		["Rotten Breath"] = 32,
		["Barrage"] = 1,
		["Twisting Shadows"] = 32,
		["Paralytic Poison"] = 8,
		["Death from Above"] = 1,
		["Lunging Attack"] = 1,
		["Epicenter"] = 8,
		["Starsurge"] = 72,
		["Chaos Glare"] = 32,
		["Eye Sore"] = 64,
		["Bloodletting Sweep"] = 1,
		["Alone in the Darkness"] = 32,
		["Sundered Ground"] = 4,
		["Tainted Blood"] = 8,
		["Rupturing Singularity"] = 64,
		["Death and Decay"] = 32,
		["Inferno Pyre"] = 4,
		["Violent Gale Winds"] = 8,
		["Thunderstorm"] = 8,
		["Arcane Assault"] = 64,
		["Orb of Corrosion"] = 16,
		["Sha Vortex"] = 32,
		["Rolling Fury"] = 1,
		["Waterbolt"] = 16,
		["Mark of the Sunfury"] = 4,
		["Ring of Destruction"] = 32,
		["Toxic Hivebomb"] = 8,
		["Volcanic Plume"] = 4,
		["Frigid Nova"] = 16,
		["Raging Tempest"] = 8,
		["Unstable Slag Explosion"] = 4,
		["Fungal Decay"] = 8,
		["Soul Siphon"] = 32,
		["Surging Waters"] = 16,
		["Rending Pounce"] = 1,
		["Special Delivery"] = 1,
		["Searing Blaze"] = 4,
		["Dark Slash"] = 32,
		["Blizzard"] = 16,
		["Lava Lash"] = 4,
		["Junk Toss"] = 1,
		["Leg Sweep"] = 1,
		["Hoof Stomp"] = 1,
		["Amber Strike"] = 8,
		["Unleashed Energy"] = 4,
		["Wretched Fireball"] = 4,
		["Fel Mortar"] = 4,
		["Lava Spout Totem"] = 4,
		["Massive Crash"] = 16,
		["Exposed Core"] = 64,
		["Hurl Brick"] = 1,
		["Mark of Kaz'rogal"] = 32,
		["Horrific Slam"] = 1,
		["Wallop"] = 1,
		["Rapid Shot"] = 32,
		["Reactive Flames"] = 4,
		["Infested Waters"] = 8,
		["Rip"] = 1,
		["Furious Stone Breath"] = 8,
		["Shadow Burn"] = 32,
		["Razor Gills"] = 1,
		["Corruption: Unfathomable Reality"] = 4,
		["Rapid Fire"] = 4,
		["Arcane Charge"] = 64,
		["Stinging Venom"] = 4,
		["Blazing Flame"] = 4,
		["Mortal Strike"] = 1,
		["Bilewater Corrosion"] = 16,
		["Burning Blaze"] = 4,
		["Summon Solar Flare"] = 4,
		["Focused Mana Ray"] = 64,
		["Searing Gaze"] = 32,
		["Detonate"] = 4,
		["Nether Touch"] = 64,
		["Shuriken Storm"] = 1,
		["Rockfall"] = 8,
		["Cleansing Destruction"] = 64,
		["Torn Soul"] = 32,
		["Peck"] = 1,
		["Flame Strike"] = 4,
		["Body Slam"] = 1,
		["Bounding Cleave"] = 1,
		["Barbed Spear"] = 1,
		["Frostfire Bolt"] = 20,
		["Bombardment"] = 32,
		["Soul Rot"] = 32,
		["Voidburst"] = 32,
		["Shadow Blast"] = 32,
		["Spirit Gale"] = 32,
		["Seal of Wrath"] = 2,
		["Voidtouched"] = 32,
		["Slicing Tornado"] = 1,
		["Spectral Charge"] = 32,
		["Holy Prism"] = 2,
		["Radiance of Anzu"] = 4,
		["Touch of Corruption"] = 32,
		["Flanking Strike"] = 1,
		["Exploding Shot"] = 4,
		["Flame Jet"] = 4,
		["Seeping Shadows"] = 32,
		["Nightmare Buffet"] = 32,
		["Entropic Force"] = 32,
		["Shot"] = 1,
		["Explosive Rune"] = 4,
		["Down Draft"] = 8,
		["Frozen Bomb"] = 16,
		["Hindering Anomaly"] = 64,
		["Fel Chain"] = 4,
		["Conflagration"] = 4,
		["Echoes of the Void"] = 32,
		["Run Through"] = 1,
		["Flame Gout"] = 4,
		["Force Nova"] = 64,
		["Bloody Strike"] = 1,
		["Pulverize"] = 1,
		["Eye of Dread"] = 32,
		["Viscid Bile"] = 8,
		["Siege Nova"] = 4,
		["Apocalyptic Felburst"] = 4,
		["Shockwave"] = 8,
		["Grand Immolation"] = 4,
		["A Murder of Crows"] = 1,
		["Rancid Pool"] = 8,
		["Dragon Roar"] = 1,
		["Aura of Oppression"] = 32,
		["Venom Spit"] = 8,
		["Boar's Rush"] = 1,
		["Crypt Scarabs"] = 1,
		["Black Arrow"] = 32,
		["Ragnarok"] = 4,
		["Shadowy Pool"] = 32,
		["Touch of the Magi"] = 64,
		["Melt Flesh"] = 4,
		["From the Shadows"] = 8,
		["Choking Shadow"] = 32,
		["Crystal Shards"] = 1,
		["Maul"] = 1,
		["Fists of Flame"] = 4,
		["Gift of the Man'ari"] = 4,
		["Plague Bite"] = 8,
		["Burst of Light"] = 2,
		["Frostfire Nova"] = 20,
		["Dreadburst"] = 32,
		["Phantasmal Winds"] = 1,
		["Wailing Souls"] = 32,
		["Tidal Spear"] = 8,
		["Weaponmaster"] = 32,
		["Impaling Spear"] = 1,
		["Piercing Missiles"] = 64,
		["Throw Junk"] = 1,
		["Spineshatter"] = 1,
		["Superheated Shrapnel"] = 4,
		["Brutal Haymaker"] = 1,
		["Backstab"] = 1,
		["Wondrous Rapidity"] = 64,
		["Piercing Rain"] = 16,
		["Bane Nova"] = 32,
		["Ray of Frost"] = 16,
		["Burn"] = 4,
		["Sand Bolt"] = 4,
		["Unquenchable Flame"] = 4,
		["Turbulent Waters"] = 16,
		["Cauldron Fire"] = 4,
		["Pain Lash"] = 8,
		["Missile Barrage"] = 1,
		["Outbreak"] = 32,
		["Poisonous Shank"] = 8,
		["Hellfire Shot"] = 4,
		["Blackened Tainting"] = 32,
		["Honor Bound"] = 2,
		["Vision of Death"] = 4,
		["Feast of Souls"] = 32,
		["Carrion Wave"] = 32,
		["Heart Strike"] = 1,
		["Nether Leech"] = 32,
		["Charged Bolt"] = 64,
		["Frost Resonance"] = 16,
		["Phantasmal Wounds"] = 32,
		["Counterstrike"] = 8,
		["Darkened Tainting"] = 32,
		["Raging Torrent"] = 16,
		["Crashing Waves"] = 16,
		["Barrage of Leaves"] = 8,
		["Eye of Gul'dan"] = 32,
		["Consumption"] = 32,
		["Fel Blast"] = 4,
		["Glaive Throw"] = 1,
		["Trauma"] = 1,
		["Eradication"] = 127,
		["Venom Spray"] = 8,
		["Boil Back"] = 8,
		["Icy Grasp"] = 16,
		["Dark Blast"] = 32,
		["Poisoned Vial"] = 8,
		["Harsh Winds"] = 1,
		["Twilight Onslaught"] = 32,
		["Mark of the Necromancer"] = 32,
		["Noxious Breath"] = 8,
		["Bright Light"] = 8,
		["Surge of the Stormgod"] = 8,
		["Thrashing Claw"] = 1,
		["Frostbite"] = 16,
		["Inferno Strike"] = 4,
		["Melt Armor"] = 4,
		["Sigil of Flame"] = 4,
		["Val'kyr Strike"] = 32,
		["Demonic Upheaval"] = 4,
		["Rain of Chaos"] = 4,
		["Firebolt"] = 4,
		["Frost Attack"] = 16,
		["Molten Barrage"] = 4,
		["Time Split"] = 64,
		["Holy Smite"] = 2,
		["Spread Infestation"] = 40,
		["Collapsing Entity"] = 64,
		["Kill Command"] = 1,
		["Furious Swipes"] = 1,
		["Burning Gaze"] = 4,
		["Injected Poison"] = 8,
		["Bonds of Fel"] = 4,
		["Bloodlet"] = 1,
		["Shiv"] = 1,
		["Spear of Anguish"] = 8,
		["Soul Dispersion"] = 32,
		["Infernal Flames"] = 4,
		["Crystallized Blood"] = 1,
		["Glacial Spike"] = 16,
		["Blinding Light"] = 2,
		["Burning Wound"] = 4,
		["Necrobomb"] = 32,
		["Ceaseless Winter"] = 16,
		["Mark of Chaos"] = 64,
		["Interrupting Shout"] = 1,
		["Strike of the Windlord"] = 1,
		["Victory Rush"] = 1,
		["Blazing Nova"] = 4,
		["Rage of the Illidari"] = 127,
		["Lacerate"] = 1,
		["Fel Crystals"] = 4,
		["Thunder Trap"] = 8,
		["Fel Blade"] = 4,
		["Fel Prison"] = 32,
		["Phoenix's Flames"] = 4,
		["Ionization"] = 8,
		["Nullification Barrier"] = 64,
		["Nether Tempest"] = 64,
		["Defy Gravity"] = 32,
		["Fel Impact"] = 1,
		["Bulwark of the Tyrant"] = 32,
		["Lava Slash"] = 4,
		["Spear Leap"] = 1,
		["Arterial Cut"] = 1,
		["Spinning Shell"] = 1,
		["Deathly Screech"] = 32,
		["Biting Cold"] = 16,
		["Flames of Argus"] = 4,
		["Felling Strike"] = 1,
		["Shattered Will"] = 32,
		["Searing Brand"] = 4,
		["Flashing Forks"] = 1,
		["Summon Spark of Rhyolith"] = 4,
		["Beam"] = 4,
		["Templar's Verdict"] = 2,
		["Arc Lightning"] = 64,
		["Puncturing Stab"] = 1,
		["Severing Hew"] = 1,
		["Woe Strike"] = 32,
		["Firestorm Kick"] = 4,
		["Dark Storm"] = 32,
		["Bonestorm"] = 32,
		["Virulent Haunt"] = 32,
		["Virulent Poison"] = 8,
		["Convulsive Shadows"] = 32,
		["Overwhelming Blows"] = 1,
		["Raging Bite"] = 64,
		["Withering Winds"] = 32,
		["Void Rage"] = 32,
		["Screech"] = 1,
		["Toxic Blood"] = 8,
		["Greater Essence of Fear"] = 32,
		["Main Gauche"] = 1,
		["Health Funnel"] = 32,
		["Ignite Armor"] = 4,
		["Arcing Storm"] = 8,
		["Fel Rush"] = 127,
		["Tiro-Autom�tico"] = 1,
		["Charged Slime"] = 8,
		["Spirit Cleave"] = 32,
		["Flames of the Forge"] = 4,
		["Puncturing Strike"] = 1,
		["Gravity Squeeze"] = 32,
		["Flames of Khaz'goroth"] = 4,
		["Energize"] = 4,
		["Chaotic Flames"] = 4,
		["Touch of Death"] = 1,
		["Decomposing Aura"] = 1,
		["Burning Bones"] = 4,
		["Bellowing Roar"] = 1,
		["Frozen Tempest"] = 16,
		["Bloodsoaked Heartseeker"] = 1,
		["Poisoned Knife"] = 1,
		["Poisoned Dreams"] = 32,
		["Exploding Keg"] = 4,
		["Devastate"] = 1,
		["Soulburst Detonation"] = 32,
		["Twisted Nova"] = 32,
		["Belch Flame"] = 4,
		["Glowing Rune Axe"] = 32,
		["Well of Souls"] = 32,
		["Star Burn"] = 4,
		["Dark Mark"] = 32,
		["Reap"] = 32,
		["Impaling Shard"] = 1,
		["Singularity"] = 32,
		["Plagued Ground"] = 40,
		["Hands of Purity"] = 4,
		["Torrent of Ice"] = 16,
		["Tempest Slash"] = 8,
		["Rage of the Sleeper"] = 8,
		["Savage Maul"] = 1,
		["Ghoul Slash"] = 1,
		["Instant Poison"] = 8,
		["Consecration"] = 2,
		["Amber Explosion"] = 8,
		["Flames of Sargeras"] = 4,
		["Call the Seas"] = 16,
		["Clawing Shadows"] = 32,
		["Flying Serpent Kick"] = 1,
		["Soulbind"] = 32,
		["Dark Rush"] = 1,
		["Piercing Arrow"] = 1,
		["Dissonance Field"] = 1,
		["Nightmare Eruption"] = 8,
		["Slam"] = 1,
		["Blazing Claw"] = 1,
		["Nightmare Wounds"] = 32,
		["Iron Bellow"] = 1,
		["Slag Bomb"] = 4,
		["Fetid Rot"] = 8,
		["Stormstrike"] = 1,
		["Scatter"] = 8,
		["Corrupted Axion"] = 32,
		["Bloodletting Bite"] = 1,
		["Radiant Barrage"] = 64,
		["Sha Pool"] = 32,
		["Rising Flame Kick"] = 4,
		["Blood of Mannoroth"] = 4,
		["Ravenous Leap"] = 1,
		["Choking Gas"] = 8,
		["Fire Nova"] = 4,
		["Shadow Rune"] = 32,
		["Mystic Tornado"] = 64,
		["Expose Armor"] = 1,
		["Elemental Binding"] = 8,
		["Power Attack"] = 1,
		["Summon Fragment of Rhyolith"] = 4,
		["Lurking Eruption"] = 32,
		["Ethereal Thrust"] = 16,
		["Nightmare Brambles"] = 32,
		["Falling Debris"] = 1,
		["Hellfire"] = 4,
		["Retribution Aura"] = 2,
		["Expel Magic: Fire"] = 4,
		["Cinderstorm"] = 4,
		["Death Strike Off-Hand"] = 1,
		["Mind Warp"] = 32,
		["Fel Dash"] = 4,
		["Torment"] = 32,
		["Focused Laser"] = 4,
		["Impaled"] = 1,
		["Quarantine"] = 64,
		["Hand of Gul'dan"] = 32,
		["Drain Soul"] = 32,
		["Felfrost Bolt"] = 20,
		["Wake of Ashes"] = 6,
		["Twilight Volley"] = 32,
		["Concussive Stomp"] = 4,
		["Anguished Spirits"] = 32,
		["Immolating Blast"] = 4,
		["Blazing Charge"] = 4,
		["Flare"] = 4,
		["Choking Vines"] = 8,
		["Shatter"] = 2,
		["Lightning Breath"] = 8,
		["Volatile Rot"] = 40,
		["Glaive Storm"] = 64,
		["Fel-Crazed Rage"] = 32,
		["Grievous Whirl"] = 1,
		["Berserker Rush"] = 1,
		["Arctic Freeze"] = 16,
		["Phase Explosion"] = 64,
		["Hypothermia"] = 16,
		["Caustic Bite"] = 4,
		["Primal Rampage"] = 1,
		["Severe Dusting"] = 8,
		["Shield of the Righteous"] = 2,
		["Blisterbomb"] = 8,
		["Befouling Ink"] = 32,
		["Hateful Charge"] = 1,
		["Ghostly Strike"] = 1,
		["Blink Strikes"] = 64,
		["Shadow Mend"] = 32,
		["Blade Dance"] = 1,
		["Throw Grenade"] = 4,
		["Fiery Nature"] = 4,
		["Barreling Impact"] = 1,
		["Lava Burst"] = 4,
		["Execute"] = 1,
		["Localized Toxin"] = 8,
		["Shadowfel Burst"] = 36,
		["Mana Burst"] = 64,
		["Machinations of Aman'Thul"] = 64,
		["Execute Off-Hand"] = 1,
		["Plagued Bite"] = 8,
		["Shadow Burst"] = 32,
		["Decimating Essence"] = 64,
		["Boom"] = 4,
		["Empowered Fel Hellstorm"] = 4,
		["Unleashed Flames"] = 4,
		["Umbra Shift"] = 32,
		["Fury of Air"] = 8,
		["Shadow Slash"] = 32,
		["Curse of the Desecrated"] = 32,
		["Snarl"] = 1,
		["Spirit Axe"] = 64,
		["Poisoned Spear"] = 8,
		["Shattering Star"] = 4,
		["Sever"] = 1,
		["Toxic Chitin"] = 8,
		["Seismic Activity"] = 8,
		["Coldflame"] = 16,
		["Vile Gas"] = 1,
		["Collapsing Void"] = 32,
		["Flame Gale"] = 4,
		["Drenching Slough"] = 16,
		["Dreadfire"] = 32,
		["VX18-B Target Eliminator"] = 4,
		["Fel Fury"] = 4,
		["Shooting Stars"] = 72,
		["Nether Detonation"] = 64,
		["Crusader Strike"] = 1,
		["Twilight Flames"] = 32,
		["The Cleaver"] = 1,
		["Stellar Dust"] = 64,
		["Jagged Shards"] = 1,
		["Destructolaser"] = 4,
		["Miasma"] = 32,
		["Dark Spin"] = 1,
		["Rupturing Slam"] = 1,
		["Sonic Ring"] = 1,
		["Ill-Fated"] = 64,
		["Burning Cinders"] = 4,
		["Rapid Rupture"] = 1,
		["Shadowy Blades"] = 32,
		["Piercing Shot"] = 1,
		["Binding Shot"] = 1,
		["Magma Spit"] = 4,
		["Fel Rain"] = 4,
		["Burst of Flame"] = 4,
		["Fel Flames"] = 4,
		["Felstorm"] = 1,
		["Umbral Flanking"] = 1,
		["Envenom"] = 8,
		["Petrifying Cloud"] = 8,
		["Jagged Abrasion"] = 1,
		["Ravaging Darkness"] = 32,
		["Falling Ash"] = 4,
		["Sonic Spear"] = 1,
		["Necrotic Aura"] = 1,
		["Whirling Blade"] = 1,
		["Acid Torrent"] = 8,
		["Flame Wreath"] = 4,
		["Omen of Death"] = 32,
		["Coalescing Shadows"] = 32,
		["Lightning Fissure"] = 8,
		["Liquid Hellfire"] = 4,
		["Electrostatic Charge"] = 8,
		["Arcane Emanations"] = 64,
		["Numbing Poison"] = 8,
		["Soul Echoes"] = 32,
		["Fetid Stench"] = 8,
		["Flaming Spear"] = 4,
		["Gargoyle Strike"] = 8,
		["Thorasus"] = 64,
		["Bursting Sores"] = 32,
		["Devastator"] = 1,
		["Shattering Roar"] = 8,
		["Vile Sludge"] = 8,
		["Chaos Flames"] = 124,
		["Searing Touch"] = 4,
		["Slagblast"] = 4,
		["Armageddon"] = 64,
		["Corrupting Touch"] = 32,
		["Nightmarish Fury"] = 1,
		["Spiritual Grasp"] = 32,
		["Recursive Strikes"] = 1,
		["Acidic Fragments"] = 8,
		["Smoldering"] = 4,
		["Flamestrike"] = 4,
		["Phantasmal Nova"] = 4,
		["Weighty Stomp"] = 1,
		["Battle Runes"] = 1,
		["Hatespawn Detonation"] = 32,
		["Molten Fel"] = 4,
		["Falling Star"] = 64,
		["Hemorrhage"] = 1,
		["Chain Fireball"] = 4,
		["Retaliation"] = 1,
		["Parasitic Fetter"] = 8,
		["Shattered Vertebrae"] = 1,
		["Immolate"] = 4,
		["Apocalyptic Nightmare"] = 4,
		["Whirling Slash"] = 1,
		["Arcane Devastation"] = 64,
		["Gavel of the Tyrant"] = 4,
		["Inferno"] = 4,
		["New Moon"] = 64,
		["Shadow Phlegm"] = 32,
		["Tormenting Detonation"] = 32,
		["Sanguine Ichor"] = 32,
		["Reactive Destruction"] = 1,
		["Plague Swarm"] = 8,
		["Mark of the Hidden Satyr"] = 4,
		["Dashing Flame Gale"] = 4,
		["Stormbreaker's Bulwark"] = 8,
		["Harbinger's Mending"] = 32,
		["Fiery Phlegm"] = 4,
		["Burst"] = 64,
		["Firestorm"] = 4,
		["Hew"] = 1,
		["Seed of Corruption"] = 32,
		["Frigid Blows"] = 16,
		["Retched Blackrock"] = 8,
		["Thorns Aura"] = 8,
		["Relentless Storm"] = 16,
		["Arcane Fog"] = 64,
		["Playing With Fire"] = 4,
		["Lingering Mist"] = 16,
		["Nightfall"] = 32,
		["Withering Gaze"] = 32,
		["Impending Victory"] = 1,
		["Soulthirst"] = 32,
		["Phantom Singularity"] = 32,
		["Orb of Corruption"] = 32,
		["Inferno Breath"] = 4,
		["Molten Impact"] = 4,
		["Black Iron Cyclone"] = 1,
		["Acidic Bite"] = 8,
		["Clobber"] = 1,
		["Soul Corrosion"] = 32,
		["Earthen Rage"] = 8,
		["Echoing Stars"] = 72,
		["Wasting Dread"] = 1,
		["Maddening Whispers"] = 32,
		["Guardian Orbs"] = 2,
		["Corpo-a-Corpo"] = 1,
		["Captive Tides"] = 16,
		["Defiled Eruption"] = 32,
		["Doom Spike"] = 32,
		["Pound"] = 1,
		["Moonfire"] = 64,
		["Sulfuras"] = 4,
		["Empowered Bonds of Fel"] = 4,
		["Blazing Radiance"] = 4,
		["Coral Cut"] = 1,
		["Conflagration Flare Up"] = 4,
		["Digest"] = 32,
		["Furious Slash"] = 1,
		["Power Word: Solace"] = 2,
		["Shadow Shot"] = 32,
		["Felblaze Puddle"] = 4,
		["Legion Strike"] = 1,
		["Epocheric Orb"] = 64,
		["Brutal Slash"] = 1,
		["Massive Attack"] = 1,
		["Immolation Trap"] = 4,
		["Spellstone of Kel'danath"] = 64,
		["Wash Away"] = 16,
		["Sloooow Down"] = 1,
		["Despoiled Ground"] = 32,
		["Virulent Eruption"] = 32,
		["Spray"] = 16,
		["Ruiner"] = 4,
		["Flamescowl"] = 4,
		["Overhead Smash"] = 8,
		["Fel  Whirlwind"] = 4,
		["Savage Strikes"] = 1,
		["Energy Discharge"] = 64,
		["Infested"] = 40,
		["Wrath"] = 8,
		["Felfire Bolt"] = 4,
		["Heroic Leap"] = 1,
		["Prototype Pulse Grenade"] = 8,
		["Shadow Blade Off-hand"] = 32,
		["Razor Wing"] = 32,
		["Mind Sear"] = 32,
		["Seared Flesh"] = 4,
		["Invocation of Blood"] = 1,
		["Frozen Solid"] = 1,
		["Kill Shot"] = 1,
		["Felblazed Ground"] = 4,
		["Devour"] = 32,
		["Right Cross"] = 32,
		["Twilight Barrage"] = 32,
		["Poison Cloud"] = 8,
		["Fel Hellstorm"] = 4,
		["Thal'kiel's Consumption"] = 32,
		["Chaos Strike"] = 127,
		["Pulsing Shockwave"] = 8,
		["Jagged Disc"] = 1,
		["Pustulant Spit"] = 8,
		["Despair"] = 32,
		["Powerful Swipe"] = 1,
		["Curse of Agony"] = 32,
		["Torment the Weak"] = 32,
		["Plague Seed"] = 32,
		["Vile Spit"] = 8,
		["Lawbringer"] = 2,
		["Pinned Down"] = 1,
		["Hammer of Justice"] = 2,
		["Shear"] = 1,
		["Blistering Slash"] = 4,
		["Void Rend"] = 1,
		["Barbed Shot"] = 1,
		["Devilsaur Shock Leash"] = 8,
		["Bloody Talons"] = 1,
		["Jab"] = 1,
		["Planar Distortion"] = 64,
		["Gushing Wounds"] = 1,
		["Bull Rush"] = 1,
		["Glyph of the Inquisitor"] = 2,
		["Venom"] = 8,
		["Frost Strike Off-Hand"] = 16,
		["Tormenting Breath"] = 32,
		["Decay"] = 8,
		["Sha Spine"] = 32,
		["Fire Blast"] = 4,
		["Vile Blood"] = 8,
		["Fel Beam"] = 4,
		["Runed Flame Jets"] = 4,
		["Crackling Thunder"] = 8,
		["Mark of Ysondre"] = 32,
		["Burning Metal"] = 4,
		["Serpent Sting"] = 8,
		["Inquisitive Stare"] = 1,
		["Eye of the Vortex"] = 64,
		["Dark Ruination"] = 32,
		["Darksoul Drain"] = 8,
		["Light Infusion"] = 2,
		["Zeal"] = 1,
		["Calamity"] = 32,
		["Leaping Rush"] = 1,
		["Frost Shock"] = 16,
		["Windfury"] = 1,
		["Comet Impact"] = 1,
		["Infernal Eruption"] = 4,
		["Tyr's Enforcer"] = 2,
		["War Stomp"] = 1,
		["Twinblade Strike"] = 64,
		["Iron Star Impact"] = 1,
		["Reckless Slash"] = 1,
		["Chrono Shift"] = 64,
		["Mark of Frost"] = 16,
		["Quake"] = 8,
		["Burning Maw"] = 4,
		["Earthen Spike"] = 1,
		["Tormented Cries"] = 32,
		["Frostscythe"] = 16,
		["Festering Poison"] = 8,
		["Carnivorous Bite"] = 1,
		["Power Discharge"] = 64,
		["Lightning Tether"] = 8,
		["Overdrive"] = 1,
		["Withering Roar"] = 32,
		["Unerring Blast"] = 2,
		["Temptation"] = 32,
		["Dread Thorns"] = 32,
		["Chaotic Energy Burst"] = 64,
		["Rending Rake"] = 1,
		["Rising Sun Kick"] = 1,
		["Reorigination Pulse"] = 64,
		["Schism"] = 32,
		["Stormforged Spear"] = 8,
		["Arcane Wrath"] = 64,
		["Holy Shock"] = 2,
		["Thunder Clap"] = 1,
		["Force and Verve"] = 1,
		["Shatter Earth"] = 8,
		["Demonbolt"] = 127,
		["Devastating Stomp"] = 1,
		["Rake"] = 1,
		["Life Tap"] = 32,
		["Feedback"] = 2,
		["Lantern of Darkness"] = 32,
		["Sundering Swipe"] = 1,
		["Arcane Touch"] = 64,
		["Sha Splash"] = 32,
		["Briarskin"] = 8,
		["Deadly Poison"] = 8,
		["Dread Shadows"] = 32,
		["Skewer"] = 1,
		["Overwhelming Terror"] = 33,
		["Plague Fang"] = 8,
		["Eruption"] = 4,
		["Coldflame Trap"] = 16,
		["Fel Meteor"] = 4,
		["Imprisoning Bubble"] = 16,
		["Dark Meditation"] = 32,
		["Lightning Surge"] = 8,
		["Mark of Lethon"] = 32,
		["Carve"] = 1,
		["Infinite Abyss"] = 32,
		["Fury of the Illidari"] = 127,
		["Mounted Strike"] = 1,
		["Freezing Breath"] = 16,
		["Mark of Aluneth"] = 64,
		["Impaling Harpoon"] = 1,
		["Neltharion's Fury"] = 36,
		["Pheromone Trail"] = 8,
		["Scourge Strike"] = 32,
		["Lingering Gaze"] = 32,
		["Iron Whirlwind"] = 1,
		["Intense Cold"] = 16,
		["Dreadbite"] = 32,
		["Growl"] = 1,
		["Infernal Cleave"] = 1,
		["Bite"] = 1,
		["Plague-Ridden Stab"] = 8,
		["Null Palm"] = 32,
		["Earthen Shield"] = 8,
		["Crackling Storm"] = 8,
		["Nightmare Corruption"] = 32,
		["Spirit Fount"] = 32,
		["Sand Trap"] = 8,
		["Heaving Sands"] = 1,
		["Gazing Shadows"] = 32,
		["Shackled Torment"] = 32,
		["Seeping Fel Power"] = 4,
		["Charred Earth"] = 4,
		["Chaos Nova"] = 124,
		["Rolling Charge"] = 1,
		["Glaive"] = 1,
		["Fel Bombardment"] = 4,
		["Black Hole"] = 1,
		["Dazed"] = 1,
		["Dripping Fangs"] = 8,
		["Dark Solitude"] = 32,
		["Corrupted Mist"] = 8,
		["Icicle"] = 16,
		["Coral Slash"] = 1,
		["Blast Furnace"] = 4,
		["Torment of Flames"] = 4,
		["Molten Spew"] = 4,
		["Scornful Charge"] = 1,
		["Arc Bomb"] = 64,
		["Shield Spike"] = 1,
		["Shadow Blade"] = 32,
		["Streetsweeper"] = 64,
		["Shadow Surge"] = 32,
		["Dark Breath"] = 32,
		["Isolated Rage"] = 1,
		["Amber Scalpel"] = 8,
		["Fel Barrage"] = 126,
		["Revenge"] = 1,
		["Nightmare Explosion"] = 32,
		["Clumsy Slash"] = 1,
		["Nothingness"] = 32,
		["Frozen Orb"] = 16,
		["Quietus"] = 32,
		["Corruption Nova"] = 32,
		["Lava Burst Overload"] = 4,
		["Burning Spear"] = 1,
		["Eye Storm"] = 4,
		["Vile Wound"] = 32,
		["Sha Bolt"] = 32,
		["Detonate: Arcane Orb"] = 64,
		["Full Power"] = 64,
		["Fiery Pool"] = 4,
		["Doom Vortex"] = 4,
		["Curse of the Dreadblades"] = 32,
		["Carpal Claw"] = 1,
		["Death Grip"] = 1,
		["Empowered Eye of Gul'dan"] = 4,
		["Pounding"] = 8,
		["Burst of Time"] = 64,
		["Focused Lightning Detonation"] = 8,
		["Tormenting Infection"] = 32,
		["Volatile Felblast"] = 4,
		["Decaying Roots"] = 8,
		["Falling Slam"] = 8,
		["Blazing Hellfire"] = 4,
		["Blood Frenzy"] = 1,
		["Mark of the Loa"] = 2,
		["Fiery Boulder"] = 4,
		["Soul Energies"] = 32,
		["Discharge"] = 64,
		["Celestial Breath"] = 64,
		["Toxic Blade"] = 8,
		["Boiling Blood"] = 4,
		["Knockback"] = 1,
		["Song of the Empress"] = 1,
		["Engulfed Explosion"] = 1,
		["Rebuke"] = 1,
		["Breach"] = 64,
		["Darkened Remnant"] = 32,
		["Virulent Plague"] = 32,
		["Hydra Head"] = 1,
		["Shield Slam"] = 1,
		["Magic Resonance"] = 64,
		["Infernal Crash"] = 1,
		["Vengeful Blast"] = 48,
		["Mongoose Bite"] = 1,
		["Anima Ring"] = 4,
		["Arcburst"] = 64,
		["Fel Immolate"] = 4,
		["Wing Buffet"] = 1,
		["Bouncing Bolt"] = 8,
		["Pyrotechnics"] = 4,
		["Crushing Darkness"] = 32,
		["Nightmare Spores"] = 8,
		["Fetid Regurgitation"] = 8,
		["Massive Deluge"] = 16,
		["Mindwrack"] = 32,
		["Pyroblast"] = 4,
		["Shield-Breaker"] = 1,
		["Kingsbane"] = 8,
		["Shroud of Sorrow"] = 32,
		["Spiderling Venom"] = 8,
		["Corrupting Flames"] = 36,
		["Breath of Sindragosa"] = 48,
		["Killing Spree Off-Hand"] = 1,
		["Dark Flay"] = 32,
		["Caw"] = 1,
		["Volatile Magic"] = 64,
		["Fel Breath"] = 4,
		["Fire Orchid Pollen"] = 4,
		["Unstable Affliction"] = 32,
		["Pounce"] = 1,
		["Volatile Ichor"] = 8,
		["Concealing Murk"] = 32,
		["Motivating Roar"] = 1,
		["Puncture Wound"] = 1,
		["Ancient Miasma"] = 32,
		["Lightning"] = 8,
		["Serpent Kick"] = 4,
		["Ring of Shadows"] = 32,
		["Chomp"] = 1,
		["Blackout Kick"] = 1,
		["Shield Charge"] = 1,
		["Lunar Beam"] = 8,
		["Rending Charge"] = 1,
		["Anguished Outburst"] = 32,
		["Void Vortex"] = 32,
		["Crystalline Shockwave"] = 1,
		["Nether Link"] = 64,
		["Strangling Roots"] = 8,
		["Wake of Destruction"] = 32,
		["Sundering Doom"] = 32,
		["Death Glare"] = 8,
		["Opportunity Strikes"] = 1,
		["Foulness"] = 8,
		["Acid Spray"] = 8,
		["Violent Winds"] = 1,
		["Edict of Condemnation"] = 32,
		["Infinite Breath"] = 64,
		["Darkness"] = 32,
		["Sacred Ground"] = 2,
		["Foul Geyser"] = 8,
		["Toxic Retch"] = 8,
		["Shadow Bolt"] = 32,
		["Nightmare Blades"] = 1,
		["Carrion Plague"] = 32,
		["Mana Fang"] = 64,
		["Backslash"] = 1,
		["Crosswinds"] = 1,
		["Water Jet"] = 16,
		["Shadowy Apparition"] = 32,
		["Tangled Web"] = 64,
		["Gastric Bloat"] = 40,
		["Ebonbolt"] = 48,
		["Suppressive Fire"] = 4,
		["Fel Explosion"] = 4,
		["Shrapnel Blast"] = 4,
		["Infested Ground"] = 40,
		["Mind Blast"] = 32,
		["Fire Bomb"] = 4,
		["Agony"] = 32,
		["Boulder Crush"] = 1,
		["Greater Blessing of Might"] = 2,
		["Eye of Tyr"] = 2,
		["Soul Burst"] = 4,
		["Water Ball"] = 16,
		["Multi-Shot"] = 64,
		["Cinders"] = 4,
		["Blistering Ooze"] = 8,
		["Obliterate"] = 1,
		["Summon Enchanted Armament"] = 4,
		["Celestial Brand"] = 64,
		["Controlled Chaos"] = 64,
		["Explosive Shard"] = 4,
		["Earthquake Totem"] = 8,
		["Flame Spout"] = 4,
		["Amassing Darkness"] = 32,
		["Seething Corruption"] = 4,
		["Aftershock"] = 1,
		["Bear Trap"] = 1,
		["Holy Word: Chastise"] = 2,
		["Marked Shot"] = 1,
		["Lunar Detonation"] = 64,
		["Inferno Charge"] = 4,
		["Withering Blight"] = 32,
		["Erupting Terror"] = 32,
		["Call of the Grave"] = 32,
		["Dispersed Spores"] = 32,
		["Eye for an Eye"] = 1,
		["Fiery Blood"] = 4,
		["Acid Splash"] = 8,
		["Bane"] = 32,
		["Nightmare Gaze"] = 32,
		["Illidan's Sightless Gaze"] = 4,
		["Time Release"] = 64,
		["Exhale"] = 1,
		["Corrupted Breath"] = 32,
		["Fireball"] = 4,
		["Smouldering"] = 4,
		["Holy Wrath"] = 2,
		["Flametongue Attack"] = 4,
		["Corruption Meteor"] = 32,
		["Cowardice"] = 1,
		["Throw Torch"] = 4,
		["Chilled Blood"] = 16,
		["Bilewater Sludge"] = 16,
		["Frost Tomb"] = 16,
		["Blood Leech"] = 8,
		["Lightning Bolt Overload"] = 8,
		["Multi-Headed"] = 1,
		["Stab"] = 1,
		["Lava Spit"] = 4,
		["Bladestorm Off-Hand"] = 1,
		["Poison Spit"] = 8,
		["Felfire Slam"] = 4,
		["Hurl Weapon"] = 1,
		["Lunar Barrage"] = 64,
		["Armageddon Rain"] = 4,
		["Crippling Bite"] = 1,
		["Imbued Iron Axe"] = 4,
		["Cutter Laser"] = 4,
		["Arcane Eclipse"] = 64,
		["Searing Rend"] = 4,
		["Armorshell Shrapnel"] = 1,
		["Shadow Cleave"] = 32,
		["Ice Patch"] = 16,
		["Shadowflame Bolt"] = 4,
		["Expel Magic: Frost"] = 16,
		["Watery Splash"] = 16,
		["Volatile Resonance"] = 4,
		["Infected Bite"] = 1,
		["Armageddon Blast"] = 4,
		["Pepper Breath"] = 4,
		["Necrotic Pitch"] = 32,
		["Impaling Throw"] = 1,
		["Delphuric Beam"] = 64,
		["Shattered Rune"] = 32,
		["Fel Spark"] = 4,
		["Shadowfel Annihilation"] = 36,
		["Artillery"] = 4,
		["Rain of Fire"] = 4,
		["Scorned Touch"] = 32,
		["Crushing Charge"] = 1,
		["Nightmare Bomb"] = 32,
		["Keg Smash"] = 1,
		["Shadow Bolt Volley"] = 32,
		["Corpse Breath"] = 32,
		["Expel Magic: Arcane"] = 64,
		["Arcane Blast"] = 64,
		["Radiation"] = 64,
		["Volcano"] = 1,
		["Overwhelming Chaos"] = 127,
		["Death Sweep"] = 1,
		["Brackwater Barrage"] = 16,
		["Jade Serpent Kick"] = 4,
		["Fan of Knives"] = 1,
		["Blade Flurry"] = 1,
		["Carrion Swarm"] = 32,
		["Permafrost"] = 16,
		["Asphyxiate"] = 1,
		["Frostbrand"] = 16,
		["Ravenous Bite"] = 8,
		["Volatile Fragments"] = 4,
		["Touch of Karma"] = 8,
		["Vengeful Retreat"] = 1,
		["Optic Blast"] = 4,
		["Umbra Detonation"] = 32,
		["Fel Sludge"] = 4,
		["Soul Vortex"] = 32,
		["Arcane Missiles"] = 64,
		["Exterminate"] = 64,
		["Scorching Shot"] = 4,
		["Chains of Fel"] = 4,
		["Flaming Slice"] = 4,
		["Gaseous Bubbles"] = 16,
		["Toxic Spores"] = 8,
		["Overrun"] = 1,
		["Crimson Wake"] = 4,
		["Devouring"] = 1,
		["Gaze of Vethriz"] = 32,
		["Overloaded Circuits"] = 8,
		["Dark Eclipse"] = 32,
		["Beast Cleave"] = 1,
		["Defiant Strike"] = 1,
		["Demonic Obelisk"] = 4,
		["Millificent's Ire"] = 8,
		["Blood of Y'Shaarj"] = 32,
		["Spectral Glaive"] = 96,
		["Burning Brand"] = 4,
		["Brackish Bolt"] = 8,
		["Shadowsoul Bolt"] = 32,
		["Infested Breath"] = 40,
		["Impale"] = 1,
		["Mutagen"] = 8,
		["Holy Nova"] = 2,
		["Touch of Harm"] = 32,
		["Destruction"] = 8,
		["Toss Anchor"] = 1,
		["Toxic Tornado"] = 8,
		["Sunder Armor"] = 1,
		["Storm Tempests"] = 8,
		["Arc Slash"] = 64,
		["Blood Bomb"] = 32,
		["Haunted Shadows"] = 32,
		["Explosive Burst"] = 4,
		["Magma Breaker"] = 4,
		["Unleashed Torment"] = 32,
		["Chicken Swarm Rockets"] = 4,
		["Thrash"] = 1,
		["Elder's Wrath"] = 4,
		["Cleansing Waters"] = 1,
		["Light Eruption"] = 2,
		["Blistering Rain"] = 4,
		["Foul Explosion"] = 32,
		["Blade of Justice"] = 1,
		["Magma Wave"] = 4,
		["Raging Shadows"] = 32,
		["Corrosive Fel Poison"] = 8,
		["Blood Assault"] = 16,
		["Shadow Word: Bane"] = 32,
		["Blade Dash"] = 1,
		["Darkness of a Thousand Souls"] = 32,
		["Vengeance"] = 1,
		["Static Shock"] = 8,
		["Choking Mists"] = 8,
		["Dashing Strike"] = 1,
		["Living Seed"] = 8,
		["Scalding Steam"] = 4,
		["Howling Blast"] = 16,
		["Vine Line"] = 8,
		["The Infinite Dark"] = 32,
		["Shattering Strike"] = 8,
		["Volatile Fire"] = 4,
		["Felflame Shield"] = 4,
		["Bash"] = 1,
		["Supernova"] = 64,
		["Temporal Orb"] = 64,
		["Brand of Argus"] = 4,
		["Slag Blast"] = 4,
		["Warped Blast"] = 64,
		["Titanic Strike"] = 1,
		["Fel Fire"] = 4,
		["Deathspike"] = 32,
		["Whirling Saber"] = 4,
		["Lizard Bolt"] = 8,
		["Lightning Shield"] = 8,
		["Curse of the Legion"] = 32,
		["Debilitating Fixation"] = 32,
		["Mystical Blast"] = 64,
		["Icky Goo"] = 8,
		["Entanglement"] = 8,
		["Infectious Bite"] = 8,
		["Ritual of Bones"] = 32,
		["Tormented Eruption"] = 4,
		["Spinning Crane Kick"] = 1,
		["Resonant Slash"] = 64,
		["Corruption Shock"] = 8,
		["Rippling Smash"] = 8,
		["Corruption: Crushing Shadows"] = 1,
		["Bilewater Liquefaction"] = 16,
		["Void Trap"] = 32,
		["Infernal Spike"] = 4,
		["Fel Squall"] = 4,
		["Stormstrike Off-Hand"] = 1,
		["Infected Talons"] = 8,
		["Flame Lick"] = 4,
		["Dark Torrent"] = 32,
		["Hatred"] = 4,
		["Bubble Blast"] = 16,
		["Void Bolt"] = 32,
		["Blackrock-Plated Gauntlets"] = 1,
		["Blast Wave"] = 4,
		["Maddened Strike"] = 1,
		["Crackling Jade Lightning"] = 8,
		["Flames"] = 4,
		["Molten Crash"] = 8,
		["Rushing Jade Wind"] = 1,
		["Blessed Hammer"] = 2,
		["Roar of Sacrifice"] = 8,
		["Desiccation"] = 32,
		["Crash Lightning"] = 8,
		["Orb of Destruction"] = 4,
		["Rupture"] = 1,
		["Spear of Light"] = 2,
		["Goblin Dragon Gun"] = 4,
		["Arcane Seepage"] = 64,
		["Shadow Thrash"] = 32,
		["Corpse Shield"] = 32,
		["Dispatch"] = 1,
		["Smack Down"] = 1,
		["Grievous Tear"] = 1,
		["Give No Quarter"] = 64,
		["Drain Life"] = 32,
		["Temporal Charge"] = 64,
		["Corrupted Touch"] = 32,
		["Twisted Touch of Life"] = 32,
		["Sanctify"] = 2,
		["Mana Volley"] = 64,
		["Fel Strike"] = 4,
		["Kromog's Fury"] = 8,
		["Lacerating Swipe"] = 1,
		["Ice Shards"] = 16,
		["Desolate Ground"] = 4,
		["Soul Fragment"] = 32,
		["Devouring Maw"] = 16,
		["Dragonfire Brew"] = 4,
		["Savage Stomp"] = 1,
		["Overflow"] = 64,
		["Doomed"] = 32,
		["Dread Charge"] = 1,
		["Corrupted Bellow"] = 32,
		["Touch of the Grave"] = 32,
		["Destructive Wake"] = 64,
		["Empowered Mannoroth's Gaze"] = 32,
		["Entombed in Ice"] = 16,
		["Disease Cloud"] = 8,
		["Fracture"] = 1,
		["Frozen Soul"] = 16,
		["Lightning Storm"] = 8,
		["Ice Nova"] = 16,
		["Kneel to the Flame!"] = 4,
		["X21-01A Missile Barrage"] = 4,
		["Starburst"] = 64,
		["Sea-Brine Toxin"] = 8,
		["Burning Ground"] = 4,
		["Nether Storm"] = 4,
		["Breath of Fear"] = 32,
		["Rune of Grasping Earth"] = 8,
		["Lightning Fissure Conduction"] = 8,
		["Nether Spike"] = 64,
		["Spirit Light"] = 4,
		["Fel Immolation"] = 4,
		["Light of Day"] = 4,
		["Death Throes"] = 4,
		["Frost Blossom"] = 16,
		["Pristine Proto-Scale Girdle"] = 4,
		["Inhale"] = 1,
		["World Shatterer's Roar"] = 1,
		["Enfeebling Roar"] = 1,
		["Hailstorm"] = 16,
		["Blood Splatter"] = 32,
		["Corruption: Descent into Madness"] = 1,
		["Dark Maul"] = 32,
		["Molten Stomp"] = 4,
		["Dread Thrash"] = 1,
		["Stampede"] = 1,
		["Venomous Discharge"] = 8,
		["Fel Scythe"] = 4,
		["Sha Globe"] = 32,
		["Fel Pool"] = 4,
		["Twisted Fate"] = 32,
		["Spirit Burst"] = 32,
		["Obliterate Off-Hand"] = 1,
		["Mind Bomb"] = 32,
		["Rot Armor"] = 8,
		["Bone Flurry"] = 1,
		["Iron Prison"] = 1,
		["Fel Detonation"] = 4,
		["Deluge Strike"] = 8,
		["Intense Flame"] = 4,
		["Furious Flames"] = 4,
		["Rumbling Fissure"] = 4,
		["Comet Storm"] = 16,
		["Undying Shadows"] = 32,
		["Tantrum"] = 8,
		["Frigid Grasp"] = 16,
		["Darkfall"] = 32,
		["Throw"] = 1,
		["Frost Aura"] = 16,
		["Fel Streak"] = 4,
		["Hammer Fist"] = 32,
		["Flaming Punch"] = 4,
		["Frost Bomb"] = 16,
		["Sealed Magic"] = 64,
		["Burning Slash"] = 4,
		["Overheated"] = 4,
		["Holy Fire"] = 4,
		["Whirling Dragon Punch"] = 1,
		["Shattering Blade"] = 4,
		["Static Field"] = 8,
		["Wildfire Infusion"] = 4,
		["Kil'jaeden's Burning Wish"] = 4,
		["Rend Flesh"] = 1,
		["Poisoned Arrow Volley"] = 8,
		["Burning Soul"] = 4,
		["Soulbomb"] = 32,
		["Glowing Fragment"] = 2,
		["Debilitating Barrage"] = 32,
		["Static Charge"] = 64,
		["Ignite Felblade"] = 4,
		["Fel Firebolt"] = 4,
		["Spray Sand"] = 8,
		["Explosive Shadows"] = 32,
		["Vicious Bite"] = 1,
		["Fire Shield"] = 4,
		["Smash"] = 1,
		["Flame Infusion"] = 4,
		["Diabolic Bomb"] = 32,
		["Feral Lunge"] = 1,
		["Lightning Ring"] = 8,
		["Fel Obelisk"] = 1,
		["Destructive Resonance"] = 64,
		["Energy Drain"] = 64,
		["Sha Residue"] = 32,
		["Venomous Pool"] = 8,
		["Felblaze Residue"] = 4,
		["Annihilated"] = 1,
		["Expelled Corruption"] = 32,
		["Darkened Discharge"] = 32,
		["Boulderfist"] = 8,
		["Ashamane's Frenzy"] = 1,
		["Icy Touch"] = 16,
		["Vengeful Strikes"] = 1,
		["Released Anguish"] = 32,
		["Guardian Nova"] = 64,
		["Fiery Brand"] = 4,
		["Wind Bomb"] = 8,
		["Shadow Spike"] = 32,
		["Sanctified Ground"] = 2,
		["Nether Meteor"] = 68,
		["Mojo Puddle"] = 8,
		["Curse of Doom"] = 32,
		["Frost Strike"] = 16,
		["Spiked Shield"] = 1,
		["Raptor Strike"] = 1,
		["Cosmic Scythe"] = 64,
		["Brutal Slam"] = 1,
		["Plague Cloud"] = 8,
		["Arcane Shot"] = 64,
		["Slice Bone"] = 1,
		["Light Surge"] = 4,
		["Shimmer"] = 64,
		["Arcanetic Ring"] = 64,
		["Solar Collapse"] = 4,
		["Hamstring"] = 1,
		["Plague Spit"] = 8,
		["Mark of Taerar"] = 32,
		["Eye of the Storm"] = 8,
		["Gathering Clouds"] = 1,
		["Throw Wrench"] = 1,
		["Ring of Fire"] = 4,
		["Volatile Firebomb"] = 4,
		["Focused Lightning Violent Detonation"] = 8,
		["Shattering Scream"] = 32,
		["Huge Slag Eruption"] = 4,
		["Dark Waters"] = 32,
		["Brackwater Blast"] = 16,
		["Divine Surge"] = 66,
		["Sticky Ooze"] = 8,
		["Laser Burn"] = 4,
		["Challenging Shout"] = 1,
		["Purge the Wicked"] = 4,
		["Dark Lashing"] = 32,
		["Mark of the Legion"] = 32,
		["Permeliative Torment"] = 64,
		["Chill to the Bone"] = 16,
		["Overwhelming Power"] = 4,
		["Hand of Hindrance"] = 2,
		["Choking Dust"] = 8,
		["Soul Chamber"] = 1,
		["Seismic Slam"] = 1,
		["Stone Blast"] = 8,
		["Overflowing Energy"] = 64,
		["Arcane Bolt"] = 64,
		["Thundering Throw"] = 1,
		["Demonwrath"] = 32,
		["Swirling Scythe"] = 1,
		["Wildly Stabbing"] = 1,
		["Mark of Emeriss"] = 32,
		["Blackrock Mortar"] = 4,
		["Half Moon"] = 64,
		["Shield of Vengeance"] = 2,
		["Desecration"] = 32,
		["Corrupted Blood of Zakajz"] = 32,
		["Crawler Mine Blast"] = 1,
		["Momentum"] = 1,
		["Heart Seeker"] = 1,
		["Abyssal Smash"] = 1,
		["Earthquake"] = 1,
		["Breath of Corruption"] = 4,
		["Fading Light"] = 1,
		["Elemental Blast"] = 28,
		["Wave Crush"] = 16,
		["Undertow"] = 16,
		["Whirling Barrage"] = 4,
		["Whirling Fel"] = 4,
		["Shared Fate"] = 32,
		["Death Fog"] = 32,
		["Fel Hellfire"] = 4,
		["Sha Corruption"] = 32,
		["Dreaded Nightmare"] = 32,
		["Bristling Hackles"] = 8,
		["Rune Axe"] = 32,
		["Dark Plague"] = 8,
		["Death Coil"] = 32,
		["Crystal Spike"] = 1,
		["Massive Blast"] = 32,
		["Magma Pool"] = 4,
		["Cone of Cold"] = 16,
		["Corrupted Dissonance Field"] = 1,
		["Charged Chaotic Energy Burst"] = 64,
		["Salty Spittle"] = 16,
		["Nether Rift"] = 64,
		["Wildfire"] = 4,
		["Suppression Field"] = 32,
		["Giant Insect Swarm"] = 1,
		["Immolation"] = 4,
		["Black Bile"] = 32,
		["Spectral Army of Norgannon"] = 64,
		["Shadow Lick"] = 32,
		["Blades of Light"] = 1,
		["Master of the Glaive"] = 1,
		["Haunt"] = 32,
		["Bolthorn's Rune of Flame"] = 4,
		["Scorching Burns"] = 4,
		["Mutilate Off-Hand"] = 1,
		["Insignia of Ravenholdt"] = 32,
		["Stomp"] = 1,
		["Face Rage"] = 1,
		["Elemental Fire"] = 4,
		["Doomfire"] = 4,
		["Tiro-Autom�tico"] = 1,
		["Spanning Singularity"] = 64,
		["Soul Link"] = 32,
		["Haymaker"] = 1,
		["Throw Spear"] = 1,
		["Shado-Pan Torch"] = 1,
		["Flurry"] = 1,
		["Ruin Bolt"] = 64,
		["Whirling Edge"] = 1,
		["Torrent of Blades"] = 1,
		["Burning"] = 4,
		["Leyline Rift"] = 64,
		["Fuel Streak"] = 8,
		["Ember of Rage"] = 32,
		["Cleave"] = 1,
		["Auto Shot"] = 1,
		["Chi Wave"] = 8,
		["Volatile Amber"] = 8,
		["Salt Spray"] = 1,
		["Dark Hunt"] = 32,
		["Curse of Isolation"] = 32,
		["Razorice"] = 16,
		["Sense of Dread"] = 32,
		["Seeking Embers"] = 4,
		["Goring Swipe"] = 1,
		["Volatile Energy"] = 8,
		["Bloodbolt"] = 32,
		["Felsinged"] = 4,
		["Siphon Life"] = 32,
		["Consuming Flame"] = 4,
		["Corruption Bolt"] = 32,
		["Nether Tear"] = 32,
		["Rush of Flame"] = 4,
		["Lightning Bolt"] = 8,
		["Corrupted Brew"] = 32,
		["Swoop"] = 1,
		["Boar Charge"] = 1,
		["Saber Slash"] = 1,
		["Cleansing Flame"] = 2,
		["Shadow Nova"] = 32,
		["Avenger's Shield"] = 2,
		["Cosmic Smash"] = 64,
		["Frost Breath"] = 16,
		["Corruption"] = 32,
		["Strike"] = 1,
		["Rancor"] = 32,
		["Wasting Void"] = 32,
		["Slime Pool"] = 8,
		["Arcane Swipe"] = 64,
		["Howling Axe"] = 8,
		["Electrified Cloud"] = 1,
		["Water Bolt"] = 16,
		["Phoenix Reborn"] = 4,
		["Full Moon"] = 64,
		["Unstable Mana"] = 64,
		["Edge of Obliteration"] = 1,
		["Rending Claws"] = 1,
		["Stream of Blades"] = 1,
		["Starstrike"] = 64,
		["Toxic Tonic"] = 8,
		["Cadaverous Pallor"] = 8,
		["Hydra Acid"] = 8,
		["Pistol Barrage"] = 32,
		["Volley"] = 1,
		["Vampiric Touch"] = 32,
		["Unholy Aura"] = 32,
		["Penance"] = 2,
		["Burning Pitch"] = 4,
		["Shadow Globule"] = 32,
		["Divine Judgment"] = 2,
		["Wondrous Radiance"] = 64,
		["Lunge"] = 1,
		["Crystal Spikes"] = 8,
		["Volatile Toxin"] = 8,
		["Pheromones of Zeal"] = 8,
		["Drifting Embers"] = 4,
		["Bone Rattling Howl"] = 32,
		["Fire Storm"] = 4,
		["Electric Pulse"] = 8,
		["Muzzle"] = 1,
		["Executioner's Strike"] = 32,
		["Corrupting Nova"] = 32,
		["Blazing Fists"] = 4,
		["Foul Aura"] = 32,
		["Overload"] = 8,
		["Garrote"] = 1,
		["Falling Rocks"] = 1,
		["Glaive Thrust"] = 1,
		["Shattered Bleed"] = 1,
		["Rupturing Skitter"] = 8,
		["Vileblood Serum"] = 8,
		["Slag Eruption"] = 4,
		["Avalanche"] = 1,
		["Shattered Earth"] = 8,
		["Corrosive Aura"] = 8,
		["Chilling Winds"] = 16,
		["Blitz"] = 4,
		["Heavenly Crash"] = 64,
		["Moving Train"] = 4,
		["Wake of Shadows"] = 32,
		["Magic Burn"] = 64,
		["Lightning Strike"] = 8,
		["Infusion of Light"] = 2,
		["Frost Nova"] = 16,
		["Burning Wounds"] = 4,
		["Heroic Throw"] = 1,
		["Ablaze"] = 4,
		["Deck Fire"] = 4,
		["Arcing Lightning"] = 8,
		["Dragon's Breath"] = 4,
		["Blackout Strike"] = 1,
		["Sweep"] = 1,
		["Berserk Trample"] = 1,
		["Magma"] = 4,
		["Fire Blossom"] = 4,
		["Venom Sting"] = 8,
		["Infested Mind"] = 40,
		["Bone Saw"] = 1,
		["Nightmare Bloom"] = 32,
		["Reverberations"] = 1,
		["Singe"] = 4,
		["Crystalline Fragments"] = 64,
		["Eye Beam"] = 124,
		["Goremaw's Bite"] = 32,
		["Massive Quake"] = 16,
		["Shred"] = 1,
		["Icy Blood"] = 16,
		["Plague Strike"] = 1,
		["Superheated Scrap"] = 4,
		["Death Strike"] = 1,
		["Purifying Flames"] = 4,
		["Burning Acid"] = 4,
		["Nightmare Bomb [PH EFFECT]"] = 32,
		["Landslide"] = 8,
		["Demonic Feedback"] = 32,
		["Gaseous Blight"] = 32,
		["Reverberating Strike"] = 64,
		["Death's Caress"] = 32,
		["Burst of Magic"] = 64,
		["Toxin"] = 8,
		["Piercing Rush"] = 1,
		["Radiating Nightmare"] = 32,
		["Leech"] = 1,
		["Incinerating Breath"] = 4,
		["Call of the Storm"] = 8,
		["Curse of the Nocturnal"] = 32,
		["Scorch"] = 4,
		["Attenuating"] = 0,
		["Skulker Shot"] = 1,
		["Blood Nova"] = 1,
		["Splash"] = 4,
		["Cataclysm"] = 36,
		["Lava Shower"] = 4,
		["Cannon Barrage"] = 4,
		["Acid Breath"] = 8,
		["Focused Blast"] = 64,
		["Crystal Bark"] = 64,
		["Suppression Protocol"] = 64,
		["Compounding Horror"] = 32,
		["Gushing Wound"] = 1,
		["Secret Defense Mechanism"] = 1,
		["Expel Harm"] = 8,
		["Slag Tanker"] = 4,
		["Wicked Strike"] = 4,
		["Detonate: Searing Brand"] = 4,
		["Upwind"] = 1,
		["Slicing Maelstrom"] = 1,
		["Lava Geyser"] = 4,
		["Firebomb"] = 4,
		["Starfall"] = 72,
		["Drenching Waters"] = 16,
	},
	["deathlog_healingdone_min"] = 10000,
	["tutorial"] = {
		["unlock_button"] = 4,
		["main_help_button"] = 3948,
		["SWITCH_PANEL_FIRST_OPENED"] = true,
		["ATTRIBUTE_SELECT_TUTORIAL1"] = true,
		["MEMORY_USAGE_ALERT1"] = true,
		["logons"] = 3948,
		["STREAMER_FEATURES_POPUP1"] = true,
		["DETAILS_INFO_TUTORIAL2"] = 10,
		["STREAMER_PLUGIN_FIRSTRUN"] = true,
		["ENCOUNTER_DETAILS_TUTORIAL2"] = true,
		["FULL_DELETE_WINDOW"] = true,
		["ENCOUNTER_DETAILS_TUTORIAL1"] = true,
		["DETAILS_INFO_TUTORIAL1"] = true,
		["alert_frames"] = {
			false, -- [1]
			false, -- [2]
			false, -- [3]
			false, -- [4]
			false, -- [5]
			false, -- [6]
		},
		["feedback_window1"] = true,
		["ENCOUNTER_DETAILS_BALLON_TUTORIAL1"] = true,
		["OVERALLDATA_WARNING1"] = 10,
		["WINDOW_GROUP_MAKING1"] = true,
		["version_announce"] = 0,
		["bookmark_tutorial"] = true,
		["OPTIONS_PANEL_OPENED"] = true,
		["WINDOW_LOCK_UNLOCK1"] = true,
		["ctrl_click_close_tutorial"] = true,
	},
	["mythic_plus"] = {
		["make_overall_boss_only"] = false,
		["mythicrun_chart_frame"] = {
		},
		["merge_boss_trash"] = true,
		["delay_to_show_graphic"] = 5,
		["always_in_combat"] = false,
		["make_overall_when_done"] = true,
		["delete_trash_after_merge"] = true,
		["show_damage_graphic"] = true,
		["boss_dedicated_segment"] = true,
		["mythicrun_chart_frame_minimized"] = {
		},
		["last_mythicrun_chart"] = {
		},
	},
	["realm_sync"] = true,
	["createauraframe"] = {
		["y"] = 7.629394531250e-006,
		["x"] = -3.05175781250e-005,
		["point"] = "CENTER",
		["scale"] = 1,
	},
	["switchSaved"] = {
		["slots"] = 18,
		["table"] = {
			{
				["atributo"] = 1,
				["sub_atributo"] = 1,
			}, -- [1]
			{
				["atributo"] = 2,
				["sub_atributo"] = 1,
			}, -- [2]
			{
				["atributo"] = 1,
				["sub_atributo"] = 6,
			}, -- [3]
			{
				["atributo"] = 4,
				["sub_atributo"] = 5,
			}, -- [4]
			{
				["atributo"] = 1,
				["sub_atributo"] = 3,
			}, -- [5]
			{
				["atributo"] = 4,
				["sub_atributo"] = 3,
			}, -- [6]
			{
				["atributo"] = 5,
				["sub_atributo"] = 2,
			}, -- [7]
			{
				["atributo"] = 4,
				["sub_atributo"] = 3,
			}, -- [8]
			{
				["atributo"] = 1,
				["sub_atributo"] = 7,
			}, -- [9]
			{
				["atributo"] = 1,
				["sub_atributo"] = 4,
			}, -- [10]
			{
				["atributo"] = 1,
				["sub_atributo"] = 8,
			}, -- [11]
			{
				["atributo"] = 2,
				["sub_atributo"] = 3,
			}, -- [12]
			{
				["atributo"] = 2,
				["sub_atributo"] = 5,
			}, -- [13]
			{
				["atributo"] = 1,
				["sub_atributo"] = 6,
			}, -- [14]
			{
				["atributo"] = 4,
				["sub_atributo"] = 7,
			}, -- [15]
			{
				["atributo"] = 5,
				["sub_atributo"] = 10,
			}, -- [16]
			{
				["atributo"] = 1,
				["sub_atributo"] = 5,
			}, -- [17]
			{
				["atributo"] = 5,
				["sub_atributo"] = 11,
			}, -- [18]
			{
				["atributo"] = "plugin",
				["sub_atributo"] = "DETAILS_PLUGIN_TINY_THREAT",
			}, -- [19]
			{
				["atributo"] = "plugin",
				["sub_atributo"] = "DETAILS_PLUGIN_DPS_TUNING",
			}, -- [20]
			{
				["atributo"] = 1,
				["sub_atributo"] = 2,
			}, -- [21]
			{
				["atributo"] = 2,
				["sub_atributo"] = 4,
			}, -- [22]
			{
				["atributo"] = 4,
				["sub_atributo"] = 4,
			}, -- [23]
			{
				["atributo"] = 3,
				["sub_atributo"] = 1,
			}, -- [24]
			{
				["atributo"] = 3,
				["sub_atributo"] = 5,
			}, -- [25]
			{
			}, -- [26]
			{
			}, -- [27]
			{
			}, -- [28]
			{
			}, -- [29]
			{
			}, -- [30]
			{
			}, -- [31]
			{
			}, -- [32]
			{
			}, -- [33]
			{
			}, -- [34]
			{
			}, -- [35]
			{
			}, -- [36]
			{
			}, -- [37]
			{
			}, -- [38]
			{
			}, -- [39]
			{
			}, -- [40]
			{
			}, -- [41]
			{
			}, -- [42]
		},
	},
	["savedCustomSpells"] = {
		{
			1, -- [1]
			"Melee", -- [2]
			"Interface\\ICONS\\INV_Sword_04", -- [3]
		}, -- [1]
		{
			2, -- [1]
			"Auto Shot", -- [2]
			"Interface\\ICONS\\INV_Weapon_Bow_07", -- [3]
		}, -- [2]
		{
			4, -- [1]
			"Environment (Drowning)", -- [2]
			"Interface\\ICONS\\Ability_Suffocate", -- [3]
		}, -- [3]
		{
			8, -- [1]
			"Environment (Slime)", -- [2]
			"Interface\\ICONS\\Ability_Creature_Poison_02", -- [3]
		}, -- [4]
		{
			88082, -- [1]
			"Fireball (Mirror Image)", -- [2]
			"Interface\\Icons\\Spell_Fire_FlameBolt", -- [3]
		}, -- [5]
		{
			94472, -- [1]
			"Atonement (critical)", -- [2]
			"Interface\\Icons\\Spell_Holy_CircleOfRenewal", -- [3]
		}, -- [6]
		{
			59638, -- [1]
			"Frostbolt (Mirror Image)", -- [2]
			"Interface\\Icons\\Spell_Frost_FrostBolt02", -- [3]
		}, -- [7]
		{
			5, -- [1]
			"Environment (Fatigue)", -- [2]
			"Interface\\ICONS\\Spell_Arcane_MindMastery", -- [3]
		}, -- [8]
		{
			158336, -- [1]
			"Pulverize (wave #1)", -- [2]
			"Interface\\Icons\\INV_Stone_16", -- [3]
		}, -- [9]
		{
			3, -- [1]
			"Environment (Falling)", -- [2]
			"Interface\\ICONS\\Spell_Magic_FeatherFall", -- [3]
		}, -- [10]
		{
			6, -- [1]
			"Environment (Fire)", -- [2]
			"Interface\\ICONS\\INV_SummerFest_FireSpirit", -- [3]
		}, -- [11]
		{
			120761, -- [1]
			"Glaive Toss (Glaive #2)", -- [2]
			"Interface\\Icons\\Ability_UpgradeMoonGlaive", -- [3]
		}, -- [12]
		{
			44461, -- [1]
			"Living Bomb (explosion)", -- [2]
			"Interface\\Icons\\Ability_Mage_LivingBomb", -- [3]
		}, -- [13]
		{
			33778, -- [1]
			"Lifebloom (bloom)", -- [2]
			"Interface\\Icons\\Spell_Nature_HealingTouch", -- [3]
		}, -- [14]
		{
			158159, -- [1]
			"Shield Charge", -- [2]
			"Interface\\Icons\\Ability_Warrior_ShieldGuard", -- [3]
		}, -- [15]
		{
			121414, -- [1]
			"Glaive Toss (Glaive #1)", -- [2]
			"Interface\\Icons\\Ability_UpgradeMoonGlaive", -- [3]
		}, -- [16]
		{
			177608, -- [1]
			"Shield Charge (copies)", -- [2]
			"Interface\\Icons\\Ability_Warrior_ShieldGuard", -- [3]
		}, -- [17]
		{
			7, -- [1]
			"Environment (Lava)", -- [2]
			"Interface\\ICONS\\Ability_Rhyolith_Volcano", -- [3]
		}, -- [18]
		{
			158420, -- [1]
			"Pulverize (wave #3)", -- [2]
			"Interface\\Icons\\INV_Stone_16", -- [3]
		}, -- [19]
		{
			158417, -- [1]
			"Pulverize (wave #2)", -- [2]
			"Interface\\Icons\\INV_Stone_16", -- [3]
		}, -- [20]
		{
			161612, -- [1]
			"Overflowing Energy (caught)", -- [2]
			"Interface\\Icons\\spell_fel_elementaldevastation", -- [3]
		}, -- [21]
		{
			98021, -- [1]
			"Health Exchange", -- [2]
			"Interface\\Icons\\Spell_Shaman_SpiritLink", -- [3]
		}, -- [22]
		{
			161576, -- [1]
			"Overflowing Energy (explosion)", -- [2]
			"Interface\\Icons\\spell_fel_elementaldevastation", -- [3]
		}, -- [23]
		{
			213786, -- [1]
			"Nightfall (trinket)", -- [2]
			236168, -- [3]
		}, -- [24]
		{
			214350, -- [1]
			"Nightmare Essence (trinket)", -- [2]
			1357816, -- [3]
		}, -- [25]
		{
			224078, -- [1]
			"Devilsaur Shock Leash (trinket)", -- [2]
			136048, -- [3]
		}, -- [26]
	},
	["plater"] = {
		["realtime_dps_enabled"] = false,
		["damage_taken_anchor"] = {
			["y"] = 0,
			["x"] = 0,
			["side"] = 7,
		},
		["realtime_dps_player_shadow"] = true,
		["damage_taken_enabled"] = false,
		["realtime_dps_player_size"] = 12,
		["damage_taken_size"] = 12,
		["realtime_dps_color"] = {
			1, -- [1]
			1, -- [2]
			0, -- [3]
			1, -- [4]
		},
		["realtime_dps_anchor"] = {
			["y"] = 0,
			["x"] = 0,
			["side"] = 7,
		},
		["realtime_dps_size"] = 12,
		["damage_taken_shadow"] = true,
		["damage_taken_color"] = {
			1, -- [1]
			1, -- [2]
			0, -- [3]
			1, -- [4]
		},
		["realtime_dps_player_color"] = {
			1, -- [1]
			1, -- [2]
			0, -- [3]
			1, -- [4]
		},
		["realtime_dps_player_anchor"] = {
			["y"] = 0,
			["x"] = 0,
			["side"] = 7,
		},
		["realtime_dps_player_enabled"] = false,
		["realtime_dps_shadow"] = true,
	},
	["update_warning_timeout"] = 10,
	["__profiles"] = {
		["Default"] = {
			["show_arena_role_icon"] = false,
			["capture_real"] = {
				["heal"] = true,
				["spellcast"] = true,
				["miscdata"] = true,
				["aura"] = true,
				["energy"] = true,
				["damage"] = true,
			},
			["row_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["player_details_window"] = {
				["scale"] = 1,
				["bar_texture"] = "Skyline",
				["skin"] = "ElvUI",
			},
			["numerical_system"] = 1,
			["use_row_animations"] = true,
			["report_heal_links"] = false,
			["windows_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["death_tooltip_width"] = 350,
			["report_to_who"] = "rapidrivers",
			["overall_flag"] = 13,
			["profile_save_pos"] = true,
			["tooltip"] = {
				["header_statusbar"] = {
					0.3, -- [1]
					0.3, -- [2]
					0.3, -- [3]
					0.8, -- [4]
					false, -- [5]
					false, -- [6]
					"WorldState Score", -- [7]
				},
				["fontcolor_right"] = {
					1, -- [1]
					0.7, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["tooltip_max_targets"] = 2,
				["icon_size"] = {
					["W"] = 13,
					["H"] = 13,
				},
				["tooltip_max_pets"] = 2,
				["anchor_relative"] = "top",
				["abbreviation"] = 2,
				["anchored_to"] = 1,
				["show_amount"] = true,
				["header_text_color"] = {
					1, -- [1]
					0.9176, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["fontsize"] = 13,
				["background"] = {
					0.196078431372549, -- [1]
					0.196078431372549, -- [2]
					0.196078431372549, -- [3]
					0, -- [4]
				},
				["submenu_wallpaper"] = true,
				["fontsize_title"] = 10,
				["icon_border_texcoord"] = {
					["B"] = 0.921875,
					["L"] = 0.078125,
					["T"] = 0.078125,
					["R"] = 0.921875,
				},
				["commands"] = {
				},
				["tooltip_max_abilities"] = 6,
				["fontface"] = "FORCED SQUARE",
				["border_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					0, -- [4]
				},
				["border_texture"] = "Blizzard Tooltip",
				["anchor_offset"] = {
					0, -- [1]
					0, -- [2]
				},
				["maximize_method"] = 1,
				["fontshadow"] = false,
				["border_size"] = 16,
				["menus_bg_texture"] = "Interface\\SPELLBOOK\\Spellbook-Page-1",
				["anchor_screen_pos"] = {
					507.7, -- [1]
					-350.5, -- [2]
				},
				["anchor_point"] = "bottom",
				["menus_bg_coords"] = {
					0.309777336120606, -- [1]
					0.924000015258789, -- [2]
					0.213000011444092, -- [3]
					0.279000015258789, -- [4]
				},
				["fontcolor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["menus_bg_color"] = {
					0.8, -- [1]
					0.8, -- [2]
					0.8, -- [3]
					0.2, -- [4]
				},
			},
			["ps_abbreviation"] = 3,
			["world_combat_is_trash"] = false,
			["update_speed"] = 0.33,
			["animation_speed_mintravel"] = 0.45,
			["track_item_level"] = true,
			["windows_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["instances_menu_click_to_open"] = false,
			["overall_clear_newchallenge"] = true,
			["time_type"] = 2,
			["data_cleanup_logout"] = false,
			["instances_disable_bar_highlight"] = false,
			["trash_concatenate"] = false,
			["color_by_arena_team"] = true,
			["animation_speed"] = 33,
			["disable_stretch_from_toolbar"] = false,
			["disable_lock_ungroup_buttons"] = false,
			["memory_ram"] = 64,
			["disable_window_groups"] = false,
			["instances_suppress_trash"] = 0,
			["animation_speed_maxtravel"] = 3,
			["deny_score_messages"] = false,
			["default_bg_alpha"] = 0.5,
			["font_faces"] = {
				["menus"] = "Expressway",
			},
			["all_players_are_group"] = false,
			["standard_skin"] = {
				["hide_in_combat_type"] = 1,
				["backdrop_texture"] = "Details Ground",
				["color"] = {
					0.333333333333333, -- [1]
					0.333333333333333, -- [2]
					0.333333333333333, -- [3]
					0.3777777777777, -- [4]
				},
				["menu_anchor"] = {
					16, -- [1]
					0, -- [2]
					["side"] = 2,
				},
				["bg_r"] = 0.0941176470588235,
				["skin"] = "Minimalistic",
				["following"] = {
					["bar_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
					["enabled"] = false,
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
				},
				["color_buttons"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["switch_healer"] = false,
				["skin_custom"] = "",
				["bg_b"] = 0.0941176470588235,
				["switch_healer_in_combat"] = false,
				["hide_out_of_combat"] = false,
				["tooltip"] = {
					["n_abilities"] = 3,
					["n_enemies"] = 3,
				},
				["auto_hide_menu"] = {
					["left"] = false,
					["right"] = false,
				},
				["total_bar"] = {
					["enabled"] = false,
					["only_in_group"] = true,
					["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
					["color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
				},
				["switch_all_roles_in_combat"] = false,
				["instance_button_anchor"] = {
					-27, -- [1]
					1, -- [2]
				},
				["name"] = "",
				["row_info"] = {
					["textR_outline"] = false,
					["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
					["textL_outline"] = false,
					["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
					["textL_outline_small"] = true,
					["textL_enable_custom_text"] = false,
					["fixed_text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
					["space"] = {
						["right"] = 0,
						["left"] = 0,
						["between"] = 0,
					},
					["texture_background_class_color"] = false,
					["start_after_icon"] = false,
					["font_face_file"] = "Interface\\Addons\\Details\\fonts\\Accidental Presidency.ttf",
					["textL_custom_text"] = "{data1}. {data3}{data2}",
					["font_size"] = 10,
					["texture_custom_file"] = "Interface\\",
					["texture_file"] = "Interface\\AddOns\\Details\\images\\BantoBar",
					["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small_alpha",
					["height"] = 14,
					["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar4_reverse",
					["use_spec_icons"] = true,
					["textR_enable_custom_text"] = false,
					["models"] = {
						["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
						["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
						["upper_alpha"] = 0.5,
						["lower_enabled"] = false,
						["lower_alpha"] = 0.1,
						["upper_enabled"] = false,
					},
					["fixed_texture_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
					},
					["textL_show_number"] = true,
					["percent_type"] = 1,
					["texture_custom"] = "",
					["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
					["texture"] = "BantoBar",
					["textR_outline_small"] = true,
					["textR_show_data"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
					},
					["textL_outline_small_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["texture_background"] = "Details D'ictum (reverse)",
					["alpha"] = 1,
					["textR_class_colors"] = false,
					["textR_outline_small_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						1, -- [4]
					},
					["no_icon"] = false,
					["textL_class_colors"] = false,
					["backdrop"] = {
						["enabled"] = false,
						["texture"] = "Details BarBorder 2",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["size"] = 12,
					},
					["font_face"] = "Accidental Presidency",
					["texture_class_colors"] = true,
					["fixed_texture_background_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0.150228589773178, -- [4]
					},
					["fast_ps_update"] = false,
					["textR_separator"] = ",",
					["textR_bracket"] = "(",
				},
				["switch_tank"] = false,
				["menu_alpha"] = {
					["enabled"] = false,
					["onleave"] = 1,
					["ignorebars"] = false,
					["iconstoo"] = true,
					["onenter"] = 1,
				},
				["menu_icons_size"] = 0.850000023841858,
				["plugins_grow_direction"] = 1,
				["desaturated_menu"] = false,
				["strata"] = "LOW",
				["show_sidebars"] = false,
				["window_scale"] = 1,
				["ignore_mass_showhide"] = false,
				["hide_in_combat_alpha"] = 0,
				["switch_all_roles_after_wipe"] = false,
				["menu_icons"] = {
					true, -- [1]
					true, -- [2]
					true, -- [3]
					true, -- [4]
					true, -- [5]
					false, -- [6]
					["space"] = -2,
					["shadow"] = true,
				},
				["switch_damager"] = false,
				["statusbar_info"] = {
					["alpha"] = 0.3777777777777,
					["overlay"] = {
						0.333333333333333, -- [1]
						0.333333333333333, -- [2]
						0.333333333333333, -- [3]
					},
				},
				["bars_grow_direction"] = 1,
				["row_show_animation"] = {
					["anim"] = "Fade",
					["options"] = {
					},
				},
				["micro_displays_locked"] = true,
				["bars_sort_direction"] = 1,
				["switch_damager_in_combat"] = false,
				["grab_on_top"] = false,
				["bg_alpha"] = 0.0984569266438484,
				["hide_icon"] = true,
				["auto_current"] = true,
				["toolbar_side"] = 1,
				["bg_g"] = 0.0941176470588235,
				["menu_anchor_down"] = {
					16, -- [1]
					-3, -- [2]
				},
				["hide_in_combat"] = false,
				["libwindow"] = {
					["y"] = 47,
					["x"] = 245.500015258789,
					["point"] = "BOTTOMLEFT",
				},
				["show_statusbar"] = false,
				["micro_displays_side"] = 2,
				["wallpaper"] = {
					["overlay"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["texcoord"] = {
						0, -- [1]
						1, -- [2]
						0, -- [3]
						0.7, -- [4]
					},
					["enabled"] = false,
					["anchor"] = "all",
					["height"] = 114.042518615723,
					["alpha"] = 0.5,
					["width"] = 283.000183105469,
				},
				["stretch_button_side"] = 1,
				["switch_tank_in_combat"] = false,
				["attribute_text"] = {
					["show_timer"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
					},
					["shadow"] = false,
					["side"] = 1,
					["text_size"] = 12,
					["custom_text"] = "{name}",
					["text_face"] = "Accidental Presidency",
					["anchor"] = {
						-18, -- [1]
						3, -- [2]
					},
					["enabled"] = true,
					["enable_custom_text"] = false,
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
				},
				["version"] = 3,
				["bars_inverted"] = false,
			},
			["animate_scroll"] = false,
			["instances"] = {
				{
					["__snapV"] = false,
					["__pos"] = {
						["normal"] = {
							["y"] = -419.215469825207,
							["x"] = -731.999997971154,
							["w"] = 391.337310791016,
							["h"] = 124.493804931641,
						},
						["solo"] = {
							["y"] = -47.3035888671875,
							["x"] = 604.971069335938,
							["w"] = 299.999847412109,
							["h"] = 300,
						},
					},
					["show_statusbar"] = false,
					["menu_icons_size"] = 0.850000023841858,
					["color"] = {
						0.333333333333333, -- [1]
						0.333333333333333, -- [2]
						0.333333333333333, -- [3]
						1, -- [4]
					},
					["menu_anchor"] = {
						16, -- [1]
						0, -- [2]
						["side"] = 2,
					},
					["__snapH"] = false,
					["bars_grow_direction"] = 1,
					["bg_r"] = 0.0941176470588235,
					["skin"] = "Minimalistic",
					["__was_opened"] = true,
					["hide_out_of_combat"] = false,
					["micro_displays_locked"] = true,
					["following"] = {
						["enabled"] = true,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["toolbar_icon_file"] = "Interface\\AddOns\\Details\\images\\toolbar_icons",
					["skin_custom"] = "",
					["hide_in_combat_type"] = 1,
					["menu_anchor_down"] = {
						16, -- [1]
						-3, -- [2]
					},
					["stretch_button_side"] = 1,
					["switch_damager_in_combat"] = false,
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["StatusBarSaved"] = {
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["textYMod"] = 1,
								["textXMod"] = 0,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 0,
								["textStyle"] = 2,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_THREAT"] = {
								["isHidden"] = false,
								["textStyle"] = 2,
								["textYMod"] = 1,
								["segmentType"] = 2,
								["textXMod"] = 0,
								["textFace"] = "Accidental Presidency",
								["textAlign"] = 0,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									1, -- [4]
								},
								["textFace"] = "Accidental Presidency",
								["textXMod"] = 6,
								["textAlign"] = 0,
								["timeType"] = 1,
								["textStyle"] = 2,
								["textSize"] = 10,
								["textYMod"] = 1,
							},
						},
						["left"] = "DETAILS_STATUSBAR_PLUGIN_THREAT",
					},
					["micro_displays_side"] = 2,
					["switch_all_roles_in_combat"] = false,
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["version"] = 3,
					["attribute_text"] = {
						["enabled"] = true,
						["shadow"] = false,
						["side"] = 1,
						["text_size"] = 12,
						["custom_text"] = "{name}",
						["text_face"] = "Accidental Presidency",
						["anchor"] = {
							-18, -- [1]
							3, -- [2]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["enable_custom_text"] = false,
						["show_timer"] = {
							true, -- [1]
							true, -- [2]
							true, -- [3]
						},
					},
					["__locked"] = true,
					["menu_alpha"] = {
						["enabled"] = true,
						["onenter"] = 1,
						["iconstoo"] = true,
						["ignorebars"] = false,
						["onleave"] = 1,
					},
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["bg_b"] = 0.0941176470588235,
					["grab_on_top"] = false,
					["strata"] = "MEDIUM",
					["switch_healer_in_combat"] = false,
					["__snap"] = {
					},
					["ignore_mass_showhide"] = false,
					["hide_in_combat_alpha"] = 0,
					["plugins_grow_direction"] = 1,
					["menu_icons"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						true, -- [4]
						true, -- [5]
						false, -- [6]
						["space"] = -3,
						["shadow"] = true,
					},
					["switch_damager"] = false,
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
					["statusbar_info"] = {
						["alpha"] = 1,
						["overlay"] = {
							0.333333333333333, -- [1]
							0.333333333333333, -- [2]
							0.333333333333333, -- [3]
						},
					},
					["window_scale"] = 0.996582746505737,
					["libwindow"] = {
						["y"] = 58.7502758194951,
						["x"] = 32.9999993191132,
						["point"] = "BOTTOMLEFT",
						["scale"] = 0.996582746505737,
					},
					["bg_alpha"] = 0.0984569266438484,
					["switch_tank_in_combat"] = false,
					["hide_icon"] = true,
					["backdrop_texture"] = "Details Ground",
					["show_sidebars"] = false,
					["auto_current"] = true,
					["toolbar_side"] = 1,
					["bg_g"] = 0.0941176470588235,
					["switch_healer"] = false,
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = -419.215469825207,
							["x"] = -731.999997971154,
							["w"] = 391.337310791016,
							["h"] = 124.493804931641,
						},
						["solo"] = {
							["y"] = -47.3035888671875,
							["x"] = 604.971069335938,
							["w"] = 299.999847412109,
							["h"] = 300,
						},
					},
					["switch_tank"] = false,
					["switch_all_roles_after_wipe"] = false,
					["wallpaper"] = {
						["enabled"] = false,
						["texcoord"] = {
							0, -- [1]
							1, -- [2]
							0, -- [3]
							0.7, -- [4]
						},
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							1, -- [4]
						},
						["anchor"] = "all",
						["height"] = 114.042518615723,
						["alpha"] = 0.5,
						["width"] = 283.000183105469,
					},
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["bars_sort_direction"] = 1,
					["desaturated_menu"] = false,
					["row_info"] = {
						["textR_outline"] = false,
						["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
						["textL_outline"] = false,
						["textR_outline_small"] = true,
						["textR_show_data"] = {
							true, -- [1]
							true, -- [2]
							true, -- [3]
						},
						["textL_enable_custom_text"] = false,
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["space"] = {
							["right"] = 0,
							["left"] = 0,
							["between"] = 0,
						},
						["texture_background_class_color"] = false,
						["start_after_icon"] = false,
						["font_face_file"] = "Interface\\Addons\\Details\\fonts\\Accidental Presidency.ttf",
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["models"] = {
							["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
							["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
							["upper_alpha"] = 0.5,
							["lower_enabled"] = false,
							["lower_alpha"] = 0.1,
							["upper_enabled"] = false,
						},
						["height"] = 14,
						["texture_file"] = "Interface\\AddOns\\Details\\images\\BantoBar",
						["textR_bracket"] = "(",
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small_alpha",
						["icon_grayscale"] = false,
						["font_size"] = 15,
						["use_spec_icons"] = true,
						["textR_enable_custom_text"] = false,
						["backdrop"] = {
							["enabled"] = false,
							["size"] = 12,
							["color"] = {
								1, -- [1]
								1, -- [2]
								1, -- [3]
								1, -- [4]
							},
							["texture"] = "Details BarBorder 2",
						},
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["texture"] = "BantoBar",
						["texture_custom"] = "",
						["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0.150228589773178, -- [4]
						},
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar4_reverse",
						["textL_class_colors"] = false,
						["textR_class_colors"] = false,
						["textR_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["texture_background"] = "Details D'ictum (reverse)",
						["alpha"] = 1,
						["no_icon"] = false,
						["percent_type"] = 1,
						["textL_outline_small_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["font_face"] = "Accidental Presidency",
						["texture_class_colors"] = true,
						["textL_outline_small"] = true,
						["fast_ps_update"] = false,
						["textR_separator"] = ",",
						["texture_custom_file"] = "Interface\\",
					},
					["bars_inverted"] = false,
				}, -- [1]
			},
			["report_lines"] = 5,
			["use_battleground_server_parser"] = false,
			["instances_segments_locked"] = false,
			["skin"] = "WoW Interface",
			["override_spellids"] = false,
			["overall_clear_newboss"] = true,
			["force_activity_time_pvp"] = true,
			["class_specs_coords"] = {
				[62] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[63] = {
					0.375, -- [1]
					0.5, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[250] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[251] = {
					0.125, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[252] = {
					0.25, -- [1]
					0.375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[253] = {
					0.875, -- [1]
					1, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[254] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[255] = {
					0.125, -- [1]
					0.25, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[66] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[257] = {
					0.5, -- [1]
					0.625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[258] = {
					0.6328125, -- [1]
					0.75, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[259] = {
					0.75, -- [1]
					0.875, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[260] = {
					0.875, -- [1]
					1, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[577] = {
					0.25, -- [1]
					0.375, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[262] = {
					0.125, -- [1]
					0.25, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[581] = {
					0.375, -- [1]
					0.5, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[264] = {
					0.375, -- [1]
					0.5, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[265] = {
					0.5, -- [1]
					0.625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[266] = {
					0.625, -- [1]
					0.75, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[267] = {
					0.75, -- [1]
					0.875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[268] = {
					0.625, -- [1]
					0.75, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[269] = {
					0.875, -- [1]
					1, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[270] = {
					0.75, -- [1]
					0.875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[70] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[102] = {
					0.375, -- [1]
					0.5, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[71] = {
					0.875, -- [1]
					1, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[103] = {
					0.5, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[72] = {
					0, -- [1]
					0.125, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[104] = {
					0.625, -- [1]
					0.75, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[73] = {
					0.125, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[64] = {
					0.5, -- [1]
					0.625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[105] = {
					0.75, -- [1]
					0.875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[65] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[256] = {
					0.375, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[261] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[263] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
			},
			["minimum_combat_time"] = 5,
			["overall_clear_logout"] = false,
			["pvp_as_group"] = true,
			["cloud_capture"] = true,
			["damage_taken_everything"] = false,
			["scroll_speed"] = 2,
			["font_sizes"] = {
				["menus"] = 10,
			},
			["memory_threshold"] = 3,
			["deadlog_events"] = 32,
			["class_icons_small"] = "Interface\\AddOns\\Details\\images\\classes_small",
			["close_shields"] = false,
			["class_coords"] = {
				["HUNTER"] = {
					0, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["WARRIOR"] = {
					0, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["ROGUE"] = {
					0.49609375, -- [1]
					0.7421875, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["MAGE"] = {
					0.25, -- [1]
					0.49609375, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["PET"] = {
					0.25, -- [1]
					0.49609375, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["DRUID"] = {
					0.7421875, -- [1]
					0.98828125, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["MONK"] = {
					0.5, -- [1]
					0.73828125, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["DEATHKNIGHT"] = {
					0.25, -- [1]
					0.5, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["MONSTER"] = {
					0, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["UNKNOW"] = {
					0.5, -- [1]
					0.75, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["PRIEST"] = {
					0.49609375, -- [1]
					0.7421875, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["SHAMAN"] = {
					0.25, -- [1]
					0.49609375, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["Alliance"] = {
					0.49609375, -- [1]
					0.7421875, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["ENEMY"] = {
					0, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["DEMONHUNTER"] = {
					0.73828126, -- [1]
					1, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["Horde"] = {
					0.7421875, -- [1]
					0.98828125, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["PALADIN"] = {
					0, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["UNGROUPPLAYER"] = {
					0.5, -- [1]
					0.75, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["WARLOCK"] = {
					0.7421875, -- [1]
					0.98828125, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
			},
			["use_scroll"] = false,
			["disable_alldisplays_window"] = false,
			["time_type_original"] = 2,
			["hotcorner_topleft"] = {
				["hide"] = false,
			},
			["class_colors"] = {
				["HUNTER"] = {
					0.67, -- [1]
					0.83, -- [2]
					0.45, -- [3]
				},
				["WARRIOR"] = {
					0.78, -- [1]
					0.61, -- [2]
					0.43, -- [3]
				},
				["SHAMAN"] = {
					0, -- [1]
					0.44, -- [2]
					0.87, -- [3]
				},
				["MAGE"] = {
					0.41, -- [1]
					0.8, -- [2]
					0.94, -- [3]
				},
				["ARENA_YELLOW"] = {
					0.9, -- [1]
					0.9, -- [2]
					0, -- [3]
				},
				["UNGROUPPLAYER"] = {
					0.4, -- [1]
					0.4, -- [2]
					0.4, -- [3]
				},
				["DRUID"] = {
					1, -- [1]
					0.49, -- [2]
					0.04, -- [3]
				},
				["MONK"] = {
					0, -- [1]
					1, -- [2]
					0.59, -- [3]
				},
				["DEATHKNIGHT"] = {
					0.77, -- [1]
					0.12, -- [2]
					0.23, -- [3]
				},
				["ENEMY"] = {
					0.94117, -- [1]
					0, -- [2]
					0.0196, -- [3]
					1, -- [4]
				},
				["UNKNOW"] = {
					0.2, -- [1]
					0.2, -- [2]
					0.2, -- [3]
				},
				["PRIEST"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
				},
				["ROGUE"] = {
					1, -- [1]
					0.96, -- [2]
					0.41, -- [3]
				},
				["ARENA_GREEN"] = {
					0.1, -- [1]
					0.85, -- [2]
					0.1, -- [3]
				},
				["WARLOCK"] = {
					0.58, -- [1]
					0.51, -- [2]
					0.79, -- [3]
				},
				["DEMONHUNTER"] = {
					0.64, -- [1]
					0.19, -- [2]
					0.79, -- [3]
				},
				["version"] = 1,
				["NEUTRAL"] = {
					1, -- [1]
					1, -- [2]
					0, -- [3]
				},
				["PALADIN"] = {
					0.96, -- [1]
					0.55, -- [2]
					0.73, -- [3]
				},
				["PET"] = {
					0.3, -- [1]
					0.4, -- [2]
					0.5, -- [3]
				},
			},
			["animation_speed_triggertravel"] = 5,
			["clear_graphic"] = true,
			["total_abbreviation"] = 2,
			["segments_auto_erase"] = 1,
			["options_group_edit"] = true,
			["segments_amount_to_save"] = 18,
			["minimap"] = {
				["onclick_what_todo"] = 1,
				["radius"] = 160,
				["text_type"] = 1,
				["minimapPos"] = 337.93798216025,
				["text_format"] = 3,
				["hide"] = false,
			},
			["instances_amount"] = 5,
			["max_window_size"] = {
				["height"] = 450,
				["width"] = 480,
			},
			["window_clamp"] = {
				-8, -- [1]
				0, -- [2]
				21, -- [3]
				-14, -- [4]
			},
			["only_pvp_frags"] = false,
			["disable_stretch_button"] = false,
			["remove_realm_from_name"] = true,
			["broadcaster_enabled"] = false,
			["trash_auto_remove"] = true,
			["segments_panic_mode"] = false,
			["default_bg_color"] = 0.0941,
			["numerical_system_symbols"] = "auto",
			["row_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["chat_tab_embed"] = {
				["enabled"] = true,
				["tab_name"] = "Details",
				["w2_pos"] = {
					["y"] = 166.749816894531,
					["h"] = 129.999984741211,
					["point"] = "LEFT",
					["pos_table"] = true,
					["x_legacy"] = -521.499877929688,
					["y_legacy"] = 166.749877929688,
					["w"] = 320.000061035156,
					["x"] = 278.500091552734,
				},
				["single_window"] = true,
				["w1_pos"] = {
					["y"] = -87.0003051757813,
					["x"] = 87.499740600586,
					["point"] = "TOPLEFT",
					["h"] = 132.000137329102,
					["x_legacy"] = -691.000061035156,
					["y_legacy"] = 386.999633789063,
					["w"] = 363.000396728516,
					["pos_table"] = true,
				},
			},
			["new_window_size"] = {
				["height"] = 130,
				["width"] = 320,
			},
			["clear_ungrouped"] = true,
			["report_schema"] = 1,
			["current_dps_meter"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["arena_enabled"] = true,
				["font_shadow"] = "NONE",
				["font_size"] = 18,
				["mythic_dungeon_enabled"] = true,
				["sample_size"] = 5,
				["font_face"] = "Friz Quadrata TT",
				["frame"] = {
					["show_title"] = false,
					["strata"] = "LOW",
					["backdrop_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0.2, -- [4]
					},
					["locked"] = false,
					["height"] = 65,
					["width"] = 220,
				},
				["update_interval"] = 0.1,
				["options_frame"] = {
				},
			},
			["instances_no_libwindow"] = false,
			["disable_reset_button"] = true,
			["data_broker_text"] = "",
			["segments_amount"] = 18,
			["streamer_config"] = {
				["faster_updates"] = false,
				["quick_detection"] = false,
				["reset_spec_cache"] = false,
				["no_alerts"] = false,
				["use_animation_accel"] = true,
				["disable_mythic_dungeon"] = false,
			},
			["deadlog_limit"] = 16,
			["event_tracker"] = {
				["enabled"] = false,
				["font_color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["line_height"] = 16,
				["line_color"] = {
					0.1, -- [1]
					0.1, -- [2]
					0.1, -- [3]
					0.3, -- [4]
				},
				["font_shadow"] = "NONE",
				["font_size"] = 10,
				["font_face"] = "Friz Quadrata TT",
				["frame"] = {
					["show_title"] = true,
					["strata"] = "LOW",
					["backdrop_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0.2, -- [4]
					},
					["locked"] = false,
					["height"] = 300,
					["width"] = 250,
				},
				["line_texture"] = "Details Serenity",
				["options_frame"] = {
				},
			},
		},
		["Serenerivers-Korgath"] = {
			["capture_real"] = {
				["heal"] = true,
				["spellcast"] = true,
				["miscdata"] = true,
				["aura"] = true,
				["energy"] = true,
				["damage"] = true,
			},
			["row_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["player_details_window"] = {
				["scale"] = 1,
				["bar_texture"] = "Skyline",
				["skin"] = "ElvUI",
			},
			["numerical_system"] = 1,
			["use_row_animations"] = true,
			["report_heal_links"] = false,
			["windows_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["death_tooltip_width"] = 300,
			["report_to_who"] = "",
			["overall_flag"] = 13,
			["profile_save_pos"] = true,
			["tooltip"] = {
				["header_statusbar"] = {
					0.3, -- [1]
					0.3, -- [2]
					0.3, -- [3]
					0.8, -- [4]
					false, -- [5]
					false, -- [6]
					"WorldState Score", -- [7]
				},
				["fontcolor_right"] = {
					1, -- [1]
					0.7, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["tooltip_max_targets"] = 2,
				["icon_size"] = {
					["W"] = 13,
					["H"] = 13,
				},
				["tooltip_max_pets"] = 2,
				["anchor_relative"] = "top",
				["abbreviation"] = 2,
				["anchored_to"] = 1,
				["show_amount"] = false,
				["header_text_color"] = {
					1, -- [1]
					0.9176, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["fontsize"] = 10,
				["background"] = {
					0.196, -- [1]
					0.196, -- [2]
					0.196, -- [3]
					0.8697, -- [4]
				},
				["submenu_wallpaper"] = true,
				["fontsize_title"] = 10,
				["icon_border_texcoord"] = {
					["B"] = 0.921875,
					["L"] = 0.078125,
					["T"] = 0.078125,
					["R"] = 0.921875,
				},
				["commands"] = {
				},
				["tooltip_max_abilities"] = 5,
				["fontface"] = "Friz Quadrata TT",
				["border_color"] = {
					0, -- [1]
					0, -- [2]
					0, -- [3]
					1, -- [4]
				},
				["border_texture"] = "Details BarBorder 3",
				["anchor_offset"] = {
					0, -- [1]
					0, -- [2]
				},
				["maximize_method"] = 1,
				["fontshadow"] = false,
				["border_size"] = 14,
				["menus_bg_texture"] = "Interface\\SPELLBOOK\\Spellbook-Page-1",
				["anchor_screen_pos"] = {
					507.7, -- [1]
					-350.5, -- [2]
				},
				["anchor_point"] = "bottom",
				["menus_bg_coords"] = {
					0.309777336120606, -- [1]
					0.924000015258789, -- [2]
					0.213000011444092, -- [3]
					0.279000015258789, -- [4]
				},
				["fontcolor"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["menus_bg_color"] = {
					0.8, -- [1]
					0.8, -- [2]
					0.8, -- [3]
					0.2, -- [4]
				},
			},
			["ps_abbreviation"] = 3,
			["update_speed"] = 0.300000011920929,
			["track_item_level"] = true,
			["windows_fade_in"] = {
				"in", -- [1]
				0.2, -- [2]
			},
			["instances_menu_click_to_open"] = false,
			["overall_clear_newchallenge"] = true,
			["time_type"] = 2,
			["instances_disable_bar_highlight"] = false,
			["trash_concatenate"] = false,
			["disable_stretch_from_toolbar"] = false,
			["disable_lock_ungroup_buttons"] = false,
			["memory_ram"] = 64,
			["disable_window_groups"] = false,
			["instances_suppress_trash"] = 0,
			["font_faces"] = {
				["menus"] = "Friz Quadrata TT",
			},
			["segments_amount"] = 12,
			["report_lines"] = 5,
			["skin"] = "WoW Interface",
			["standard_skin"] = {
				["hide_in_combat_type"] = 1,
				["menu_icons_size"] = 0.899999976158142,
				["color"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["menu_anchor"] = {
					16, -- [1]
					2, -- [2]
					["side"] = 2,
				},
				["bg_r"] = 0.3294,
				["skin"] = "ElvUI Frame Style",
				["following"] = {
					["bar_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
					["enabled"] = false,
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
				},
				["color_buttons"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
					1, -- [4]
				},
				["switch_healer"] = false,
				["micro_displays_locked"] = true,
				["bg_b"] = 0.3294,
				["tooltip"] = {
					["n_abilities"] = 3,
					["n_enemies"] = 3,
				},
				["backdrop_texture"] = "Details Ground",
				["show_statusbar"] = false,
				["switch_all_roles_in_combat"] = false,
				["switch_tank_in_combat"] = false,
				["bg_alpha"] = 0.51,
				["attribute_text"] = {
					["enabled"] = true,
					["shadow"] = true,
					["side"] = 1,
					["text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						0.7, -- [4]
					},
					["custom_text"] = "{name}",
					["text_face"] = "FORCED SQUARE",
					["anchor"] = {
						-19, -- [1]
						5, -- [2]
					},
					["show_timer"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
					},
					["enable_custom_text"] = false,
					["text_size"] = 12,
				},
				["instance_button_anchor"] = {
					-27, -- [1]
					1, -- [2]
				},
				["menu_alpha"] = {
					["enabled"] = false,
					["onleave"] = 1,
					["ignorebars"] = false,
					["iconstoo"] = true,
					["onenter"] = 1,
				},
				["stretch_button_side"] = 1,
				["micro_displays_side"] = 2,
				["ignore_mass_showhide"] = false,
				["strata"] = "LOW",
				["desaturated_menu"] = false,
				["auto_hide_menu"] = {
					["left"] = false,
					["right"] = false,
				},
				["switch_tank"] = false,
				["hide_in_combat_alpha"] = 0,
				["plugins_grow_direction"] = 1,
				["menu_icons"] = {
					true, -- [1]
					true, -- [2]
					true, -- [3]
					true, -- [4]
					true, -- [5]
					false, -- [6]
					["space"] = -3,
					["shadow"] = false,
				},
				["switch_damager"] = false,
				["show_sidebars"] = true,
				["window_scale"] = 1,
				["bars_grow_direction"] = 1,
				["row_info"] = {
					["textR_outline"] = false,
					["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
					["textL_outline"] = false,
					["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
					["textR_show_data"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
					},
					["textL_enable_custom_text"] = false,
					["fixed_text_color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
					["space"] = {
						["right"] = -2,
						["left"] = 1,
						["between"] = 1,
					},
					["texture_background_class_color"] = false,
					["start_after_icon"] = false,
					["font_face_file"] = "Interface\\Addons\\Details\\fonts\\FORCED SQUARE.ttf",
					["textL_custom_text"] = "{data1}. {data3}{data2}",
					["font_size"] = 10,
					["height"] = 14,
					["texture_file"] = "Interface\\AddOns\\Details\\images\\bar_skyline",
					["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small_alpha",
					["textR_bracket"] = "(",
					["texture_custom"] = "",
					["fixed_texture_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
					},
					["textL_show_number"] = true,
					["use_spec_icons"] = true,
					["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
					["texture"] = "Skyline",
					["models"] = {
						["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
						["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
						["upper_alpha"] = 0.5,
						["lower_enabled"] = false,
						["lower_alpha"] = 0.1,
						["upper_enabled"] = false,
					},
					["texture_custom_file"] = "Interface\\",
					["percent_type"] = 1,
					["fixed_texture_background_color"] = {
						0, -- [1]
						0, -- [2]
						0, -- [3]
						0.339636147022247, -- [4]
					},
					["textR_class_colors"] = false,
					["textL_class_colors"] = false,
					["alpha"] = 0.8,
					["no_icon"] = false,
					["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar_background",
					["texture_background"] = "DGround",
					["font_face"] = "FORCED SQUARE",
					["texture_class_colors"] = true,
					["textR_enable_custom_text"] = false,
					["fast_ps_update"] = false,
					["textR_separator"] = ",",
					["backdrop"] = {
						["enabled"] = false,
						["texture"] = "Details BarBorder 2",
						["color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							1, -- [4]
						},
						["size"] = 4,
					},
				},
				["hide_icon"] = true,
				["switch_damager_in_combat"] = false,
				["grab_on_top"] = false,
				["row_show_animation"] = {
					["anim"] = "Fade",
					["options"] = {
					},
				},
				["bars_sort_direction"] = 1,
				["auto_current"] = true,
				["toolbar_side"] = 1,
				["bg_g"] = 0.3294,
				["menu_anchor_down"] = {
					16, -- [1]
					-2, -- [2]
				},
				["hide_in_combat"] = false,
				["statusbar_info"] = {
					["alpha"] = 1,
					["overlay"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
				},
				["libwindow"] = {
				},
				["switch_all_roles_after_wipe"] = false,
				["wallpaper"] = {
					["overlay"] = {
						0.999997794628143, -- [1]
						0.999997794628143, -- [2]
						0.999997794628143, -- [3]
						0.799998223781586, -- [4]
					},
					["width"] = 266.000061035156,
					["texcoord"] = {
						0.0480000019073486, -- [1]
						0.298000011444092, -- [2]
						0.630999984741211, -- [3]
						0.755999984741211, -- [4]
					},
					["enabled"] = true,
					["anchor"] = "all",
					["height"] = 225.999984741211,
					["alpha"] = 0.800000071525574,
					["texture"] = "Interface\\AddOns\\Details\\images\\skins\\elvui",
				},
				["total_bar"] = {
					["enabled"] = false,
					["only_in_group"] = true,
					["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
					["color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
					},
				},
				["switch_healer_in_combat"] = false,
				["hide_out_of_combat"] = false,
				["skin_custom"] = "",
				["bars_inverted"] = false,
			},
			["default_bg_alpha"] = 0.5,
			["use_battleground_server_parser"] = true,
			["memory_threshold"] = 3,
			["minimum_combat_time"] = 5,
			["animate_scroll"] = false,
			["cloud_capture"] = true,
			["damage_taken_everything"] = false,
			["scroll_speed"] = 2,
			["new_window_size"] = {
				["height"] = 130,
				["width"] = 320,
			},
			["chat_tab_embed"] = {
				["enabled"] = false,
				["tab_name"] = "",
				["single_window"] = false,
			},
			["deadlog_events"] = 32,
			["overall_clear_newboss"] = true,
			["close_shields"] = false,
			["class_coords"] = {
				["HUNTER"] = {
					0, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["WARRIOR"] = {
					0, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["ROGUE"] = {
					0.49609375, -- [1]
					0.7421875, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["MAGE"] = {
					0.25, -- [1]
					0.49609375, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["PET"] = {
					0.25, -- [1]
					0.49609375, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["DRUID"] = {
					0.7421875, -- [1]
					0.98828125, -- [2]
					0, -- [3]
					0.25, -- [4]
				},
				["MONK"] = {
					0.5, -- [1]
					0.73828125, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["DEATHKNIGHT"] = {
					0.25, -- [1]
					0.5, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["UNKNOW"] = {
					0.5, -- [1]
					0.75, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["PRIEST"] = {
					0.49609375, -- [1]
					0.7421875, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["MONSTER"] = {
					0, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["Alliance"] = {
					0.49609375, -- [1]
					0.7421875, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["WARLOCK"] = {
					0.7421875, -- [1]
					0.98828125, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["SHAMAN"] = {
					0.25, -- [1]
					0.49609375, -- [2]
					0.25, -- [3]
					0.5, -- [4]
				},
				["Horde"] = {
					0.7421875, -- [1]
					0.98828125, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["PALADIN"] = {
					0, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.75, -- [4]
				},
				["ENEMY"] = {
					0, -- [1]
					0.25, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
				["UNGROUPPLAYER"] = {
					0.5, -- [1]
					0.75, -- [2]
					0.75, -- [3]
					1, -- [4]
				},
			},
			["class_specs_coords"] = {
				[62] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[63] = {
					0.375, -- [1]
					0.5, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[250] = {
					0, -- [1]
					0.125, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[251] = {
					0.125, -- [1]
					0.25, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[252] = {
					0.25, -- [1]
					0.375, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[253] = {
					0.875, -- [1]
					1, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[254] = {
					0, -- [1]
					0.125, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[255] = {
					0.125, -- [1]
					0.25, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[66] = {
					0.125, -- [1]
					0.25, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[257] = {
					0.5, -- [1]
					0.625, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[258] = {
					0.6328125, -- [1]
					0.75, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[259] = {
					0.75, -- [1]
					0.875, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[260] = {
					0.875, -- [1]
					1, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[261] = {
					0, -- [1]
					0.125, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[262] = {
					0.125, -- [1]
					0.25, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[263] = {
					0.25, -- [1]
					0.375, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[264] = {
					0.375, -- [1]
					0.5, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[265] = {
					0.5, -- [1]
					0.625, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[266] = {
					0.625, -- [1]
					0.75, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[267] = {
					0.75, -- [1]
					0.875, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[268] = {
					0.625, -- [1]
					0.75, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[269] = {
					0.875, -- [1]
					1, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[270] = {
					0.75, -- [1]
					0.875, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
				[70] = {
					0.251953125, -- [1]
					0.375, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[102] = {
					0.375, -- [1]
					0.5, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[71] = {
					0.875, -- [1]
					1, -- [2]
					0.375, -- [3]
					0.5, -- [4]
				},
				[103] = {
					0.5, -- [1]
					0.625, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[72] = {
					0, -- [1]
					0.125, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[104] = {
					0.625, -- [1]
					0.75, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[73] = {
					0.125, -- [1]
					0.25, -- [2]
					0.5, -- [3]
					0.625, -- [4]
				},
				[105] = {
					0.75, -- [1]
					0.875, -- [2]
					0, -- [3]
					0.125, -- [4]
				},
				[256] = {
					0.375, -- [1]
					0.5, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[65] = {
					0, -- [1]
					0.125, -- [2]
					0.25, -- [3]
					0.375, -- [4]
				},
				[64] = {
					0.5, -- [1]
					0.625, -- [2]
					0.125, -- [3]
					0.25, -- [4]
				},
			},
			["disable_alldisplays_window"] = false,
			["overall_clear_logout"] = false,
			["force_activity_time_pvp"] = true,
			["pvp_as_group"] = true,
			["class_icons_small"] = "Interface\\AddOns\\Details\\images\\classes_small",
			["clear_graphic"] = true,
			["hotcorner_topleft"] = {
				["hide"] = false,
			},
			["segments_auto_erase"] = 1,
			["options_group_edit"] = true,
			["segments_amount_to_save"] = 5,
			["minimap"] = {
				["onclick_what_todo"] = 1,
				["radius"] = 160,
				["text_type"] = 1,
				["minimapPos"] = 220,
				["text_format"] = 3,
				["hide"] = false,
			},
			["instances_amount"] = 5,
			["max_window_size"] = {
				["height"] = 450,
				["width"] = 480,
			},
			["trash_auto_remove"] = true,
			["only_pvp_frags"] = false,
			["disable_stretch_button"] = false,
			["time_type_original"] = 2,
			["default_bg_color"] = 0.0941,
			["numerical_system_symbols"] = "auto",
			["segments_panic_mode"] = false,
			["window_clamp"] = {
				-8, -- [1]
				0, -- [2]
				21, -- [3]
				-14, -- [4]
			},
			["remove_realm_from_name"] = true,
			["row_fade_out"] = {
				"out", -- [1]
				0.2, -- [2]
			},
			["use_scroll"] = false,
			["class_colors"] = {
				["HUNTER"] = {
					0.67, -- [1]
					0.83, -- [2]
					0.45, -- [3]
				},
				["WARRIOR"] = {
					0.78, -- [1]
					0.61, -- [2]
					0.43, -- [3]
				},
				["PALADIN"] = {
					0.96, -- [1]
					0.55, -- [2]
					0.73, -- [3]
				},
				["MAGE"] = {
					0.41, -- [1]
					0.8, -- [2]
					0.94, -- [3]
				},
				["ARENA_YELLOW"] = {
					0.9, -- [1]
					0.9, -- [2]
					0, -- [3]
				},
				["UNGROUPPLAYER"] = {
					0.4, -- [1]
					0.4, -- [2]
					0.4, -- [3]
				},
				["DRUID"] = {
					1, -- [1]
					0.49, -- [2]
					0.04, -- [3]
				},
				["MONK"] = {
					0, -- [1]
					1, -- [2]
					0.59, -- [3]
				},
				["DEATHKNIGHT"] = {
					0.77, -- [1]
					0.12, -- [2]
					0.23, -- [3]
				},
				["UNKNOW"] = {
					0.2, -- [1]
					0.2, -- [2]
					0.2, -- [3]
				},
				["PRIEST"] = {
					1, -- [1]
					1, -- [2]
					1, -- [3]
				},
				["ARENA_GREEN"] = {
					0.1, -- [1]
					0.85, -- [2]
					0.1, -- [3]
				},
				["ENEMY"] = {
					0.94117, -- [1]
					0, -- [2]
					0.0196, -- [3]
					1, -- [4]
				},
				["WARLOCK"] = {
					0.58, -- [1]
					0.51, -- [2]
					0.79, -- [3]
				},
				["SHAMAN"] = {
					0, -- [1]
					0.44, -- [2]
					0.87, -- [3]
				},
				["version"] = 1,
				["NEUTRAL"] = {
					1, -- [1]
					1, -- [2]
					0, -- [3]
				},
				["PET"] = {
					0.3, -- [1]
					0.4, -- [2]
					0.5, -- [3]
				},
				["ROGUE"] = {
					1, -- [1]
					0.96, -- [2]
					0.41, -- [3]
				},
			},
			["total_abbreviation"] = 2,
			["report_schema"] = 1,
			["clear_ungrouped"] = true,
			["font_sizes"] = {
				["menus"] = 10,
			},
			["disable_reset_button"] = false,
			["data_broker_text"] = "",
			["instances_no_libwindow"] = false,
			["instances_segments_locked"] = false,
			["deadlog_limit"] = 16,
			["instances"] = {
				{
					["__pos"] = {
						["normal"] = {
							["y"] = -166.400085449219,
							["x"] = 637.97021484375,
							["w"] = 381.629730224609,
							["h"] = 153.703735351563,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["hide_in_combat_type"] = 1,
					["menu_icons_size"] = 0.899999976158142,
					["color"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["menu_anchor"] = {
						16, -- [1]
						2, -- [2]
						["side"] = 2,
					},
					["bg_b"] = 0.3294,
					["bars_sort_direction"] = 1,
					["bg_r"] = 0.3294,
					["micro_displays_locked"] = true,
					["statusbar_info"] = {
						["alpha"] = 1,
						["overlay"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["hide_out_of_combat"] = false,
					["total_bar"] = {
						["enabled"] = false,
						["only_in_group"] = true,
						["icon"] = "Interface\\ICONS\\INV_Sigil_Thorim",
						["color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["following"] = {
						["enabled"] = false,
						["bar_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
					},
					["color_buttons"] = {
						1, -- [1]
						1, -- [2]
						1, -- [3]
						1, -- [4]
					},
					["switch_healer"] = false,
					["skin_custom"] = "",
					["__was_opened"] = true,
					["attribute_text"] = {
						["show_timer"] = {
							true, -- [1]
							true, -- [2]
							true, -- [3]
						},
						["shadow"] = true,
						["side"] = 1,
						["text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
							0.7, -- [4]
						},
						["custom_text"] = "{name}",
						["text_face"] = "FORCED SQUARE",
						["anchor"] = {
							-19, -- [1]
							5, -- [2]
						},
						["text_size"] = 12,
						["enable_custom_text"] = false,
						["enabled"] = true,
					},
					["libwindow"] = {
						["y"] = -166.400100708008,
						["x"] = -81.437255859375,
						["point"] = "RIGHT",
					},
					["auto_hide_menu"] = {
						["left"] = false,
						["right"] = false,
					},
					["tooltip"] = {
						["n_abilities"] = 3,
						["n_enemies"] = 3,
					},
					["StatusBarSaved"] = {
						["center"] = "DETAILS_STATUSBAR_PLUGIN_CLOCK",
						["right"] = "DETAILS_STATUSBAR_PLUGIN_PDPS",
						["options"] = {
							["DETAILS_STATUSBAR_PLUGIN_THREAT"] = {
								["isHidden"] = false,
								["textStyle"] = 2,
								["textYMod"] = 1,
								["segmentType"] = 2,
								["textFace"] = "FORCED SQUARE",
								["textXMod"] = 0,
								["textAlign"] = 0,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									0.7, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_PDPS"] = {
								["textYMod"] = 1,
								["textXMod"] = 0,
								["textFace"] = "FORCED SQUARE",
								["textAlign"] = 0,
								["textStyle"] = 2,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									0.7, -- [4]
								},
							},
							["DETAILS_STATUSBAR_PLUGIN_CLOCK"] = {
								["textYMod"] = 1,
								["textAlign"] = 0,
								["textXMod"] = 6,
								["textStyle"] = 2,
								["textFace"] = "FORCED SQUARE",
								["timeType"] = 1,
								["textSize"] = 10,
								["textColor"] = {
									1, -- [1]
									1, -- [2]
									1, -- [3]
									0.7, -- [4]
								},
							},
						},
						["left"] = "DETAILS_STATUSBAR_PLUGIN_THREAT",
					},
					["row_show_animation"] = {
						["anim"] = "Fade",
						["options"] = {
						},
					},
					["switch_all_roles_in_combat"] = false,
					["instance_button_anchor"] = {
						-27, -- [1]
						1, -- [2]
					},
					["version"] = 3,
					["row_info"] = {
						["textR_outline"] = false,
						["spec_file"] = "Interface\\AddOns\\Details\\images\\spec_icons_normal",
						["textL_outline"] = false,
						["texture_highlight"] = "Interface\\FriendsFrame\\UI-FriendsList-Highlight",
						["textR_show_data"] = {
							true, -- [1]
							true, -- [2]
							true, -- [3]
						},
						["percent_type"] = 1,
						["fixed_text_color"] = {
							1, -- [1]
							1, -- [2]
							1, -- [3]
						},
						["space"] = {
							["right"] = -2,
							["left"] = 1,
							["between"] = 1,
						},
						["texture_background_class_color"] = false,
						["start_after_icon"] = false,
						["font_face_file"] = "Interface\\Addons\\Details\\fonts\\FORCED SQUARE.ttf",
						["textL_custom_text"] = "{data1}. {data3}{data2}",
						["font_size"] = 10,
						["height"] = 14,
						["texture_file"] = "Interface\\AddOns\\Details\\images\\bar_skyline",
						["icon_file"] = "Interface\\AddOns\\Details\\images\\classes_small_alpha",
						["textR_bracket"] = "(",
						["textR_enable_custom_text"] = false,
						["fixed_texture_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
						},
						["textL_show_number"] = true,
						["backdrop"] = {
							["enabled"] = false,
							["size"] = 4,
							["color"] = {
								0, -- [1]
								0, -- [2]
								0, -- [3]
								1, -- [4]
							},
							["texture"] = "Details BarBorder 2",
						},
						["textR_custom_text"] = "{data1} ({data2}, {data3}%)",
						["fixed_texture_background_color"] = {
							0, -- [1]
							0, -- [2]
							0, -- [3]
							0.339636147022247, -- [4]
						},
						["texture_custom_file"] = "Interface\\",
						["texture"] = "Skyline",
						["texture_custom"] = "",
						["models"] = {
							["upper_model"] = "Spells\\AcidBreath_SuperGreen.M2",
							["lower_model"] = "World\\EXPANSION02\\DOODADS\\Coldarra\\COLDARRALOCUS.m2",
							["upper_alpha"] = 0.5,
							["lower_enabled"] = false,
							["lower_alpha"] = 0.1,
							["upper_enabled"] = false,
						},
						["textL_class_colors"] = false,
						["textR_class_colors"] = false,
						["alpha"] = 0.8,
						["no_icon"] = false,
						["texture_background"] = "DGround",
						["texture_background_file"] = "Interface\\AddOns\\Details\\images\\bar_background",
						["font_face"] = "FORCED SQUARE",
						["texture_class_colors"] = true,
						["textL_enable_custom_text"] = false,
						["fast_ps_update"] = false,
						["textR_separator"] = ",",
						["use_spec_icons"] = true,
					},
					["__locked"] = true,
					["__snapH"] = false,
					["ignore_mass_showhide"] = false,
					["switch_damager"] = false,
					["micro_displays_side"] = 2,
					["strata"] = "LOW",
					["bars_grow_direction"] = 1,
					["__snap"] = {
					},
					["switch_tank"] = false,
					["hide_in_combat_alpha"] = 0,
					["plugins_grow_direction"] = 1,
					["menu_icons"] = {
						true, -- [1]
						true, -- [2]
						true, -- [3]
						true, -- [4]
						true, -- [5]
						false, -- [6]
						["space"] = -3,
						["shadow"] = false,
					},
					["desaturated_menu"] = false,
					["show_sidebars"] = true,
					["window_scale"] = 1,
					["__snapV"] = false,
					["grab_on_top"] = false,
					["hide_icon"] = true,
					["switch_healer_in_combat"] = false,
					["switch_damager_in_combat"] = false,
					["bg_alpha"] = 0.51,
					["menu_anchor_down"] = {
						16, -- [1]
						-2, -- [2]
					},
					["auto_current"] = true,
					["toolbar_side"] = 1,
					["bg_g"] = 0.3294,
					["switch_all_roles_after_wipe"] = false,
					["hide_in_combat"] = false,
					["posicao"] = {
						["normal"] = {
							["y"] = -166.400085449219,
							["x"] = 637.97021484375,
							["w"] = 381.629730224609,
							["h"] = 153.703735351563,
						},
						["solo"] = {
							["y"] = 2,
							["x"] = 1,
							["w"] = 300,
							["h"] = 200,
						},
					},
					["menu_alpha"] = {
						["enabled"] = false,
						["onenter"] = 1,
						["iconstoo"] = true,
						["ignorebars"] = false,
						["onleave"] = 1,
					},
					["switch_tank_in_combat"] = false,
					["wallpaper"] = {
						["enabled"] = true,
						["texture"] = "Interface\\AddOns\\Details\\images\\skins\\elvui",
						["texcoord"] = {
							0.0480000019073486, -- [1]
							0.298000011444092, -- [2]
							0.630999984741211, -- [3]
							0.755999984741211, -- [4]
						},
						["overlay"] = {
							0.999997794628143, -- [1]
							0.999997794628143, -- [2]
							0.999997794628143, -- [3]
							0.799998223781586, -- [4]
						},
						["anchor"] = "all",
						["height"] = 225.999984741211,
						["alpha"] = 0.800000071525574,
						["width"] = 266.000061035156,
					},
					["stretch_button_side"] = 1,
					["skin"] = "ElvUI Frame Style",
					["backdrop_texture"] = "Details Ground",
					["show_statusbar"] = false,
					["bars_inverted"] = false,
				}, -- [1]
			},
		},
	},
	["global_plugin_database"] = {
		["DETAILS_PLUGIN_ENCOUNTER_DETAILS"] = {
			["encounter_timers_bw"] = {
				["186783"] = {
					"Xhul'horac", -- [1]
					"186783", -- [2]
					"Withering Gaze", -- [3]
					6, -- [4]
					"Interface\\Icons\\Spell_Shadow_DeathsEmbrace", -- [5]
					["id"] = 1800,
				},
				["180608"] = {
					"Tyrant Velhari", -- [1]
					"180608", -- [2]
					"Gavel of the Tyrant", -- [3]
					40, -- [4]
					"Interface\\Icons\\Spell_Fire_FlameTounge", -- [5]
					["id"] = 1784,
				},
				["163753"] = {
					"Operator Thogar", -- [1]
					"163753", -- [2]
					"Iron Bellow", -- [3]
					12, -- [4]
					"Interface\\Icons\\Ability_Warrior_Rampage", -- [5]
					["id"] = 1692,
				},
				["initiate"] = {
					"Alysrazor", -- [1]
					"initiate", -- [2]
					"Both Initiates", -- [3]
					27, -- [4]
					236449, -- [5]
					["id"] = 1206,
				},
				["62488"] = {
					"Ignis the Furnace Master", -- [1]
					"62488", -- [2]
					"Next Add", -- [3]
					10, -- [4]
					"Interface\\Icons\\INV_Misc_Statue_07", -- [5]
					["id"] = 1136,
				},
				["181956"] = {
					"Shadow-Lord Iskar", -- [1]
					"181956", -- [2]
					"Phantasmal Winds", -- [3]
					17, -- [4]
					"Interface\\Icons\\Spell_Frost_ArcticWinds", -- [5]
					["id"] = 1788,
				},
				["197478"] = {
					"Illysanna Ravencrest", -- [1]
					"197478", -- [2]
					"Dark Rush", -- [3]
					14.8, -- [4]
					1247261, -- [5]
					["id"] = 1833,
				},
				["bolt"] = {
					"Yor'sahj the Unsleeping", -- [1]
					"bolt", -- [2]
					"1x Bolt on Serenerivers", -- [3]
					12, -- [4]
					"Interface\\Icons\\Spell_Shadow_DemonicEmpathy", -- [5]
					["id"] = 1295,
				},
				["crystal"] = {
					"Ultraxion", -- [1]
					"crystal", -- [2]
					"Red Crystal", -- [3]
					80, -- [4]
					"Interface\\Icons\\inv_misc_head_dragon_01", -- [5]
					["id"] = 1297,
				},
				["181753"] = {
					"Shadow-Lord Iskar", -- [1]
					"181753", -- [2]
					"Fel Bomb", -- [3]
					15.5, -- [4]
					"Interface\\Icons\\ability_felarakkoa_feldetonation_green", -- [5]
					["id"] = 1788,
				},
				["64597"] = {
					"Algalon the Observer", -- [1]
					"64597", -- [2]
					"Cosmic Smash", -- [3]
					41, -- [4]
					135789, -- [5]
					["id"] = 1130,
				},
				["118077"] = {
					"Protectors of the Endless", -- [1]
					"118077", -- [2]
					"Lightning Storm", -- [3]
					26, -- [4]
					237589, -- [5]
					["id"] = 1409,
				},
				["179977"] = {
					"Gorefiend", -- [1]
					"179977", -- [2]
					"Touch of Doom", -- [3]
					8.3, -- [4]
					"Interface\\Icons\\ability_bossgorefiend_touchofdoom", -- [5]
					["id"] = 1783,
				},
				["161801"] = {
					"Skylord Tovra", -- [1]
					"161801", -- [2]
					"Thunderous Breath", -- [3]
					17.3, -- [4]
					136099, -- [5]
					["id"] = 1736,
				},
				["213083"] = {
					"Spellblade Aluriel", -- [1]
					"213083", -- [2]
					"Frozen Tempest", -- [3]
					74, -- [4]
					629077, -- [5]
					["id"] = 1871,
				},
				["115297"] = {
					"Thalnos the Soulrender", -- [1]
					"115297", -- [2]
					"Evict Soul", -- [3]
					25, -- [4]
					463284, -- [5]
					["id"] = 1423,
				},
				["228837"] = {
					"Nightbane", -- [1]
					"228837", -- [2]
					"Bellowing Roar", -- [3]
					15.5, -- [4]
					136129, -- [5]
					["id"] = 2031,
				},
				["86307"] = {
					"Conclave of Wind", -- [1]
					"86307", -- [2]
					"Rohash is Gathering Strength", -- [3]
					60, -- [4]
					"Interface\\Icons\\Spell_Arcane_MassDispel", -- [5]
					["id"] = 1035,
				},
				["208807"] = {
					"Grand Magistrix Elisande", -- [1]
					"208807", -- [2]
					"Arcanetic Ring", -- [3]
					36.3, -- [4]
					1033906, -- [5]
					["id"] = 1872,
				},
				["204463"] = {
					"Nythendra", -- [1]
					"204463", -- [2]
					"Volatile Rot", -- [3]
					22.8, -- [4]
					236271, -- [5]
					["id"] = 1853,
				},
				["fists"] = {
					"Brother Korloff", -- [1]
					"fists", -- [2]
					"Blazing Fists", -- [3]
					20, -- [4]
					574572, -- [5]
					["id"] = 1424,
				},
				["209011"] = {
					"Gul'dan", -- [1]
					"209011", -- [2]
					"Bonds of Fel", -- [3]
					50, -- [4]
					1117883, -- [5]
					["id"] = 1866,
				},
				["193597"] = {
					"Lady Hatecoil", -- [1]
					"193597", -- [2]
					"Static Nova", -- [3]
					10, -- [4]
					237587, -- [5]
					["id"] = 1811,
				},
				["103851"] = {
					"Morchok", -- [1]
					"103851", -- [2]
					"Black Blood", -- [3]
					56, -- [4]
					"Interface\\Icons\\achievement_dungeon_the stonecore_ozruk", -- [5]
					["id"] = 1292,
				},
				["182428"] = {
					"Kilrogg Deadeye", -- [1]
					"182428", -- [2]
					"Vision of Death (1)", -- [3]
					60, -- [4]
					"Interface\\Icons\\ability_warlock_fireandbrimstonegreen", -- [5]
					["id"] = 1786,
				},
				["219235"] = {
					"High Botanist Tel'arn", -- [1]
					"219235", -- [2]
					"Toxic Spores on YOU!", -- [3]
					30, -- [4]
					134220, -- [5]
					["id"] = 1886,
				},
				["135991"] = {
					"Lei Shen", -- [1]
					"135991", -- [2]
					"Diffusion Chain", -- [3]
					7, -- [4]
					"Interface\\Icons\\Spell_Nature_LightningBolt", -- [5]
					["id"] = 1579,
				},
				["ball"] = {
					"Warlord Zon'ozz", -- [1]
					"ball", -- [2]
					"Void ball", -- [3]
					6, -- [4]
					"Interface\\Icons\\INV_Enchant_VoidSphere", -- [5]
					["id"] = 1294,
				},
				["225412"] = {
					"Nighthold Trash", -- [1]
					"225412", -- [2]
					"Mass Siphon", -- [3]
					15, -- [4]
					429383, -- [5]
					["id"] = 1871,
				},
				["200898"] = {
					"Inquisitor Tormentorum", -- [1]
					"200898", -- [2]
					"Teleport", -- [3]
					69, -- [4]
					136222, -- [5]
					["id"] = 1850,
				},
				["193826"] = {
					"God-King Skovald", -- [1]
					"193826", -- [2]
					"Ragnarok", -- [3]
					11, -- [4]
					135799, -- [5]
					["id"] = 1808,
				},
				["182323"] = {
					"Shadow-Lord Iskar", -- [1]
					"182323", -- [2]
					"Phantasmal Wounds", -- [3]
					34, -- [4]
					"Interface\\Icons\\Spell_Shadow_DevouringPlague", -- [5]
					["id"] = 1788,
				},
				["138297"] = {
					"Ra-den", -- [1]
					"138297", -- [2]
					"Unstable Vita: Stynkfyst", -- [3]
					5, -- [4]
					136049, -- [5]
					["id"] = 1580,
				},
				["206677"] = {
					"Krosus", -- [1]
					"206677", -- [2]
					"Searing Brand", -- [3]
					15, -- [4]
					135794, -- [5]
					["id"] = 1842,
				},
				["212492"] = {
					"Spellblade Aluriel", -- [1]
					"212492", -- [2]
					"Annihilate", -- [3]
					8, -- [4]
					135642, -- [5]
					["id"] = 1871,
				},
				["158605"] = {
					"Imperator Mar'gok", -- [1]
					"158605", -- [2]
					"Mark of Chaos", -- [3]
					34, -- [4]
					"Interface\\Icons\\Spell_Arcane_MassDispel", -- [5]
					["id"] = 1705,
				},
				["operator"] = {
					"The Blast Furnace", -- [1]
					"operator", -- [2]
					"Bellows Operator", -- [3]
					65.5, -- [4]
					"Interface\\Icons\\INV_Gizmo_FuelCell", -- [5]
					["id"] = 1690,
				},
				["235907"] = {
					"The Desolate Host", -- [1]
					"235907", -- [2]
					"Collapsing Fissure", -- [3]
					7.3, -- [4]
					136160, -- [5]
					["id"] = 2054,
				},
				["156467"] = {
					"Imperator Mar'gok", -- [1]
					"156467", -- [2]
					"Destructive Resonance", -- [3]
					15, -- [4]
					"Interface\\Icons\\ability_socererking_arcanemines", -- [5]
					["id"] = 1705,
				},
				["pursue"] = {
					"Flame Leviathan", -- [1]
					"pursue", -- [2]
					"Leviathan pursues Wildrivers!", -- [3]
					30, -- [4]
					"Interface\\Icons\\Ability_Rogue_FindWeakness", -- [5]
					["id"] = 1132,
				},
				["120455"] = {
					"Sha of Fear", -- [1]
					"120455", -- [2]
					"Submerge (1)", -- [3]
					-20.32, -- [4]
					538567, -- [5]
					["id"] = 1431,
				},
				["bwcbSereneriversbreak you fucks"] = {
					"Bars", -- [1]
					"bwcbSereneriversbreak you fucks", -- [2]
					"Serenerivers: break you fucks", -- [3]
					600, -- [4]
					"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
					["id"] = 1783,
				},
				["204471"] = {
					"Skorpyron", -- [1]
					"204471", -- [2]
					"Focused Blast", -- [3]
					15, -- [4]
					135739, -- [5]
					["id"] = 1849,
				},
				["200359"] = {
					"Shade of Xavius", -- [1]
					"200359", -- [2]
					"Induced Paranoia", -- [3]
					23, -- [4]
					460691, -- [5]
					["id"] = 1839,
				},
				["200904"] = {
					"Inquisitor Tormentorum", -- [1]
					"200904", -- [2]
					"Sap Soul", -- [3]
					15.8, -- [4]
					460857, -- [5]
					["id"] = 1850,
				},
				["eggs"] = {
					"Alysrazor", -- [1]
					"eggs", -- [2]
					"Hatch Eggs", -- [3]
					42, -- [4]
					"Interface\\Icons\\inv_trinket_firelands_02", -- [5]
					["id"] = 1206,
				},
				["181099"] = {
					"Mannoroth", -- [1]
					"181099", -- [2]
					"Mark of Doom", -- [3]
					12, -- [4]
					"Interface\\Icons\\Spell_Shadow_AuraOfDarkness", -- [5]
					["id"] = 1795,
				},
				["204859"] = {
					"Ursoc", -- [1]
					"204859", -- [2]
					"Rend Flesh (1)", -- [3]
					15, -- [4]
					1033474, -- [5]
					["id"] = 1841,
				},
				["-9921"] = {
					"Imperator Mar'gok", -- [1]
					"-9921", -- [2]
					"Gorian Reaver", -- [3]
					15, -- [4]
					"Interface\\Icons\\ability_warrior_shieldbreak", -- [5]
					["id"] = 1705,
				},
				["55098"] = {
					"Moorabi", -- [1]
					"55098", -- [2]
					"Transformation", -- [3]
					4, -- [4]
					132254, -- [5]
					["id"] = 1980,
				},
				["207806"] = {
					"Patrol Captain Gerdo", -- [1]
					"207806", -- [2]
					"Signal Beacon", -- [3]
					14, -- [4]
					135433, -- [5]
					["id"] = 1868,
				},
				["183817"] = {
					"Archimonde", -- [1]
					"183817", -- [2]
					"Shadowfel Burst", -- [3]
					43, -- [4]
					"Interface\\Icons\\Ability_Warlock_EverlastingAffliction", -- [5]
					["id"] = 1799,
				},
				["-7078"] = {
					"Horridon", -- [1]
					"-7078", -- [2]
					"Triple Puncture", -- [3]
					10, -- [4]
					"Interface\\ICONS\\Ability_Warrior_ShieldBreak.blp", -- [5]
					["id"] = 1575,
				},
				["236072"] = {
					"The Desolate Host", -- [1]
					"236072", -- [2]
					"Wailing Souls", -- [3]
					60, -- [4]
					136194, -- [5]
					["id"] = 2054,
				},
				["202217"] = {
					"Anub'esset", -- [1]
					"202217", -- [2]
					"Mandible Strike", -- [3]
					9, -- [4]
					132122, -- [5]
					["id"] = 1852,
				},
				["235924"] = {
					"The Desolate Host", -- [1]
					"235924", -- [2]
					"Spear of Anguish", -- [3]
					6, -- [4]
					135131, -- [5]
					["id"] = 2054,
				},
				["206515"] = {
					"Gul'dan", -- [1]
					"206515", -- [2]
					"Fel Efflux", -- [3]
					11, -- [4]
					841219, -- [5]
					["id"] = 1866,
				},
				["205549"] = {
					"Naraxas", -- [1]
					"205549", -- [2]
					"Rancid Maw", -- [3]
					7, -- [4]
					136007, -- [5]
					["id"] = 1792,
				},
				["blades"] = {
					"Armsmaster Harlan", -- [1]
					"blades", -- [2]
					"Blades of Light", -- [3]
					41, -- [4]
					132369, -- [5]
					["id"] = 1421,
				},
				["ship"] = {
					"The Iron Maidens", -- [1]
					"ship", -- [2]
					"Jump to Ship", -- [3]
					60, -- [4]
					"Interface\\Icons\\ability_vehicle_siegeenginecannon", -- [5]
					["id"] = 1695,
				},
				["44141"] = {
					"Priestess Delrissa", -- [1]
					"44141", -- [2]
					"Seed of Corruption: Wild Imp", -- [3]
					18, -- [4]
					136193, -- [5]
					["id"] = 1895,
				},
				["214348"] = {
					"Elerethe Renferal", -- [1]
					"214348", -- [2]
					"Vile Ambush", -- [3]
					8.2, -- [4]
					132089, -- [5]
					["id"] = 1876,
				},
				["225105"] = {
					"Nighthold Trash", -- [1]
					"225105", -- [2]
					"Arcanic Release: Taverley", -- [3]
					6, -- [4]
					1041232, -- [5]
					["id"] = 1886,
				},
				["207720"] = {
					"Star Augur Etraeus", -- [1]
					"207720", -- [2]
					"<Cast: Witness the Void>", -- [3]
					4, -- [4]
					895885, -- [5]
					["id"] = 1863,
				},
				["206744"] = {
					"Gul'dan", -- [1]
					"206744", -- [2]
					"Black Harvest", -- [3]
					66, -- [4]
					537517, -- [5]
					["id"] = 1866,
				},
				["191325"] = {
					"Dresaron", -- [1]
					"191325", -- [2]
					"Breath of Corruption", -- [3]
					14.5, -- [4]
					1357794, -- [5]
					["id"] = 1838,
				},
				["185282"] = {
					"Iron Reaver", -- [1]
					"185282", -- [2]
					"Barrage (1)", -- [3]
					13.3, -- [4]
					"Interface\\Icons\\Spell_Fire_FelRainOfFire", -- [5]
					["id"] = 1785,
				},
				["232249"] = {
					"Goroth", -- [1]
					"232249", -- [2]
					"Crashing Comet", -- [3]
					8.5, -- [4]
					135797, -- [5]
					["id"] = 2032,
				},
				["181275"] = {
					"Mannoroth", -- [1]
					"181275", -- [2]
					"Curse of the Legion: Medikat*", -- [3]
					20, -- [4]
					"Interface\\Icons\\spell_warlock_summonterrorguard", -- [5]
					["id"] = 1795,
				},
				["228918"] = {
					"Odyn-TrialOfValor", -- [1]
					"228918", -- [2]
					"Stormforged Spear", -- [3]
					9, -- [4]
					1508064, -- [5]
					["id"] = 1958,
				},
				["137175"] = {
					"Jin'rokh the Breaker", -- [1]
					"137175", -- [2]
					"Thundering Throw", -- [3]
					30, -- [4]
					"Interface\\Icons\\ability_warrior_throwdown", -- [5]
					["id"] = 1577,
				},
				["191284"] = {
					"Hymdall", -- [1]
					"191284", -- [2]
					"Horn of Valor", -- [3]
					8, -- [4]
					134229, -- [5]
					["id"] = 1805,
				},
				["71255"] = {
					"Professor Putricide", -- [1]
					"71255", -- [2]
					"More yellow gas bombs", -- [3]
					14, -- [4]
					136173, -- [5]
					["id"] = 1102,
				},
				["206365"] = {
					"Tichondrius", -- [1]
					"206365", -- [2]
					"Illusionary Night (1)", -- [3]
					130, -- [4]
					607852, -- [5]
					["id"] = 1862,
				},
				["206617"] = {
					"Chronomatic Anomaly", -- [1]
					"206617", -- [2]
					"Time Bomb on YOU!", -- [3]
					21, -- [4]
					609814, -- [5]
					["id"] = 1865,
				},
				["murloc"] = {
					"Morogrim Tidewalker", -- [1]
					"murloc", -- [2]
					"~Murlocs", -- [3]
					40, -- [4]
					134169, -- [5]
					["id"] = 627,
				},
				["196562"] = {
					"Ivanyr", -- [1]
					"196562", -- [2]
					"Volatile Magic", -- [3]
					10, -- [4]
					1041233, -- [5]
					["id"] = 1827,
				},
				["-7741"] = {
					"Jin'rokh the Breaker", -- [1]
					"-7741", -- [2]
					"Focused Lightning", -- [3]
					11, -- [4]
					"Interface\\ICONS\\Ability_Vehicle_ElectroCharge.blp", -- [5]
					["id"] = 1577,
				},
				["136294"] = {
					"Tortos", -- [1]
					"136294", -- [2]
					"Call of Tortos", -- [3]
					21, -- [4]
					"Interface\\Icons\\achievement_boss_tortos", -- [5]
					["id"] = 1565,
				},
				["182459"] = {
					"Tyrant Velhari", -- [1]
					"182459", -- [2]
					"Edict of Condemnation", -- [3]
					57, -- [4]
					"Interface\\Icons\\inv_hammer_1h_draeneipaladin_c_01", -- [5]
					["id"] = 1784,
				},
				["228029"] = {
					"Odyn-TrialOfValor", -- [1]
					"228029", -- [2]
					"Expel Light", -- [3]
					32, -- [4]
					237541, -- [5]
					["id"] = 1958,
				},
				["144758"] = {
					"Garrosh Hellscream", -- [1]
					"144758", -- [2]
					"Desecrate", -- [3]
					11, -- [4]
					425955, -- [5]
					["id"] = 1623,
				},
				["136442"] = {
					"Council of Elders", -- [1]
					"136442", -- [2]
					"Full power", -- [3]
					76, -- [4]
					"Interface\\Icons\\achievement_moguraid_03", -- [5]
					["id"] = 1570,
				},
				["meteor"] = {
					"Alysrazor", -- [1]
					"meteor", -- [2]
					"Meteor", -- [3]
					30, -- [4]
					136186, -- [5]
					["id"] = 1206,
				},
				["impale"] = {
					"Madness of Deathwing", -- [1]
					"impale", -- [2]
					"Impale", -- [3]
					22, -- [4]
					"Interface\\Icons\\Ability_SearingArrow", -- [5]
					["id"] = 1299,
				},
				["236442"] = {
					"Sisters of the Moon", -- [1]
					"236442", -- [2]
					"Twilight Volley", -- [3]
					16.6, -- [4]
					1391677, -- [5]
					["id"] = 2050,
				},
				["-8298"] = {
					"Garrosh Hellscream", -- [1]
					"-8298", -- [2]
					"Siege Engineer", -- [3]
					20, -- [4]
					236216, -- [5]
					["id"] = 1623,
				},
				["228877"] = {
					"Grand Magistrix Elisande", -- [1]
					"228877", -- [2]
					"Arcanetic Ring (1)", -- [3]
					35, -- [4]
					1033906, -- [5]
					["id"] = 1872,
				},
				["156704"] = {
					"Kromog", -- [1]
					"156704", -- [2]
					"Slam", -- [3]
					24, -- [4]
					"Interface\\Icons\\Spell_Nature_Earthquake", -- [5]
					["id"] = 1713,
				},
				["bwcbSereneriverszach's internet sucks"] = {
					"Bars", -- [1]
					"bwcbSereneriverszach's internet sucks", -- [2]
					"Serenerivers: zach's internet sucks", -- [3]
					300, -- [4]
					"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
					["id"] = 1876,
				},
				["-7054"] = {
					"Council of Elders", -- [1]
					"-7054", -- [2]
					"Frigid Assault", -- [3]
					30, -- [4]
					527836, -- [5]
					["id"] = 1570,
				},
				["144467"] = {
					"Iron Juggernaut", -- [1]
					"144467", -- [2]
					"Ignite Armor", -- [3]
					9, -- [4]
					532284, -- [5]
					["id"] = 1600,
				},
				["215128"] = {
					"Il'gynoth", -- [1]
					"215128", -- [2]
					"Cursed Blood on YOU!", -- [3]
					8, -- [4]
					237515, -- [5]
					["id"] = 1873,
				},
				["153954"] = {
					"High Sage Viryx", -- [1]
					"153954", -- [2]
					"Cast Down", -- [3]
					15, -- [4]
					1029578, -- [5]
					["id"] = 1701,
				},
				["213238"] = {
					"Tichondrius", -- [1]
					"213238", -- [2]
					"Seeker Swarm (1)", -- [3]
					27, -- [4]
					136128, -- [5]
					["id"] = 1862,
				},
				["204275"] = {
					"Skorpyron", -- [1]
					"204275", -- [2]
					"Arcanoslash", -- [3]
					6, -- [4]
					655172, -- [5]
					["id"] = 1849,
				},
				["135145"] = {
					"Iron Qon", -- [1]
					"135145", -- [2]
					"Freeze Incoming!", -- [3]
					6, -- [4]
					"Interface\\Icons\\Spell_Frost_ColdHearted", -- [5]
					["id"] = 1559,
				},
				["159724"] = {
					"The Iron Maidens", -- [1]
					"159724", -- [2]
					"Blood Ritual", -- [3]
					5, -- [4]
					"Interface\\Icons\\ability_ironmaidens_bloodritual", -- [5]
					["id"] = 1695,
				},
				["143958"] = {
					"The Fallen Protectors", -- [1]
					"143958", -- [2]
					"Corruption Shock", -- [3]
					5, -- [4]
					136050, -- [5]
					["id"] = 1598,
				},
				["146595"] = {
					"Sha of Pride", -- [1]
					"146595", -- [2]
					"Gift of the Titans", -- [3]
					7, -- [4]
					254117, -- [5]
					["id"] = 1604,
				},
				["203552"] = {
					"Nythendra", -- [1]
					"203552", -- [2]
					"Heart of the Swarm", -- [3]
					92, -- [4]
					136128, -- [5]
					["id"] = 1853,
				},
				["209244"] = {
					"Grand Magistrix Elisande", -- [1]
					"209244", -- [2]
					"Delphuric Beam on YOU!", -- [3]
					2.3080000000009, -- [4]
					135730, -- [5]
					["id"] = 1872,
				},
				["88481"] = {
					"Foe Reaper 5000", -- [1]
					"88481", -- [2]
					"Overdrive", -- [3]
					10, -- [4]
					132369, -- [5]
					["id"] = 1063,
				},
				["37018"] = {
					"Kael'thas Sunstrider", -- [1]
					"37018", -- [2]
					"Conflagration on YOU!", -- [3]
					10, -- [4]
					135818, -- [5]
					["id"] = 733,
				},
				["209170"] = {
					"Grand Magistrix Elisande", -- [1]
					"209170", -- [2]
					"Spanning Singularity (1)", -- [3]
					25, -- [4]
					135735, -- [5]
					["id"] = 1872,
				},
				["227883"] = {
					"Guarm-TrialOfValor", -- [1]
					"227883", -- [2]
					"Roaring Leap", -- [3]
					48, -- [4]
					236169, -- [5]
					["id"] = 1962,
				},
				["142986"] = {
					"Malkorok", -- [1]
					"142986", -- [2]
					"Implosion", -- [3]
					9, -- [4]
					136115, -- [5]
					["id"] = 1595,
				},
				["71340"] = {
					"Blood-Queen Lana'thel", -- [1]
					"71340", -- [2]
					"Next Pact", -- [3]
					16, -- [4]
					"Interface\\Icons\\Spell_Shadow_DestructiveSoul", -- [5]
					["id"] = 1103,
				},
				["144330"] = {
					"Kor'kron Dark Shaman", -- [1]
					"144330", -- [2]
					"Iron Prison", -- [3]
					60, -- [4]
					644388, -- [5]
					["id"] = 1606,
				},
				["198446"] = {
					"Smashspite", -- [1]
					"198446", -- [2]
					"Fel Vomit", -- [3]
					35, -- [4]
					1129418, -- [5]
					["id"] = 1834,
				},
				["218304"] = {
					"High Botanist Tel'arn", -- [1]
					"218304", -- [2]
					"Parasitic Fetter", -- [3]
					21.5, -- [4]
					538515, -- [5]
					["id"] = 1886,
				},
				["143766"] = {
					"Thok the Bloodthirsty", -- [1]
					"143766", -- [2]
					"Fearsome Roar", -- [3]
					12, -- [4]
					237567, -- [5]
					["id"] = 1599,
				},
				["198495"] = {
					"Helya", -- [1]
					"198495", -- [2]
					"Torrent", -- [3]
					11, -- [4]
					135861, -- [5]
					["id"] = 1824,
				},
				["fear"] = {
					"Nighthold Trash", -- [1]
					"fear", -- [2]
					"Fear: Khilikili*", -- [3]
					10, -- [4]
					1386549, -- [5]
					["id"] = 1862,
				},
				["attenuation"] = {
					"Imperial Vizier Zor'lok", -- [1]
					"attenuation", -- [2]
					"Discs... Dance!", -- [3]
					14, -- [4]
					132333, -- [5]
					["id"] = 1507,
				},
				["214529"] = {
					"Cenarius", -- [1]
					"214529", -- [2]
					"Spear of Nightmares", -- [3]
					15.7, -- [4]
					1357799, -- [5]
					["id"] = 1877,
				},
				["206589"] = {
					"Star Augur Etraeus", -- [1]
					"206589", -- [2]
					"Chilled on YOU!", -- [3]
					12, -- [4]
					236208, -- [5]
					["id"] = 1863,
				},
				["213852"] = {
					"Spellblade Aluriel", -- [1]
					"213852", -- [2]
					"Replicate: Arcane Orb", -- [3]
					26, -- [4]
					135732, -- [5]
					["id"] = 1871,
				},
				["144358"] = {
					"Sha of Pride", -- [1]
					"144358", -- [2]
					"Wounded Pride", -- [3]
					11, -- [4]
					237555, -- [5]
					["id"] = 1604,
				},
				["205368"] = {
					"Krosus", -- [1]
					"205368", -- [2]
					"Fel Beam (1)", -- [3]
					9.5, -- [4]
					841219, -- [5]
					["id"] = 1842,
				},
				["59842"] = {
					"Slad'ran", -- [1]
					"59842", -- [2]
					"Poison Nova", -- [3]
					3.5, -- [4]
					136030, -- [5]
					["id"] = 1978,
				},
				["drakes"] = {
					"Galakras", -- [1]
					"drakes", -- [2]
					"Proto-Drakes", -- [3]
					168, -- [4]
					"Interface\\Icons\\ability_mount_drake_proto", -- [5]
					["id"] = 1622,
				},
				["bwcbRapidriverstest"] = {
					"Bars", -- [1]
					"bwcbRapidriverstest", -- [2]
					"Rapidrivers: test", -- [3]
					2, -- [4]
					"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
					["id"] = 1865,
				},
				["64623"] = {
					"Mimiron", -- [1]
					"64623", -- [2]
					"Next Frost Bomb", -- [3]
					45, -- [4]
					135849, -- [5]
					["id"] = 1138,
				},
				["227987"] = {
					"Opera Hall: Beautiful Beast", -- [1]
					"227987", -- [2]
					"Dinner Bell!", -- [3]
					8.5, -- [4]
					133706, -- [5]
					["id"] = 1957,
				},
				["228519"] = {
					"Helya-TrialOfValor", -- [1]
					"228519", -- [2]
					"Anchor Slam", -- [3]
					12, -- [4]
					132470, -- [5]
					["id"] = 2008,
				},
				["161612"] = {
					"Ko'ragh", -- [1]
					"161612", -- [2]
					"Balls hit (1)", -- [3]
					36, -- [4]
					"Interface\\Icons\\spell_fel_elementaldevastation", -- [5]
					["id"] = 1723,
				},
				["209602"] = {
					"Advisor Melandrus", -- [1]
					"209602", -- [2]
					"Blade Surge", -- [3]
					15, -- [4]
					965900, -- [5]
					["id"] = 1870,
				},
				["212726"] = {
					"Cenarius", -- [1]
					"212726", -- [2]
					"Forces of Nightmare (1)", -- [3]
					10, -- [4]
					1357812, -- [5]
					["id"] = 1877,
				},
				["volatile_anomaly"] = {
					"Ko'ragh", -- [1]
					"volatile_anomaly", -- [2]
					"Volatile Anomalies (2)", -- [3]
					8, -- [4]
					"Interface\\Icons\\spell_arcane_arcane04", -- [5]
					["id"] = 1723,
				},
				["204078"] = {
					"Dragons of Nightmare", -- [1]
					"204078", -- [2]
					"<Cast: Bellowing Roar>", -- [3]
					6, -- [4]
					136129, -- [5]
					["id"] = 1854,
				},
				["181735"] = {
					"Mannoroth", -- [1]
					"181735", -- [2]
					"Felseeker", -- [3]
					60, -- [4]
					"Interface\\Icons\\spell_fel_elementaldevastation", -- [5]
					["id"] = 1795,
				},
				["72034"] = {
					"Toravon the Ice Watcher", -- [1]
					"72034", -- [2]
					"Whiteout 1", -- [3]
					30, -- [4]
					135849, -- [5]
					["id"] = 1129,
				},
				["236694"] = {
					"Sisters of the Moon", -- [1]
					"236694", -- [2]
					"Call Moontalon", -- [3]
					5.7, -- [4]
					132150, -- [5]
					["id"] = 2050,
				},
				["explosion_casting_by_you"] = {
					"Amber-Shaper Un'sok", -- [1]
					"explosion_casting_by_you", -- [2]
					"<Cast: Explosion>", -- [3]
					2.5, -- [4]
					236305, -- [5]
					["id"] = 1499,
				},
				["228019"] = {
					"Opera Hall: Beautiful Beast", -- [1]
					"228019", -- [2]
					"Leftovers", -- [3]
					7, -- [4]
					133783, -- [5]
					["id"] = 1957,
				},
				["143469"] = {
					"Immerseus", -- [1]
					"143469", -- [2]
					"Reform", -- [3]
					25, -- [4]
					893777, -- [5]
					["id"] = 1602,
				},
				["embodied_terror"] = {
					"Tsulong", -- [1]
					"embodied_terror", -- [2]
					"~Embodied Terror (1)", -- [3]
					11, -- [4]
					651083, -- [5]
					["id"] = 1505,
				},
				["180526"] = {
					"Tyrant Velhari", -- [1]
					"180526", -- [2]
					"Font of Corruption", -- [3]
					22, -- [4]
					"Interface\\Icons\\Spell_Shadow_TwistedFaith", -- [5]
					["id"] = 1784,
				},
				["204667"] = {
					"Oakheart", -- [1]
					"204667", -- [2]
					"Nightmare Breath", -- [3]
					22, -- [4]
					1357794, -- [5]
					["id"] = 1837,
				},
				["158986"] = {
					"Kargath Bladefist", -- [1]
					"158986", -- [2]
					"Berserker Rush", -- [3]
					54, -- [4]
					"Interface\\Icons\\ability_fixated_state_red", -- [5]
					["id"] = 1721,
				},
				["71265"] = {
					"Blood-Queen Lana'thel", -- [1]
					"71265", -- [2]
					"Next Shadows", -- [3]
					30, -- [4]
					"Interface\\Icons\\Ability_Rogue_ShadowDance", -- [5]
					["id"] = 1103,
				},
				["233263"] = {
					"Sisters of the Moon", -- [1]
					"233263", -- [2]
					"Embrace of the Eclipse", -- [3]
					48.3, -- [4]
					236151, -- [5]
					["id"] = 2050,
				},
				["121995"] = {
					"Amber-Shaper Un'sok", -- [1]
					"121995", -- [2]
					"Amber Scalpel", -- [3]
					10, -- [4]
					135279, -- [5]
					["id"] = 1499,
				},
				["108046"] = {
					"Warmaster Blackhorn", -- [1]
					"108046", -- [2]
					"Shockwave", -- [3]
					14, -- [4]
					"Interface\\Icons\\Ability_Warrior_Shockwave", -- [5]
					["id"] = 1298,
				},
				["201379"] = {
					"Shivermaw", -- [1]
					"201379", -- [2]
					"Frost Breath", -- [3]
					5, -- [4]
					1029007, -- [5]
					["id"] = 1845,
				},
				["136889"] = {
					"Lei Shen", -- [1]
					"136889", -- [2]
					"Violent Gale Winds", -- [3]
					20, -- [4]
					"Interface\\Icons\\Ability_Druid_GaleWinds", -- [5]
					["id"] = 1579,
				},
				["236459"] = {
					"The Desolate Host", -- [1]
					"236459", -- [2]
					"Soulbind", -- [3]
					14.5, -- [4]
					607854, -- [5]
					["id"] = 2054,
				},
				["117309"] = {
					"Protectors of the Endless", -- [1]
					"117309", -- [2]
					"Cleansing Waters", -- [3]
					11, -- [4]
					"Interface\\Icons\\ability_shaman_fortifyingwaters", -- [5]
					["id"] = 1409,
				},
				["157054"] = {
					"Kromog", -- [1]
					"157054", -- [2]
					"Thundering Blows", -- [3]
					13, -- [4]
					"Interface\\Icons\\Ability_Smash", -- [5]
					["id"] = 1713,
				},
				["145226"] = {
					"Norushen", -- [1]
					"145226", -- [2]
					"Blind Hatred", -- [3]
					25, -- [4]
					651082, -- [5]
					["id"] = 1624,
				},
				["143759"] = {
					"Paragons of the Klaxxi", -- [1]
					"143759", -- [2]
					"Hurl Amber", -- [3]
					35, -- [4]
					646670, -- [5]
					["id"] = 1593,
				},
				["233983"] = {
					"Demonic Inquisition", -- [1]
					"233983", -- [2]
					"Echoing Anguish", -- [3]
					22, -- [4]
					136181, -- [5]
					["id"] = 2048,
				},
				["46165"] = {
					"Kael'thas Sunstrider", -- [1]
					"46165", -- [2]
					"Shock Barrier", -- [3]
					60, -- [4]
					136051, -- [5]
					["id"] = 1894,
				},
				["-9396"] = {
					"Kargath Bladefist", -- [1]
					"-9396", -- [2]
					"Ravenous Bloodmaw", -- [3]
					110, -- [4]
					"Interface\\Icons\\ability_druid_tigersroar", -- [5]
					["id"] = 1721,
				},
				["202473"] = {
					"Saelorn", -- [1]
					"202473", -- [2]
					"Fel Detonation", -- [3]
					30, -- [4]
					135800, -- [5]
					["id"] = 1851,
				},
				["-8305"] = {
					"Garrosh Hellscream", -- [1]
					"-8305", -- [2]
					"Intermission", -- [3]
					25, -- [4]
					"Interface\\Icons\\SPELL_HOLY_PRAYEROFSHADOWPROTECTION", -- [5]
					["id"] = 1623,
				},
				["123059"] = {
					"Amber-Shaper Un'sok", -- [1]
					"123059", -- [2]
					"Boss: (1)Destabilize", -- [3]
					15, -- [4]
					132109, -- [5]
					["id"] = 1499,
				},
				["203787"] = {
					"Dragons of Nightmare", -- [1]
					"203787", -- [2]
					"Volatile Infection", -- [3]
					45, -- [4]
					135914, -- [5]
					["id"] = 1854,
				},
				["197422"] = {
					"Cordana Felsong", -- [1]
					"197422", -- [2]
					"<Cast: Creeping Doom>", -- [3]
					35, -- [4]
					1022944, -- [5]
					["id"] = 1818,
				},
				["197365"] = {
					"Wrath of Azshara", -- [1]
					"197365", -- [2]
					"Crushing Depths", -- [3]
					20, -- [4]
					629077, -- [5]
					["id"] = 1814,
				},
				["-7980"] = {
					"Thok the Bloodthirsty", -- [1]
					"-7980", -- [2]
					"Fixate: Monkeroni", -- [3]
					12, -- [4]
					236188, -- [5]
					["id"] = 1599,
				},
				["crystal_add"] = {
					"Morchok", -- [1]
					"crystal_add", -- [2]
					"Kohcrom - Explosion", -- [3]
					12, -- [4]
					"INTERFACE\\ICONS\\inv_chaos_orb", -- [5]
					["id"] = 1292,
				},
				["99464"] = {
					"Alysrazor", -- [1]
					"99464", -- [2]
					"Molt", -- [3]
					12.5, -- [4]
					132929, -- [5]
					["id"] = 1206,
				},
				["154350"] = {
					"Ner'zhul", -- [1]
					"154350", -- [2]
					"Omen of Death", -- [3]
					11, -- [4]
					136022, -- [5]
					["id"] = 1682,
				},
				["59300"] = {
					"King Ymiron", -- [1]
					"59300", -- [2]
					"Fetid Rot: Marfang", -- [3]
					9, -- [4]
					132100, -- [5]
					["id"] = 2028,
				},
				["202414"] = {
					"Saelorn", -- [1]
					"202414", -- [2]
					"Venom Spray", -- [3]
					22, -- [4]
					132104, -- [5]
					["id"] = 1851,
				},
				["122409"] = {
					"Wind Lord Mel'jarak", -- [1]
					"122409", -- [2]
					"Kor'thik Strike", -- [3]
					19, -- [4]
					615300, -- [5]
					["id"] = 1498,
				},
				["146589"] = {
					"Thok the Bloodthirsty", -- [1]
					"146589", -- [2]
					"Skeleton Key on YOU!", -- [3]
					60, -- [4]
					348554, -- [5]
					["id"] = 1599,
				},
				["179583"] = {
					"Fel Lord Zakuun", -- [1]
					"179583", -- [2]
					"Rumbling Fissures", -- [3]
					7, -- [4]
					"Interface\\Icons\\ability_bossfellord_felfissure", -- [5]
					["id"] = 1777,
				},
				["154960"] = {
					"Beastlord Darmac", -- [1]
					"154960", -- [2]
					"Pinned Down", -- [3]
					11, -- [4]
					"Interface\\Icons\\INV_Spear_06", -- [5]
					["id"] = 1694,
				},
				["236378"] = {
					"Kil'jaeden", -- [1]
					"236378", -- [2]
					"Reflection: Wailing", -- [3]
					48.4, -- [4]
					463284, -- [5]
					["id"] = 2051,
				},
				["warming_up"] = {
					"The Iron Maidens", -- [1]
					"warming_up", -- [2]
					"Warming Up", -- [3]
					88, -- [4]
					"Interface\\Icons\\spell_fire_selfdestruct", -- [5]
					["id"] = 1695,
				},
				["155499"] = {
					"Beastlord Darmac", -- [1]
					"155499", -- [2]
					"Superheated Shrapnel", -- [3]
					12, -- [4]
					"Interface\\Icons\\INV_SummerFest_FireSpirit", -- [5]
					["id"] = 1694,
				},
				["70337"] = {
					"The Lich King", -- [1]
					"70337", -- [2]
					"Necrotic Plague", -- [3]
					31, -- [4]
					"Interface\\Icons\\Ability_Creature_Disease_02", -- [5]
					["id"] = 1106,
				},
				["213162"] = {
					"Cenarius", -- [1]
					"213162", -- [2]
					"Nightmare Blast", -- [3]
					30, -- [4]
					1357799, -- [5]
					["id"] = 1877,
				},
				["100002"] = {
					"Shannox", -- [1]
					"100002", -- [2]
					"Hurl Spear", -- [3]
					23, -- [4]
					136022, -- [5]
					["id"] = 1205,
				},
				["63138"] = {
					"Yogg-Saron", -- [1]
					"63138", -- [2]
					"Fervor on Tinyrivers!", -- [3]
					15, -- [4]
					237557, -- [5]
					["id"] = 1143,
				},
				["72350"] = {
					"The Lich King", -- [1]
					"72350", -- [2]
					"Last Phase", -- [3]
					160, -- [4]
					"Interface\\Icons\\INV_Sword_122", -- [5]
					["id"] = 1106,
				},
				["123788"] = {
					"Grand Empress Shek'zeer", -- [1]
					"123788", -- [2]
					"Cry of Terror", -- [3]
					25, -- [4]
					136131, -- [5]
					["id"] = 1501,
				},
				["71426"] = {
					"Lady Deathwhisper", -- [1]
					"71426", -- [2]
					"Next Spirit", -- [3]
					30, -- [4]
					"Interface\\Icons\\Spell_Holy_SenseUndead", -- [5]
					["id"] = 1100,
				},
				["142826"] = {
					"Malkorok", -- [1]
					"142826", -- [2]
					"Arcing Smash (1)", -- [3]
					12, -- [4]
					451165, -- [5]
					["id"] = 1595,
				},
				["-11462"] = {
					"Socrethar the Eternal", -- [1]
					"-11462", -- [2]
					"Haunting Soul", -- [3]
					30, -- [4]
					"Interface\\Icons\\achievement_halloween_ghost_01", -- [5]
					["id"] = 1794,
				},
				["158010"] = {
					"The Iron Maidens", -- [1]
					"158010", -- [2]
					"Bloodsoaked Heartseeker", -- [3]
					32, -- [4]
					"Interface\\Icons\\ability_ironmaidens_boomerangrush", -- [5]
					["id"] = 1695,
				},
				["233155"] = {
					"Mephistroth", -- [1]
					"233155", -- [2]
					"Carrion Swarm", -- [3]
					18.1, -- [4]
					136128, -- [5]
					["id"] = 2039,
				},
				["212681"] = {
					"Cenarius", -- [1]
					"212681", -- [2]
					"Cleansed Ground", -- [3]
					13, -- [4]
					136074, -- [5]
					["id"] = 1877,
				},
				["192520"] = {
					"Ashgolm", -- [1]
					"192520", -- [2]
					"Volcano", -- [3]
					10, -- [4]
					135830, -- [5]
					["id"] = 1816,
				},
				["-8218"] = {
					"Norushen", -- [1]
					"-8218", -- [2]
					"Unleashed Anger", -- [3]
					10, -- [4]
					897142, -- [5]
					["id"] = 1624,
				},
				["-7634"] = {
					"Twin Consorts", -- [1]
					"-7634", -- [2]
					"Beast of Nightmares", -- [3]
					50, -- [4]
					"Interface\\ICONS\\Creatureportrait_TwilightsHammer_DragonEgg_02.blp", -- [5]
					["id"] = 1560,
				},
				["144498"] = {
					"Iron Juggernaut", -- [1]
					"144498", -- [2]
					"Explosive Tar", -- [3]
					10, -- [4]
					576309, -- [5]
					["id"] = 1600,
				},
				["162894"] = {
					"Tectus", -- [1]
					"162894", -- [2]
					"Gift of Earth", -- [3]
					10, -- [4]
					"Interface\\Icons\\ability_earthenfury_giftofearth", -- [5]
					["id"] = 1722,
				},
				["184657"] = {
					"Hellfire High Council", -- [1]
					"184657", -- [2]
					"<Cast: Nightmare Visage>", -- [3]
					16, -- [4]
					"Interface\\Icons\\Spell_Shadow_SummonVoidWalker", -- [5]
					["id"] = 1798,
				},
				["184964"] = {
					"Archimonde", -- [1]
					"184964", -- [2]
					"Shackled Torment (1)", -- [3]
					27, -- [4]
					"Interface\\Icons\\ability_warlock_soullink", -- [5]
					["id"] = 1799,
				},
				["162124"] = {
					"Hans'gar and Franzok", -- [1]
					"162124", -- [2]
					"Smart Stampers", -- [3]
					13, -- [4]
					"INTERFACE\\ICONS\\warrior_talent_icon_lambstotheslaughter", -- [5]
					["id"] = 1693,
				},
				["guard"] = {
					"The Blast Furnace", -- [1]
					"guard", -- [2]
					"Security Guard", -- [3]
					65, -- [4]
					"Interface\\Icons\\INV_Shield_32", -- [5]
					["id"] = 1690,
				},
				["152979"] = {
					"Nhallish", -- [1]
					"152979", -- [2]
					"Soul Shred", -- [3]
					37, -- [4]
					828455, -- [5]
					["id"] = 1688,
				},
				["99516"] = {
					"Baleroc", -- [1]
					"99516", -- [2]
					"Link", -- [3]
					25, -- [4]
					136106, -- [5]
					["id"] = 1200,
				},
				["182020"] = {
					"Iron Reaver", -- [1]
					"182020", -- [2]
					"Pounding (1)", -- [3]
					34.4, -- [4]
					"INTERFACE\\ICONS\\spell_shaman_earthquake", -- [5]
					["id"] = 1785,
				},
				["56130"] = {
					"Elder Nadox", -- [1]
					"56130", -- [2]
					"Brood Plague: Marfang", -- [3]
					30, -- [4]
					135935, -- [5]
					["id"] = 1969,
				},
				["204459"] = {
					"Skorpyron", -- [1]
					"204459", -- [2]
					"Exoskeletal Vulnerability", -- [3]
					14, -- [4]
					132358, -- [5]
					["id"] = 1849,
				},
				["221160"] = {
					"Nighthold Trash", -- [1]
					"221160", -- [2]
					"Compress the Void", -- [3]
					15, -- [4]
					1386548, -- [5]
					["id"] = 1865,
				},
				["155794"] = {
					"The Iron Maidens", -- [1]
					"155794", -- [2]
					"Blade Dash", -- [3]
					11, -- [4]
					"Interface\\Icons\\Ability_Rogue_QuickRecovery", -- [5]
					["id"] = 1695,
				},
				["168227"] = {
					"Skulloc", -- [1]
					"168227", -- [2]
					"Gronn Smash", -- [3]
					30, -- [4]
					132318, -- [5]
					["id"] = 1754,
				},
				["-6550"] = {
					"Tsulong", -- [1]
					"-6550", -- [2]
					"The Dark of Night", -- [3]
					30, -- [4]
					136223, -- [5]
					["id"] = 1505,
				},
				["161090"] = {
					"Rocketspark and Borka", -- [1]
					"161090", -- [2]
					"Mad Dash", -- [3]
					29.5, -- [4]
					132307, -- [5]
					["id"] = 1715,
				},
				["194325"] = {
					"Harbaron", -- [1]
					"194325", -- [2]
					"Fragment", -- [3]
					18, -- [4]
					236300, -- [5]
					["id"] = 1823,
				},
				["211471"] = {
					"Cenarius", -- [1]
					"211471", -- [2]
					"Scorned Touch on YOU!", -- [3]
					11.9989999998361, -- [4]
					1357804, -- [5]
					["id"] = 1877,
				},
				["199345"] = {
					"Dresaron", -- [1]
					"199345", -- [2]
					"Down Draft", -- [3]
					21, -- [4]
					1029595, -- [5]
					["id"] = 1838,
				},
				["194216"] = {
					"Harbaron", -- [1]
					"194216", -- [2]
					"Cosmic Scythe", -- [3]
					3.6, -- [4]
					1120185, -- [5]
					["id"] = 1823,
				},
				["210290"] = {
					"Cenarius", -- [1]
					"210290", -- [2]
					"Nightmare Brambles", -- [3]
					28, -- [4]
					1357815, -- [5]
					["id"] = 1877,
				},
				["150776"] = {
					"Gug'rokk", -- [1]
					"150776", -- [2]
					"Magma Eruption", -- [3]
					20, -- [4]
					524795, -- [5]
					["id"] = 1654,
				},
				["238505"] = {
					"Kil'jaeden", -- [1]
					"238505", -- [2]
					"Focused Dreadflame", -- [3]
					23.5, -- [4]
					236216, -- [5]
					["id"] = 2051,
				},
				["181295"] = {
					"Gorefiend", -- [1]
					"181295", -- [2]
					"Digest on YOU!", -- [3]
					40, -- [4]
					"Interface\\Icons\\Spell_Shadow_DeathCoil", -- [5]
					["id"] = 1783,
				},
				["tentacle"] = {
					"Yogg-Saron", -- [1]
					"tentacle", -- [2]
					"Crusher 2!", -- [3]
					55, -- [4]
					132106, -- [5]
					["id"] = 1143,
				},
				["143309"] = {
					"Immerseus", -- [1]
					"143309", -- [2]
					"Swirl", -- [3]
					20.8, -- [4]
					135861, -- [5]
					["id"] = 1602,
				},
				["-13022"] = {
					"Chronomatic Anomaly", -- [1]
					"-13022", -- [2]
					"Add", -- [3]
					25, -- [4]
					135739, -- [5]
					["id"] = 1865,
				},
				["227646"] = {
					"Moroes", -- [1]
					"227646", -- [2]
					"Iron Whirlwind", -- [3]
					4.5, -- [4]
					460959, -- [5]
					["id"] = 1961,
				},
				["destructor_tentacle"] = {
					"Helya", -- [1]
					"destructor_tentacle", -- [2]
					"Destructor Tentacle", -- [3]
					26, -- [4]
					"Interface\\Icons\\inv_misc_monsterhorn_03", -- [5]
					["id"] = 1824,
				},
				["154989"] = {
					"Beastlord Darmac", -- [1]
					"154989", -- [2]
					"Inferno Breath", -- [3]
					5, -- [4]
					"Interface\\Icons\\INV_SummerFest_FireSpirit", -- [5]
					["id"] = 1694,
				},
				["bwcbSereneriversbaby agro"] = {
					"Bars", -- [1]
					"bwcbSereneriversbaby agro", -- [2]
					"Serenerivers: baby agro", -- [3]
					300, -- [4]
					"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
					["id"] = 1788,
				},
				["-8179"] = {
					"Iron Juggernaut", -- [1]
					"-8179", -- [2]
					"Borer Drill", -- [3]
					19, -- [4]
					657936, -- [5]
					["id"] = 1600,
				},
				["-6346"] = {
					"Blade Lord Ta'yak", -- [1]
					"-6346", -- [2]
					"Unseen Strike (1)", -- [3]
					30, -- [4]
					458737, -- [5]
					["id"] = 1504,
				},
				["-8195"] = {
					"Siegecrafter Blackfuse", -- [1]
					"-8195", -- [2]
					"Launch Sawblade", -- [3]
					9, -- [4]
					134427, -- [5]
					["id"] = 1601,
				},
				["186546"] = {
					"Xhul'horac", -- [1]
					"186546", -- [2]
					"Black Hole", -- [3]
					18, -- [4]
					"Interface\\Icons\\INV_Enchant_VoidSphere", -- [5]
					["id"] = 1800,
				},
				["crystal_boss"] = {
					"Morchok", -- [1]
					"crystal_boss", -- [2]
					"Crystal", -- [3]
					16, -- [4]
					"Interface\\Icons\\inv_chaos_orb", -- [5]
					["id"] = 1292,
				},
				["105651"] = {
					"Madness of Deathwing", -- [1]
					"105651", -- [2]
					"Elementium Bolt", -- [3]
					40.5, -- [4]
					"Interface\\Icons\\Spell_Fire_MeteorStorm", -- [5]
					["id"] = 1299,
				},
				["143491"] = {
					"The Fallen Protectors", -- [1]
					"143491", -- [2]
					"Calamity", -- [3]
					29, -- [4]
					632353, -- [5]
					["id"] = 1598,
				},
				["193611"] = {
					"Lady Hatecoil", -- [1]
					"193611", -- [2]
					"Focused Lightning", -- [3]
					35, -- [4]
					136015, -- [5]
					["id"] = 1811,
				},
				["181288"] = {
					"Socrethar the Eternal", -- [1]
					"181288", -- [2]
					"Fel Prison", -- [3]
					48, -- [4]
					"Interface\\Icons\\inv_gizmo_felstabilizer", -- [5]
					["id"] = 1794,
				},
				["bwcbRapidriversbreak"] = {
					"Bars", -- [1]
					"bwcbRapidriversbreak", -- [2]
					"Rapidrivers: break", -- [3]
					600, -- [4]
					"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
					["id"] = 1871,
				},
				["59322"] = {
					"Skadi the Ruthless", -- [1]
					"59322", -- [2]
					"<Cast: Whirlwind>", -- [3]
					10, -- [4]
					132369, -- [5]
					["id"] = 2029,
				},
				["62680"] = {
					"Ignis the Furnace Master", -- [1]
					"62680", -- [2]
					"Flame Jets", -- [3]
					21, -- [4]
					135826, -- [5]
					["id"] = 1136,
				},
				["145215"] = {
					"Sha of Pride", -- [1]
					"145215", -- [2]
					"Banishment", -- [3]
					37.4, -- [4]
					651097, -- [5]
					["id"] = 1604,
				},
				["139822"] = {
					"Megaera", -- [1]
					"139822", -- [2]
					"Cinders: Rothric", -- [3]
					30, -- [4]
					"INTERFACE\\ICONS\\inv_misc_volatilefire", -- [5]
					["id"] = 1578,
				},
				["recursive_elemental"] = {
					"Grand Magistrix Elisande", -- [1]
					"recursive_elemental", -- [2]
					"Recursive Elemental", -- [3]
					5, -- [4]
					653221, -- [5]
					["id"] = 1872,
				},
				["210948"] = {
					"Elerethe Renferal", -- [1]
					"210948", -- [2]
					"Dark Storm", -- [3]
					27, -- [4]
					649816, -- [5]
					["id"] = 1876,
				},
				["-8262"] = {
					"Sha of Pride", -- [1]
					"-8262", -- [2]
					"Big Add", -- [3]
					60, -- [4]
					651096, -- [5]
					["id"] = 1604,
				},
				["203888"] = {
					"Dragons of Nightmare", -- [1]
					"203888", -- [2]
					"Siphon Spirit", -- [3]
					25, -- [4]
					136122, -- [5]
					["id"] = 1854,
				},
				["234015"] = {
					"Demonic Inquisition", -- [1]
					"234015", -- [2]
					"Tormenting Burst", -- [3]
					17.1, -- [4]
					136123, -- [5]
					["id"] = 2048,
				},
				["199193"] = {
					"Kurtalos Ravencrest", -- [1]
					"199193", -- [2]
					"Dreadlord's Guile", -- [3]
					27, -- [4]
					840942, -- [5]
					["id"] = 1835,
				},
				["-8199"] = {
					"Siegecrafter Blackfuse", -- [1]
					"-8199", -- [2]
					"Automated Shredders", -- [3]
					35, -- [4]
					"Interface\\Icons\\INV_MISC_ARMORKIT_27", -- [5]
					["id"] = 1601,
				},
				["warmup"] = {
					"Ultraxion", -- [1]
					"warmup", -- [2]
					"Ultraxion", -- [3]
					30, -- [4]
					"Interface\\Icons\\achievment_boss_ultraxion", -- [5]
					["id"] = 1297,
				},
				["boss_active"] = {
					"Grand Magistrix Elisande", -- [1]
					"boss_active", -- [2]
					"Elisande Active", -- [3]
					68, -- [4]
					"Interface\\Icons\\achievement_thenighthold_grandmagistrixelisande", -- [5]
					["id"] = 1872,
				},
				["228829"] = {
					"Nightbane", -- [1]
					"228829", -- [2]
					"Burning Bones", -- [3]
					18, -- [4]
					460696, -- [5]
					["id"] = 2031,
				},
				["212030"] = {
					"General Xakal", -- [1]
					"212030", -- [2]
					"Shadow Slash", -- [3]
					13, -- [4]
					607850, -- [5]
					["id"] = 1828,
				},
				["59795"] = {
					"Ionar", -- [1]
					"59795", -- [2]
					"Static Overload: Marfang", -- [3]
					10, -- [4]
					136050, -- [5]
					["id"] = 1984,
				},
				["44863"] = {
					"Kael'thas Sunstrider", -- [1]
					"44863", -- [2]
					"~Fear", -- [3]
					30, -- [4]
					136129, -- [5]
					["id"] = 733,
				},
				["155198"] = {
					"Beastlord Darmac", -- [1]
					"155198", -- [2]
					"Savage Howl", -- [3]
					17, -- [4]
					"Interface\\Icons\\ability_warlock_howlofterror", -- [5]
					["id"] = 1694,
				},
				["209676"] = {
					"Advisor Melandrus", -- [1]
					"209676", -- [2]
					"Slicing Maelstrom", -- [3]
					10, -- [4]
					1029585, -- [5]
					["id"] = 1870,
				},
				["139011"] = {
					"Lei Shen", -- [1]
					"139011", -- [2]
					"Helm of Command", -- [3]
					14, -- [4]
					133833, -- [5]
					["id"] = 1579,
				},
				["227267"] = {
					"The Curator", -- [1]
					"227267", -- [2]
					"Summon Volatile Energy", -- [3]
					5, -- [4]
					237510, -- [5]
					["id"] = 1964,
				},
				["137528"] = {
					"Ji-Kun", -- [1]
					"137528", -- [2]
					"Feed Young", -- [3]
					41, -- [4]
					"Interface\\Icons\\INV_Misc_Slime_01", -- [5]
					["id"] = 1573,
				},
				["-8073"] = {
					"Paragons of the Klaxxi", -- [1]
					"-8073", -- [2]
					"Aim (1)", -- [3]
					38, -- [4]
					878211, -- [5]
					["id"] = 1593,
				},
				["-6889"] = {
					"Durumu the Forgotten", -- [1]
					"-6889", -- [2]
					"Walls of Ice", -- [3]
					127, -- [4]
					517161, -- [5]
					["id"] = 1572,
				},
				["rejuvenating_mushroom"] = {
					"Brackenspore", -- [1]
					"rejuvenating_mushroom", -- [2]
					"Rejuvenating Mushroom", -- [3]
					82, -- [4]
					"Interface\\Icons\\Spell_Magic_ManaGain", -- [5]
					["id"] = 1720,
				},
				["135095"] = {
					"Lei Shen", -- [1]
					"135095", -- [2]
					"Thunderstruck", -- [3]
					25, -- [4]
					"Interface\\Icons\\ability_thunderking_thunderstruck", -- [5]
					["id"] = 1579,
				},
				["210264"] = {
					"Xavius", -- [1]
					"210264", -- [2]
					"Manifest Corruption", -- [3]
					62, -- [4]
					1357796, -- [5]
					["id"] = 1864,
				},
				["236542"] = {
					"The Desolate Host", -- [1]
					"236542", -- [2]
					"Sundering Doom", -- [3]
					17, -- [4]
					1120185, -- [5]
					["id"] = 2054,
				},
				["180533"] = {
					"Tyrant Velhari", -- [1]
					"180533", -- [2]
					"Tainted Shadows (1)", -- [3]
					5, -- [4]
					"INTERFACE\\ICONS\\spell_fire_twilightcano", -- [5]
					["id"] = 1784,
				},
				["228796"] = {
					"Nightbane", -- [1]
					"228796", -- [2]
					"Ignite Soul", -- [3]
					20, -- [4]
					136196, -- [5]
					["id"] = 2031,
				},
				["144400"] = {
					"Sha of Pride", -- [1]
					"144400", -- [2]
					"Swelling Pride (1)", -- [3]
					77, -- [4]
					895888, -- [5]
					["id"] = 1604,
				},
				["117921"] = {
					"The Spirit Kings", -- [1]
					"117921", -- [2]
					"Massive Attack", -- [3]
					5, -- [4]
					"Interface\\Icons\\Ability_Warrior_PunishingBlow", -- [5]
					["id"] = 1436,
				},
				["59529"] = {
					"Volkhan", -- [1]
					"59529", -- [2]
					"Shattering Stomp", -- [3]
					3, -- [4]
					132368, -- [5]
					["id"] = 1985,
				},
				["-5865"] = {
					"Thalnos the Soulrender", -- [1]
					"-5865", -- [2]
					"<Cast: Spirit Gale>", -- [3]
					2, -- [4]
					463286, -- [5]
					["id"] = 1423,
				},
				["-14404"] = {
					"Odyn-TrialOfValor", -- [1]
					"-14404", -- [2]
					"Hyrja", -- [3]
					16, -- [4]
					"Interface\\Icons\\inv_shield_1h_hyrja_d_01", -- [5]
					["id"] = 1958,
				},
				["203028"] = {
					"Dragons of Nightmare", -- [1]
					"203028", -- [2]
					"Corrupted Breath", -- [3]
					17, -- [4]
					136123, -- [5]
					["id"] = 1854,
				},
				["208431"] = {
					"Xavius", -- [1]
					"208431", -- [2]
					"Corruption: Descent into Madness on YOU!", -- [3]
					20, -- [4]
					1357814, -- [5]
					["id"] = 1864,
				},
				["228834"] = {
					"Nightbane", -- [1]
					"228834", -- [2]
					"Jagged Shards (1)", -- [3]
					12, -- [4]
					1003591, -- [5]
					["id"] = 2031,
				},
				["200404"] = {
					"Dargrul", -- [1]
					"200404", -- [2]
					"Magma Wave", -- [3]
					60, -- [4]
					237583, -- [5]
					["id"] = 1793,
				},
				["228390"] = {
					"Helya-TrialOfValor", -- [1]
					"228390", -- [2]
					"Sludge Nova", -- [3]
					14, -- [4]
					1500940, -- [5]
					["id"] = 2008,
				},
				["197796"] = {
					"Cordana Felsong", -- [1]
					"197796", -- [2]
					"Avatar of Vengeance", -- [3]
					45, -- [4]
					134496, -- [5]
					["id"] = 1818,
				},
				["227629"] = {
					"Odyn-TrialOfValor", -- [1]
					"227629", -- [2]
					"Unerring Blast", -- [3]
					70, -- [4]
					135981, -- [5]
					["id"] = 1958,
				},
				["211616"] = {
					"Grand Magistrix Elisande", -- [1]
					"211616", -- [2]
					"Summon Time Elemental - Fast", -- [3]
					8, -- [4]
					135738, -- [5]
					["id"] = 1872,
				},
				["219815"] = {
					"Chronomatic Anomaly", -- [1]
					"219815", -- [2]
					"Temporal Orbs", -- [3]
					13, -- [4]
					610472, -- [5]
					["id"] = 1865,
				},
				["193051"] = {
					"King Deepbeard", -- [1]
					"193051", -- [2]
					"Call the Seas", -- [3]
					20, -- [4]
					135861, -- [5]
					["id"] = 1812,
				},
				["209166"] = {
					"Grand Magistrix Elisande", -- [1]
					"209166", -- [2]
					"Fast Time on YOU!", -- [3]
					23.0769999999993, -- [4]
					648208, -- [5]
					["id"] = 1872,
				},
				["99925"] = {
					"Alysrazor", -- [1]
					"99925", -- [2]
					"Full Power", -- [3]
					25, -- [4]
					459027, -- [5]
					["id"] = 1206,
				},
				["181827"] = {
					"Shadow-Lord Iskar", -- [1]
					"181827", -- [2]
					"Fel Conduit", -- [3]
					6, -- [4]
					"Interface\\Icons\\Spell_Fire_FelFireNova", -- [5]
					["id"] = 1788,
				},
				["-8202"] = {
					"Siegecrafter Blackfuse", -- [1]
					"-8202", -- [2]
					"The Assembly Line (2)", -- [3]
					40, -- [4]
					"Interface\\Icons\\Inv_crate_03", -- [5]
					["id"] = 1601,
				},
				["192675"] = {
					"Wrath of Azshara", -- [1]
					"192675", -- [2]
					"Mystic Tornado", -- [3]
					8, -- [4]
					606549, -- [5]
					["id"] = 1814,
				},
				["193668"] = {
					"God-King Skovald", -- [1]
					"193668", -- [2]
					"Savage Blade", -- [3]
					23, -- [4]
					135271, -- [5]
					["id"] = 1808,
				},
				["224649"] = {
					"Xavius", -- [1]
					"224649", -- [2]
					"Tormenting Swipe", -- [3]
					10, -- [4]
					1396978, -- [5]
					["id"] = 1864,
				},
				["155301"] = {
					"Gruul", -- [1]
					"155301", -- [2]
					"Smash or Slam", -- [3]
					21, -- [4]
					"Interface\\Icons\\ability_kilruk_reave", -- [5]
					["id"] = 1691,
				},
				["bwcbSereneriversbreak love :)"] = {
					"Bars", -- [1]
					"bwcbSereneriversbreak love :)", -- [2]
					"Serenerivers: break love :)", -- [3]
					600, -- [4]
					"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
					["id"] = 1800,
				},
				["208230"] = {
					"Tichondrius", -- [1]
					"208230", -- [2]
					"Feast of Blood (1)", -- [3]
					20, -- [4]
					538039, -- [5]
					["id"] = 1862,
				},
				["77333"] = {
					"Iron Qon", -- [1]
					"77333", -- [2]
					"Whirling Winds", -- [3]
					17, -- [4]
					136018, -- [5]
					["id"] = 1559,
				},
				["living_mushroom"] = {
					"Brackenspore", -- [1]
					"living_mushroom", -- [2]
					"Living Mushroom", -- [3]
					18, -- [4]
					"Interface\\Icons\\inv_misc_starspecklemushroom", -- [5]
					["id"] = 1720,
				},
				["214876"] = {
					"Cenarius", -- [1]
					"214876", -- [2]
					"Beasts of Nightmare", -- [3]
					30.3, -- [4]
					1357812, -- [5]
					["id"] = 1877,
				},
				["156197"] = {
					"The Butcher", -- [1]
					"156197", -- [2]
					"Bounding Cleave", -- [3]
					60, -- [4]
					"Interface\\Icons\\ability_butcher_whirl", -- [5]
					["id"] = 1706,
				},
				["-6891"] = {
					"Durumu the Forgotten", -- [1]
					"-6891", -- [2]
					"Light Spectrum", -- [3]
					41, -- [4]
					"Interface\\ICONS\\INV_Misc_Gem_Variety_02.blp", -- [5]
					["id"] = 1572,
				},
				["59835"] = {
					"Loken", -- [1]
					"59835", -- [2]
					"Lightning Nova", -- [3]
					4, -- [4]
					136050, -- [5]
					["id"] = 1986,
				},
				["105848"] = {
					"Spine of Deathwing", -- [1]
					"105848", -- [2]
					"Armor Exposed", -- [3]
					23, -- [4]
					"Interface\\Icons\\ability_deathwing_sealarmorbreachtga", -- [5]
					["id"] = 1291,
				},
				["160681"] = {
					"Nitrogg Thundertower", -- [1]
					"160681", -- [2]
					"Suppressive Fire: Aliciateas", -- [3]
					10, -- [4]
					841383, -- [5]
					["id"] = 1732,
				},
				["221875"] = {
					"Star Augur Etraeus", -- [1]
					"221875", -- [2]
					"Nether Traversal", -- [3]
					20, -- [4]
					1041232, -- [5]
					["id"] = 1863,
				},
				["105845"] = {
					"Spine of Deathwing", -- [1]
					"105845", -- [2]
					"Nuclear Blast", -- [3]
					5, -- [4]
					"Interface\\Icons\\INV_Gizmo_SuperSapperCharge", -- [5]
					["id"] = 1291,
				},
				["156928"] = {
					"Blackhand", -- [1]
					"156928", -- [2]
					"Slag Eruption", -- [3]
					31.5, -- [4]
					"Interface\\Icons\\spell_fire_ragnaros_lavabolt", -- [5]
					["id"] = 1704,
				},
				["122774"] = {
					"Garalon", -- [1]
					"122774", -- [2]
					"Crush (1)", -- [3]
					28, -- [4]
					451165, -- [5]
					["id"] = 1463,
				},
				["180224"] = {
					"Kilrogg Deadeye", -- [1]
					"180224", -- [2]
					"Death Throes (1)", -- [3]
					40, -- [4]
					"Interface\\Icons\\Ability_Warrior_Cleave", -- [5]
					["id"] = 1786,
				},
				["icyAdd"] = {
					"Spellblade Aluriel", -- [1]
					"icyAdd", -- [2]
					"Icy Enchantment", -- [3]
					65, -- [4]
					135862, -- [5]
					["id"] = 1871,
				},
				["135695"] = {
					"Lei Shen", -- [1]
					"135695", -- [2]
					"Static Shock", -- [3]
					18, -- [4]
					"Interface\\Icons\\Spell_Shaman_StaticShock", -- [5]
					["id"] = 1579,
				},
				["-7915"] = {
					"General Nazgrim", -- [1]
					"-7915", -- [2]
					"Berserker(NOW:Battle)", -- [3]
					60, -- [4]
					132275, -- [5]
					["id"] = 1603,
				},
				["190748"] = {
					"Hellfire Assault", -- [1]
					"190748", -- [2]
					"Cannonball", -- [3]
					12, -- [4]
					"Interface\\Icons\\ability_vehicle_launchplayer", -- [5]
					["id"] = 1778,
				},
				["hemorrhage"] = {
					"Madness of Deathwing", -- [1]
					"hemorrhage", -- [2]
					"Hemorrhage", -- [3]
					55.5, -- [4]
					"Interface\\Icons\\Spell_Fire_MoltenBlood", -- [5]
					["id"] = 1299,
				},
				["212834"] = {
					"Shade of Xavius", -- [1]
					"212834", -- [2]
					"Nightmare Bolt", -- [3]
					17, -- [4]
					1357805, -- [5]
					["id"] = 1839,
				},
				["186490"] = {
					"Xhul'horac", -- [1]
					"186490", -- [2]
					"Chains of Fel", -- [3]
					33, -- [4]
					"INTERFACE\\ICONS\\inv_misc_steelweaponchain", -- [5]
					["id"] = 1800,
				},
				["186453"] = {
					"Xhul'horac", -- [1]
					"186453", -- [2]
					"Felblaze Flurry", -- [3]
					12, -- [4]
					"Interface\\Icons\\ability_ironmaidens_bladerush", -- [5]
					["id"] = 1800,
				},
				["182200"] = {
					"Shadow-Lord Iskar", -- [1]
					"182200", -- [2]
					"Fel Chakram", -- [3]
					5.5, -- [4]
					"Interface\\Icons\\ability_arakkoa_spinning_blade", -- [5]
					["id"] = 1788,
				},
				["99259"] = {
					"Baleroc", -- [1]
					"99259", -- [2]
					"Shards of Torment", -- [3]
					5, -- [4]
					133265, -- [5]
					["id"] = 1200,
				},
				["207630"] = {
					"Trilliax", -- [1]
					"207630", -- [2]
					"Annihilation", -- [3]
					20.5, -- [4]
					135734, -- [5]
					["id"] = 1867,
				},
				["siegemaker"] = {
					"Blackhand", -- [1]
					"siegemaker", -- [2]
					"Siegemaker (1)", -- [3]
					16, -- [4]
					"Interface\\Icons\\ability_vehicle_siegeenginecharge", -- [5]
					["id"] = 1704,
				},
				["159947"] = {
					"Kargath Bladefist", -- [1]
					"159947", -- [2]
					"Chain Hurl", -- [3]
					90, -- [4]
					"Interface\\Icons\\inv_misc_steelweaponchain", -- [5]
					["id"] = 1721,
				},
				["159996"] = {
					"Brackenspore", -- [1]
					"159996", -- [2]
					"Infesting Spores", -- [3]
					45, -- [4]
					"Interface\\Icons\\Ability_Creature_Disease_01", -- [5]
					["id"] = 1720,
				},
				["spore_shooter"] = {
					"Brackenspore", -- [1]
					"spore_shooter", -- [2]
					"Small Adds", -- [3]
					20, -- [4]
					"Interface\\Icons\\Ability_Creature_Disease_03", -- [5]
					["id"] = 1720,
				},
				["192517"] = {
					"Ashgolm", -- [1]
					"192517", -- [2]
					"Brittle", -- [3]
					20, -- [4]
					460686, -- [5]
					["id"] = 1816,
				},
				["235572"] = {
					"Fallen Avatar", -- [1]
					"235572", -- [2]
					"Rupture Realities (1)", -- [3]
					38, -- [4]
					135801, -- [5]
					["id"] = 2038,
				},
				["155222"] = {
					"Beastlord Darmac", -- [1]
					"155222", -- [2]
					"Tantrum (1)", -- [3]
					25, -- [4]
					"Interface\\Icons\\Spell_Nature_Earthquake", -- [5]
					["id"] = 1694,
				},
				["133597"] = {
					"Durumu the Forgotten", -- [1]
					"133597", -- [2]
					"Dark Parasite", -- [3]
					60, -- [4]
					136138, -- [5]
					["id"] = 1572,
				},
				["186961"] = {
					"Archimonde", -- [1]
					"186961", -- [2]
					"Nether Banish", -- [3]
					13, -- [4]
					"Interface\\Icons\\ability_warlock_moltencoregreen", -- [5]
					["id"] = 1799,
				},
				["198635"] = {
					"Kurtalos Ravencrest", -- [1]
					"198635", -- [2]
					"Unerring Shear", -- [3]
					5.5, -- [4]
					1278100, -- [5]
					["id"] = 1835,
				},
				["59267"] = {
					"Gortok Palehoof", -- [1]
					"59267", -- [2]
					"Withering Roar", -- [3]
					10, -- [4]
					132091, -- [5]
					["id"] = 2027,
				},
				["118122"] = {
					"The Spirit Kings", -- [1]
					"118122", -- [2]
					"Rain of Arrows", -- [3]
					41, -- [4]
					"Interface\\Icons\\INV_Ammo_Arrow_01", -- [5]
					["id"] = 1436,
				},
				["136850"] = {
					"Lei Shen", -- [1]
					"136850", -- [2]
					"Lightning Whip", -- [3]
					29, -- [4]
					"Interface\\Icons\\ability_thunderking_lightningwhip", -- [5]
					["id"] = 1579,
				},
				["bwcbSereneriversbreak"] = {
					"Bars", -- [1]
					"bwcbSereneriversbreak", -- [2]
					"Serenerivers: break", -- [3]
					600, -- [4]
					"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
					["id"] = 1783,
				},
				["204574"] = {
					"Oakheart", -- [1]
					"204574", -- [2]
					"Strangling Roots", -- [3]
					13, -- [4]
					458176, -- [5]
					["id"] = 1837,
				},
				["204100"] = {
					"Dragons of Nightmare", -- [1]
					"204100", -- [2]
					"Shades of Taerar", -- [3]
					49, -- [4]
					135824, -- [5]
					["id"] = 1854,
				},
				["71289"] = {
					"Lady Deathwhisper", -- [1]
					"71289", -- [2]
					"Dominate Mind", -- [3]
					30, -- [4]
					"Interface\\Icons\\INV_Belt_18", -- [5]
					["id"] = 1100,
				},
				["206641"] = {
					"Trilliax", -- [1]
					"206641", -- [2]
					"Arcane Slash", -- [3]
					7.5, -- [4]
					1041233, -- [5]
					["id"] = 1867,
				},
				["144005"] = {
					"Kor'kron Dark Shaman", -- [1]
					"144005", -- [2]
					"Toxic Storm", -- [3]
					32, -- [4]
					649816, -- [5]
					["id"] = 1606,
				},
				["236544"] = {
					"The Desolate Host", -- [1]
					"236544", -- [2]
					"Doomed Sundering", -- [3]
					28, -- [4]
					1033912, -- [5]
					["id"] = 2054,
				},
				["bwcbRapidriversbreak!"] = {
					"Bars", -- [1]
					"bwcbRapidriversbreak!", -- [2]
					"Rapidrivers: break!", -- [3]
					600, -- [4]
					134376, -- [5]
					["id"] = 1865,
				},
				["force"] = {
					"Imperial Vizier Zor'lok", -- [1]
					"force", -- [2]
					"<Cast: AoE Pulse>", -- [3]
					12, -- [4]
					589118, -- [5]
					["id"] = 1507,
				},
				["212784"] = {
					"Court of Stars Trash", -- [1]
					"212784", -- [2]
					"<Cast: Eye Storm>", -- [3]
					8, -- [4]
					136032, -- [5]
					["id"] = 1869,
				},
				["197810"] = {
					"General Xakal", -- [1]
					"197810", -- [2]
					"Wicked Slam", -- [3]
					47, -- [4]
					1109118, -- [5]
					["id"] = 1828,
				},
				["210984"] = {
					"Il'gynoth", -- [1]
					"210984", -- [2]
					"Eye of Fate", -- [3]
					10, -- [4]
					1357799, -- [5]
					["id"] = 1873,
				},
				["firestorm"] = {
					"Brother Korloff", -- [1]
					"firestorm", -- [2]
					"Firestorm Kick", -- [3]
					11, -- [4]
					135788, -- [5]
					["id"] = 1424,
				},
				["120669"] = {
					"Sha of Fear", -- [1]
					"120669", -- [2]
					"Naked and Afraid", -- [3]
					31, -- [4]
					236272, -- [5]
					["id"] = 1431,
				},
				["144485"] = {
					"Iron Juggernaut", -- [1]
					"144485", -- [2]
					"Shock Pulse (1)", -- [3]
					15, -- [4]
					136025, -- [5]
					["id"] = 1600,
				},
				["portals"] = {
					"Socrethar the Eternal", -- [1]
					"portals", -- [2]
					"Portals Move", -- [3]
					138, -- [4]
					"Interface\\Icons\\Spell_Arcane_PortalOrgrimmar", -- [5]
					["id"] = 1794,
				},
				["193018"] = {
					"King Deepbeard", -- [1]
					"193018", -- [2]
					"Gaseous Bubbles", -- [3]
					12, -- [4]
					893778, -- [5]
					["id"] = 1812,
				},
				["196376"] = {
					"Archdruid Glaidalis", -- [1]
					"196376", -- [2]
					"Grievous Tear", -- [3]
					5, -- [4]
					132133, -- [5]
					["id"] = 1836,
				},
				["55931"] = {
					"Prince Taldaram", -- [1]
					"55931", -- [2]
					"Conjure Flame Sphere", -- [3]
					10, -- [4]
					135824, -- [5]
					["id"] = 1966,
				},
				["209270"] = {
					"Gul'dan", -- [1]
					"209270", -- [2]
					"Eye of Gul'dan", -- [3]
					60, -- [4]
					136210, -- [5]
					["id"] = 1866,
				},
				["122754"] = {
					"Garalon", -- [1]
					"122754", -- [2]
					"Fury", -- [3]
					30, -- [4]
					237553, -- [5]
					["id"] = 1463,
				},
				["222761"] = {
					"Star Augur Etraeus", -- [1]
					"222761", -- [2]
					"Big Bang", -- [3]
					201.5, -- [4]
					1029583, -- [5]
					["id"] = 1863,
				},
				["206896"] = {
					"Gul'dan", -- [1]
					"206896", -- [2]
					"Torn Soul: Onslaught", -- [3]
					30, -- [4]
					607512, -- [5]
					["id"] = 1866,
				},
				["122784"] = {
					"Amber-Shaper Un'sok", -- [1]
					"122784", -- [2]
					"Reshape Life (1)", -- [3]
					20, -- [4]
					463485, -- [5]
					["id"] = 1499,
				},
				["138334"] = {
					"Ra-den", -- [1]
					"138334", -- [2]
					"Fatal Strike", -- [3]
					10, -- [4]
					651728, -- [5]
					["id"] = 1580,
				},
				["-12727"] = {
					"Ashgolm", -- [1]
					"-12727", -- [2]
					"Countermeasures", -- [3]
					7.5, -- [4]
					"Interface\\Icons\\ability_monk_counteractmagic", -- [5]
					["id"] = 1816,
				},
				["228025"] = {
					"Opera Hall: Beautiful Beast", -- [1]
					"228025", -- [2]
					"Heat Wave", -- [3]
					30, -- [4]
					136196, -- [5]
					["id"] = 1957,
				},
				["174404"] = {
					"Highmaul Trash", -- [1]
					"174404", -- [2]
					"Frozen Core: Mcdar*", -- [3]
					20, -- [4]
					"Interface\\Icons\\spell_frost_frozenorb", -- [5]
					["id"] = 1723,
				},
				["134380"] = {
					"Ji-Kun", -- [1]
					"134380", -- [2]
					"Quills", -- [3]
					60, -- [4]
					"Interface\\Icons\\Ability_Hunter_Pet_DragonHawk", -- [5]
					["id"] = 1573,
				},
				["228565"] = {
					"Helya-TrialOfValor", -- [1]
					"228565", -- [2]
					"Corrupted Breath", -- [3]
					19.5, -- [4]
					136195, -- [5]
					["id"] = 2008,
				},
				["183963"] = {
					"Archimonde", -- [1]
					"183963", -- [2]
					"Light of the Naaru", -- [3]
					10, -- [4]
					"Interface\\Icons\\Spell_Holy_SurgeOfLight", -- [5]
					["id"] = 1799,
				},
				["-12527"] = {
					"Naraxas", -- [1]
					"-12527", -- [2]
					"Wormspeaker Devout", -- [3]
					10, -- [4]
					136189, -- [5]
					["id"] = 1792,
				},
				["203096"] = {
					"Nythendra", -- [1]
					"203096", -- [2]
					"Rot", -- [3]
					5.8, -- [4]
					136134, -- [5]
					["id"] = 1853,
				},
				["100714"] = {
					"Ragnaros", -- [1]
					"100714", -- [2]
					"Cloudburst", -- [3]
					51, -- [4]
					136032, -- [5]
					["id"] = 1203,
				},
				["stomp_boss"] = {
					"Morchok", -- [1]
					"stomp_boss", -- [2]
					"Stomp", -- [3]
					11, -- [4]
					"Interface\\Icons\\INV_Misc_Apexis_Crystal", -- [5]
					["id"] = 1292,
				},
				["209034"] = {
					"Xavius", -- [1]
					"209034", -- [2]
					"Bonds of Terror", -- [3]
					7.5, -- [4]
					1396973, -- [5]
					["id"] = 1864,
				},
				["229307"] = {
					"Nightbane", -- [1]
					"229307", -- [2]
					"Reverberating Shadows", -- [3]
					16.5, -- [4]
					462324, -- [5]
					["id"] = 2031,
				},
				["196392"] = {
					"Ivanyr", -- [1]
					"196392", -- [2]
					"Overcharge Mana", -- [3]
					37.5, -- [4]
					136208, -- [5]
					["id"] = 1827,
				},
				["183254"] = {
					"Archimonde", -- [1]
					"183254", -- [2]
					"Allure of Flames", -- [3]
					30, -- [4]
					"Interface\\Icons\\Spell_Fire_FelFlameStrike", -- [5]
					["id"] = 1799,
				},
				["99432"] = {
					"Alysrazor", -- [1]
					"99432", -- [2]
					"Burnout", -- [3]
					33, -- [4]
					135867, -- [5]
					["id"] = 1206,
				},
				["117975"] = {
					"Protectors of the Endless", -- [1]
					"117975", -- [2]
					"Expel Corruption", -- [3]
					6, -- [4]
					136211, -- [5]
					["id"] = 1409,
				},
				["229945"] = {
					"Gul'dan", -- [1]
					"229945", -- [2]
					"Fel Obelisk", -- [3]
					23, -- [4]
					1118739, -- [5]
					["id"] = 1866,
				},
				["185345"] = {
					"Shadow-Lord Iskar", -- [1]
					"185345", -- [2]
					"Shadow Riposte", -- [3]
					9.5, -- [4]
					"Interface\\Icons\\Ability_Warrior_Riposte", -- [5]
					["id"] = 1788,
				},
				["156793"] = {
					"Ranjit", -- [1]
					"156793", -- [2]
					"Four Winds", -- [3]
					36, -- [4]
					1029585, -- [5]
					["id"] = 1698,
				},
				["72037"] = {
					"Blood Prince Council", -- [1]
					"72037", -- [2]
					"Next Shock", -- [3]
					20, -- [4]
					136022, -- [5]
					["id"] = 1095,
				},
				["210273"] = {
					"Gul'dan", -- [1]
					"210273", -- [2]
					"Fel Obelisk", -- [3]
					23, -- [4]
					1118739, -- [5]
					["id"] = 1866,
				},
				["155080"] = {
					"Gruul", -- [1]
					"155080", -- [2]
					"Inferno Slice (1)", -- [3]
					14.5, -- [4]
					"Interface\\Icons\\Spell_Fire_FlameBlades", -- [5]
					["id"] = 1691,
				},
				["bats"] = {
					"Tortos", -- [1]
					"bats", -- [2]
					"Summon Bats", -- [3]
					46, -- [4]
					"Interface\\Icons\\Ability_Hunter_Pet_Bat", -- [5]
					["id"] = 1565,
				},
				["193093"] = {
					"King Deepbeard", -- [1]
					"193093", -- [2]
					"Ground Slam", -- [3]
					6, -- [4]
					132318, -- [5]
					["id"] = 1812,
				},
				["70351"] = {
					"Professor Putricide", -- [1]
					"70351", -- [2]
					"Next ooze", -- [3]
					25, -- [4]
					"Interface\\Icons\\Spell_Shadow_UnstableAffliction_1", -- [5]
					["id"] = 1102,
				},
				["63631"] = {
					"Mimiron", -- [1]
					"63631", -- [2]
					"Next Shock Blast", -- [3]
					30, -- [4]
					"Interface\\Icons\\Spell_Nature_GroundingTotem", -- [5]
					["id"] = 1138,
				},
				["192072"] = {
					"Warlord Parjesh", -- [1]
					"192072", -- [2]
					"Call Reinforcements", -- [3]
					5, -- [4]
					298644, -- [5]
					["id"] = 1810,
				},
				["206480"] = {
					"Tichondrius", -- [1]
					"206480", -- [2]
					"Carrion Plague (1)", -- [3]
					7, -- [4]
					1029009, -- [5]
					["id"] = 1862,
				},
				["157000"] = {
					"Blackhand", -- [1]
					"157000", -- [2]
					"Attach Slag Bombs", -- [3]
					12, -- [4]
					"Interface\\Icons\\ability_blackhand_attachedslagbombs", -- [5]
					["id"] = 1704,
				},
				["214505"] = {
					"Cenarius", -- [1]
					"214505", -- [2]
					"Entangling Nightmares", -- [3]
					51, -- [4]
					1357814, -- [5]
					["id"] = 1877,
				},
				["122842"] = {
					"Blade Lord Ta'yak", -- [1]
					"122842", -- [2]
					"Tempest Slash", -- [3]
					9.8, -- [4]
					236154, -- [5]
					["id"] = 1504,
				},
				["201354"] = {
					"Shivermaw", -- [1]
					"201354", -- [2]
					"Tail Sweep", -- [3]
					17, -- [4]
					134307, -- [5]
					["id"] = 1845,
				},
				["208689"] = {
					"Il'gynoth", -- [1]
					"208689", -- [2]
					"Ground Slam", -- [3]
					11.5, -- [4]
					254105, -- [5]
					["id"] = 1873,
				},
				["134920"] = {
					"Tortos", -- [1]
					"134920", -- [2]
					"Quake Stomp (1)", -- [3]
					28, -- [4]
					"Interface\\Icons\\Spell_Nature_Earthquake", -- [5]
					["id"] = 1565,
				},
				["176121"] = {
					"The Blast Furnace", -- [1]
					"176121", -- [2]
					"Volatile Fire on YOU!", -- [3]
					14.9989999999998, -- [4]
					"Interface\\Icons\\Spell_Fire_LavaSpawn", -- [5]
					["id"] = 1690,
				},
				["143280"] = {
					"Paragons of the Klaxxi", -- [1]
					"143280", -- [2]
					"Bloodletting", -- [3]
					6, -- [4]
					878217, -- [5]
					["id"] = 1593,
				},
				["123495"] = {
					"Garalon", -- [1]
					"123495", -- [2]
					"Mend Leg", -- [3]
					30, -- [4]
					136043, -- [5]
					["id"] = 1463,
				},
				["58663"] = {
					"Archavon the Stone Watcher", -- [1]
					"58663", -- [2]
					"Stomp", -- [3]
					47, -- [4]
					132318, -- [5]
					["id"] = 1126,
				},
				["roll"] = {
					"Spine of Deathwing", -- [1]
					"roll", -- [2]
					"Roll", -- [3]
					10, -- [4]
					"Interface\\Icons\\achievement_bg_returnxflags_def_wsg", -- [5]
					["id"] = 1291,
				},
				["218415"] = {
					"Il'gynoth", -- [1]
					"218415", -- [2]
					"Death Blossom", -- [3]
					60, -- [4]
					1357815, -- [5]
					["id"] = 1873,
				},
				["143385"] = {
					"Siegecrafter Blackfuse", -- [1]
					"143385", -- [2]
					"Electrostatic Charge", -- [3]
					17, -- [4]
					237587, -- [5]
					["id"] = 1601,
				},
				["209443"] = {
					"Xavius", -- [1]
					"209443", -- [2]
					"Nightmare Infusion", -- [3]
					62, -- [4]
					1396976, -- [5]
					["id"] = 1864,
				},
				["210346"] = {
					"Cenarius", -- [1]
					"210346", -- [2]
					"Aura of Dread Thorns", -- [3]
					6, -- [4]
					1357798, -- [5]
					["id"] = 1877,
				},
				["236480"] = {
					"Sisters of the Moon", -- [1]
					"236480", -- [2]
					"Glaive Storm", -- [3]
					42.6, -- [4]
					132330, -- [5]
					["id"] = 2050,
				},
				["19408"] = {
					"Magmadar", -- [1]
					"19408", -- [2]
					"Panic", -- [3]
					9.7, -- [4]
					136147, -- [5]
					["id"] = 664,
				},
				["180004"] = {
					"Tyrant Velhari", -- [1]
					"180004", -- [2]
					"Enforcer's Onslaught", -- [3]
					18, -- [4]
					"Interface\\Icons\\inv_knife_1h_firelandsraid_d_01", -- [5]
					["id"] = 1784,
				},
				["144328"] = {
					"Kor'kron Dark Shaman", -- [1]
					"144328", -- [2]
					"Iron Tomb", -- [3]
					31, -- [4]
					134385, -- [5]
					["id"] = 1606,
				},
				["154110"] = {
					"Araknath", -- [1]
					"154110", -- [2]
					"Smash", -- [3]
					8.5, -- [4]
					132154, -- [5]
					["id"] = 1699,
				},
				["233441"] = {
					"Demonic Inquisition", -- [1]
					"233441", -- [2]
					"Bone Saw", -- [3]
					60.5, -- [4]
					999952, -- [5]
					["id"] = 2048,
				},
				["208165"] = {
					"Talixae Flamewreath", -- [1]
					"208165", -- [2]
					"Withering Soul", -- [3]
					13, -- [4]
					460700, -- [5]
					["id"] = 1869,
				},
				["204767"] = {
					"Dragons of Nightmare", -- [1]
					"204767", -- [2]
					"Shade: Corrupted Breath", -- [3]
					17, -- [4]
					136123, -- [5]
					["id"] = 1854,
				},
				["69483"] = {
					"Deathspeaker High Priest", -- [1]
					"69483", -- [2]
					"Dark Reckoning", -- [3]
					8, -- [4]
					"Interface\\Icons\\Spell_Shadow_DevouringPlague.", -- [5]
					["id"] = 1100,
				},
				["184681"] = {
					"Hellfire High Council", -- [1]
					"184681", -- [2]
					"Wailing Horror (1)", -- [3]
					75, -- [4]
					"Interface\\Icons\\Ability_Rogue_EnvelopingShadows", -- [5]
					["id"] = 1798,
				},
				["143428"] = {
					"Thok the Bloodthirsty", -- [1]
					"143428", -- [2]
					"Tail Lash", -- [3]
					10, -- [4]
					132109, -- [5]
					["id"] = 1599,
				},
				["236519"] = {
					"Sisters of the Moon", -- [1]
					"236519", -- [2]
					"Moon Burn", -- [3]
					9.4, -- [4]
					136057, -- [5]
					["id"] = 2050,
				},
				["137162"] = {
					"Jin'rokh the Breaker", -- [1]
					"137162", -- [2]
					"Static Burst", -- [3]
					13, -- [4]
					"Interface\\Icons\\Spell_Nature_LightningOverload", -- [5]
					["id"] = 1577,
				},
				["188114"] = {
					"Rokmora", -- [1]
					"188114", -- [2]
					"Shatter", -- [3]
					24, -- [4]
					451165, -- [5]
					["id"] = 1790,
				},
				["163312"] = {
					"Tectus", -- [1]
					"163312", -- [2]
					"Raving Assault", -- [3]
					13, -- [4]
					"Interface\\Icons\\Spell_Shadow_UnholyFrenzy", -- [5]
					["id"] = 1722,
				},
				["119414"] = {
					"Sha of Fear", -- [1]
					"119414", -- [2]
					"Breath of Fear", -- [3]
					33, -- [4]
					252997, -- [5]
					["id"] = 1431,
				},
				["201146"] = {
					"Kaahrj", -- [1]
					"201146", -- [2]
					"Hysteria", -- [3]
					15, -- [4]
					136184, -- [5]
					["id"] = 1846,
				},
				["155247"] = {
					"Beastlord Darmac", -- [1]
					"155247", -- [2]
					"Stampede", -- [3]
					15, -- [4]
					"Interface\\Icons\\Ability_WarStomp", -- [5]
					["id"] = 1694,
				},
				["158200"] = {
					"Twin Ogron", -- [1]
					"158200", -- [2]
					"Quake", -- [3]
					12, -- [4]
					"Interface\\Icons\\spell_shaman_earthquake", -- [5]
					["id"] = 1719,
				},
				["orb_ranged"] = {
					"Helya-TrialOfValor", -- [1]
					"orb_ranged", -- [2]
					"Ranged Orb (1)", -- [3]
					31, -- [4]
					1097742, -- [5]
					["id"] = 2008,
				},
				["227789"] = {
					"Maiden of Virtue", -- [1]
					"227789", -- [2]
					"Sacred Ground", -- [3]
					24, -- [4]
					135926, -- [5]
					["id"] = 1954,
				},
				["bwcbSereneriversroth loves you"] = {
					"Bars", -- [1]
					"bwcbSereneriversroth loves you", -- [2]
					"Serenerivers: roth loves you", -- [3]
					780, -- [4]
					"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
					["id"] = 1800,
				},
				["181912"] = {
					"Shadow-Lord Iskar", -- [1]
					"181912", -- [2]
					"Focused Blast", -- [3]
					20, -- [4]
					"Interface\\Icons\\ability_felarakkoa_focusedblast", -- [5]
					["id"] = 1788,
				},
				["156390"] = {
					"Oregorger", -- [1]
					"156390", -- [2]
					"Explosive Shard", -- [3]
					9, -- [4]
					"Interface\\Icons\\6bf_explosive_shard", -- [5]
					["id"] = 1696,
				},
				["196805"] = {
					"Ivanyr", -- [1]
					"196805", -- [2]
					"Nether Link", -- [3]
					18, -- [4]
					429383, -- [5]
					["id"] = 1827,
				},
				["234891"] = {
					"Maiden of Vigilance", -- [1]
					"234891", -- [2]
					"Wrath of the Creators", -- [3]
					43.5, -- [4]
					135922, -- [5]
					["id"] = 2052,
				},
				["123011"] = {
					"Tsulong", -- [1]
					"123011", -- [2]
					"Terrorize", -- [3]
					5, -- [4]
					236296, -- [5]
					["id"] = 1505,
				},
				["-6327"] = {
					"Wise Mari", -- [1]
					"-6327", -- [2]
					"Next Add", -- [3]
					5, -- [4]
					135862, -- [5]
					["id"] = 1418,
				},
				["156240"] = {
					"Oregorger", -- [1]
					"156240", -- [2]
					"Acid Torrent (1)", -- [3]
					10.7, -- [4]
					"Interface\\Icons\\6bf_retched_blackrock", -- [5]
					["id"] = 1696,
				},
				["98476"] = {
					"Majordomo Staghelm", -- [1]
					"98476", -- [2]
					"Leaping Flames", -- [3]
					17.3, -- [4]
					135788, -- [5]
					["id"] = 1185,
				},
				["213166"] = {
					"Spellblade Aluriel", -- [1]
					"213166", -- [2]
					"Searing Brand", -- [3]
					18, -- [4]
					135811, -- [5]
					["id"] = 1871,
				},
				["191941"] = {
					"Tirathon Saltheril", -- [1]
					"191941", -- [2]
					"Darkstrikes", -- [3]
					22, -- [4]
					132304, -- [5]
					["id"] = 1815,
				},
				["122855"] = {
					"Tsulong", -- [1]
					"122855", -- [2]
					"Sun Breath", -- [3]
					32, -- [4]
					535045, -- [5]
					["id"] = 1505,
				},
				["181597"] = {
					"Mannoroth", -- [1]
					"181597", -- [2]
					"Mannoroth's Gaze", -- [3]
					40, -- [4]
					"Interface\\Icons\\ability_bossmannoroth_mannorothsgaze", -- [5]
					["id"] = 1795,
				},
				["180008"] = {
					"Socrethar the Eternal", -- [1]
					"180008", -- [2]
					"Reverberating Blow", -- [3]
					7, -- [4]
					"Interface\\Icons\\Ability_GolemThunderClap", -- [5]
					["id"] = 1794,
				},
				["dread_felbat"] = {
					"General Xakal", -- [1]
					"dread_felbat", -- [2]
					"Dread Felbat", -- [3]
					20, -- [4]
					"Interface\\Icons\\inv_felbatmount", -- [5]
					["id"] = 1828,
				},
				["213567"] = {
					"Spellblade Aluriel", -- [1]
					"213567", -- [2]
					"Animate: Searing Brand", -- [3]
					65, -- [4]
					135811, -- [5]
					["id"] = 1871,
				},
				["48276"] = {
					"Svala Sorrowgrave", -- [1]
					"48276", -- [2]
					"<Cast: Ritual of the Sword>", -- [3]
					26, -- [4]
					135285, -- [5]
					["id"] = 2030,
				},
				["144563"] = {
					"Sha of Pride", -- [1]
					"144563", -- [2]
					"Imprison", -- [3]
					52.5, -- [4]
					895886, -- [5]
					["id"] = 1604,
				},
				["215443"] = {
					"Elerethe Renferal", -- [1]
					"215443", -- [2]
					"Necrotic Venom", -- [3]
					22, -- [4]
					132107, -- [5]
					["id"] = 1876,
				},
				["200732"] = {
					"Dargrul", -- [1]
					"200732", -- [2]
					"Molten Crash", -- [3]
					18, -- [4]
					236253, -- [5]
					["id"] = 1793,
				},
				["192522"] = {
					"Ashgolm", -- [1]
					"192522", -- [2]
					"Fissure", -- [3]
					42, -- [4]
					1032476, -- [5]
					["id"] = 1816,
				},
				["211368"] = {
					"Cenarius", -- [1]
					"211368", -- [2]
					"Twisted Touch of Life", -- [3]
					12.1, -- [4]
					237564, -- [5]
					["id"] = 1877,
				},
				["spinner"] = {
					"Beth'tilac", -- [1]
					"spinner", -- [2]
					"Spinners #1", -- [3]
					12, -- [4]
					"Interface\\Icons\\spell_fire_moltenblood", -- [5]
					["id"] = 1197,
				},
				["163776"] = {
					"The Blast Furnace", -- [1]
					"163776", -- [2]
					"Superheated", -- [3]
					385.593999999997, -- [4]
					"Interface\\Icons\\inv_misc_ring_firelands_3", -- [5]
					["id"] = 1690,
				},
				["210296"] = {
					"Gul'dan", -- [1]
					"210296", -- [2]
					"<Cast: Resonant Barrier>", -- [3]
					6, -- [4]
					1022950, -- [5]
					["id"] = 1866,
				},
				["106371"] = {
					"Ultraxion", -- [1]
					"106371", -- [2]
					"Hour of Twilight", -- [3]
					45, -- [4]
					"Interface\\Icons\\Spell_Shadow_Twilight", -- [5]
					["id"] = 1297,
				},
				["150755"] = {
					"Gug'rokk", -- [1]
					"150755", -- [2]
					"Summon Unstable Slag", -- [3]
					20, -- [4]
					135790, -- [5]
					["id"] = 1654,
				},
				["228730"] = {
					"Helya-TrialOfValor", -- [1]
					"228730", -- [2]
					"<Cast: Tentacle Strike>", -- [3]
					6, -- [4]
					254105, -- [5]
					["id"] = 2008,
				},
				["kick_combo"] = {
					"Cordana Felsong", -- [1]
					"kick_combo", -- [2]
					"Kick Combo", -- [3]
					16, -- [4]
					574575, -- [5]
					["id"] = 1818,
				},
				["117986"] = {
					"Protectors of the Endless", -- [1]
					"117986", -- [2]
					"Defiled Ground", -- [3]
					11, -- [4]
					136158, -- [5]
					["id"] = 1409,
				},
				["192706"] = {
					"Wrath of Azshara", -- [1]
					"192706", -- [2]
					"Arcane Bomb", -- [3]
					23, -- [4]
					132861, -- [5]
					["id"] = 1814,
				},
				["156238"] = {
					"Imperator Mar'gok", -- [1]
					"156238", -- [2]
					"Arcane Wrath", -- [3]
					6, -- [4]
					"Interface\\Icons\\ability_socererking_arcanewrath", -- [5]
					["id"] = 1705,
				},
				["180199"] = {
					"Kilrogg Deadeye", -- [1]
					"180199", -- [2]
					"Shred Armor", -- [3]
					10.8, -- [4]
					"Interface\\Icons\\Ability_Warrior_Riposte", -- [5]
					["id"] = 1786,
				},
				["137458"] = {
					"Horridon", -- [1]
					"137458", -- [2]
					"Dire Call", -- [3]
					61, -- [4]
					132270, -- [5]
					["id"] = 1575,
				},
				["198641"] = {
					"Kurtalos Ravencrest", -- [1]
					"198641", -- [2]
					"Whirling Blade", -- [3]
					11, -- [4]
					132330, -- [5]
					["id"] = 1835,
				},
				["71772"] = {
					"Blood-Queen Lana'thel", -- [1]
					"71772", -- [2]
					"Air phase", -- [3]
					127, -- [4]
					"Interface\\Icons\\Spell_Nature_AstralRecal", -- [5]
					["id"] = 1103,
				},
				["189894"] = {
					"Archimonde", -- [1]
					"189894", -- [2]
					"Void Star", -- [3]
					15.8, -- [4]
					"Interface\\Icons\\Spell_Shadow_Shadowfury", -- [5]
					["id"] = 1799,
				},
				["30500"] = {
					"Grand Warlock Nethekurse", -- [1]
					"30500", -- [2]
					"Death Coil", -- [3]
					12, -- [4]
					136145, -- [5]
					["id"] = 1936,
				},
				["152801"] = {
					"Nhallish", -- [1]
					"152801", -- [2]
					"Void Vortex", -- [3]
					23, -- [4]
					236296, -- [5]
					["id"] = 1688,
				},
				["211192"] = {
					"Cenarius", -- [1]
					"211192", -- [2]
					"<Cast: Rotten Breath>", -- [3]
					5.5, -- [4]
					1357794, -- [5]
					["id"] = 1877,
				},
				["70123"] = {
					"Sindragosa", -- [1]
					"70123", -- [2]
					"Icy Grip", -- [3]
					34, -- [4]
					"Interface\\Icons\\Spell_Frost_ArcticWinds", -- [5]
					["id"] = 1105,
				},
				["153067"] = {
					"Nhallish", -- [1]
					"153067", -- [2]
					"Void Devastation", -- [3]
					65.7, -- [4]
					535592, -- [5]
					["id"] = 1688,
				},
				["211073"] = {
					"Cenarius", -- [1]
					"211073", -- [2]
					"Desiccating Stomp", -- [3]
					33, -- [4]
					1357801, -- [5]
					["id"] = 1877,
				},
				["194966"] = {
					"Amalgam of Souls", -- [1]
					"194966", -- [2]
					"Soul Echoes", -- [3]
					15.7, -- [4]
					463284, -- [5]
					["id"] = 1832,
				},
				["97282"] = {
					"Lord Rhyolith", -- [1]
					"97282", -- [2]
					"Stomp", -- [3]
					15, -- [4]
					132847, -- [5]
					["id"] = 1204,
				},
				["181582"] = {
					"Gorefiend", -- [1]
					"181582", -- [2]
					"Bellowing Shout", -- [3]
					13.5, -- [4]
					"Interface\\Icons\\ability_fomor_boss_shout", -- [5]
					["id"] = 1783,
				},
				["drain"] = {
					"Warlord Zon'ozz", -- [1]
					"drain", -- [2]
					"Psychic Drain", -- [3]
					17, -- [4]
					"Interface\\Icons\\Ability_Rogue_Shadowstep", -- [5]
					["id"] = 1294,
				},
				["airphase"] = {
					"Sindragosa", -- [1]
					"airphase", -- [2]
					"Next air phase", -- [3]
					63, -- [4]
					"Interface\\Icons\\INV_Misc_Head_Dragon_Blue", -- [5]
					["id"] = 1105,
				},
				["227736"] = {
					"Moroes", -- [1]
					"227736", -- [2]
					"Vanish", -- [3]
					7, -- [4]
					132331, -- [5]
					["id"] = 1961,
				},
				["121949"] = {
					"Amber-Shaper Un'sok", -- [1]
					"121949", -- [2]
					"Parasitic Growth", -- [3]
					24, -- [4]
					576313, -- [5]
					["id"] = 1499,
				},
				["136216"] = {
					"Primordius", -- [1]
					"136216", -- [2]
					"Caustic Gas", -- [3]
					12, -- [4]
					236271, -- [5]
					["id"] = 1574,
				},
				["berserk"] = {
					"Conclave of Wind", -- [1]
					"berserk", -- [2]
					"Berserk", -- [3]
					480, -- [4]
					"Interface\\Icons\\Spell_Shadow_UnholyFrenzy", -- [5]
					["id"] = 1035,
				},
				["231350"] = {
					"Odyn-TrialOfValor", -- [1]
					"231350", -- [2]
					"Radiant Smite", -- [3]
					7.5, -- [4]
					1360764, -- [5]
					["id"] = 1958,
				},
				["70981"] = {
					"Blood Prince Council", -- [1]
					"70981", -- [2]
					"Next health swap", -- [3]
					45, -- [4]
					237513, -- [5]
					["id"] = 1095,
				},
				["137408"] = {
					"Twin Consorts", -- [1]
					"137408", -- [2]
					"Fan of Flames", -- [3]
					15, -- [4]
					"Interface\\Icons\\inv_offhand_1h_panstart_a_02", -- [5]
					["id"] = 1560,
				},
				["201392"] = {
					"Millificent Manastorm", -- [1]
					"201392", -- [2]
					"Thorium Rocket Chicken", -- [3]
					24, -- [4]
					656513, -- [5]
					["id"] = 1847,
				},
				["69762"] = {
					"Sindragosa", -- [1]
					"69762", -- [2]
					"Unchained Magic", -- [3]
					15, -- [4]
					"Interface\\Icons\\Spell_Arcane_FocusedPower", -- [5]
					["id"] = 1105,
				},
				["-11269"] = {
					"Kilrogg Deadeye", -- [1]
					"-11269", -- [2]
					"Hulking Terror", -- [3]
					15, -- [4]
					"Interface\\Icons\\spell_nature_shamanrage", -- [5]
					["id"] = 1786,
				},
				["214167"] = {
					"Star Augur Etraeus", -- [1]
					"214167", -- [2]
					"Gravitational Pull: Plinixela", -- [3]
					5, -- [4]
					1041234, -- [5]
					["id"] = 1863,
				},
				["103434"] = {
					"Warlord Zon'ozz", -- [1]
					"103434", -- [2]
					"Disrupting Shadows", -- [3]
					23, -- [4]
					"Interface\\Icons\\Spell_Shadow_Shadowfury", -- [5]
					["id"] = 1294,
				},
				["117697"] = {
					"The Spirit Kings", -- [1]
					"117697", -- [2]
					"Shield of Darkness", -- [3]
					40, -- [4]
					"Interface\\Icons\\Spell_Shadow_SacrificialShield", -- [5]
					["id"] = 1436,
				},
				["230345"] = {
					"Goroth", -- [1]
					"230345", -- [2]
					"Crashing Comet", -- [3]
					8.5, -- [4]
					840194, -- [5]
					["id"] = 2032,
				},
				["181307"] = {
					"Kormrok", -- [1]
					"181307", -- [2]
					"Foul Crush", -- [3]
					21, -- [4]
					"Interface\\Icons\\Spell_Shadow_Requiem", -- [5]
					["id"] = 1787,
				},
				["blazing"] = {
					"Valithria Dreamwalker", -- [1]
					"blazing", -- [2]
					"Blazing Skeleton", -- [3]
					50, -- [4]
					"Interface\\Icons\\Achievement_Zone_HellfirePeninsula_01", -- [5]
					["id"] = 1098,
				},
				["136478"] = {
					"Lei Shen", -- [1]
					"136478", -- [2]
					"Fusion Slash", -- [3]
					46, -- [4]
					"Interface\\Icons\\Spell_Nature_ThunderClap", -- [5]
					["id"] = 1579,
				},
				["138485"] = {
					"Dark Animus", -- [1]
					"138485", -- [2]
					"Crimson Wake on YOU!", -- [3]
					30, -- [4]
					538744, -- [5]
					["id"] = 1576,
				},
				["161328"] = {
					"Ko'ragh", -- [1]
					"161328", -- [2]
					"Suppression Field", -- [3]
					15, -- [4]
					"Interface\\Icons\\Spell_Fire_FelFlameStrike", -- [5]
					["id"] = 1723,
				},
				["100479"] = {
					"Ragnaros", -- [1]
					"100479", -- [2]
					"Breadth of Frost", -- [3]
					34, -- [4]
					464484, -- [5]
					["id"] = 1203,
				},
				["212735"] = {
					"Spellblade Aluriel", -- [1]
					"212735", -- [2]
					"Detonate: Mark of Frost", -- [3]
					51, -- [4]
					609814, -- [5]
					["id"] = 1871,
				},
				["arena_sweeper"] = {
					"Kargath Bladefist", -- [1]
					"arena_sweeper", -- [2]
					"Arena Sweeper", -- [3]
					55, -- [4]
					"Interface\\Icons\\ability_kick", -- [5]
					["id"] = 1721,
				},
				["155209"] = {
					"The Blast Furnace", -- [1]
					"155209", -- [2]
					"Blast", -- [3]
					30, -- [4]
					"Interface\\Icons\\ability_foundryraid_blastwave", -- [5]
					["id"] = 1690,
				},
				["187180"] = {
					"Archimonde", -- [1]
					"187180", -- [2]
					"Demonic Feedback", -- [3]
					35, -- [4]
					"Interface\\Icons\\ability_bossgorefiend_touchofdoom", -- [5]
					["id"] = 1799,
				},
				["nextphase"] = {
					"Hagara the Stormbinder", -- [1]
					"nextphase", -- [2]
					"Lightning or Frost", -- [3]
					30, -- [4]
					"Interface\\Icons\\Spell_Frost_IceShock", -- [5]
					["id"] = 1296,
				},
				["180221"] = {
					"Socrethar the Eternal", -- [1]
					"180221", -- [2]
					"Volatile Fel Orb", -- [3]
					13, -- [4]
					"Interface\\Icons\\achievement_zone_cataclysmgreen", -- [5]
					["id"] = 1794,
				},
				["209915"] = {
					"Il'gynoth", -- [1]
					"209915", -- [2]
					"Stuff of Nightmares", -- [3]
					60, -- [4]
					136174, -- [5]
					["id"] = 1873,
				},
				["108044"] = {
					"Warmaster Blackhorn", -- [1]
					"108044", -- [2]
					"Disrupting Roar", -- [3]
					20, -- [4]
					"Interface\\Icons\\Ability_Warrior_Rampage", -- [5]
					["id"] = 1298,
				},
				["bwcbSereneriversalex sucks"] = {
					"Bars", -- [1]
					"bwcbSereneriversalex sucks", -- [2]
					"Serenerivers: alex sucks", -- [3]
					600, -- [4]
					"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
					["id"] = 1800,
				},
				["136193"] = {
					"Iron Qon", -- [1]
					"136193", -- [2]
					"Arcing Lightning on YOU!", -- [3]
					30, -- [4]
					135990, -- [5]
					["id"] = 1559,
				},
				["221164"] = {
					"Nighthold Trash", -- [1]
					"221164", -- [2]
					"<Cast: Fulminate>", -- [3]
					5, -- [4]
					462651, -- [5]
					["id"] = 1865,
				},
				["220871"] = {
					"Advisor Vandros", -- [1]
					"220871", -- [2]
					"Unstable Mana: Jukebôx*", -- [3]
					8, -- [4]
					1391677, -- [5]
					["id"] = 1829,
				},
				["209158"] = {
					"Xavius", -- [1]
					"209158", -- [2]
					"Blackening Soul", -- [3]
					10, -- [4]
					1396968, -- [5]
					["id"] = 1864,
				},
				["-7643"] = {
					"Twin Consorts", -- [1]
					"-7643", -- [2]
					"Tears of the Sun", -- [3]
					28, -- [4]
					"Interface\\ICONS\\PALADIN_HOLY.BLP", -- [5]
					["id"] = 1560,
				},
				["ability_cd"] = {
					"Sha of Fear", -- [1]
					"ability_cd", -- [2]
					"Huddle or Spout or Strike", -- [3]
					10, -- [4]
					538567, -- [5]
					["id"] = 1431,
				},
				["233196"] = {
					"Mephistroth", -- [1]
					"233196", -- [2]
					"Demonic Upheaval", -- [3]
					3.5, -- [4]
					1118739, -- [5]
					["id"] = 2039,
				},
				["211927"] = {
					"Chronomatic Anomaly", -- [1]
					"211927", -- [2]
					"Power Overwhelming", -- [3]
					60, -- [4]
					1125916, -- [5]
					["id"] = 1865,
				},
				["212794"] = {
					"Tichondrius", -- [1]
					"212794", -- [2]
					"Brand of Argus (1)", -- [3]
					15, -- [4]
					841219, -- [5]
					["id"] = 1862,
				},
				["160013"] = {
					"Brackenspore", -- [1]
					"160013", -- [2]
					"Decay (2)", -- [3]
					9.5, -- [4]
					"Interface\\Icons\\Spell_Nature_WispSplodeGreen", -- [5]
					["id"] = 1720,
				},
				["158057"] = {
					"Twin Ogron", -- [1]
					"158057", -- [2]
					"Enfeebling Roar", -- [3]
					33, -- [4]
					"Interface\\Icons\\Ability_Warrior_BattleShout", -- [5]
					["id"] = 1719,
				},
				["216024"] = {
					"Tichondrius", -- [1]
					"216024", -- [2]
					"Volatile Wound on YOU!", -- [3]
					8, -- [4]
					135734, -- [5]
					["id"] = 1862,
				},
				["-7958"] = {
					"The Fallen Protectors", -- [1]
					"-7958", -- [2]
					"Defiled Ground", -- [3]
					9, -- [4]
					463566, -- [5]
					["id"] = 1598,
				},
				["143337"] = {
					"Paragons of the Klaxxi", -- [1]
					"143337", -- [2]
					"Mutate", -- [3]
					23, -- [4]
					878216, -- [5]
					["id"] = 1593,
				},
				["phase"] = {
					"Professor Putricide", -- [1]
					"phase", -- [2]
					"Next Phase", -- [3]
					45, -- [4]
					"Interface\\Icons\\achievement_boss_profputricide", -- [5]
					["id"] = 1102,
				},
				["148677"] = {
					"Paragons of the Klaxxi", -- [1]
					"148677", -- [2]
					"Reave", -- [3]
					42, -- [4]
					132369, -- [5]
					["id"] = 1593,
				},
				["145065"] = {
					"Garrosh Hellscream", -- [1]
					"145065", -- [2]
					"Mind Control", -- [3]
					29, -- [4]
					892448, -- [5]
					["id"] = 1623,
				},
				["218124"] = {
					"Elerethe Renferal", -- [1]
					"218124", -- [2]
					"Violent Winds", -- [3]
					53, -- [4]
					1029595, -- [5]
					["id"] = 1876,
				},
				["add"] = {
					"High Sage Viryx", -- [1]
					"add", -- [2]
					"Add", -- [3]
					32, -- [4]
					"Interface\\Icons\\icon_petfamily_mechanical", -- [5]
					["id"] = 1701,
				},
				["236305"] = {
					"Sisters of the Moon", -- [1]
					"236305", -- [2]
					"Incorporeal Shot", -- [3]
					48.3, -- [4]
					959793, -- [5]
					["id"] = 2050,
				},
				["101304"] = {
					"Lord Rhyolith", -- [1]
					"101304", -- [2]
					"Superheated", -- [3]
					300, -- [4]
					135830, -- [5]
					["id"] = 1204,
				},
				["136366"] = {
					"Lei Shen", -- [1]
					"136366", -- [2]
					"Bouncing Bolt", -- [3]
					8.5, -- [4]
					"INTERFACE\\ICONS\\spell_shaman_measuredinsight", -- [5]
					["id"] = 1579,
				},
				["185021"] = {
					"Hellfire Assault", -- [1]
					"185021", -- [2]
					"Call to Arms!", -- [3]
					9, -- [4]
					"Interface\\Icons\\Achievement_BG_KillFlagCarriers_grabFlag_CapIt", -- [5]
					["id"] = 1778,
				},
				["162617"] = {
					"Rocketspark and Borka", -- [1]
					"162617", -- [2]
					"Slam", -- [3]
					6.5, -- [4]
					236316, -- [5]
					["id"] = 1715,
				},
				["explosion_by_you"] = {
					"Amber-Shaper Un'sok", -- [1]
					"explosion_by_you", -- [2]
					"You start casting...", -- [3]
					15, -- [4]
					236305, -- [5]
					["id"] = 1499,
				},
				["218438"] = {
					"High Botanist Tel'arn", -- [1]
					"218438", -- [2]
					"Controlled Chaos", -- [3]
					35, -- [4]
					429383, -- [5]
					["id"] = 1886,
				},
				["116157"] = {
					"Feng the Accursed", -- [1]
					"116157", -- [2]
					"Lightning Fists", -- [3]
					12, -- [4]
					"Interface\\Icons\\Spell_Shaman_StaticShock", -- [5]
					["id"] = 1390,
				},
				["46192"] = {
					"Priestess Delrissa", -- [1]
					"46192", -- [2]
					"Renew: Priestess Delrissa", -- [3]
					15, -- [4]
					135953, -- [5]
					["id"] = 1895,
				},
				["164357"] = {
					"Witherbark", -- [1]
					"164357", -- [2]
					"Parched Gasp", -- [3]
					7, -- [4]
					796638, -- [5]
					["id"] = 1746,
				},
				["181299"] = {
					"Kormrok", -- [1]
					"181299", -- [2]
					"Grasping Hands", -- [3]
					51, -- [4]
					"Interface\\Icons\\ability_bossfelmagnaron_hand", -- [5]
					["id"] = 1787,
				},
				["117436"] = {
					"Protectors of the Endless", -- [1]
					"117436", -- [2]
					"Lightning Prison", -- [3]
					25, -- [4]
					"Interface\\Icons\\Spell_Shaman_StaticShock", -- [5]
					["id"] = 1409,
				},
				["13323"] = {
					"Priestess Delrissa", -- [1]
					"13323", -- [2]
					"Polymorph: Gamestar*", -- [3]
					8, -- [4]
					136071, -- [5]
					["id"] = 1895,
				},
				["201355"] = {
					"Shivermaw", -- [1]
					"201355", -- [2]
					"Wing Buffet", -- [3]
					20.5, -- [4]
					134155, -- [5]
					["id"] = 1845,
				},
				["206788"] = {
					"Trilliax", -- [1]
					"206788", -- [2]
					"Toxic Slice", -- [3]
					11, -- [4]
					237360, -- [5]
					["id"] = 1867,
				},
				["201672"] = {
					"Shivermaw", -- [1]
					"201672", -- [2]
					"Relentless Storm", -- [3]
					9, -- [4]
					1033907, -- [5]
					["id"] = 1845,
				},
				["142564"] = {
					"Paragons of the Klaxxi", -- [1]
					"142564", -- [2]
					"Encase in Amber", -- [3]
					25, -- [4]
					463485, -- [5]
					["id"] = 1593,
				},
				["162058"] = {
					"Skylord Tovra", -- [1]
					"162058", -- [2]
					"Spinning Spear", -- [3]
					16.5, -- [4]
					135130, -- [5]
					["id"] = 1736,
				},
				["221606"] = {
					"Gul'dan", -- [1]
					"221606", -- [2]
					"Flames of Sargeras", -- [3]
					27.5, -- [4]
					1035051, -- [5]
					["id"] = 1866,
				},
				["203147"] = {
					"Dragons of Nightmare", -- [1]
					"203147", -- [2]
					"Nightmare Blast", -- [3]
					16, -- [4]
					237561, -- [5]
					["id"] = 1854,
				},
				["235751"] = {
					"Agronox", -- [1]
					"235751", -- [2]
					"Timber Smash", -- [3]
					6.2, -- [4]
					132318, -- [5]
					["id"] = 2055,
				},
				["198073"] = {
					"Smashspite", -- [1]
					"198073", -- [2]
					"Earthshaking Stomp", -- [3]
					13.1, -- [4]
					132368, -- [5]
					["id"] = 1834,
				},
				["209597"] = {
					"Grand Magistrix Elisande", -- [1]
					"209597", -- [2]
					"Conflexive Burst (1)", -- [3]
					48, -- [4]
					1044088, -- [5]
					["id"] = 1872,
				},
				["218148"] = {
					"High Botanist Tel'arn", -- [1]
					"218148", -- [2]
					"Solar Collapse", -- [3]
					10, -- [4]
					135981, -- [5]
					["id"] = 1886,
				},
				["235267"] = {
					"Maiden of Vigilance", -- [1]
					"235267", -- [2]
					"Mass Instability", -- [3]
					22, -- [4]
					535593, -- [5]
					["id"] = 2052,
				},
				["134366"] = {
					"Ji-Kun", -- [1]
					"134366", -- [2]
					"Talon Rake", -- [3]
					24, -- [4]
					"Interface\\Icons\\Ability_Rogue_Dismantle", -- [5]
					["id"] = 1573,
				},
				["231854"] = {
					"Harjatan the Bludger", -- [1]
					"231854", -- [2]
					"Unchecked Rage", -- [3]
					20.7, -- [4]
					132344, -- [5]
					["id"] = 2036,
				},
				["116364"] = {
					"Feng the Accursed", -- [1]
					"116364", -- [2]
					"Arcane Velocity (2)", -- [3]
					28, -- [4]
					"Interface\\Icons\\Spell_Arcane_ArcaneTorrent", -- [5]
					["id"] = 1390,
				},
				["100744"] = {
					"Alysrazor", -- [1]
					"100744", -- [2]
					"Firestorm", -- [3]
					95, -- [4]
					237588, -- [5]
					["id"] = 1206,
				},
				["122752"] = {
					"Tsulong", -- [1]
					"122752", -- [2]
					"Shadow Breath", -- [3]
					10, -- [4]
					236302, -- [5]
					["id"] = 1505,
				},
				["206883"] = {
					"Gul'dan", -- [1]
					"206883", -- [2]
					"<Cast: Soul Vortex>", -- [3]
					3, -- [4]
					607512, -- [5]
					["id"] = 1866,
				},
				["224632"] = {
					"Nighthold Trash", -- [1]
					"224632", -- [2]
					"Heavenly Crash: Kharonxela", -- [3]
					5, -- [4]
					236168, -- [5]
					["id"] = 1863,
				},
				["143574"] = {
					"Immerseus", -- [1]
					"143574", -- [2]
					"Swelling Corruption", -- [3]
					10, -- [4]
					656551, -- [5]
					["id"] = 1602,
				},
				["64443"] = {
					"Algalon the Observer", -- [1]
					"64443", -- [2]
					"Big Bang", -- [3]
					106, -- [4]
					135981, -- [5]
					["id"] = 1130,
				},
				["184366"] = {
					"Hellfire High Council", -- [1]
					"184366", -- [2]
					"Demolishing Leap", -- [3]
					72, -- [4]
					"Interface\\Icons\\ability_foundryraid_demolition", -- [5]
					["id"] = 1798,
				},
				["122735"] = {
					"Garalon", -- [1]
					"122735", -- [2]
					"Furious Swipe", -- [3]
					11, -- [4]
					132141, -- [5]
					["id"] = 1463,
				},
				["62997"] = {
					"Mimiron", -- [1]
					"62997", -- [2]
					"Plasma", -- [3]
					20, -- [4]
					"Interface\\Icons\\Spell_Fire_Incinerate", -- [5]
					["id"] = 1138,
				},
				["199143"] = {
					"Kurtalos Ravencrest", -- [1]
					"199143", -- [2]
					"Cloud of Hypnosis", -- [3]
					30.8, -- [4]
					136182, -- [5]
					["id"] = 1835,
				},
				["201159"] = {
					"Millificent Manastorm", -- [1]
					"201159", -- [2]
					"Delta Finger Laser X-treme", -- [3]
					5, -- [4]
					892834, -- [5]
					["id"] = 1847,
				},
				["182826"] = {
					"Archimonde", -- [1]
					"182826", -- [2]
					"Doomfire", -- [3]
					6, -- [4]
					"Interface\\Icons\\Spell_Fire_FelFlameRing", -- [5]
					["id"] = 1799,
				},
				["169613"] = {
					"Yalnu", -- [1]
					"169613", -- [2]
					"Genesis", -- [3]
					26, -- [4]
					132125, -- [5]
					["id"] = 1756,
				},
				["181508"] = {
					"Fel Lord Zakuun", -- [1]
					"181508", -- [2]
					"Seed of Destruction", -- [3]
					9, -- [4]
					"Interface\\Icons\\Spell_Shadow_SeedOfDestruction", -- [5]
					["id"] = 1777,
				},
				["181799"] = {
					"Mannoroth", -- [1]
					"181799", -- [2]
					"Shadowforce", -- [3]
					26.5, -- [4]
					"Interface\\Icons\\ability_ironmaidens_convulsiveshadows", -- [5]
					["id"] = 1795,
				},
				["99816"] = {
					"Alysrazor", -- [1]
					"99816", -- [2]
					"Stage 2", -- [3]
					250, -- [4]
					236216, -- [5]
					["id"] = 1206,
				},
				["154932"] = {
					"Flamebender Ka'graz", -- [1]
					"154932", -- [2]
					"Molten Torrent", -- [3]
					31, -- [4]
					"Interface\\Icons\\spell_burningbladeshaman_molten_torrent", -- [5]
					["id"] = 1689,
				},
				["143973"] = {
					"Kor'kron Dark Shaman", -- [1]
					"143973", -- [2]
					"Falling Ash (1)", -- [3]
					17, -- [4]
					132839, -- [5]
					["id"] = 1606,
				},
				["bwcbSereneriversrawr!"] = {
					"Bars", -- [1]
					"bwcbSereneriversrawr!", -- [2]
					"Serenerivers: rawr!", -- [3]
					600, -- [4]
					"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
					["id"] = 1841,
				},
				["211614"] = {
					"Grand Magistrix Elisande", -- [1]
					"211614", -- [2]
					"Summon Time Elemental - Slow", -- [3]
					5, -- [4]
					135738, -- [5]
					["id"] = 1872,
				},
				["204316"] = {
					"Skorpyron", -- [1]
					"204316", -- [2]
					"Shockwave", -- [3]
					60, -- [4]
					1029595, -- [5]
					["id"] = 1849,
				},
				["73529"] = {
					"The Lich King", -- [1]
					"73529", -- [2]
					"Shadow Trap", -- [3]
					16, -- [4]
					"Interface\\Icons\\Spell_Shadow_GatherShadows", -- [5]
					["id"] = 1106,
				},
				["143019"] = {
					"The Fallen Protectors", -- [1]
					"143019", -- [2]
					"Corrupted Brew", -- [3]
					18, -- [4]
					651085, -- [5]
					["id"] = 1598,
				},
				["-8055"] = {
					"Paragons of the Klaxxi", -- [1]
					"-8055", -- [2]
					"Calculate (2)", -- [3]
					35, -- [4]
					878230, -- [5]
					["id"] = 1593,
				},
				["143330"] = {
					"The Fallen Protectors", -- [1]
					"143330", -- [2]
					"Gouge", -- [3]
					23, -- [4]
					132155, -- [5]
					["id"] = 1598,
				},
				["stages"] = {
					"Shadow-Lord Iskar", -- [1]
					"stages", -- [2]
					"Phase 1", -- [3]
					40, -- [4]
					"Interface\\Icons\\achievement_boss_hellfire_felarakkoa", -- [5]
					["id"] = 1788,
				},
				["68605"] = {
					"Flame Leviathan", -- [1]
					"68605", -- [2]
					"Blue Pyrite", -- [3]
					10, -- [4]
					"Interface\\Icons\\ability_vehicle_liquidpyrite_blue", -- [5]
					["id"] = 1132,
				},
				["179889"] = {
					"Iron Reaver", -- [1]
					"179889", -- [2]
					"Blitz", -- [3]
					64.3, -- [4]
					"Interface\\Icons\\Ability_Mage_FireStarter", -- [5]
					["id"] = 1785,
				},
				["164271"] = {
					"The Iron Maidens", -- [1]
					"164271", -- [2]
					"Penetrating Shot", -- [3]
					21, -- [4]
					"Interface\\Icons\\ability_ironmaidens_ironshot", -- [5]
					["id"] = 1695,
				},
				["236547"] = {
					"Sisters of the Moon", -- [1]
					"236547", -- [2]
					"Moon Glaive", -- [3]
					14.2, -- [4]
					1117879, -- [5]
					["id"] = 2050,
				},
				["182055"] = {
					"Iron Reaver", -- [1]
					"182055", -- [2]
					"Full Charge", -- [3]
					139, -- [4]
					"Interface\\Icons\\INV_Misc_EngGizmos_06", -- [5]
					["id"] = 1785,
				},
				["193152"] = {
					"King Deepbeard", -- [1]
					"193152", -- [2]
					"Quake", -- [3]
					15, -- [4]
					136025, -- [5]
					["id"] = 1812,
				},
				["181999"] = {
					"Iron Reaver", -- [1]
					"181999", -- [2]
					"Firebomb (1)", -- [3]
					11, -- [4]
					"Interface\\Icons\\ability_ironmaidens_bombardment", -- [5]
					["id"] = 1785,
				},
				["240735"] = {
					"Tomb of Sargeras Trash", -- [1]
					"240735", -- [2]
					"Polymorph Bomb: Peybear*", -- [3]
					9.99900000006892, -- [4]
					575586, -- [5]
					["id"] = 2054,
				},
				["-9680"] = {
					"Ner'zhul", -- [1]
					"-9680", -- [2]
					"Ritual of Bones", -- [3]
					20.6, -- [4]
					"Interface\\Icons\\Spell_Shadow_ChillTouch", -- [5]
					["id"] = 1682,
				},
				["155064"] = {
					"Flamebender Ka'graz", -- [1]
					"155064", -- [2]
					"Rekindle", -- [3]
					8, -- [4]
					"Interface\\Icons\\inv_misc_volatilefire", -- [5]
					["id"] = 1689,
				},
				["-7090"] = {
					"Horridon", -- [1]
					"-7090", -- [2]
					"Dino-Mending", -- [3]
					8, -- [4]
					136043, -- [5]
					["id"] = 1575,
				},
				["248812"] = {
					"Maiden of Vigilance", -- [1]
					"248812", -- [2]
					"Blowback", -- [3]
					42.5, -- [4]
					236256, -- [5]
					["id"] = 2052,
				},
				["134626"] = {
					"Durumu the Forgotten", -- [1]
					"134626", -- [2]
					"Lingering Gaze", -- [3]
					15, -- [4]
					"Interface\\Icons\\inv_misc_eye_02", -- [5]
					["id"] = 1572,
				},
				["198006"] = {
					"Ursoc", -- [1]
					"198006", -- [2]
					"Focused Gaze (1|TInterface\\TARGETINGFRAME\\UI-RaidTargetingIcon_4.blp:0|t)", -- [3]
					19, -- [4]
					571585, -- [5]
					["id"] = 1841,
				},
				["156852"] = {
					"Kromog", -- [1]
					"156852", -- [2]
					"Stone Breath (1)", -- [3]
					9, -- [4]
					"Interface\\Icons\\Spell_Shaman_LavaBurst", -- [5]
					["id"] = 1713,
				},
				["195804"] = {
					"Corstilax", -- [1]
					"195804", -- [2]
					"Quarantine", -- [3]
					22, -- [4]
					458245, -- [5]
					["id"] = 1825,
				},
				["-6914"] = {
					"Iron Qon", -- [1]
					"-6914", -- [2]
					"Dead Zone", -- [3]
					7, -- [4]
					"Interface\\ICONS\\Spell_Arcane_Arcane01.blp", -- [5]
					["id"] = 1559,
				},
				["198564"] = {
					"Ularogg Cragshaper", -- [1]
					"198564", -- [2]
					"Stance of the Mountain", -- [3]
					97, -- [4]
					1016245, -- [5]
					["id"] = 1791,
				},
				["243124"] = {
					"Thrashbite the Scornful", -- [1]
					"243124", -- [2]
					"Heave Cudgel", -- [3]
					15.8, -- [4]
					1084435, -- [5]
					["id"] = 2057,
				},
				["227672"] = {
					"Moroes", -- [1]
					"227672", -- [2]
					"Will Breaker", -- [3]
					10.5, -- [4]
					132351, -- [5]
					["id"] = 1961,
				},
				["blink"] = {
					"Noth the Plaguebringer", -- [1]
					"blink", -- [2]
					"Blink", -- [3]
					30, -- [4]
					135736, -- [5]
					["id"] = 1117,
				},
				["198108"] = {
					"Ursoc", -- [1]
					"198108", -- [2]
					"Momentum on YOU!", -- [3]
					50, -- [4]
					132096, -- [5]
					["id"] = 1841,
				},
				["-7981"] = {
					"Thok the Bloodthirsty", -- [1]
					"-7981", -- [2]
					"Blood Frenzy Over!", -- [3]
					13, -- [4]
					132334, -- [5]
					["id"] = 1599,
				},
				["-8325"] = {
					"Garrosh Hellscream", -- [1]
					"-8325", -- [2]
					"Explosive Despair on YOU!", -- [3]
					10, -- [4]
					538558, -- [5]
					["id"] = 1623,
				},
				["153623"] = {
					"Nhallish", -- [1]
					"153623", -- [2]
					"Planar Shift", -- [3]
					21, -- [4]
					237560, -- [5]
					["id"] = 1688,
				},
				["117708"] = {
					"The Spirit Kings", -- [1]
					"117708", -- [2]
					"Maddening Shout", -- [3]
					46.7, -- [4]
					"Interface\\Icons\\warrior_talent_icon_furyintheblood", -- [5]
					["id"] = 1436,
				},
				["recklessness"] = {
					"Wind Lord Mel'jarak", -- [1]
					"recklessness", -- [2]
					"Recklessness", -- [3]
					30, -- [4]
					132352, -- [5]
					["id"] = 1498,
				},
				["143497"] = {
					"The Fallen Protectors", -- [1]
					"143497", -- [2]
					"<Cast: Heal: Rook Stonetoe>", -- [3]
					15, -- [4]
					612969, -- [5]
					["id"] = 1598,
				},
				["210864"] = {
					"Elerethe Renferal", -- [1]
					"210864", -- [2]
					"Twisting Shadows", -- [3]
					8, -- [4]
					1022950, -- [5]
					["id"] = 1876,
				},
				["-6882"] = {
					"Durumu the Forgotten", -- [1]
					"-6882", -- [2]
					"Death beam", -- [3]
					135, -- [4]
					"Interface\\ICONS\\inv_misc_dust.blp", -- [5]
					["id"] = 1572,
				},
				["197418"] = {
					"Illysanna Ravencrest", -- [1]
					"197418", -- [2]
					"Vengeful Shear", -- [3]
					8.3, -- [4]
					136158, -- [5]
					["id"] = 1833,
				},
				["engineer"] = {
					"The Blast Furnace", -- [1]
					"engineer", -- [2]
					"Furnace Engineer", -- [3]
					65, -- [4]
					"Interface\\Icons\\INV_Misc_Wrench_02", -- [5]
					["id"] = 1690,
				},
				["forces"] = {
					"Il'gynoth", -- [1]
					"forces", -- [2]
					"Deathglare Tentacle (1)", -- [3]
					26, -- [4]
					462324, -- [5]
					["id"] = 1873,
				},
				["119521"] = {
					"The Spirit Kings", -- [1]
					"119521", -- [2]
					"Annihilate", -- [3]
					10, -- [4]
					"Interface\\Icons\\Ability_Warrior_BloodBath", -- [5]
					["id"] = 1436,
				},
				["storm_duration"] = {
					"Jin'rokh the Breaker", -- [1]
					"storm_duration", -- [2]
					"<Cast: Storm>", -- [3]
					15, -- [4]
					237589, -- [5]
					["id"] = 1577,
				},
				["236710"] = {
					"Kil'jaeden", -- [1]
					"236710", -- [2]
					"Reflection: Erupting", -- [3]
					20, -- [4]
					1357814, -- [5]
					["id"] = 2051,
				},
				["144985"] = {
					"Garrosh Hellscream", -- [1]
					"144985", -- [2]
					"Whirling Corruption (1)", -- [3]
					45, -- [4]
					892449, -- [5]
					["id"] = 1623,
				},
				["218809"] = {
					"High Botanist Tel'arn", -- [1]
					"218809", -- [2]
					"Call of Night", -- [3]
					64, -- [4]
					135752, -- [5]
					["id"] = 1886,
				},
				["184358"] = {
					"Hellfire High Council", -- [1]
					"184358", -- [2]
					"Fel Rage", -- [3]
					30, -- [4]
					"Interface\\Icons\\Spell_Fire_ElementalDevastation", -- [5]
					["id"] = 1798,
				},
				["143494"] = {
					"General Nazgrim", -- [1]
					"143494", -- [2]
					"Sundering Blow", -- [3]
					10, -- [4]
					132363, -- [5]
					["id"] = 1603,
				},
				["118977"] = {
					"Sha of Fear", -- [1]
					"118977", -- [2]
					"Fearless", -- [3]
					30, -- [4]
					538565, -- [5]
					["id"] = 1431,
				},
				["215300"] = {
					"Elerethe Renferal", -- [1]
					"215300", -- [2]
					"Web of Pain", -- [3]
					6, -- [4]
					237431, -- [5]
					["id"] = 1876,
				},
				["206005"] = {
					"Xavius", -- [1]
					"206005", -- [2]
					"Dream Simulacrum on YOU!", -- [3]
					180, -- [4]
					1396974, -- [5]
					["id"] = 1864,
				},
				["142851"] = {
					"Malkorok", -- [1]
					"142851", -- [2]
					"Seismic Slam", -- [3]
					5, -- [4]
					136025, -- [5]
					["id"] = 1595,
				},
				["teleport"] = {
					"Noth the Plaguebringer", -- [1]
					"teleport", -- [2]
					"Teleport!", -- [3]
					90, -- [4]
					"Interface\\Icons\\Spell_Magic_LesserInvisibilty", -- [5]
					["id"] = 1117,
				},
				["228012"] = {
					"Odyn-TrialOfValor", -- [1]
					"228012", -- [2]
					"Horn of Valor", -- [3]
					8, -- [4]
					134229, -- [5]
					["id"] = 1958,
				},
				["138644"] = {
					"Dark Animus", -- [1]
					"138644", -- [2]
					"Siphon Anima", -- [3]
					30, -- [4]
					"Interface\\Icons\\ability_animusdraw", -- [5]
					["id"] = 1576,
				},
				["143436"] = {
					"Immerseus", -- [1]
					"143436", -- [2]
					"Corrosive Blast", -- [3]
					10, -- [4]
					236302, -- [5]
					["id"] = 1602,
				},
				["227800"] = {
					"Maiden of Virtue", -- [1]
					"227800", -- [2]
					"Holy Shock", -- [3]
					12, -- [4]
					135972, -- [5]
					["id"] = 1954,
				},
				["44335"] = {
					"Vexallus", -- [1]
					"44335", -- [2]
					"Energy Feedback: Akrazugul", -- [3]
					30, -- [4]
					135731, -- [5]
					["id"] = 1898,
				},
				["155992"] = {
					"Blackhand", -- [1]
					"155992", -- [2]
					"Smash (1)", -- [3]
					21, -- [4]
					"Interface\\Icons\\Ability_Smash", -- [5]
					["id"] = 1704,
				},
				["-6877"] = {
					"Iron Qon", -- [1]
					"-6877", -- [2]
					"Windstorm", -- [3]
					50, -- [4]
					"Interface\\ICONS\\Ability_Druid_GaleWinds.blp", -- [5]
					["id"] = 1559,
				},
				["192094"] = {
					"Warlord Parjesh", -- [1]
					"192094", -- [2]
					"Impaling Spear", -- [3]
					35, -- [4]
					135130, -- [5]
					["id"] = 1810,
				},
				["236650"] = {
					"Agronox", -- [1]
					"236650", -- [2]
					"Choking Vines", -- [3]
					24.4, -- [4]
					135263, -- [5]
					["id"] = 2055,
				},
				["59978"] = {
					"Herald Volazj", -- [1]
					"59978", -- [2]
					"Shiver: Naxgrim", -- [3]
					15, -- [4]
					136131, -- [5]
					["id"] = 1968,
				},
				["159113"] = {
					"Kargath Bladefist", -- [1]
					"159113", -- [2]
					"Impale", -- [3]
					37, -- [4]
					"Interface\\Icons\\Ability_Rogue_HungerforBlood", -- [5]
					["id"] = 1721,
				},
				["157060"] = {
					"Kromog", -- [1]
					"157060", -- [2]
					"Rune of Grasping Earth", -- [3]
					50, -- [4]
					"Interface\\Icons\\ability_fomor_boss_rune_yellow", -- [5]
					["id"] = 1713,
				},
				["118071"] = {
					"Feng the Accursed", -- [1]
					"118071", -- [2]
					"Siphoning Shield (1)", -- [3]
					4, -- [4]
					"Interface\\Icons\\Ability_Rogue_EnvelopingShadows", -- [5]
					["id"] = 1390,
				},
				["70372"] = {
					"The Lich King", -- [1]
					"70372", -- [2]
					"Next Horror", -- [3]
					22, -- [4]
					"Interface\\Icons\\Spell_DeathKnight_Gnaw_Ghoul", -- [5]
					["id"] = 1106,
				},
				["137313"] = {
					"Jin'rokh the Breaker", -- [1]
					"137313", -- [2]
					"Storm", -- [3]
					93, -- [4]
					"Interface\\Icons\\Spell_Shaman_ThunderStorm", -- [5]
					["id"] = 1577,
				},
				["155326"] = {
					"Gruul", -- [1]
					"155326", -- [2]
					"Smash or Slam", -- [3]
					21, -- [4]
					"Interface\\Icons\\ability_kilruk_reave", -- [5]
					["id"] = 1691,
				},
				["205300"] = {
					"Dragons of Nightmare", -- [1]
					"205300", -- [2]
					"Corruption", -- [3]
					15, -- [4]
					651084, -- [5]
					["id"] = 1854,
				},
				["189009"] = {
					"Fel Lord Zakuun", -- [1]
					"189009", -- [2]
					"Cavitation", -- [3]
					36.5, -- [4]
					"INTERFACE\\ICONS\\warrior_talent_icon_mastercleaver", -- [5]
					["id"] = 1777,
				},
				["113134"] = {
					"High Inquisitor Whitemane", -- [1]
					"113134", -- [2]
					"Mass Resurrection", -- [3]
					10, -- [4]
					413586, -- [5]
					["id"] = 1425,
				},
				["223121"] = {
					"Il'gynoth", -- [1]
					"223121", -- [2]
					"<Cast: Final Torpor>", -- [3]
					100, -- [4]
					1357796, -- [5]
					["id"] = 1873,
				},
				["69200"] = {
					"The Lich King", -- [1]
					"69200", -- [2]
					"Raging Spirit", -- [3]
					15, -- [4]
					"Interface\\Icons\\Ability_Warrior_EndlessRage", -- [5]
					["id"] = 1106,
				},
				["188693"] = {
					"Socrethar the Eternal", -- [1]
					"188693", -- [2]
					"Apocalyptic Felburst (1)", -- [3]
					34, -- [4]
					"Interface\\Icons\\Spell_Fire_FelFlameStrike", -- [5]
					["id"] = 1794,
				},
				["pyro"] = {
					"Kael'thas Sunstrider", -- [1]
					"pyro", -- [2]
					"Pyroblast", -- [3]
					60, -- [4]
					"Interface\\Icons\\Spell_Fire_Fireball02", -- [5]
					["id"] = 733,
				},
				["-6917"] = {
					"Iron Qon", -- [1]
					"-6917", -- [2]
					"Fist Smash (1)", -- [3]
					20, -- [4]
					"Interface\\ICONS\\Spell_Nature_Earthquake.blp", -- [5]
					["id"] = 1559,
				},
				["help"] = {
					"Armsmaster Harlan", -- [1]
					"help", -- [2]
					"Call for Help", -- [3]
					20, -- [4]
					"", -- [5]
					["id"] = 1421,
				},
				["227992"] = {
					"Helya-TrialOfValor", -- [1]
					"227992", -- [2]
					"<Cast: Bilewater Liquefaction>", -- [3]
					22.5, -- [4]
					893778, -- [5]
					["id"] = 2008,
				},
				["-11778"] = {
					"Socrethar the Eternal", -- [1]
					"-11778", -- [2]
					"Add (1)", -- [3]
					20, -- [4]
					"Interface\\Icons\\spell_shadow_summonfelhunter", -- [5]
					["id"] = 1794,
				},
				["193698"] = {
					"Lady Hatecoil", -- [1]
					"193698", -- [2]
					"Curse of the Witch", -- [3]
					10, -- [4]
					135952, -- [5]
					["id"] = 1811,
				},
				["89588"] = {
					"Al'Akir", -- [1]
					"89588", -- [2]
					"Lightning Clouds", -- [3]
					16, -- [4]
					"Interface\\Icons\\Spell_Nature_CallStorm", -- [5]
					["id"] = 1034,
				},
				["228187"] = {
					"Guarm-TrialOfValor", -- [1]
					"228187", -- [2]
					"Guardian's Breath", -- [3]
					13, -- [4]
					988195, -- [5]
					["id"] = 1962,
				},
				["flight"] = {
					"Alysrazor", -- [1]
					"flight", -- [2]
					"Wings of Flame", -- [3]
					30, -- [4]
					514340, -- [5]
					["id"] = 1206,
				},
				["38759"] = {
					"Pandemonius", -- [1]
					"38759", -- [2]
					"Dark Shell", -- [3]
					6, -- [4]
					136121, -- [5]
					["id"] = 1900,
				},
				["235230"] = {
					"Demonic Inquisition", -- [1]
					"235230", -- [2]
					"Fel Squall", -- [3]
					35, -- [4]
					841219, -- [5]
					["id"] = 2048,
				},
				["205233"] = {
					"Fel Lord Betrug", -- [1]
					"205233", -- [2]
					"Execution", -- [3]
					34, -- [4]
					135358, -- [5]
					["id"] = 1856,
				},
				["194231"] = {
					"Harbaron", -- [1]
					"194231", -- [2]
					"Summon Shackled Servitor", -- [3]
					8, -- [4]
					636332, -- [5]
					["id"] = 1823,
				},
				["32361"] = {
					"Tavarok", -- [1]
					"32361", -- [2]
					"Crystal Prison: ???", -- [3]
					5, -- [4]
					135988, -- [5]
					["id"] = 1901,
				},
				["38618"] = {
					"Commander Kolurg/Stoutbeard", -- [1]
					"38618", -- [2]
					"Whirlwind", -- [3]
					14.5, -- [4]
					132369, -- [5]
					["id"] = 519,
				},
				["37850"] = {
					"Morogrim Tidewalker", -- [1]
					"37850", -- [2]
					"~Graves", -- [3]
					20, -- [4]
					136148, -- [5]
					["id"] = 627,
				},
				["-2598"] = {
					"Baleroc", -- [1]
					"-2598", -- [2]
					"~Next Blade", -- [3]
					30, -- [4]
					136136, -- [5]
					["id"] = 1200,
				},
				["213390"] = {
					"Spellblade Aluriel", -- [1]
					"213390", -- [2]
					"Detonate: Arcane Orb", -- [3]
					48, -- [4]
					1033906, -- [5]
					["id"] = 1871,
				},
				["198551"] = {
					"Harbaron", -- [1]
					"198551", -- [2]
					"Fragment", -- [3]
					34, -- [4]
					236300, -- [5]
					["id"] = 1823,
				},
				["236541"] = {
					"Sisters of the Moon", -- [1]
					"236541", -- [2]
					"Twilight Glaive", -- [3]
					19.1, -- [4]
					132330, -- [5]
					["id"] = 2050,
				},
				["227816"] = {
					"Guarm-TrialOfValor", -- [1]
					"227816", -- [2]
					"Headlong Charge", -- [3]
					57, -- [4]
					304501, -- [5]
					["id"] = 1962,
				},
				["198077"] = {
					"Odyn", -- [1]
					"198077", -- [2]
					"Shatter Spears", -- [3]
					40, -- [4]
					612968, -- [5]
					["id"] = 1809,
				},
				["195254"] = {
					"Amalgam of Souls", -- [1]
					"195254", -- [2]
					"Swirling Scythe", -- [3]
					8.5, -- [4]
					1060569, -- [5]
					["id"] = 1832,
				},
				["232153"] = {
					"Opera Hall: Beautiful Beast", -- [1]
					"232153", -- [2]
					"Kara Kazham!", -- [3]
					17, -- [4]
					458731, -- [5]
					["id"] = 1957,
				},
				["167935"] = {
					"Gul'dan", -- [1]
					"167935", -- [2]
					"Storm of the Destroyer", -- [3]
					84, -- [4]
					651097, -- [5]
					["id"] = 1866,
				},
				["-6905"] = {
					"Durumu the Forgotten", -- [1]
					"-6905", -- [2]
					"Force of Will", -- [3]
					33, -- [4]
					"Interface\\ICONS\\Ability_Monk_ForceSphere.blp", -- [5]
					["id"] = 1572,
				},
				["228790"] = {
					"Nightbane", -- [1]
					"228790", -- [2]
					"Concentrated Power", -- [3]
					40, -- [4]
					615100, -- [5]
					["id"] = 2031,
				},
				["immolation"] = {
					"Shannox", -- [1]
					"immolation", -- [2]
					"Riplimb is Wary!", -- [3]
					25, -- [4]
					132138, -- [5]
					["id"] = 1205,
				},
				["86205"] = {
					"Conclave of Wind", -- [1]
					"86205", -- [2]
					"Soothing Breeze", -- [3]
					16.2, -- [4]
					"Interface\\Icons\\Spell_Nature_Regeneration_02", -- [5]
					["id"] = 1035,
				},
				["44224"] = {
					"Kael'thas Sunstrider", -- [1]
					"44224", -- [2]
					"Gravity Lapse", -- [3]
					35, -- [4]
					136111, -- [5]
					["id"] = 1894,
				},
				["voidfiend"] = {
					"Xhul'horac", -- [1]
					"voidfiend", -- [2]
					"Unstable Voidfiend", -- [3]
					14.5, -- [4]
					"Interface\\Icons\\spell_shadow_summonvoidwalker", -- [5]
					["id"] = 1800,
				},
				["134370"] = {
					"Ji-Kun", -- [1]
					"134370", -- [2]
					"Down Draft", -- [3]
					90, -- [4]
					"Interface\\Icons\\Ability_Druid_GaleWinds", -- [5]
					["id"] = 1573,
				},
				["225943"] = {
					"Nythendra", -- [1]
					"225943", -- [2]
					"Infested Mind", -- [3]
					49, -- [4]
					892448, -- [5]
					["id"] = 1853,
				},
				["62016"] = {
					"Thorim", -- [1]
					"62016", -- [2]
					"Charge Orb", -- [3]
					15, -- [4]
					136015, -- [5]
					["id"] = 1141,
				},
				["143974"] = {
					"Paragons of the Klaxxi", -- [1]
					"143974", -- [2]
					"Shield Bash", -- [3]
					20, -- [4]
					132357, -- [5]
					["id"] = 1593,
				},
				["floor"] = {
					"Elegon", -- [1]
					"floor", -- [2]
					"Floor Despawn", -- [3]
					6, -- [4]
					"Interface\\Icons\\ability_vehicle_launchplayer", -- [5]
					["id"] = 1500,
				},
				["-6700"] = {
					"Sha of Fear", -- [1]
					"-6700", -- [2]
					"Dread Thrash", -- [3]
					10, -- [4]
					425957, -- [5]
					["id"] = 1431,
				},
				["bigtentacle"] = {
					"Madness of Deathwing", -- [1]
					"bigtentacle", -- [2]
					"Mutated Corruption", -- [3]
					11.2, -- [4]
					"Interface\\Icons\\ability_deathwing_grasping_tendrils", -- [5]
					["id"] = 1299,
				},
				["227508"] = {
					"Maiden of Virtue", -- [1]
					"227508", -- [2]
					"<Cast: Mass Repentance>", -- [3]
					5, -- [4]
					135942, -- [5]
					["id"] = 1954,
				},
				["-6969"] = {
					"Primordius", -- [1]
					"-6969", -- [2]
					"Black Blood", -- [3]
					12, -- [4]
					576309, -- [5]
					["id"] = 1574,
				},
				["big_adds"] = {
					"Norushen", -- [1]
					"big_adds", -- [2]
					"Big add (1)", -- [3]
					5, -- [4]
					897143, -- [5]
					["id"] = 1624,
				},
				["136543"] = {
					"Lei Shen", -- [1]
					"136543", -- [2]
					"Ball Lightning", -- [3]
					14, -- [4]
					"Interface\\Icons\\ability_thunderking_balllightning", -- [5]
					["id"] = 1579,
				},
				["200551"] = {
					"Dargrul", -- [1]
					"200551", -- [2]
					"Crystal Spikes", -- [3]
					21, -- [4]
					132780, -- [5]
					["id"] = 1793,
				},
				["210022"] = {
					"Grand Magistrix Elisande", -- [1]
					"210022", -- [2]
					"Epocheric Orb", -- [3]
					28, -- [4]
					429383, -- [5]
					["id"] = 1872,
				},
				["179711"] = {
					"Fel Lord Zakuun", -- [1]
					"179711", -- [2]
					"Befouled", -- [3]
					16, -- [4]
					"Interface\\Icons\\Spell_Shadow_GatherShadows", -- [5]
					["id"] = 1777,
				},
				["201960"] = {
					"Shivermaw", -- [1]
					"201960", -- [2]
					"Ice Bomb", -- [3]
					47, -- [4]
					609814, -- [5]
					["id"] = 1845,
				},
				["-6698"] = {
					"Gara'jal the Spiritbinder", -- [1]
					"-6698", -- [2]
					"Attack (1)", -- [3]
					6.7, -- [4]
					"Interface\\Icons\\ability_monk_roundhousekick", -- [5]
					["id"] = 1434,
				},
				["227514"] = {
					"Guarm-TrialOfValor", -- [1]
					"227514", -- [2]
					"Flashing Fangs", -- [3]
					5, -- [4]
					132127, -- [5]
					["id"] = 1962,
				},
				["236543"] = {
					"Domatrax", -- [1]
					"236543", -- [2]
					"Felsoul Cleave", -- [3]
					8.3, -- [4]
					1109118, -- [5]
					["id"] = 2053,
				},
				["193211"] = {
					"Ymiron", -- [1]
					"193211", -- [2]
					"Dark Slash", -- [3]
					3.5, -- [4]
					135371, -- [5]
					["id"] = 1822,
				},
				["64059"] = {
					"Yogg-Saron", -- [1]
					"64059", -- [2]
					"Induce Madness", -- [3]
					60, -- [4]
					252997, -- [5]
					["id"] = 1143,
				},
				["-7631"] = {
					"Twin Consorts", -- [1]
					"-7631", -- [2]
					"Cosmic Barrage", -- [3]
					14, -- [4]
					"Interface\\ICONS\\Spell_Fire_BluePyroblast.blp", -- [5]
					["id"] = 1560,
				},
				["-8292"] = {
					"Garrosh Hellscream", -- [1]
					"-8292", -- [2]
					"Kor'kron Warbringer", -- [3]
					2, -- [4]
					132316, -- [5]
					["id"] = 1623,
				},
				["bwcbSereneriversbreak, love <3"] = {
					"Bars", -- [1]
					"bwcbSereneriversbreak, love <3", -- [2]
					"Serenerivers: break, love <3", -- [3]
					660, -- [4]
					"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
					["id"] = 1777,
				},
				["138732"] = {
					"Jin'rokh the Breaker", -- [1]
					"138732", -- [2]
					"Ionization", -- [3]
					60, -- [4]
					136014, -- [5]
					["id"] = 1577,
				},
				["192073"] = {
					"Warlord Parjesh", -- [1]
					"192073", -- [2]
					"Call Reinforcements", -- [3]
					5, -- [4]
					236422, -- [5]
					["id"] = 1810,
				},
				["210150"] = {
					"Naraxas", -- [1]
					"210150", -- [2]
					"Toxic Retch", -- [3]
					12, -- [4]
					136016, -- [5]
					["id"] = 1792,
				},
				["238430"] = {
					"Kil'jaeden", -- [1]
					"238430", -- [2]
					"Bursting Dreadflame", -- [3]
					7.7, -- [4]
					460698, -- [5]
					["id"] = 2051,
				},
				["-5970"] = {
					"Xin the Weaponmaster", -- [1]
					"-5970", -- [2]
					"<Cast: Ground Slam>", -- [3]
					3, -- [4]
					451165, -- [5]
					["id"] = 1441,
				},
				["227233"] = {
					"Helya", -- [1]
					"227233", -- [2]
					"Corrupted Bellow", -- [3]
					22, -- [4]
					136183, -- [5]
					["id"] = 1824,
				},
				["harpoon"] = {
					"Razorscale", -- [1]
					"harpoon", -- [2]
					"Harpoon 1", -- [3]
					55, -- [4]
					"Interface\\Icons\\INV_Spear_06", -- [5]
					["id"] = 1139,
				},
				["unstable_sha"] = {
					"Tsulong", -- [1]
					"unstable_sha", -- [2]
					"Summon Unstable Sha", -- [3]
					18, -- [4]
					136181, -- [5]
					["id"] = 1505,
				},
				["154975"] = {
					"Beastlord Darmac", -- [1]
					"154975", -- [2]
					"Call the Pack", -- [3]
					19.5, -- [4]
					"Interface\\Icons\\Ability_Warrior_BattleShout", -- [5]
					["id"] = 1694,
				},
				["113641"] = {
					"Flameweaver Koegler", -- [1]
					"113641", -- [2]
					"Dragon's Breath", -- [3]
					30, -- [4]
					134153, -- [5]
					["id"] = 1420,
				},
				["157592"] = {
					"Kromog", -- [1]
					"157592", -- [2]
					"Rippling Smash", -- [3]
					24, -- [4]
					"Interface\\Icons\\INV_Elemental_Primal_Earth", -- [5]
					["id"] = 1713,
				},
				["188169"] = {
					"Rokmora", -- [1]
					"188169", -- [2]
					"Razor Shards", -- [3]
					25, -- [4]
					135857, -- [5]
					["id"] = 1790,
				},
				["35181"] = {
					"Al'ar", -- [1]
					"35181", -- [2]
					"Dive Bomb", -- [3]
					52, -- [4]
					135808, -- [5]
					["id"] = 730,
				},
				["207573"] = {
					"Dragons of Nightmare", -- [1]
					"207573", -- [2]
					"Call Defiled Spirit", -- [3]
					30, -- [4]
					1022944, -- [5]
					["id"] = 1854,
				},
				["211152"] = {
					"Gul'dan", -- [1]
					"211152", -- [2]
					"Empowered Eye of Gul'dan", -- [3]
					39, -- [4]
					971290, -- [5]
					["id"] = 1866,
				},
				["214670"] = {
					"Trilliax", -- [1]
					"214670", -- [2]
					"Imprint: Energized", -- [3]
					2.5, -- [4]
					254104, -- [5]
					["id"] = 1867,
				},
				["208672"] = {
					"Gul'dan", -- [1]
					"208672", -- [2]
					"Carrion Wave", -- [3]
					6.1, -- [4]
					136128, -- [5]
					["id"] = 1866,
				},
				["143701"] = {
					"Paragons of the Klaxxi", -- [1]
					"143701", -- [2]
					"Whirling", -- [3]
					11, -- [4]
					236154, -- [5]
					["id"] = 1593,
				},
				["193977"] = {
					"Ymiron", -- [1]
					"193977", -- [2]
					"Winds of Northrend", -- [3]
					15.1, -- [4]
					135833, -- [5]
					["id"] = 1822,
				},
				["107588"] = {
					"Warmaster Blackhorn", -- [1]
					"107588", -- [2]
					"Twilight Onslaught", -- [3]
					47, -- [4]
					"INTERFACE\\ICONS\\spell_fire_twilightflamebreath", -- [5]
					["id"] = 1298,
				},
				["steel"] = {
					"High Inquisitor Whitemane", -- [1]
					"steel", -- [2]
					"Flash of Steel", -- [3]
					10.8, -- [4]
					132294, -- [5]
					["id"] = 1425,
				},
				["239739"] = {
					"Fallen Avatar", -- [1]
					"239739", -- [2]
					"Dark Mark", -- [3]
					21.5, -- [4]
					633004, -- [5]
					["id"] = 2038,
				},
				["154159"] = {
					"Araknath", -- [1]
					"154159", -- [2]
					"Energize", -- [3]
					17, -- [4]
					1029582, -- [5]
					["id"] = 1699,
				},
				["124849"] = {
					"Grand Empress Shek'zeer", -- [1]
					"124849", -- [2]
					"Consuming Terror", -- [3]
					10, -- [4]
					136204, -- [5]
					["id"] = 1501,
				},
				["201598"] = {
					"Festerface", -- [1]
					"201598", -- [2]
					"Congealing Vomit", -- [3]
					11, -- [4]
					132108, -- [5]
					["id"] = 1848,
				},
				["116784"] = {
					"Feng the Accursed", -- [1]
					"116784", -- [2]
					"Wildfire on YOU!", -- [3]
					5, -- [4]
					"Interface\\Icons\\Spell_Fire_Burnout", -- [5]
					["id"] = 1390,
				},
				["197961"] = {
					"Odyn", -- [1]
					"197961", -- [2]
					"Runic Brand", -- [3]
					44, -- [4]
					442743, -- [5]
					["id"] = 1809,
				},
				["134691"] = {
					"Iron Qon", -- [1]
					"134691", -- [2]
					"Impale", -- [3]
					20, -- [4]
					"Interface\\Icons\\Ability_Warrior_FocusedRage", -- [5]
					["id"] = 1559,
				},
				["199178"] = {
					"Naraxas", -- [1]
					"199178", -- [2]
					"Spiked Tongue", -- [3]
					50, -- [4]
					136113, -- [5]
					["id"] = 1792,
				},
				["233856"] = {
					"Fallen Avatar", -- [1]
					"233856", -- [2]
					"<Cast: Cleansing Protocol>", -- [3]
					18, -- [4]
					135802, -- [5]
					["id"] = 2038,
				},
				["232722"] = {
					"Mistress Sassz'ine", -- [1]
					"232722", -- [2]
					"Slicing Tornado", -- [3]
					30.3, -- [4]
					999952, -- [5]
					["id"] = 2037,
				},
				["184394"] = {
					"Hellfire Assault", -- [1]
					"184394", -- [2]
					"Shockwave", -- [3]
					6, -- [4]
					"Interface\\Icons\\ability_earthen_pillar", -- [5]
					["id"] = 1778,
				},
				["phases"] = {
					"Tsulong", -- [1]
					"phases", -- [2]
					"The Day", -- [3]
					121, -- [4]
					"Interface\\Icons\\spell_holy_circleofrenewal", -- [5]
					["id"] = 1505,
				},
				["136295"] = {
					"Lei Shen", -- [1]
					"136295", -- [2]
					"Overcharged", -- [3]
					7, -- [4]
					"Interface\\Icons\\ability_thunderking_overcharge", -- [5]
					["id"] = 1579,
				},
				["205420"] = {
					"Krosus", -- [1]
					"205420", -- [2]
					"Burning Pitch (1)", -- [3]
					38, -- [4]
					135804, -- [5]
					["id"] = 1842,
				},
				["-8181"] = {
					"Iron Juggernaut", -- [1]
					"-8181", -- [2]
					"Ricochet", -- [3]
					15, -- [4]
					134427, -- [5]
					["id"] = 1600,
				},
				["88495"] = {
					"Foe Reaper 5000", -- [1]
					"88495", -- [2]
					"Harvest", -- [3]
					56, -- [4]
					134427, -- [5]
					["id"] = 1063,
				},
				["157349"] = {
					"Imperator Mar'gok", -- [1]
					"157349", -- [2]
					"Force Nova", -- [3]
					45, -- [4]
					"Interface\\Icons\\ability_socererking_forcenova", -- [5]
					["id"] = 1705,
				},
				["224982"] = {
					"Nighthold Trash", -- [1]
					"224982", -- [2]
					"Fel Glare: Dailyn", -- [3]
					10, -- [4]
					135798, -- [5]
					["id"] = 1862,
				},
				["227493"] = {
					"Attumen the Huntsman", -- [1]
					"227493", -- [2]
					"Mortal Strike: Plinixela", -- [3]
					10, -- [4]
					132338, -- [5]
					["id"] = 1960,
				},
				["206949"] = {
					"Star Augur Etraeus", -- [1]
					"206949", -- [2]
					"Frigid Nova", -- [3]
					53, -- [4]
					464484, -- [5]
					["id"] = 1863,
				},
				["44320"] = {
					"Selin Fireheart", -- [1]
					"44320", -- [2]
					"Mana Rage", -- [3]
					10, -- [4]
					136170, -- [5]
					["id"] = 1897,
				},
				["202974"] = {
					"Advisor Vandros", -- [1]
					"202974", -- [2]
					"Force Bomb", -- [3]
					29, -- [4]
					1041235, -- [5]
					["id"] = 1829,
				},
				["157763"] = {
					"Imperator Mar'gok", -- [1]
					"157763", -- [2]
					"Fixate on YOU!", -- [3]
					15, -- [4]
					"Interface\\Icons\\ability_fixated_state_red", -- [5]
					["id"] = 1705,
				},
				["156471"] = {
					"Imperator Mar'gok", -- [1]
					"156471", -- [2]
					"Arcane Aberration (1)", -- [3]
					25, -- [4]
					"Interface\\Icons\\ability_socererking_summonaberration", -- [5]
					["id"] = 1705,
				},
				["118162"] = {
					"The Spirit Kings", -- [1]
					"118162", -- [2]
					"Sleight of Hand", -- [3]
					42, -- [4]
					"Interface\\Icons\\Ability_Rogue_SinisterCalling", -- [5]
					["id"] = 1436,
				},
				["227254"] = {
					"The Curator", -- [1]
					"227254", -- [2]
					"<Cast: Evocation>", -- [3]
					20, -- [4]
					135729, -- [5]
					["id"] = 1964,
				},
				["136192"] = {
					"Iron Qon", -- [1]
					"136192", -- [2]
					"Lightning Storm", -- [3]
					17, -- [4]
					"Interface\\Icons\\INV_Rod_EnchantedAdamantite", -- [5]
					["id"] = 1559,
				},
				["121896"] = {
					"Wind Lord Mel'jarak", -- [1]
					"121896", -- [2]
					"Whirling Blade", -- [3]
					36, -- [4]
					236303, -- [5]
					["id"] = 1498,
				},
				["dominator"] = {
					"Socrethar the Eternal", -- [1]
					"dominator", -- [2]
					"Sargerei Dominator (1)", -- [3]
					24, -- [4]
					"Interface\\Icons\\achievement_boss_kiljaedan", -- [5]
					["id"] = 1794,
				},
				["bwcbSereneriversalex you suck"] = {
					"Bars", -- [1]
					"bwcbSereneriversalex you suck", -- [2]
					"Serenerivers: alex you suck", -- [3]
					600, -- [4]
					"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
					["id"] = 1786,
				},
				["241636"] = {
					"Maiden of Vigilance", -- [1]
					"241636", -- [2]
					"Hammer of Obliteration", -- [3]
					32, -- [4]
					1038844, -- [5]
					["id"] = 2052,
				},
				["wave"] = {
					"Freya", -- [1]
					"wave", -- [2]
					"Next Wave", -- [3]
					11, -- [4]
					135861, -- [5]
					["id"] = 1133,
				},
				["158708"] = {
					"The Iron Maidens", -- [1]
					"158708", -- [2]
					"Earthen Barrier", -- [3]
					10, -- [4]
					"Interface\\Icons\\ability_gift_of_earth", -- [5]
					["id"] = 1695,
				},
				["-6186"] = {
					"Elegon", -- [1]
					"-6186", -- [2]
					"<Cast: Total Annihilation>", -- [3]
					4, -- [4]
					"Interface\\ICONS\\Spell_Arcane_Blast.blp", -- [5]
					["id"] = 1500,
				},
				["186123"] = {
					"Archimonde", -- [1]
					"186123", -- [2]
					"Wrought Chaos", -- [3]
					7, -- [4]
					"Interface\\Icons\\spell_misc_zandalari_council_soulswap", -- [5]
					["id"] = 1799,
				},
				["63849"] = {
					"XT-002 Deconstructor", -- [1]
					"63849", -- [2]
					"Exposed Heart", -- [3]
					30, -- [4]
					"Interface\\Icons\\Spell_BrokenHeart", -- [5]
					["id"] = 1142,
				},
				["184449"] = {
					"Hellfire High Council", -- [1]
					"184449", -- [2]
					"Mark of the Necromancer", -- [3]
					6.3, -- [4]
					"Interface\\Icons\\ability_bossfelorcs_necromancer_purple", -- [5]
					["id"] = 1798,
				},
				["100646"] = {
					"Ragnaros", -- [1]
					"100646", -- [2]
					"Entrapping Roots", -- [3]
					68, -- [4]
					136100, -- [5]
					["id"] = 1203,
				},
				["201733"] = {
					"Kurtalos Ravencrest", -- [1]
					"201733", -- [2]
					"Stinging Swarm", -- [3]
					17, -- [4]
					538518, -- [5]
					["id"] = 1835,
				},
				["122761"] = {
					"Imperial Vizier Zor'lok", -- [1]
					"122761", -- [2]
					"Exhale on YOU!", -- [3]
					6, -- [4]
					136184, -- [5]
					["id"] = 1507,
				},
				["200185"] = {
					"Shade of Xavius", -- [1]
					"200185", -- [2]
					"Nightmare Bolt", -- [3]
					8, -- [4]
					1357805, -- [5]
					["id"] = 1839,
				},
				["187204"] = {
					"Xhul'horac", -- [1]
					"187204", -- [2]
					"Overwhelming Chaos", -- [3]
					10, -- [4]
					"Interface\\Icons\\sha_spell_shaman_lavaburst", -- [5]
					["id"] = 1800,
				},
				["155318"] = {
					"Flamebender Ka'graz", -- [1]
					"155318", -- [2]
					"Lava Slash", -- [3]
					11, -- [4]
					"Interface\\Icons\\spell_burningbladeshaman_lavaslash", -- [5]
					["id"] = 1689,
				},
				["144396"] = {
					"The Fallen Protectors", -- [1]
					"144396", -- [2]
					"Vengeful Strikes", -- [3]
					7, -- [4]
					651092, -- [5]
					["id"] = 1598,
				},
				["202019"] = {
					"Kurtalos Ravencrest", -- [1]
					"202019", -- [2]
					"Shadow Bolt Volley", -- [3]
					8.5, -- [4]
					136197, -- [5]
					["id"] = 1835,
				},
				["190050"] = {
					"Archimonde", -- [1]
					"190050", -- [2]
					"Touch of Shadows (2)", -- [3]
					11, -- [4]
					"Interface\\Icons\\warlock_curse_shadow_aura", -- [5]
					["id"] = 1799,
				},
				["230358"] = {
					"Mistress Sassz'ine", -- [1]
					"230358", -- [2]
					"Thundering Shock", -- [3]
					10.5, -- [4]
					839974, -- [5]
					["id"] = 2037,
				},
				["-6325"] = {
					"Grand Empress Shek'zeer", -- [1]
					"-6325", -- [2]
					"Dissonance Field", -- [3]
					20, -- [4]
					237546, -- [5]
					["id"] = 1501,
				},
				["winds"] = {
					"Gul'dan", -- [1]
					"winds", -- [2]
					"Violent Winds (1)", -- [3]
					11.5, -- [4]
					1029595, -- [5]
					["id"] = 1866,
				},
				["explosion_by_other"] = {
					"Amber-Shaper Un'sok", -- [1]
					"explosion_by_other", -- [2]
					"Monster: Explosion", -- [3]
					55, -- [4]
					236305, -- [5]
					["id"] = 1499,
				},
				["146849"] = {
					"Galakras", -- [1]
					"146849", -- [2]
					"Shattering Cleave", -- [3]
					7, -- [4]
					132358, -- [5]
					["id"] = 1622,
				},
				["-7134"] = {
					"Tortos", -- [1]
					"-7134", -- [2]
					"Shell Concussion", -- [3]
					15, -- [4]
					463281, -- [5]
					["id"] = 1565,
				},
				["202977"] = {
					"Nythendra", -- [1]
					"202977", -- [2]
					"Infested Breath", -- [3]
					38, -- [4]
					538518, -- [5]
					["id"] = 1853,
				},
				["208910"] = {
					"Trilliax", -- [1]
					"208910", -- [2]
					"Linked with |cffff7c0aSpomoo|r", -- [3]
					29.968000000008, -- [4]
					607854, -- [5]
					["id"] = 1867,
				},
				["156425"] = {
					"Blackhand", -- [1]
					"156425", -- [2]
					"Demolition", -- [3]
					15.5, -- [4]
					"Interface\\Icons\\ability_blackhand_demolition", -- [5]
					["id"] = 1704,
				},
				["227809"] = {
					"Maiden of Virtue", -- [1]
					"227809", -- [2]
					"Holy Bolt", -- [3]
					12, -- [4]
					1022948, -- [5]
					["id"] = 1954,
				},
				["144215"] = {
					"Kor'kron Dark Shaman", -- [1]
					"144215", -- [2]
					"Froststorm Strike", -- [3]
					6, -- [4]
					462327, -- [5]
					["id"] = 1606,
				},
				["bwcbSereneriversbreaktime!"] = {
					"Bars", -- [1]
					"bwcbSereneriversbreaktime!", -- [2]
					"Serenerivers: breaktime!", -- [3]
					600, -- [4]
					"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
					["id"] = 1783,
				},
				["207881"] = {
					"Talixae Flamewreath", -- [1]
					"207881", -- [2]
					"Infernal Eruption", -- [3]
					19, -- [4]
					451164, -- [5]
					["id"] = 1869,
				},
				["198379"] = {
					"Archdruid Glaidalis", -- [1]
					"198379", -- [2]
					"Primal Rampage", -- [3]
					14.5, -- [4]
					571585, -- [5]
					["id"] = 1836,
				},
				["204040"] = {
					"Dragons of Nightmare", -- [1]
					"204040", -- [2]
					"Shadow Burst on YOU!", -- [3]
					10, -- [4]
					132843, -- [5]
					["id"] = 1854,
				},
				["bwcbSereneriversbreak!"] = {
					"Bars", -- [1]
					"bwcbSereneriversbreak!", -- [2]
					"Serenerivers: break!", -- [3]
					600, -- [4]
					"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
					["id"] = 1777,
				},
				["143027"] = {
					"The Fallen Protectors", -- [1]
					"143027", -- [2]
					"Clash", -- [3]
					44, -- [4]
					628134, -- [5]
					["id"] = 1598,
				},
				["181296"] = {
					"Kormrok", -- [1]
					"181296", -- [2]
					"Empowered Explosive Runes", -- [3]
					13, -- [4]
					"Interface\\Icons\\ability_bossfelmagnaron_runeempowered", -- [5]
					["id"] = 1787,
				},
				["146124"] = {
					"Norushen", -- [1]
					"146124", -- [2]
					"Self Doubt", -- [3]
					16, -- [4]
					895885, -- [5]
					["id"] = 1624,
				},
				["179909"] = {
					"Gorefiend", -- [1]
					"179909", -- [2]
					"Shared Fate", -- [3]
					18, -- [4]
					"Interface\\Icons\\ability_warlock_soullink", -- [5]
					["id"] = 1783,
				},
				["-13767"] = {
					"Skorpyron", -- [1]
					"-13767", -- [2]
					"Red Mode", -- [3]
					35, -- [4]
					1003591, -- [5]
					["id"] = 1849,
				},
				["116018"] = {
					"Feng the Accursed", -- [1]
					"116018", -- [2]
					"Epicenter (1)", -- [3]
					18, -- [4]
					"Interface\\Icons\\Spell_Nature_Earthquake", -- [5]
					["id"] = 1390,
				},
				["156225"] = {
					"Imperator Mar'gok", -- [1]
					"156225", -- [2]
					"Branded on YOU!", -- [3]
					4, -- [4]
					"Interface\\Icons\\ability_socererking_arcanewrath", -- [5]
					["id"] = 1705,
				},
				["-8294"] = {
					"Garrosh Hellscream", -- [1]
					"-8294", -- [2]
					"Farseer Wolf Rider", -- [3]
					30, -- [4]
					136015, -- [5]
					["id"] = 1623,
				},
				["227279"] = {
					"The Curator", -- [1]
					"227279", -- [2]
					"Power Discharge", -- [3]
					12, -- [4]
					136048, -- [5]
					["id"] = 1964,
				},
				["153794"] = {
					"Rukhran", -- [1]
					"153794", -- [2]
					"Pierce Armor", -- [3]
					10.5, -- [4]
					132354, -- [5]
					["id"] = 1700,
				},
				["215234"] = {
					"Il'gynoth", -- [1]
					"215234", -- [2]
					"Nightmarish Fury", -- [3]
					10, -- [4]
					530806, -- [5]
					["id"] = 1873,
				},
				["205843"] = {
					"Xavius", -- [1]
					"205843", -- [2]
					"<Cast: The Dreaming (1)>", -- [3]
					6, -- [4]
					136090, -- [5]
					["id"] = 1864,
				},
				["hardmode"] = {
					"Hodir", -- [1]
					"hardmode", -- [2]
					"Hard mode", -- [3]
					180, -- [4]
					132333, -- [5]
					["id"] = 1135,
				},
				["123474"] = {
					"Blade Lord Ta'yak", -- [1]
					"123474", -- [2]
					"Assault", -- [3]
					15, -- [4]
					236317, -- [5]
					["id"] = 1504,
				},
				["233062"] = {
					"Goroth", -- [1]
					"233062", -- [2]
					"Infernal Burning", -- [3]
					54, -- [4]
					135802, -- [5]
					["id"] = 2032,
				},
				["158385"] = {
					"Twin Ogron", -- [1]
					"158385", -- [2]
					"Pulverize", -- [3]
					28, -- [4]
					"Interface\\Icons\\INV_Stone_16", -- [5]
					["id"] = 1719,
				},
				["156030"] = {
					"Blackhand", -- [1]
					"156030", -- [2]
					"Throw Slag Bombs", -- [3]
					6, -- [4]
					"Interface\\Icons\\ability_blackhand_slagbombs", -- [5]
					["id"] = 1704,
				},
				["230139"] = {
					"Mistress Sassz'ine", -- [1]
					"230139", -- [2]
					"Hydra Shot (1)", -- [3]
					25, -- [4]
					133578, -- [5]
					["id"] = 2037,
				},
				["inferno_self"] = {
					"The Fallen Protectors", -- [1]
					"inferno_self", -- [2]
					"You explode!", -- [3]
					8.85, -- [4]
					132863, -- [5]
					["id"] = 1598,
				},
				["98710"] = {
					"Ragnaros", -- [1]
					"98710", -- [2]
					"Lava Wave", -- [3]
					30, -- [4]
					451169, -- [5]
					["id"] = 1203,
				},
				["200284"] = {
					"Naltira", -- [1]
					"200284", -- [2]
					"Tangled Web", -- [3]
					35, -- [4]
					237431, -- [5]
					["id"] = 1826,
				},
				["137122"] = {
					"Council of Elders", -- [1]
					"137122", -- [2]
					"Reckless Charge", -- [3]
					21, -- [4]
					458970, -- [5]
					["id"] = 1570,
				},
				["228633"] = {
					"Helya-TrialOfValor", -- [1]
					"228633", -- [2]
					"Give No Quarter", -- [3]
					7, -- [4]
					132337, -- [5]
					["id"] = 2008,
				},
				["194333"] = {
					"Glazer", -- [1]
					"194333", -- [2]
					"Beamed", -- [3]
					15, -- [4]
					236226, -- [5]
					["id"] = 1817,
				},
				["-12809"] = {
					"Dragons of Nightmare", -- [1]
					"-12809", -- [2]
					"Mark of Ysondre (1) on YOU!", -- [3]
					35, -- [4]
					"", -- [5]
					["id"] = 1854,
				},
				["234621"] = {
					"Mistress Sassz'ine", -- [1]
					"234621", -- [2]
					"Devouring Maw", -- [3]
					42.2, -- [4]
					463487, -- [5]
					["id"] = 2037,
				},
				["119888"] = {
					"Sha of Fear", -- [1]
					"119888", -- [2]
					"<Cast: Death Blossom>", -- [3]
					2.25, -- [4]
					461120, -- [5]
					["id"] = 1431,
				},
				["drone"] = {
					"Beth'tilac", -- [1]
					"drone", -- [2]
					"Drone", -- [3]
					45, -- [4]
					"Interface\\Icons\\INV_Misc_Head_Nerubian_01", -- [5]
					["id"] = 1197,
				},
				["183885"] = {
					"Hellfire High Council", -- [1]
					"183885", -- [2]
					"Mirror Images", -- [3]
					78, -- [4]
					"Interface\\Icons\\Spell_Nature_MirrorImage", -- [5]
					["id"] = 1798,
				},
				["firecaller"] = {
					"The Blast Furnace", -- [1]
					"firecaller", -- [2]
					"Firecaller", -- [3]
					75, -- [4]
					"Interface\\Icons\\Spell_Fire_Incinerate", -- [5]
					["id"] = 1690,
				},
				["193364"] = {
					"Ymiron", -- [1]
					"193364", -- [2]
					"Screams of the Dead", -- [3]
					5.9, -- [4]
					136184, -- [5]
					["id"] = 1822,
				},
				["185590"] = {
					"Archimonde", -- [1]
					"185590", -- [2]
					"Desecrate", -- [3]
					27, -- [4]
					"Interface\\Icons\\ability_bossfellord_felspike", -- [5]
					["id"] = 1799,
				},
				["181306"] = {
					"Kormrok", -- [1]
					"181306", -- [2]
					"Explosive Burst", -- [3]
					25, -- [4]
					"Interface\\Icons\\Ability_Mage_LivingBomb", -- [5]
					["id"] = 1787,
				},
				["125310"] = {
					"Blade Lord Ta'yak", -- [1]
					"125310", -- [2]
					"Blade Tempest", -- [3]
					60, -- [4]
					132369, -- [5]
					["id"] = 1504,
				},
				["213853"] = {
					"Spellblade Aluriel", -- [1]
					"213853", -- [2]
					"Animate: Mark of Frost", -- [3]
					75, -- [4]
					136243, -- [5]
					["id"] = 1871,
				},
				["241635"] = {
					"Maiden of Vigilance", -- [1]
					"241635", -- [2]
					"Hammer of Creation", -- [3]
					14, -- [4]
					135875, -- [5]
					["id"] = 2052,
				},
				["69165"] = {
					"Festergut", -- [1]
					"69165", -- [2]
					"Inhale (1)", -- [3]
					33.5, -- [4]
					"INTERFACE\\ICONS\\achievement_boss_festergutrotface", -- [5]
					["id"] = 1097,
				},
				["186407"] = {
					"Xhul'horac", -- [1]
					"186407", -- [2]
					"Fel Surge", -- [3]
					19, -- [4]
					"Interface\\Icons\\spell_fel_incinerate", -- [5]
					["id"] = 1800,
				},
				["182225"] = {
					"Archimonde", -- [1]
					"182225", -- [2]
					"Rain of Chaos", -- [3]
					62, -- [4]
					"Interface\\Icons\\ability_warlock_burningembersgreen", -- [5]
					["id"] = 1799,
				},
				["234817"] = {
					"Mephistroth", -- [1]
					"234817", -- [2]
					"Dark Solitude", -- [3]
					7.1, -- [4]
					458229, -- [5]
					["id"] = 2039,
				},
				["215582"] = {
					"Elerethe Renferal", -- [1]
					"215582", -- [2]
					"Raking Talons", -- [3]
					53, -- [4]
					537444, -- [5]
					["id"] = 1876,
				},
				["181973"] = {
					"Gorefiend", -- [1]
					"181973", -- [2]
					"Feast of Souls", -- [3]
					123, -- [4]
					"Interface\\Icons\\spell_misc_zandalari_council_soulswap", -- [5]
					["id"] = 1783,
				},
				["205588"] = {
					"Xavius", -- [1]
					"205588", -- [2]
					"Call of Nightmares", -- [3]
					55, -- [4]
					1357812, -- [5]
					["id"] = 1864,
				},
				["142842"] = {
					"Malkorok", -- [1]
					"142842", -- [2]
					"Breath of Y'Shaarj (1)", -- [3]
					67.7, -- [4]
					136194, -- [5]
					["id"] = 1595,
				},
				["232061"] = {
					"Harjatan the Bludger", -- [1]
					"232061", -- [2]
					"Draw In", -- [3]
					58, -- [4]
					893777, -- [5]
					["id"] = 2036,
				},
				["155864"] = {
					"Operator Thogar", -- [1]
					"155864", -- [2]
					"Grenade", -- [3]
					7, -- [4]
					"Interface\\Icons\\inv_misc_pyriumgrenade", -- [5]
					["id"] = 1692,
				},
				["228611"] = {
					"Helya-TrialOfValor", -- [1]
					"228611", -- [2]
					"Ghostly Rage", -- [3]
					10, -- [4]
					236310, -- [5]
					["id"] = 2008,
				},
				["-7086"] = {
					"Horridon", -- [1]
					"-7086", -- [2]
					"Zandalari Dinomancer", -- [3]
					58, -- [4]
					"Interface\\Icons\\ability_hunter_beastwithin", -- [5]
					["id"] = 1575,
				},
				["196947"] = {
					"Helya", -- [1]
					"196947", -- [2]
					"Submerged", -- [3]
					59, -- [4]
					136116, -- [5]
					["id"] = 1824,
				},
				["207976"] = {
					"Chronomatic Anomaly", -- [1]
					"207976", -- [2]
					"Full Power", -- [3]
					360, -- [4]
					1125916, -- [5]
					["id"] = 1865,
				},
				["233426"] = {
					"Demonic Inquisition", -- [1]
					"233426", -- [2]
					"Scythe Sweep", -- [3]
					5.8, -- [4]
					1060569, -- [5]
					["id"] = 2048,
				},
				["181305"] = {
					"Kormrok", -- [1]
					"181305", -- [2]
					"Swat", -- [3]
					22.348, -- [4]
					"INTERFACE\\ICONS\\inv_offhand_stratholme_a_02", -- [5]
					["id"] = 1787,
				},
				["172747"] = {
					"Ko'ragh", -- [1]
					"172747", -- [2]
					"Expel Magic: Frost", -- [3]
					40, -- [4]
					"Interface\\Icons\\spell_frost_frozenorb", -- [5]
					["id"] = 1723,
				},
				["135150"] = {
					"Lei Shen", -- [1]
					"135150", -- [2]
					"Crashing Thunder", -- [3]
					30, -- [4]
					"INTERFACE\\ICONS\\spell_shaman_measuredinsight", -- [5]
					["id"] = 1579,
				},
				["155539"] = {
					"Gruul", -- [1]
					"155539", -- [2]
					"Destructive Rampage", -- [3]
					105, -- [4]
					"Interface\\Icons\\Ability_Warrior_Rampage", -- [5]
					["id"] = 1691,
				},
				["suppresser"] = {
					"Valithria Dreamwalker", -- [1]
					"suppresser", -- [2]
					"Suppressers", -- [3]
					14, -- [4]
					"Interface\\Icons\\Spell_Shadow_ShadowEmbrace", -- [5]
					["id"] = 1098,
				},
				["215988"] = {
					"Tichondrius", -- [1]
					"215988", -- [2]
					"<Cast: Carrion Nightmare>", -- [3]
					8.5, -- [4]
					840194, -- [5]
					["id"] = 1862,
				},
				["-8183"] = {
					"Iron Juggernaut", -- [1]
					"-8183", -- [2]
					"Crawler Mine (1)", -- [3]
					30, -- [4]
					133710, -- [5]
					["id"] = 1600,
				},
				["138339"] = {
					"Ra-den", -- [1]
					"138339", -- [2]
					"Summon Crackling Stalker", -- [3]
					8, -- [4]
					237007, -- [5]
					["id"] = 1580,
				},
				["157943"] = {
					"Twin Ogron", -- [1]
					"157943", -- [2]
					"Whirlwind", -- [3]
					33, -- [4]
					"Interface\\Icons\\ability_whirlwind", -- [5]
					["id"] = 1719,
				},
				["212364"] = {
					"Elerethe Renferal", -- [1]
					"212364", -- [2]
					"Feeding Time", -- [3]
					16, -- [4]
					132196, -- [5]
					["id"] = 1876,
				},
				["207278"] = {
					"Patrol Captain Gerdo", -- [1]
					"207278", -- [2]
					"Arcane Lockdown", -- [3]
					27, -- [4]
					1041230, -- [5]
					["id"] = 1868,
				},
				["162066"] = {
					"Skylord Tovra", -- [1]
					"162066", -- [2]
					"Freezing Snare", -- [3]
					16.5, -- [4]
					537467, -- [5]
					["id"] = 1736,
				},
				["232488"] = {
					"Helya-TrialOfValor", -- [1]
					"232488", -- [2]
					"Dark Hatred: Onslaught", -- [3]
					12, -- [4]
					633004, -- [5]
					["id"] = 2008,
				},
				["198079"] = {
					"Smashspite", -- [1]
					"198079", -- [2]
					"Hateful Gaze", -- [3]
					5.8, -- [4]
					132284, -- [5]
					["id"] = 1834,
				},
				["bwcbSerenerivershi dere"] = {
					"Bars", -- [1]
					"bwcbSerenerivershi dere", -- [2]
					"Serenerivers: hi dere", -- [3]
					660, -- [4]
					"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
					["id"] = 1800,
				},
				["133767"] = {
					"Durumu the Forgotten", -- [1]
					"133767", -- [2]
					"Serious Wound", -- [3]
					12, -- [4]
					"Interface\\Icons\\Ability_Druid_InfectedWound", -- [5]
					["id"] = 1572,
				},
				["205370"] = {
					"Krosus", -- [1]
					"205370", -- [2]
					"Fel Beam (1)", -- [3]
					9.5, -- [4]
					841219, -- [5]
					["id"] = 1842,
				},
				["bwcbSereneriversbreaktime"] = {
					"Bars", -- [1]
					"bwcbSereneriversbreaktime", -- [2]
					"Serenerivers: breaktime", -- [3]
					600, -- [4]
					"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
					["id"] = 1777,
				},
				["202062"] = {
					"Shivermaw", -- [1]
					"202062", -- [2]
					"Frigid Winds", -- [3]
					61, -- [4]
					236209, -- [5]
					["id"] = 1845,
				},
				["150759"] = {
					"Slave Watcher Crushto", -- [1]
					"150759", -- [2]
					"Ferocious Yell", -- [3]
					13.3, -- [4]
					132333, -- [5]
					["id"] = 1653,
				},
				["134912"] = {
					"Lei Shen", -- [1]
					"134912", -- [2]
					"Decapitate", -- [3]
					40, -- [4]
					"Interface\\Icons\\ability_thunderking_decapitate", -- [5]
					["id"] = 1579,
				},
				["98237"] = {
					"Ragnaros", -- [1]
					"98237", -- [2]
					"Knockback", -- [3]
					25, -- [4]
					135807, -- [5]
					["id"] = 1203,
				},
				["204646"] = {
					"Oakheart", -- [1]
					"204646", -- [2]
					"Crushing Grip", -- [3]
					33, -- [4]
					236316, -- [5]
					["id"] = 1837,
				},
				["194668"] = {
					"Harbaron", -- [1]
					"194668", -- [2]
					"Nether Rip", -- [3]
					12.5, -- [4]
					1022950, -- [5]
					["id"] = 1823,
				},
				["227982"] = {
					"Helya-TrialOfValor", -- [1]
					"227982", -- [2]
					"Bilewater Redox on YOU!", -- [3]
					30, -- [4]
					458736, -- [5]
					["id"] = 2008,
				},
				["196543"] = {
					"Fenryr", -- [1]
					"196543", -- [2]
					"Unnerving Howl", -- [3]
					30, -- [4]
					1033494, -- [5]
					["id"] = 1807,
				},
				["197969"] = {
					"Ursoc", -- [1]
					"197969", -- [2]
					"Roaring Cacophony (1)", -- [3]
					40, -- [4]
					136195, -- [5]
					["id"] = 1841,
				},
				["69279"] = {
					"Festergut", -- [1]
					"69279", -- [2]
					"Gas Spore", -- [3]
					20, -- [4]
					"Interface\\Icons\\Spell_Shadow_CreepingPlague", -- [5]
					["id"] = 1097,
				},
				["213564"] = {
					"Spellblade Aluriel", -- [1]
					"213564", -- [2]
					"Animate: Arcane Orb", -- [3]
					65, -- [4]
					1033906, -- [5]
					["id"] = 1871,
				},
				["235271"] = {
					"Maiden of Vigilance", -- [1]
					"235271", -- [2]
					"Infusion", -- [3]
					2, -- [4]
					1122135, -- [5]
					["id"] = 2052,
				},
				["158054"] = {
					"Blackhand", -- [1]
					"158054", -- [2]
					"Smash (1)", -- [3]
					26, -- [4]
					"Interface\\Icons\\INV_Elemental_Primal_Fire", -- [5]
					["id"] = 1704,
				},
				["87770"] = {
					"Al'Akir", -- [1]
					"87770", -- [2]
					"Wind Burst", -- [3]
					22, -- [4]
					"Interface\\Icons\\Spell_Frost_WindWalkOn", -- [5]
					["id"] = 1034,
				},
				["206936"] = {
					"Star Augur Etraeus", -- [1]
					"206936", -- [2]
					"Icy Ejection (1)", -- [3]
					25, -- [4]
					612394, -- [5]
					["id"] = 1863,
				},
				["236603"] = {
					"Sisters of the Moon", -- [1]
					"236603", -- [2]
					"Rapid Shot", -- [3]
					17.1, -- [4]
					1035040, -- [5]
					["id"] = 2050,
				},
				["overfiend"] = {
					"Archimonde", -- [1]
					"overfiend", -- [2]
					"Felborne Overfiend", -- [3]
					45, -- [4]
					"Interface\\Icons\\Spell_Fire_FelFireNova", -- [5]
					["id"] = 1799,
				},
				["bombardment"] = {
					"The Iron Maidens", -- [1]
					"bombardment", -- [2]
					"Detonation Sequence (1)", -- [3]
					11, -- [4]
					"Interface\\Icons\\ability_ironmaidens_incindiarydevice", -- [5]
					["id"] = 1695,
				},
				["133939"] = {
					"Tortos", -- [1]
					"133939", -- [2]
					"Furious Stone Breath", -- [3]
					46, -- [4]
					"Interface\\Icons\\inv_misc_dust", -- [5]
					["id"] = 1565,
				},
				["117910"] = {
					"The Spirit Kings", -- [1]
					"117910", -- [2]
					"Flanking Orders", -- [3]
					25, -- [4]
					"Interface\\Icons\\Ability_Warrior_StalwartProtector", -- [5]
					["id"] = 1436,
				},
				["nightmare_horror"] = {
					"Il'gynoth", -- [1]
					"nightmare_horror", -- [2]
					"Nightmare Horror", -- [3]
					69, -- [4]
					463569, -- [5]
					["id"] = 1873,
				},
				["submerge"] = {
					"Ragnaros ", -- [1]
					"submerge", -- [2]
					"Submerge", -- [3]
					180, -- [4]
					"Interface\\Icons\\misc_arrowdown", -- [5]
					["id"] = 672,
				},
				["180300"] = {
					"Tyrant Velhari", -- [1]
					"180300", -- [2]
					"Infernal Tempest", -- [3]
					40, -- [4]
					"Interface\\Icons\\spell_sandstorm", -- [5]
					["id"] = 1784,
				},
				["demolisher"] = {
					"Galakras", -- [1]
					"demolisher", -- [2]
					"Demolisher", -- [3]
					20, -- [4]
					252185, -- [5]
					["id"] = 1622,
				},
				["212530"] = {
					"Spellblade Aluriel", -- [1]
					"212530", -- [2]
					"Replicate: Mark of Frost", -- [3]
					31, -- [4]
					135732, -- [5]
					["id"] = 1871,
				},
				["232827"] = {
					"Mistress Sassz'ine", -- [1]
					"232827", -- [2]
					"Crashing Wave", -- [3]
					32.5, -- [4]
					135861, -- [5]
					["id"] = 2037,
				},
				["200040"] = {
					"Naltira", -- [1]
					"200040", -- [2]
					"Nether Venom", -- [3]
					26, -- [4]
					237155, -- [5]
					["id"] = 1826,
				},
				["bwcbLocalhi there"] = {
					"Bars", -- [1]
					"bwcbLocalhi there", -- [2]
					"Local: hi there", -- [3]
					300, -- [4]
					"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
					["id"] = 1873,
				},
				["69076"] = {
					"Lord Marrowgar", -- [1]
					"69076", -- [2]
					"Bone Storm", -- [3]
					45, -- [4]
					"Interface\\Icons\\Ability_Druid_Cyclone", -- [5]
					["id"] = 1101,
				},
				["164974"] = {
					"Sadana Bloodfury", -- [1]
					"164974", -- [2]
					"Dark Eclipse", -- [3]
					59, -- [4]
					236151, -- [5]
					["id"] = 1677,
				},
				["139458"] = {
					"Megaera", -- [1]
					"139458", -- [2]
					"Rampage Incoming!", -- [3]
					5, -- [4]
					"INTERFACE\\ICONS\\trade_archaeology_whitehydrafigurine", -- [5]
					["id"] = 1578,
				},
				["196563"] = {
					"Warlord Parjesh", -- [1]
					"196563", -- [2]
					"Call Reinforcements", -- [3]
					5, -- [4]
					236422, -- [5]
					["id"] = 1810,
				},
				["206651"] = {
					"Xavius", -- [1]
					"206651", -- [2]
					"Darkening Soul", -- [3]
					7.5, -- [4]
					1396972, -- [5]
					["id"] = 1864,
				},
				["116711"] = {
					"Feng the Accursed", -- [1]
					"116711", -- [2]
					"Draw Flame (1)", -- [3]
					35, -- [4]
					"Interface\\Icons\\Spell_Fire_Burnout", -- [5]
					["id"] = 1390,
				},
				["37640"] = {
					"Leotheras the Blind", -- [1]
					"37640", -- [2]
					"Whirlwind", -- [3]
					15, -- [4]
					132369, -- [5]
					["id"] = 625,
				},
				["64465"] = {
					"Yogg-Saron", -- [1]
					"64465", -- [2]
					"~Empower Cooldown", -- [3]
					46, -- [4]
					237566, -- [5]
					["id"] = 1143,
				},
				["212258"] = {
					"Gul'dan", -- [1]
					"212258", -- [2]
					"Hand of Gul'dan", -- [3]
					7, -- [4]
					535592, -- [5]
					["id"] = 1866,
				},
				["144821"] = {
					"Garrosh Hellscream", -- [1]
					"144821", -- [2]
					"Hellscream's Warsong", -- [3]
					22, -- [4]
					892447, -- [5]
					["id"] = 1623,
				},
				["180163"] = {
					"Kilrogg Deadeye", -- [1]
					"180163", -- [2]
					"Savage Strikes", -- [3]
					6, -- [4]
					"Interface\\Icons\\Ability_Warrior_Bloodsurge", -- [5]
					["id"] = 1786,
				},
				["237276"] = {
					"Thrashbite the Scornful", -- [1]
					"237276", -- [2]
					"Pulverizing Cudgel", -- [3]
					6.1, -- [4]
					132340, -- [5]
					["id"] = 2057,
				},
				["210547"] = {
					"Elerethe Renferal", -- [1]
					"210547", -- [2]
					"Razor Wing", -- [3]
					60, -- [4]
					132918, -- [5]
					["id"] = 1876,
				},
				["117960"] = {
					"Elegon", -- [1]
					"117960", -- [2]
					"Celestial Breath", -- [3]
					8.5, -- [4]
					"Interface\\Icons\\Spell_Fire_BlueFlameBreath", -- [5]
					["id"] = 1500,
				},
				["117837"] = {
					"The Spirit Kings", -- [1]
					"117837", -- [2]
					"Delirious", -- [3]
					20, -- [4]
					"Interface\\Icons\\Spell_Shadow_UnholyFrenzy", -- [5]
					["id"] = 1436,
				},
				["181180"] = {
					"Mannoroth", -- [1]
					"181180", -- [2]
					"Inferno", -- [3]
					48, -- [4]
					"Interface\\Icons\\Spell_Fire_Felcano", -- [5]
					["id"] = 1795,
				},
				["-7080"] = {
					"Horridon", -- [1]
					"-7080", -- [2]
					"Charge", -- [3]
					33, -- [4]
					"Interface\\ICONS\\Ability_Warrior_BullRush.blp", -- [5]
					["id"] = 1575,
				},
				["-6870"] = {
					"Iron Qon", -- [1]
					"-6870", -- [2]
					"Unleashed Flame", -- [3]
					17, -- [4]
					135788, -- [5]
					["id"] = 1559,
				},
				["98953"] = {
					"Ragnaros", -- [1]
					"98953", -- [2]
					"Splitting Blow", -- [3]
					7, -- [4]
					525025, -- [5]
					["id"] = 1203,
				},
				["196587"] = {
					"Amalgam of Souls", -- [1]
					"196587", -- [2]
					"Soul Burst", -- [3]
					27.5, -- [4]
					1120185, -- [5]
					["id"] = 1832,
				},
				["205649"] = {
					"Star Augur Etraeus", -- [1]
					"205649", -- [2]
					"Fel Ejection (2)", -- [3]
					4, -- [4]
					841218, -- [5]
					["id"] = 1863,
				},
				["-7830"] = {
					"Primordius", -- [1]
					"-7830", -- [2]
					"Fully Mutated", -- [3]
					120, -- [4]
					801131, -- [5]
					["id"] = 1574,
				},
				["206675"] = {
					"Gul'dan", -- [1]
					"206675", -- [2]
					"<Cast: Shatter Essence>", -- [3]
					3, -- [4]
					1109118, -- [5]
					["id"] = 1866,
				},
				["227807"] = {
					"Odyn-TrialOfValor", -- [1]
					"227807", -- [2]
					"Storm of Justice", -- [3]
					4, -- [4]
					839983, -- [5]
					["id"] = 1958,
				},
				["207830"] = {
					"Xavius", -- [1]
					"207830", -- [2]
					"Corrupting Nova", -- [3]
					20.7, -- [4]
					1396969, -- [5]
					["id"] = 1864,
				},
				["portal"] = {
					"Valithria Dreamwalker", -- [1]
					"portal", -- [2]
					"Next Portals 1", -- [3]
					46, -- [4]
					"Interface\\Icons\\Spell_Nature_WispSplodeGreen", -- [5]
					["id"] = 1098,
				},
				["smashingBridge"] = {
					"Krosus", -- [1]
					"smashingBridge", -- [2]
					"Smashing Bridge (1)", -- [3]
					93, -- [4]
					135906, -- [5]
					["id"] = 1842,
				},
				["182066"] = {
					"Iron Reaver", -- [1]
					"182066", -- [2]
					"Falling Slam", -- [3]
					54, -- [4]
					"INTERFACE\\ICONS\\spell_shaman_earthquake", -- [5]
					["id"] = 1785,
				},
				["-7963"] = {
					"Thok the Bloodthirsty", -- [1]
					"-7963", -- [2]
					"Deafening Screech", -- [3]
					14, -- [4]
					252188, -- [5]
					["id"] = 1599,
				},
				["bwcbLocaltimeir"] = {
					"Bars", -- [1]
					"bwcbLocaltimeir", -- [2]
					"Local: timeir", -- [3]
					600, -- [4]
					"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
					["id"] = 1876,
				},
				["230901"] = {
					"Spellblade Aluriel", -- [1]
					"230901", -- [2]
					"Fel Soul", -- [3]
					18, -- [4]
					135802, -- [5]
					["id"] = 1871,
				},
				["71204"] = {
					"Lady Deathwhisper", -- [1]
					"71204", -- [2]
					"Next Touch", -- [3]
					7, -- [4]
					"Interface\\Icons\\Ability_Hibernation", -- [5]
					["id"] = 1100,
				},
				["218774"] = {
					"High Botanist Tel'arn", -- [1]
					"218774", -- [2]
					"Summon Plasma Spheres", -- [3]
					37, -- [4]
					525024, -- [5]
					["id"] = 1886,
				},
				["232192"] = {
					"Harjatan the Bludger", -- [1]
					"232192", -- [2]
					"Commanding Roar", -- [3]
					17.5, -- [4]
					642418, -- [5]
					["id"] = 2036,
				},
				["193566"] = {
					"Ymiron", -- [1]
					"193566", -- [2]
					"Arise, Fallen", -- [3]
					41.2, -- [4]
					136187, -- [5]
					["id"] = 1822,
				},
				["193235"] = {
					"Hymdall", -- [1]
					"193235", -- [2]
					"Dancing Blade", -- [3]
					3.3, -- [4]
					135408, -- [5]
					["id"] = 1805,
				},
				["-7920"] = {
					"General Nazgrim", -- [1]
					"-7920", -- [2]
					"Adds (1)", -- [3]
					46, -- [4]
					"Interface\\Icons\\achievement_guildperk_everybodysfriend", -- [5]
					["id"] = 1603,
				},
				["terror"] = {
					"Madness of Deathwing", -- [1]
					"terror", -- [2]
					"Elementium Terror", -- [3]
					35.5, -- [4]
					"Interface\\Icons\\ability_tetanus", -- [5]
					["id"] = 1299,
				},
				["230384"] = {
					"Mistress Sassz'ine", -- [1]
					"230384", -- [2]
					"Consuming Hunger", -- [3]
					20.5, -- [4]
					237395, -- [5]
					["id"] = 2037,
				},
				["-5772"] = {
					"The Stone Guard", -- [1]
					"-5772", -- [2]
					"Cobalt Mine", -- [3]
					8.4, -- [4]
					"Interface\\ICONS\\Spell_Frost_Piercing Chill.blp", -- [5]
					["id"] = 1395,
				},
				["196068"] = {
					"Corstilax", -- [1]
					"196068", -- [2]
					"Suppression Protocol", -- [3]
					6, -- [4]
					1041234, -- [5]
					["id"] = 1825,
				},
				["209628"] = {
					"Advisor Melandrus", -- [1]
					"209628", -- [2]
					"Piercing Gale", -- [3]
					7, -- [4]
					1020351, -- [5]
					["id"] = 1870,
				},
				["138691"] = {
					"Dark Animus", -- [1]
					"138691", -- [2]
					"Anima Font: Stynkfyst", -- [3]
					30, -- [4]
					524305, -- [5]
					["id"] = 1576,
				},
				["188929"] = {
					"Kilrogg Deadeye", -- [1]
					"188929", -- [2]
					"Heart Seeker", -- [3]
					25, -- [4]
					"Interface\\Icons\\Ability_Hunter_MarkedForDeath", -- [5]
					["id"] = 1786,
				},
				["208929"] = {
					"Il'gynoth", -- [1]
					"208929", -- [2]
					"Spew Corruption on YOU!", -- [3]
					10, -- [4]
					136211, -- [5]
					["id"] = 1873,
				},
				["122740"] = {
					"Imperial Vizier Zor'lok", -- [1]
					"122740", -- [2]
					"Convert", -- [3]
					36, -- [4]
					135740, -- [5]
					["id"] = 1507,
				},
				["155898"] = {
					"Oregorger", -- [1]
					"155898", -- [2]
					"Rolling Fury (1)", -- [3]
					3.5, -- [4]
					"Interface\\Icons\\6bf_rolling_fury", -- [5]
					["id"] = 1696,
				},
				["182051"] = {
					"Socrethar the Eternal", -- [1]
					"182051", -- [2]
					"Felblaze Charge", -- [3]
					29, -- [4]
					"Interface\\Icons\\spell_fire_moltenbloodgreen", -- [5]
					["id"] = 1794,
				},
				["sapper"] = {
					"Warmaster Blackhorn", -- [1]
					"sapper", -- [2]
					"Sapper", -- [3]
					70, -- [4]
					"Interface\\Icons\\INV_Misc_Bomb_05", -- [5]
					["id"] = 1298,
				},
				["186362"] = {
					"Mannoroth", -- [1]
					"186362", -- [2]
					"Wrath of Gul'dan", -- [3]
					5, -- [4]
					"Interface\\Icons\\warlock_curse_shadow_aura", -- [5]
					["id"] = 1795,
				},
				["181824"] = {
					"Shadow-Lord Iskar", -- [1]
					"181824", -- [2]
					"Phantasmal Corruption on YOU!", -- [3]
					10, -- [4]
					"Interface\\Icons\\spell_fel_elementaldevastation", -- [5]
					["id"] = 1783,
				},
				["137350"] = {
					"Council of Elders", -- [1]
					"137350", -- [2]
					"Fixated: Rothric", -- [3]
					20, -- [4]
					"Interface\\Icons\\spell_priest_divinestar_shadow2", -- [5]
					["id"] = 1570,
				},
				["206464"] = {
					"Star Augur Etraeus", -- [1]
					"206464", -- [2]
					"Coronal Ejection", -- [3]
					12.5, -- [4]
					1029591, -- [5]
					["id"] = 1863,
				},
				["164275"] = {
					"Witherbark", -- [1]
					"164275", -- [2]
					"Brittle Bark", -- [3]
					30, -- [4]
					443393, -- [5]
					["id"] = 1746,
				},
				["235059"] = {
					"Kil'jaeden", -- [1]
					"235059", -- [2]
					"Rupturing Singularity (1)", -- [3]
					58, -- [4]
					1041232, -- [5]
					["id"] = 2051,
				},
				["bwcbSereneriversbreaaaak!"] = {
					"Bars", -- [1]
					"bwcbSereneriversbreaaaak!", -- [2]
					"Serenerivers: breaaaak!", -- [3]
					600, -- [4]
					"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
					["id"] = 1876,
				},
				["flesh_eater"] = {
					"Brackenspore", -- [1]
					"flesh_eater", -- [2]
					"Big Add", -- [3]
					32, -- [4]
					"Interface\\Icons\\Ability_Creature_Disease_02", -- [5]
					["id"] = 1720,
				},
				["234059"] = {
					"Fallen Avatar", -- [1]
					"234059", -- [2]
					"Unbound Chaos", -- [3]
					7, -- [4]
					135795, -- [5]
					["id"] = 2038,
				},
				["86281"] = {
					"Conclave of Wind", -- [1]
					"86281", -- [2]
					"Toxic Spores", -- [3]
					23, -- [4]
					"Interface\\Icons\\Spell_Shadow_DemonicEmpathy", -- [5]
					["id"] = 1035,
				},
				["203381"] = {
					"Thalena", -- [1]
					"203381", -- [2]
					"Blood Call", -- [3]
					30, -- [4]
					538039, -- [5]
					["id"] = 1855,
				},
				["227616"] = {
					"Moroes", -- [1]
					"227616", -- [2]
					"Empowered Arms", -- [3]
					9.5, -- [4]
					537253, -- [5]
					["id"] = 1961,
				},
				["158134"] = {
					"Twin Ogron", -- [1]
					"158134", -- [2]
					"Shield Charge", -- [3]
					38, -- [4]
					"Interface\\Icons\\Ability_Warrior_ShieldGuard", -- [5]
					["id"] = 1719,
				},
				["72272"] = {
					"Rotface", -- [1]
					"72272", -- [2]
					"Vile Gas", -- [3]
					20, -- [4]
					"Interface\\Icons\\Ability_Creature_Cursed_01", -- [5]
					["id"] = 1104,
				},
				["218927"] = {
					"High Botanist Tel'arn", -- [1]
					"218927", -- [2]
					"Grace of Nature", -- [3]
					72, -- [4]
					136074, -- [5]
					["id"] = 1886,
				},
				["156631"] = {
					"The Iron Maidens", -- [1]
					"156631", -- [2]
					"Rapid Fire", -- [3]
					19, -- [4]
					"Interface\\Icons\\ability_ironmaidens_rapidfire", -- [5]
					["id"] = 1695,
				},
				["72262"] = {
					"The Lich King", -- [1]
					"72262", -- [2]
					"Quake", -- [3]
					62, -- [4]
					"Interface\\Icons\\Spell_Fire_BlueHellfire", -- [5]
					["id"] = 1106,
				},
				["197546"] = {
					"Illysanna Ravencrest", -- [1]
					"197546", -- [2]
					"Brutal Glaive", -- [3]
					5.5, -- [4]
					1138466, -- [5]
					["id"] = 1833,
				},
				["193092"] = {
					"Hymdall", -- [1]
					"193092", -- [2]
					"Bloodletting Sweep", -- [3]
					17.7, -- [4]
					589068, -- [5]
					["id"] = 1805,
				},
				["230403"] = {
					"Spellblade Aluriel", -- [1]
					"230403", -- [2]
					"Fel Lash (1)", -- [3]
					5.5, -- [4]
					1388065, -- [5]
					["id"] = 1871,
				},
				["233206"] = {
					"Mephistroth", -- [1]
					"233206", -- [2]
					"Shadow Fade", -- [3]
					44.2, -- [4]
					132095, -- [5]
					["id"] = 2039,
				},
				["232913"] = {
					"Mistress Sassz'ine", -- [1]
					"232913", -- [2]
					"Befouling Ink", -- [3]
					11, -- [4]
					1500933, -- [5]
					["id"] = 2037,
				},
				["155776"] = {
					"Flamebender Ka'graz", -- [1]
					"155776", -- [2]
					"Summon Cinder Wolves", -- [3]
					60, -- [4]
					"Interface\\Icons\\item_summon_cinderwolf", -- [5]
					["id"] = 1689,
				},
				["117961"] = {
					"The Spirit Kings", -- [1]
					"117961", -- [2]
					"Impervious Shield", -- [3]
					40, -- [4]
					"Interface\\Icons\\Ability_Warrior_ShieldMastery", -- [5]
					["id"] = 1436,
				},
				["156107"] = {
					"Blackhand", -- [1]
					"156107", -- [2]
					"Impaling Throw", -- [3]
					5, -- [4]
					"Interface\\Icons\\Ability_SearingArrow", -- [5]
					["id"] = 1704,
				},
				["156877"] = {
					"Oregorger", -- [1]
					"156877", -- [2]
					"Blackrock Barrage", -- [3]
					14, -- [4]
					"Interface\\Icons\\6bf_blackrock_nova", -- [5]
					["id"] = 1696,
				},
				["154135"] = {
					"Araknath", -- [1]
					"154135", -- [2]
					"Burst", -- [3]
					20, -- [4]
					525026, -- [5]
					["id"] = 1699,
				},
				["228300"] = {
					"Helya-TrialOfValor", -- [1]
					"228300", -- [2]
					"Fury of the Maw", -- [3]
					50, -- [4]
					237590, -- [5]
					["id"] = 2008,
				},
				["185237"] = {
					"Tyrant Velhari", -- [1]
					"185237", -- [2]
					"Touch of Harm", -- [3]
					16, -- [4]
					"Interface\\Icons\\Spell_Shadow_ChillTouch", -- [5]
					["id"] = 1784,
				},
				["202455"] = {
					"Inquisitor Tormentorum", -- [1]
					"202455", -- [2]
					"Void Shield on BOSS!", -- [3]
					10, -- [4]
					132886, -- [5]
					["id"] = 1850,
				},
				["205344"] = {
					"Krosus", -- [1]
					"205344", -- [2]
					"Orb of Destruction (1)", -- [3]
					70, -- [4]
					135800, -- [5]
					["id"] = 1842,
				},
				["233556"] = {
					"Fallen Avatar", -- [1]
					"233556", -- [2]
					"Corrupted Matrix", -- [3]
					50, -- [4]
					1097741, -- [5]
					["id"] = 2038,
				},
				["trains"] = {
					"Operator Thogar", -- [1]
					"trains", -- [2]
					"Lane 1: Adds train", -- [3]
					32, -- [4]
					"Interface\\Icons\\warrior_talent_icon_furyintheblood", -- [5]
					["id"] = 1692,
				},
				["breaths"] = {
					"Megaera", -- [1]
					"breaths", -- [2]
					"Breaths", -- [3]
					5, -- [4]
					"Interface\\Icons\\INV_Misc_Head_Dragon_Black", -- [5]
					["id"] = 1578,
				},
				["228619"] = {
					"Helya-TrialOfValor", -- [1]
					"228619", -- [2]
					"Lantern of Darkness", -- [3]
					30, -- [4]
					134553, -- [5]
					["id"] = 2008,
				},
				["155242"] = {
					"The Blast Furnace", -- [1]
					"155242", -- [2]
					"Heat", -- [3]
					10, -- [4]
					"Interface\\Icons\\INV_Ammo_FireTar", -- [5]
					["id"] = 1690,
				},
				["197943"] = {
					"Ursoc", -- [1]
					"197943", -- [2]
					"Overwhelm", -- [3]
					10, -- [4]
					132358, -- [5]
					["id"] = 1841,
				},
				["69508"] = {
					"Rotface", -- [1]
					"69508", -- [2]
					"Next Spray", -- [3]
					19, -- [4]
					"Interface\\Icons\\Spell_Fire_Felcano", -- [5]
					["id"] = 1104,
				},
				["180600"] = {
					"Tyrant Velhari", -- [1]
					"180600", -- [2]
					"Bulwark of the Tyrant", -- [3]
					10, -- [4]
					"Interface\\Icons\\inv_shield_grimbatolraid_d_02", -- [5]
					["id"] = 1784,
				},
				["228785"] = {
					"Nightbane", -- [1]
					"228785", -- [2]
					"Cinder Breath", -- [3]
					8, -- [4]
					135831, -- [5]
					["id"] = 2031,
				},
				["206219"] = {
					"Gul'dan", -- [1]
					"206219", -- [2]
					"Liquid Hellfire (2)", -- [3]
					15, -- [4]
					135803, -- [5]
					["id"] = 1866,
				},
				["orb_melee"] = {
					"Helya-TrialOfValor", -- [1]
					"orb_melee", -- [2]
					"Melee Orb (2)", -- [3]
					28, -- [4]
					1097742, -- [5]
					["id"] = 2008,
				},
				["85422"] = {
					"Conclave of Wind", -- [1]
					"85422", -- [2]
					"Nurture/Wind Blast/Storm Shield", -- [3]
					30, -- [4]
					"Interface\\Icons\\achievement_boss_murmur", -- [5]
					["id"] = 1035,
				},
				["180260"] = {
					"Tyrant Velhari", -- [1]
					"180260", -- [2]
					"Annihilating Strike (1)", -- [3]
					10, -- [4]
					"INTERFACE\\ICONS\\inv_misc_volatilefire", -- [5]
					["id"] = 1784,
				},
				["190223"] = {
					"Xhul'horac", -- [1]
					"190223", -- [2]
					"Fel Strike", -- [3]
					8, -- [4]
					"Interface\\Icons\\ability_deathwing_grasping_tendrilsgreen", -- [5]
					["id"] = 1800,
				},
				["224508"] = {
					"Xavius", -- [1]
					"224508", -- [2]
					"Corruption Meteor: Helya*", -- [3]
					5, -- [4]
					1396970, -- [5]
					["id"] = 1864,
				},
				["siegevehicles"] = {
					"Hellfire Assault", -- [1]
					"siegevehicles", -- [2]
					"Left: Felfire Artillery", -- [3]
					137, -- [4]
					"Interface\\Icons\\INV_Misc_MissileLarge_Red", -- [5]
					["id"] = 1778,
				},
				["181292"] = {
					"Kormrok", -- [1]
					"181292", -- [2]
					"Fel Outpouring", -- [3]
					71, -- [4]
					"Interface\\Icons\\spell_yorsahj_bloodboil_purple", -- [5]
					["id"] = 1787,
				},
				["156203"] = {
					"Oregorger", -- [1]
					"156203", -- [2]
					"Retched Blackrock", -- [3]
					7, -- [4]
					"Interface\\Icons\\ability_vehicle_oiljets", -- [5]
					["id"] = 1696,
				},
				["211615"] = {
					"Trilliax", -- [1]
					"211615", -- [2]
					"Sterilize on YOU!", -- [3]
					45, -- [4]
					237587, -- [5]
					["id"] = 1867,
				},
				["179407"] = {
					"Fel Lord Zakuun", -- [1]
					"179407", -- [2]
					"Disembodied: Masquerading", -- [3]
					15, -- [4]
					"Interface\\Icons\\Ability_Mage_PotentSpirit", -- [5]
					["id"] = 1777,
				},
				["117227"] = {
					"Protectors of the Endless", -- [1]
					"117227", -- [2]
					"Corrupted Waters", -- [3]
					11, -- [4]
					462651, -- [5]
					["id"] = 1409,
				},
				["213275"] = {
					"Spellblade Aluriel", -- [1]
					"213275", -- [2]
					"Detonate: Searing Brand", -- [3]
					48, -- [4]
					135811, -- [5]
					["id"] = 1871,
				},
				["226194"] = {
					"Xavius", -- [1]
					"226194", -- [2]
					"Writhing Deep", -- [3]
					21, -- [4]
					1357812, -- [5]
					["id"] = 1864,
				},
				["210879"] = {
					"Fel Lord Betrug", -- [1]
					"210879", -- [2]
					"Seed of Destruction", -- [3]
					16, -- [4]
					136193, -- [5]
					["id"] = 1856,
				},
				["236604"] = {
					"Fallen Avatar", -- [1]
					"236604", -- [2]
					"Shadowy Blades", -- [3]
					30, -- [4]
					1035040, -- [5]
					["id"] = 2038,
				},
				["181557"] = {
					"Mannoroth", -- [1]
					"181557", -- [2]
					"Fel Hellstorm", -- [3]
					33, -- [4]
					"Interface\\Icons\\Spell_Fire_FelRainOfFire", -- [5]
					["id"] = 1795,
				},
				["235117"] = {
					"Maiden of Vigilance", -- [1]
					"235117", -- [2]
					"Unstable Soul on YOU!", -- [3]
					8, -- [4]
					841221, -- [5]
					["id"] = 2052,
				},
				["183329"] = {
					"Socrethar the Eternal", -- [1]
					"183329", -- [2]
					"Apocalypse (1)", -- [3]
					51.5, -- [4]
					"Interface\\Icons\\Spell_Shadow_ShadowPower", -- [5]
					["id"] = 1794,
				},
				["-9394"] = {
					"Kargath Bladefist", -- [1]
					"-9394", -- [2]
					"Fire Pillar", -- [3]
					20, -- [4]
					"Interface\\ICONS\\Spell_Fire_LavaSpawn.blp", -- [5]
					["id"] = 1721,
				},
				["72295"] = {
					"Professor Putricide", -- [1]
					"72295", -- [2]
					"Next bouncing goo ball", -- [3]
					6, -- [4]
					237376, -- [5]
					["id"] = 1102,
				},
				["227503"] = {
					"Odyn-TrialOfValor", -- [1]
					"227503", -- [2]
					"Draw Power", -- [3]
					40, -- [4]
					236247, -- [5]
					["id"] = 1958,
				},
				["-4159"] = {
					"Hagara the Stormbinder", -- [1]
					"-4159", -- [2]
					"Focused Assault", -- [3]
					15, -- [4]
					"Interface\\ICONS\\INV_Axe_107.blp", -- [5]
					["id"] = 1296,
				},
				["162968"] = {
					"Tectus", -- [1]
					"162968", -- [2]
					"Earthen Flechettes", -- [3]
					15, -- [4]
					"Interface\\Icons\\inv_misc_volatileearth", -- [5]
					["id"] = 1722,
				},
				["162415"] = {
					"Oshir", -- [1]
					"162415", -- [2]
					"Time to Feed: Kharonxela", -- [3]
					20, -- [4]
					132139, -- [5]
					["id"] = 1750,
				},
				["205862"] = {
					"Krosus", -- [1]
					"205862", -- [2]
					"Slam (1)", -- [3]
					33, -- [4]
					135906, -- [5]
					["id"] = 1842,
				},
				["190224"] = {
					"Xhul'horac", -- [1]
					"190224", -- [2]
					"Void Strike", -- [3]
					17, -- [4]
					"Interface\\Icons\\Spell_Shadow_FocusedPower", -- [5]
					["id"] = 1800,
				},
				["65123"] = {
					"Hodir", -- [1]
					"65123", -- [2]
					"Storm Cloud on YOU!", -- [3]
					30, -- [4]
					136075, -- [5]
					["id"] = 1135,
				},
				["204372"] = {
					"Skorpyron", -- [1]
					"204372", -- [2]
					"Call of the Scorpid", -- [3]
					21, -- [4]
					620833, -- [5]
					["id"] = 1849,
				},
				["159250"] = {
					"Kargath Bladefist", -- [1]
					"159250", -- [2]
					"Dancing", -- [3]
					10, -- [4]
					"Interface\\Icons\\ability_warrior_bladestorm", -- [5]
					["id"] = 1721,
				},
				["213569"] = {
					"Spellblade Aluriel", -- [1]
					"213569", -- [2]
					"<Cast: Armageddon>", -- [3]
					30, -- [4]
					607865, -- [5]
					["id"] = 1871,
				},
				["balls"] = {
					"Ra-den", -- [1]
					"balls", -- [2]
					"Balls", -- [3]
					11, -- [4]
					136028, -- [5]
					["id"] = 1580,
				},
				["182280"] = {
					"Iron Reaver", -- [1]
					"182280", -- [2]
					"Artillery on YOU!", -- [3]
					13, -- [4]
					"Interface\\Icons\\Ability_Hunter_MarkedForDeath", -- [5]
					["id"] = 1785,
				},
				["expedient_elemental"] = {
					"Grand Magistrix Elisande", -- [1]
					"expedient_elemental", -- [2]
					"Expedient Elemental", -- [3]
					8, -- [4]
					648208, -- [5]
					["id"] = 1872,
				},
				["shriveled_eyestalk"] = {
					"Il'gynoth", -- [1]
					"shriveled_eyestalk", -- [2]
					"Shriveled Eyestalk", -- [3]
					10, -- [4]
					462324, -- [5]
					["id"] = 1873,
				},
				["206609"] = {
					"Chronomatic Anomaly", -- [1]
					"206609", -- [2]
					"Time Release", -- [3]
					5, -- [4]
					413594, -- [5]
					["id"] = 1865,
				},
				["227404"] = {
					"Attumen the Huntsman", -- [1]
					"227404", -- [2]
					"Intangible Presence", -- [3]
					5, -- [4]
					135974, -- [5]
					["id"] = 1960,
				},
				["156157"] = {
					"The Butcher", -- [1]
					"156157", -- [2]
					"Cleave", -- [3]
					5, -- [4]
					"Interface\\Icons\\ability_butcher_cleave", -- [5]
					["id"] = 1706,
				},
				["-6554"] = {
					"Wind Lord Mel'jarak", -- [1]
					"-6554", -- [2]
					"Reinforcements: The Sra'thik", -- [3]
					50, -- [4]
					624009, -- [5]
					["id"] = 1498,
				},
				["211261"] = {
					"Grand Magistrix Elisande", -- [1]
					"211261", -- [2]
					"Permeliative Torment on YOU!", -- [3]
					11.5380000000005, -- [4]
					1041232, -- [5]
					["id"] = 1872,
				},
				["228171"] = {
					"Odyn-TrialOfValor", -- [1]
					"228171", -- [2]
					"Hyrja: Revivify", -- [3]
					10, -- [4]
					236249, -- [5]
					["id"] = 1958,
				},
				["100604"] = {
					"Ragnaros", -- [1]
					"100604", -- [2]
					"Empower Sulfuras", -- [3]
					90, -- [4]
					515200, -- [5]
					["id"] = 1203,
				},
				["122406"] = {
					"Wind Lord Mel'jarak", -- [1]
					"122406", -- [2]
					"Rain of Blades", -- [3]
					60, -- [4]
					615303, -- [5]
					["id"] = 1498,
				},
				["248671"] = {
					"Demonic Inquisition", -- [1]
					"248671", -- [2]
					"Unbridled Torment", -- [3]
					480, -- [4]
					1344654, -- [5]
					["id"] = 2048,
				},
				["228054"] = {
					"Helya-TrialOfValor", -- [1]
					"228054", -- [2]
					"Taint of the Sea", -- [3]
					12, -- [4]
					136030, -- [5]
					["id"] = 2008,
				},
				["116174"] = {
					"Gara'jal the Spiritbinder", -- [1]
					"116174", -- [2]
					"Totem (1)", -- [3]
					36.5, -- [4]
					"Interface\\Icons\\Spell_Nature_AgitatingTotem", -- [5]
					["id"] = 1434,
				},
				["216290"] = {
					"Ularogg Cragshaper", -- [1]
					"216290", -- [2]
					"Strike of the Mountain", -- [3]
					15, -- [4]
					136025, -- [5]
					["id"] = 1791,
				},
				["156938"] = {
					"Hans'gar and Franzok", -- [1]
					"156938", -- [2]
					"Crippling Suplex", -- [3]
					3, -- [4]
					"Interface\\Icons\\ability_hanzandfranz_chestbump", -- [5]
					["id"] = 1693,
				},
				["226821"] = {
					"Cenarius", -- [1]
					"226821", -- [2]
					"Desiccating Stomp (1)", -- [3]
					20, -- [4]
					1357801, -- [5]
					["id"] = 1877,
				},
				["201153"] = {
					"Kaahrj", -- [1]
					"201153", -- [2]
					"Eternal Darkness", -- [3]
					15, -- [4]
					537022, -- [5]
					["id"] = 1846,
				},
				["202328"] = {
					"Fel Lord Betrug", -- [1]
					"202328", -- [2]
					"<Cast: Mighty Smash>", -- [3]
					3, -- [4]
					132338, -- [5]
					["id"] = 1856,
				},
				["blobs"] = {
					"Yor'sahj the Unsleeping", -- [1]
					"blobs", -- [2]
					"Next blob spawn", -- [3]
					21, -- [4]
					"Interface\\Icons\\achievement_doublerainbow", -- [5]
					["id"] = 1295,
				},
				["214335"] = {
					"Star Augur Etraeus", -- [1]
					"214335", -- [2]
					"Gravitational Pull: Zenjii", -- [3]
					10, -- [4]
					1041234, -- [5]
					["id"] = 1863,
				},
				["154442"] = {
					"Ner'zhul", -- [1]
					"154442", -- [2]
					"Malevolence", -- [3]
					9, -- [4]
					237557, -- [5]
					["id"] = 1682,
				},
				["194323"] = {
					"Glazer", -- [1]
					"194323", -- [2]
					"Focusing", -- [3]
					32, -- [4]
					132177, -- [5]
					["id"] = 1817,
				},
				["215430"] = {
					"Halls of Valor Trash", -- [1]
					"215430", -- [2]
					"Thunderstrike: Hexmepls", -- [3]
					3, -- [4]
					839983, -- [5]
					["id"] = 1806,
				},
				["215460"] = {
					"Elerethe Renferal", -- [1]
					"215460", -- [2]
					"Necrotic Venom", -- [3]
					22, -- [4]
					132107, -- [5]
					["id"] = 1876,
				},
				["towers"] = {
					"Galakras", -- [1]
					"towers", -- [2]
					"Tower defender", -- [3]
					6, -- [4]
					236452, -- [5]
					["id"] = 1622,
				},
				["201240"] = {
					"Millificent Manastorm", -- [1]
					"201240", -- [2]
					"Elementium Squirrel Bomb", -- [3]
					7, -- [4]
					133709, -- [5]
					["id"] = 1847,
				},
				["-4347"] = {
					"Madness of Deathwing", -- [1]
					"-4347", -- [2]
					"Parasite", -- [3]
					11, -- [4]
					"Interface\\Icons\\ability_rhyolith_magmaflow_wave", -- [5]
					["id"] = 1299,
				},
				["202341"] = {
					"Anub'esset", -- [1]
					"202341", -- [2]
					"Impale", -- [3]
					22, -- [4]
					132090, -- [5]
					["id"] = 1852,
				},
				["-9352"] = {
					"Flamebender Ka'graz", -- [1]
					"-9352", -- [2]
					"Enchanted Weapon", -- [3]
					46, -- [4]
					"Interface\\Icons\\inv_sword_1h_firelandsraid_d_04", -- [5]
					["id"] = 1689,
				},
				["212707"] = {
					"Elerethe Renferal", -- [1]
					"212707", -- [2]
					"<Cast: Gathering Clouds>", -- [3]
					10.5, -- [4]
					132188, -- [5]
					["id"] = 1876,
				},
				["60029"] = {
					"Jedoga Shadowseeker", -- [1]
					"60029", -- [2]
					"Thundershock", -- [3]
					10, -- [4]
					136014, -- [5]
					["id"] = 1967,
				},
				["144616"] = {
					"Garrosh Hellscream", -- [1]
					"144616", -- [2]
					"Power Iron Star", -- [3]
					15, -- [4]
					236216, -- [5]
					["id"] = 1623,
				},
				["192617"] = {
					"Wrath of Azshara", -- [1]
					"192617", -- [2]
					"Massive Deluge", -- [3]
					12, -- [4]
					893778, -- [5]
					["id"] = 1814,
				},
				["134926"] = {
					"Iron Qon", -- [1]
					"134926", -- [2]
					"Throw Spear", -- [3]
					33, -- [4]
					"Interface\\Icons\\inv_shield_73", -- [5]
					["id"] = 1559,
				},
				["155192"] = {
					"The Blast Furnace", -- [1]
					"155192", -- [2]
					"Bomb on YOU!", -- [3]
					9.77499999999418, -- [4]
					"Interface\\Icons\\inv_misc_enggizmos_35", -- [5]
					["id"] = 1690,
				},
				["106523"] = {
					"Madness of Deathwing", -- [1]
					"106523", -- [2]
					"Cataclysm", -- [3]
					175, -- [4]
					"Interface\\Icons\\ability_deathwing_cataclysm", -- [5]
					["id"] = 1299,
				},
				["185510"] = {
					"Shadow-Lord Iskar", -- [1]
					"185510", -- [2]
					"Dark Bindings", -- [3]
					21, -- [4]
					"INTERFACE\\ICONS\\inv_misc_steelweaponchain", -- [5]
					["id"] = 1788,
				},
				["eyes"] = {
					"Grand Empress Shek'zeer", -- [1]
					"eyes", -- [2]
					"Eyes", -- [3]
					10.5, -- [4]
					133016, -- [5]
					["id"] = 1501,
				},
				["202779"] = {
					"Thalena", -- [1]
					"202779", -- [2]
					"Essence", -- [3]
					7, -- [4]
					236300, -- [5]
					["id"] = 1855,
				},
				["179864"] = {
					"Gorefiend", -- [1]
					"179864", -- [2]
					"|TInterface\\LFGFrame\\UI-LFG-ICON-PORTRAITROLES.blp:16:16:0:0:64:64:20:39:22:41|t Shadow of Death", -- [3]
					2, -- [4]
					"Interface\\Icons\\Spell_Arcane_PrismaticCloak", -- [5]
					["id"] = 1783,
				},
				["98498"] = {
					"Ragnaros", -- [1]
					"98498", -- [2]
					"Molten Seed", -- [3]
					22.7, -- [4]
					236301, -- [5]
					["id"] = 1203,
				},
				["156096"] = {
					"Blackhand", -- [1]
					"156096", -- [2]
					"Marked for Death", -- [3]
					36, -- [4]
					"Interface\\Icons\\ability_blackhand_marked4death", -- [5]
					["id"] = 1704,
				},
				["180025"] = {
					"Tyrant Velhari", -- [1]
					"180025", -- [2]
					"Harbinger's Mending (1)", -- [3]
					16, -- [4]
					"Interface\\Icons\\Spell_Shadow_ShadowMend", -- [5]
					["id"] = 1784,
				},
				["194956"] = {
					"Amalgam of Souls", -- [1]
					"194956", -- [2]
					"Reap Soul", -- [3]
					20.4, -- [4]
					237507, -- [5]
					["id"] = 1832,
				},
				["bwcbSereneriversbreeeaaaak"] = {
					"Bars", -- [1]
					"bwcbSereneriversbreeeaaaak", -- [2]
					"Serenerivers: breeeaaaak", -- [3]
					600, -- [4]
					"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
					["id"] = 1783,
				},
				["219488"] = {
					"Patrol Captain Gerdo", -- [1]
					"219488", -- [2]
					"Streetsweeper", -- [3]
					12, -- [4]
					1391767, -- [5]
					["id"] = 1868,
				},
				["183828"] = {
					"Archimonde", -- [1]
					"183828", -- [2]
					"Death Brand", -- [3]
					15.5, -- [4]
					"Interface\\Icons\\warlock_summon_doomguard", -- [5]
					["id"] = 1799,
				},
				["160734"] = {
					"Ko'ragh", -- [1]
					"160734", -- [2]
					"Vulnerability", -- [3]
					20, -- [4]
					"Interface\\Icons\\Spell_Fire_FelHellfire", -- [5]
					["id"] = 1723,
				},
				["cleave"] = {
					"Armsmaster Harlan", -- [1]
					"cleave", -- [2]
					"Cleave", -- [3]
					7.1, -- [4]
					132338, -- [5]
					["id"] = 1421,
				},
				["180244"] = {
					"Kormrok", -- [1]
					"180244", -- [2]
					"Pound (1)", -- [3]
					33, -- [4]
					"Interface\\Icons\\Ability_GolemThunderClap", -- [5]
					["id"] = 1787,
				},
				["206820"] = {
					"Trilliax", -- [1]
					"206820", -- [2]
					"Cleansing Rage", -- [3]
					10.5, -- [4]
					132345, -- [5]
					["id"] = 1867,
				},
				["122789"] = {
					"Tsulong", -- [1]
					"122789", -- [2]
					"Sunbeam", -- [3]
					42, -- [4]
					135981, -- [5]
					["id"] = 1505,
				},
				["bwcbSereneriverssherais here guise"] = {
					"Bars", -- [1]
					"bwcbSereneriverssherais here guise", -- [2]
					"Serenerivers: sherais here guise", -- [3]
					600, -- [4]
					"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
					["id"] = 1786,
				},
				["mind_fungus"] = {
					"Brackenspore", -- [1]
					"mind_fungus", -- [2]
					"Mind Fungus", -- [3]
					10, -- [4]
					"Interface\\Icons\\inv_mushroom_10", -- [5]
					["id"] = 1720,
				},
				["bwcbSereneriversactual break"] = {
					"Bars", -- [1]
					"bwcbSereneriversactual break", -- [2]
					"Serenerivers: actual break", -- [3]
					660, -- [4]
					"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
					["id"] = 1783,
				},
				["blob"] = {
					"Lady Hatecoil", -- [1]
					"blob", -- [2]
					"Saltsea Globule", -- [3]
					21, -- [4]
					135861, -- [5]
					["id"] = 1811,
				},
				["233514"] = {
					"Goroth", -- [1]
					"233514", -- [2]
					"Infernal Spike", -- [3]
					4.8, -- [4]
					1118739, -- [5]
					["id"] = 2032,
				},
				["bwcbSereneriversbreak!!!!!"] = {
					"Bars", -- [1]
					"bwcbSereneriversbreak!!!!!", -- [2]
					"Serenerivers: break!!!!!", -- [3]
					840, -- [4]
					"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
					["id"] = 1794,
				},
				["237726"] = {
					"Thrashbite the Scornful", -- [1]
					"237726", -- [2]
					"Scornful Gaze", -- [3]
					25.5, -- [4]
					132284, -- [5]
					["id"] = 2057,
				},
				["236524"] = {
					"Agronox", -- [1]
					"236524", -- [2]
					"Poisonous Spores (1)", -- [3]
					13.1, -- [4]
					132371, -- [5]
					["id"] = 2055,
				},
				["imps"] = {
					"Xhul'horac", -- [1]
					"imps", -- [2]
					"Wild Pyromaniac (1)", -- [3]
					12, -- [4]
					"Interface\\Icons\\spell_shadow_summonimp", -- [5]
					["id"] = 1800,
				},
				["123705"] = {
					"Lei Shi", -- [1]
					"123705", -- [2]
					"Scary Fog", -- [3]
					19, -- [4]
					136163, -- [5]
					["id"] = 1506,
				},
				["-7959"] = {
					"The Fallen Protectors", -- [1]
					"-7959", -- [2]
					"Inferno Strike", -- [3]
					7, -- [4]
					132863, -- [5]
					["id"] = 1598,
				},
				["207261"] = {
					"Patrol Captain Gerdo", -- [1]
					"207261", -- [2]
					"Resonant Slash", -- [3]
					6, -- [4]
					135734, -- [5]
					["id"] = 1868,
				},
				["238570"] = {
					"The Desolate Host", -- [1]
					"238570", -- [2]
					"Tormented Cries", -- [3]
					120, -- [4]
					463286, -- [5]
					["id"] = 2054,
				},
				["133798"] = {
					"Durumu the Forgotten", -- [1]
					"133798", -- [2]
					"Life Drain", -- [3]
					66, -- [4]
					136169, -- [5]
					["id"] = 1572,
				},
				["184124"] = {
					"Socrethar the Eternal", -- [1]
					"184124", -- [2]
					"Gift of the Man'ari", -- [3]
					5, -- [4]
					"Interface\\Icons\\Spell_Shadow_AntiMagicShell", -- [5]
					["id"] = 1794,
				},
				["99052"] = {
					"Beth'tilac", -- [1]
					"99052", -- [2]
					"Devastate #1", -- [3]
					80, -- [4]
					135981, -- [5]
					["id"] = 1197,
				},
				["-6699"] = {
					"Sha of Fear", -- [1]
					"-6699", -- [2]
					"Thrash", -- [3]
					10, -- [4]
					651090, -- [5]
					["id"] = 1431,
				},
				["212587"] = {
					"Spellblade Aluriel", -- [1]
					"212587", -- [2]
					"Mark of Frost", -- [3]
					18, -- [4]
					609814, -- [5]
					["id"] = 1871,
				},
				["143990"] = {
					"Kor'kron Dark Shaman", -- [1]
					"143990", -- [2]
					"Blobs", -- [3]
					32, -- [4]
					132104, -- [5]
					["id"] = 1606,
				},
				["nest"] = {
					"Ji-Kun", -- [1]
					"nest", -- [2]
					"(2) |cffff0000Lower|r nest", -- [3]
					40, -- [4]
					"Interface\\Icons\\misc_arrowdown", -- [5]
					["id"] = 1573,
				},
				["full_power"] = {
					"Conclave of Wind", -- [1]
					"full_power", -- [2]
					"Full Power", -- [3]
					90, -- [4]
					"Interface\\Icons\\Spell_Nature_Cyclone", -- [5]
					["id"] = 1035,
				},
				["-8034"] = {
					"Paragons of the Klaxxi", -- [1]
					"-8034", -- [2]
					"Choose Catalyst", -- [3]
					21, -- [4]
					878223, -- [5]
					["id"] = 1593,
				},
				["236527"] = {
					"Agronox", -- [1]
					"236527", -- [2]
					"Fulminating Lashers", -- [3]
					11, -- [4]
					135263, -- [5]
					["id"] = 2055,
				},
				["ironstar_impact"] = {
					"Garrosh Hellscream", -- [1]
					"ironstar_impact", -- [2]
					"Iron Star Impact", -- [3]
					9, -- [4]
					879998, -- [5]
					["id"] = 1623,
				},
				["70541"] = {
					"The Lich King", -- [1]
					"70541", -- [2]
					"Infest", -- [3]
					22, -- [4]
					"Interface\\Icons\\Ability_Rogue_EnvelopingShadows", -- [5]
					["id"] = 1106,
				},
				["bwcbSereneriversshort break"] = {
					"Bars", -- [1]
					"bwcbSereneriversshort break", -- [2]
					"Serenerivers: short break", -- [3]
					300, -- [4]
					"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
					["id"] = 1800,
				},
				["228835"] = {
					"Nightbane", -- [1]
					"228835", -- [2]
					"Absorb Vitality: Ansherai", -- [3]
					18, -- [4]
					136169, -- [5]
					["id"] = 2031,
				},
				["201148"] = {
					"Kaahrj", -- [1]
					"201148", -- [2]
					"Doom", -- [3]
					7, -- [4]
					136122, -- [5]
					["id"] = 1846,
				},
				["198263"] = {
					"Odyn", -- [1]
					"198263", -- [2]
					"Radiant Tempest", -- [3]
					24, -- [4]
					236250, -- [5]
					["id"] = 1809,
				},
				["184369"] = {
					"Hellfire Assault", -- [1]
					"184369", -- [2]
					"Howling Axe", -- [3]
					7, -- [4]
					"Interface\\Icons\\Ability_Hunter_MarkedForDeath", -- [5]
					["id"] = 1778,
				},
				["sunder"] = {
					"Warmaster Blackhorn", -- [1]
					"sunder", -- [2]
					"1x Sunder on Serenerivers", -- [3]
					30, -- [4]
					"Interface\\Icons\\Ability_Warrior_Sunder", -- [5]
					["id"] = 1298,
				},
				["240910"] = {
					"Kil'jaeden", -- [1]
					"240910", -- [2]
					"Armageddon (1)", -- [3]
					10, -- [4]
					136186, -- [5]
					["id"] = 2051,
				},
				["224333"] = {
					"Advisor Melandrus", -- [1]
					"224333", -- [2]
					"Enveloping Winds", -- [3]
					10, -- [4]
					1029595, -- [5]
					["id"] = 1870,
				},
				["stomp_add"] = {
					"Morchok", -- [1]
					"stomp_add", -- [2]
					"Kohcrom - Stomp", -- [3]
					5, -- [4]
					"Interface\\Icons\\INV_Misc_Apexis_Crystal", -- [5]
					["id"] = 1292,
				},
				["129147"] = {
					"Sha of Fear", -- [1]
					"129147", -- [2]
					"Ominous Cackle (1)", -- [3]
					25, -- [4]
					236279, -- [5]
					["id"] = 1431,
				},
				["211802"] = {
					"Xavius", -- [1]
					"211802", -- [2]
					"Nightmare Blades", -- [3]
					19.2, -- [4]
					1396975, -- [5]
					["id"] = 1864,
				},
				["181255"] = {
					"Mannoroth", -- [1]
					"181255", -- [2]
					"Fel Imp-losion", -- [3]
					38, -- [4]
					"Interface\\Icons\\Ability_Warlock_EmpoweredImp", -- [5]
					["id"] = 1795,
				},
				["injection_tank"] = {
					"Paragons of the Klaxxi", -- [1]
					"injection_tank", -- [2]
					"Injection", -- [3]
					9, -- [4]
					237031, -- [5]
					["id"] = 1593,
				},
				["188510"] = {
					"Hellfire Citadel Trash", -- [1]
					"188510", -- [2]
					"Graggra Smash: Adorable*", -- [3]
					5, -- [4]
					135860, -- [5]
					["id"] = 1798,
				},
				["19451"] = {
					"Magmadar", -- [1]
					"19451", -- [2]
					"Enrage", -- [3]
					8.5, -- [4]
					132117, -- [5]
					["id"] = 664,
				},
				["136990"] = {
					"Council of Elders", -- [1]
					"136990", -- [2]
					"Frostbite", -- [3]
					9.7, -- [4]
					"Interface\\Icons\\spell_mage_frostbomb", -- [5]
					["id"] = 1570,
				},
				["205741"] = {
					"Xavius", -- [1]
					"205741", -- [2]
					"Lurking Eruption", -- [3]
					18, -- [4]
					1396977, -- [5]
					["id"] = 1864,
				},
				["181354"] = {
					"Mannoroth", -- [1]
					"181354", -- [2]
					"Glaive Combo", -- [3]
					45, -- [4]
					"Interface\\Icons\\Ability_Warrior_Challange", -- [5]
					["id"] = 1795,
				},
				["bwcbSereneriversquick lets do this"] = {
					"Bars", -- [1]
					"bwcbSereneriversquick lets do this", -- [2]
					"Serenerivers: quick lets do this", -- [3]
					300, -- [4]
					"Interface\\Icons\\INV_Misc_PocketWatch_01", -- [5]
					["id"] = 1853,
				},
				["236712"] = {
					"Sisters of the Moon", -- [1]
					"236712", -- [2]
					"Lunar Beacon", -- [3]
					35.3, -- [4]
					429383, -- [5]
					["id"] = 2050,
				},
				["209973"] = {
					"Grand Magistrix Elisande", -- [1]
					"209973", -- [2]
					"Ablating Explosion: Plinixela", -- [3]
					8, -- [4]
					135728, -- [5]
					["id"] = 1872,
				},
				["162185"] = {
					"Ko'ragh", -- [1]
					"162185", -- [2]
					"Expel Magic: Fire", -- [3]
					6, -- [4]
					"Interface\\Icons\\INV_Elemental_Primal_Fire", -- [5]
					["id"] = 1723,
				},
				["159382"] = {
					"Rukhran", -- [1]
					"159382", -- [2]
					"Quills", -- [3]
					17, -- [4]
					132927, -- [5]
					["id"] = 1700,
				},
				["140741"] = {
					"Ji-Kun", -- [1]
					"140741", -- [2]
					"Primal Nutriment on YOU!", -- [3]
					30, -- [4]
					655706, -- [5]
					["id"] = 1573,
				},
				["193460"] = {
					"Ymiron", -- [1]
					"193460", -- [2]
					"Bane", -- [3]
					22.1, -- [4]
					136194, -- [5]
					["id"] = 1822,
				},
				["167910"] = {
					"Helya-TrialOfValor", -- [1]
					"167910", -- [2]
					"Adds", -- [3]
					14, -- [4]
					627487, -- [5]
					["id"] = 2008,
				},
				["122408"] = {
					"Amber-Shaper Un'sok", -- [1]
					"122408", -- [2]
					"Massive Stomp", -- [3]
					22, -- [4]
					132847, -- [5]
					["id"] = 1499,
				},
				["adds"] = {
					"Hellfire Assault", -- [1]
					"adds", -- [2]
					"Middle: Iron Dragoon", -- [3]
					18, -- [4]
					"Interface\\Icons\\achievement_character_orc_male", -- [5]
					["id"] = 1778,
				},
				["72091"] = {
					"Toravon the Ice Watcher", -- [1]
					"72091", -- [2]
					"Frozen Orb", -- [3]
					15, -- [4]
					135851, -- [5]
					["id"] = 1129,
				},
				["136817"] = {
					"Horridon", -- [1]
					"136817", -- [2]
					"Bestial Cry", -- [3]
					5, -- [4]
					236189, -- [5]
					["id"] = 1575,
				},
				["228162"] = {
					"Odyn-TrialOfValor", -- [1]
					"228162", -- [2]
					"Shield of Light", -- [3]
					24, -- [4]
					612968, -- [5]
					["id"] = 1958,
				},
				["flare"] = {
					"Beth'tilac", -- [1]
					"flare", -- [2]
					"Ember Flare", -- [3]
					6, -- [4]
					135807, -- [5]
					["id"] = 1197,
				},
				["fragment"] = {
					"Madness of Deathwing", -- [1]
					"fragment", -- [2]
					"Elementium Fragment", -- [3]
					10.5, -- [4]
					"Interface\\Icons\\ability_deathwing_grasping_tendrils", -- [5]
					["id"] = 1299,
				},
				["138780"] = {
					"Dark Animus", -- [1]
					"138780", -- [2]
					"Empower Golem", -- [3]
					7, -- [4]
					460957, -- [5]
					["id"] = 1576,
				},
				["122777"] = {
					"Tsulong", -- [1]
					"122777", -- [2]
					"Nightmares", -- [3]
					15.6, -- [4]
					136214, -- [5]
					["id"] = 1505,
				},
				["207906"] = {
					"Talixae Flamewreath", -- [1]
					"207906", -- [2]
					"Burning Intensity", -- [3]
					6, -- [4]
					135818, -- [5]
					["id"] = 1869,
				},
				["197556"] = {
					"Fenryr", -- [1]
					"197556", -- [2]
					"Ravenous Leap", -- [3]
					31, -- [4]
					1029718, -- [5]
					["id"] = 1807,
				},
				["118094"] = {
					"The Spirit Kings", -- [1]
					"118094", -- [2]
					"Volley", -- [3]
					41, -- [4]
					"Interface\\Icons\\ability_hunter_efficiency_brown", -- [5]
					["id"] = 1436,
				},
				["-7360"] = {
					"Ji-Kun", -- [1]
					"-7360", -- [2]
					"Flight", -- [3]
					10, -- [4]
					132927, -- [5]
					["id"] = 1573,
				},
				["202088"] = {
					"Helya", -- [1]
					"202088", -- [2]
					"Brackwater Barrage", -- [3]
					40.5, -- [4]
					135862, -- [5]
					["id"] = 1824,
				},
				["136992"] = {
					"Council of Elders", -- [1]
					"136992", -- [2]
					"Biting Cold", -- [3]
					45, -- [4]
					538770, -- [5]
					["id"] = 1570,
				},
				["nil"] = {
					"Bars", -- [1]
					"nil", -- [2]
					"Pull", -- [3]
					15, -- [4]
					"Interface\\Icons\\ability_warrior_charge", -- [5]
					["id"] = 1799,
				},
				["207439"] = {
					"Star Augur Etraeus", -- [1]
					"207439", -- [2]
					"Void Nova", -- [3]
					42, -- [4]
					458969, -- [5]
					["id"] = 1863,
				},
				["143773"] = {
					"Thok the Bloodthirsty", -- [1]
					"143773", -- [2]
					"Freezing Breath", -- [3]
					11, -- [4]
					135844, -- [5]
					["id"] = 1599,
				},
				["136037"] = {
					"Primordius", -- [1]
					"136037", -- [2]
					"Primordial Strike", -- [3]
					18, -- [4]
					"Interface\\Icons\\inv_hand_1h_bwdraid_d_01", -- [5]
					["id"] = 1574,
				},
				["-12687"] = {
					"Naltira", -- [1]
					"-12687", -- [2]
					"Blink Strikes", -- [3]
					16, -- [4]
					"Interface\\Icons\\spell_mage_arcaneorb", -- [5]
					["id"] = 1826,
				},
				["160838"] = {
					"Hans'gar and Franzok", -- [1]
					"160838", -- [2]
					"Disrupting Roar", -- [3]
					45, -- [4]
					"Interface\\Icons\\ability_garrosh_hellscreams_warsong", -- [5]
					["id"] = 1693,
				},
				["198820"] = {
					"Kurtalos Ravencrest", -- [1]
					"198820", -- [2]
					"Dark Blast", -- [3]
					12, -- [4]
					136141, -- [5]
					["id"] = 1835,
				},
				["228808"] = {
					"Nightbane", -- [1]
					"228808", -- [2]
					"Charred Earth", -- [3]
					15.5, -- [4]
					135819, -- [5]
					["id"] = 2031,
				},
				["184476"] = {
					"Hellfire High Council", -- [1]
					"184476", -- [2]
					"Reap", -- [3]
					67, -- [4]
					"INTERFACE\\ICONS\\ability_creature_cursed_03", -- [5]
					["id"] = 1798,
				},
				["179406"] = {
					"Fel Lord Zakuun", -- [1]
					"179406", -- [2]
					"Soul Cleave (1)", -- [3]
					25.5, -- [4]
					"Interface\\Icons\\Ability_Warrior_Cleave", -- [5]
					["id"] = 1777,
				},
				["205984"] = {
					"Star Augur Etraeus", -- [1]
					"205984", -- [2]
					"Gravitational Pull", -- [3]
					30, -- [4]
					1041234, -- [5]
					["id"] = 1863,
				},
				["234107"] = {
					"Domatrax", -- [1]
					"234107", -- [2]
					"Chaotic Energy", -- [3]
					32.5, -- [4]
					135799, -- [5]
					["id"] = 2053,
				},
				["155493"] = {
					"Flamebender Ka'graz", -- [1]
					"155493", -- [2]
					"Firestorm (1)", -- [3]
					62, -- [4]
					"Interface\\Icons\\spell_shaman_stormearthfire", -- [5]
					["id"] = 1689,
				},
				["205298"] = {
					"Dragons of Nightmare", -- [1]
					"205298", -- [2]
					"Essence of Corruption", -- [3]
					30, -- [4]
					134438, -- [5]
					["id"] = 1854,
				},
				["69325"] = {
					"Valithria Dreamwalker", -- [1]
					"69325", -- [2]
					"Lay Waste", -- [3]
					12, -- [4]
					236778, -- [5]
					["id"] = 1098,
				},
				["180040"] = {
					"Tyrant Velhari", -- [1]
					"180040", -- [2]
					"Sovereign's Ward", -- [3]
					14, -- [4]
					"Interface\\Icons\\inv_shield_38", -- [5]
					["id"] = 1784,
				},
				["59513"] = {
					"Prince Taldaram", -- [1]
					"59513", -- [2]
					"Embrace of the Vampyr", -- [3]
					20, -- [4]
					136129, -- [5]
					["id"] = 1966,
				},
				["118047"] = {
					"The Spirit Kings", -- [1]
					"118047", -- [2]
					"Pillage", -- [3]
					40, -- [4]
					"Interface\\Icons\\Ability_Rogue_Dismantle", -- [5]
					["id"] = 1436,
				},
				["239132"] = {
					"Fallen Avatar", -- [1]
					"239132", -- [2]
					"Rupture Realities", -- [3]
					37, -- [4]
					135801, -- [5]
					["id"] = 2038,
				},
				["61968"] = {
					"Hodir", -- [1]
					"61968", -- [2]
					"Flash Freeze", -- [3]
					35, -- [4]
					236214, -- [5]
					["id"] = 1135,
				},
				["144070"] = {
					"Kor'kron Dark Shaman", -- [1]
					"144070", -- [2]
					"Ashen Wall", -- [3]
					32.2, -- [4]
					651093, -- [5]
					["id"] = 1606,
				},
				["233279"] = {
					"Goroth", -- [1]
					"233279", -- [2]
					"Shattering Star (1)", -- [3]
					24, -- [4]
					517112, -- [5]
					["id"] = 2032,
				},
				["193367"] = {
					"Helya-TrialOfValor", -- [1]
					"193367", -- [2]
					"Fetid Rot", -- [3]
					7, -- [4]
					132100, -- [5]
					["id"] = 2008,
				},
				["-7062"] = {
					"Council of Elders", -- [1]
					"-7062", -- [2]
					"Quicksand", -- [3]
					7, -- [4]
					"Interface\\ICONS\\Spell_quicksand.blp", -- [5]
					["id"] = 1570,
				},
				["227967"] = {
					"Helya-TrialOfValor", -- [1]
					"227967", -- [2]
					"Bilewater Breath", -- [3]
					32, -- [4]
					132104, -- [5]
					["id"] = 2008,
				},
				["196838"] = {
					"Fenryr", -- [1]
					"196838", -- [2]
					"Scent of Blood", -- [3]
					34, -- [4]
					841383, -- [5]
					["id"] = 1807,
				},
				["186333"] = {
					"Xhul'horac", -- [1]
					"186333", -- [2]
					"Void Surge", -- [3]
					24, -- [4]
					"Interface\\Icons\\Spell_Shadow_DevouringPlague", -- [5]
					["id"] = 1800,
				},
				["229119"] = {
					"Helya-TrialOfValor", -- [1]
					"229119", -- [2]
					"Orb of Corruption", -- [3]
					14.5, -- [4]
					1097742, -- [5]
					["id"] = 2008,
				},
				["special"] = {
					"Lei Shi", -- [1]
					"special", -- [2]
					"Next special ability", -- [3]
					32, -- [4]
					136213, -- [5]
					["id"] = 1506,
				},
				["135251"] = {
					"Tortos", -- [1]
					"135251", -- [2]
					"Snapping Bite", -- [3]
					7, -- [4]
					"Interface\\Icons\\Ability_CriticalStrike", -- [5]
					["id"] = 1565,
				},
				["136954"] = {
					"Dark Animus", -- [1]
					"136954", -- [2]
					"Anima Ring", -- [3]
					22, -- [4]
					"Interface\\Icons\\ability_animusorbs", -- [5]
					["id"] = 1576,
				},
				["215062"] = {
					"Trilliax", -- [1]
					"215062", -- [2]
					"Imprint: Toxic Slice", -- [3]
					15.8, -- [4]
					237360, -- [5]
					["id"] = 1867,
				},
				["196115"] = {
					"Corstilax", -- [1]
					"196115", -- [2]
					"Cleansing Force", -- [3]
					30, -- [4]
					609815, -- [5]
					["id"] = 1825,
				},
				["209165"] = {
					"Grand Magistrix Elisande", -- [1]
					"209165", -- [2]
					"Slow Time on YOU!", -- [3]
					10.9880000000012, -- [4]
					653221, -- [5]
					["id"] = 1872,
				},
				["200700"] = {
					"Dargrul", -- [1]
					"200700", -- [2]
					"Landslide", -- [3]
					15, -- [4]
					451165, -- [5]
					["id"] = 1793,
				},
				["196610"] = {
					"Lady Hatecoil", -- [1]
					"196610", -- [2]
					"Monsoon", -- [3]
					31, -- [4]
					1029595, -- [5]
					["id"] = 1811,
				},
				["158093"] = {
					"Twin Ogron", -- [1]
					"158093", -- [2]
					"Interrupting Shout", -- [3]
					28, -- [4]
					"Interface\\Icons\\warrior_disruptingshout", -- [5]
					["id"] = 1719,
				},
				["31458"] = {
					"Temporus", -- [1]
					"31458", -- [2]
					"Hasten", -- [3]
					10, -- [4]
					136011, -- [5]
					["id"] = 1921,
				},
				["-8132"] = {
					"Kor'kron Dark Shaman", -- [1]
					"-8132", -- [2]
					"Foul Stream", -- [3]
					32, -- [4]
					840190, -- [5]
					["id"] = 1606,
				},
				["144800"] = {
					"Sha of Pride", -- [1]
					"144800", -- [2]
					"Small Adds", -- [3]
					25, -- [4]
					895885, -- [5]
					["id"] = 1604,
				},
				["200289"] = {
					"Shade of Xavius", -- [1]
					"200289", -- [2]
					"Growing Paranoia", -- [3]
					28, -- [4]
					460691, -- [5]
					["id"] = 1839,
				},
				["Breath of Fire"] = {
					"", -- [1]
					"Breath of Fire", -- [2]
					"Breath of Fire", -- [3]
					21, -- [4]
					"Interface\\Icons\\ability_monk_breathoffire", -- [5]
					["id"] = 1777,
				},
				["priestess_adds"] = {
					"Council of Elders", -- [1]
					"priestess_adds", -- [2]
					"Priestess add", -- [3]
					27, -- [4]
					"Interface\\Icons\\inv_misc_tournaments_banner_troll", -- [5]
					["id"] = 1570,
				},
				["136741"] = {
					"Horridon", -- [1]
					"136741", -- [2]
					"Double Swipe", -- [3]
					19, -- [4]
					"Interface\\Icons\\inv_misc_monsterhorn_07", -- [5]
					["id"] = 1575,
				},
				["123175"] = {
					"Blade Lord Ta'yak", -- [1]
					"123175", -- [2]
					"Wind Step", -- [3]
					20.5, -- [4]
					135863, -- [5]
					["id"] = 1504,
				},
				["122413"] = {
					"Amber-Shaper Un'sok", -- [1]
					"122413", -- [2]
					"Fling", -- [3]
					30, -- [4]
					463444, -- [5]
					["id"] = 1499,
				},
				["105490"] = {
					"Spine of Deathwing", -- [1]
					"105490", -- [2]
					"Fiery Grip", -- [3]
					11, -- [4]
					"Interface\\Icons\\ability_deathwing_fierygrip", -- [5]
					["id"] = 1291,
				},
				["206517"] = {
					"Star Augur Etraeus", -- [1]
					"206517", -- [2]
					"Fel Nova", -- [3]
					62, -- [4]
					1117883, -- [5]
					["id"] = 1863,
				},
				["182001"] = {
					"Iron Reaver", -- [1]
					"182001", -- [2]
					"Unstable Orb", -- [3]
					8.5, -- [4]
					"Interface\\Icons\\Spell_Fire_FelFlameRing", -- [5]
					["id"] = 1785,
				},
				["193659"] = {
					"God-King Skovald", -- [1]
					"193659", -- [2]
					"Felblaze Rush", -- [3]
					8.5, -- [4]
					1096201, -- [5]
					["id"] = 1808,
				},
				["210781"] = {
					"Il'gynoth", -- [1]
					"210781", -- [2]
					"<Cast: Dark Reconstitution>", -- [3]
					60, -- [4]
					1357796, -- [5]
					["id"] = 1873,
				},
				["mark"] = {
					"Hydross the Unstable", -- [1]
					"mark", -- [2]
					"10% - Mark of Hydross", -- [3]
					15, -- [4]
					135851, -- [5]
					["id"] = 623,
				},
				["213531"] = {
					"Tichondrius", -- [1]
					"213531", -- [2]
					"Echoes of the Void (1)", -- [3]
					57.5, -- [4]
					1022950, -- [5]
					["id"] = 1862,
				},
				["158315"] = {
					"The Iron Maidens", -- [1]
					"158315", -- [2]
					"Dark Hunt: Cecilian*", -- [3]
					8, -- [4]
					"Interface\\Icons\\ability_ironmaidens_darkhunt", -- [5]
					["id"] = 1695,
				},
				["197776"] = {
					"General Xakal", -- [1]
					"197776", -- [2]
					"Fel Fissure", -- [3]
					6, -- [4]
					1118738, -- [5]
					["id"] = 1828,
				},
			},
			["encounter_timers_dbm"] = {
			},
		},
	},
	["always_use_profile_name"] = "Default",
	["savedStyles"] = {
	},
	["always_use_profile_exception"] = {
	},
	["details_auras"] = {
	},
	["latest_news_saw"] = "v7.2.0.3673",
	["savedTimeCaptures"] = {
	},
	["plugin_window_pos"] = {
		["y"] = -5.24925231933594,
		["x"] = -163.000122070313,
		["point"] = "RIGHT",
		["scale"] = 1,
	},
	["custom"] = {
		{
			["source"] = false,
			["author"] = "Details!",
			["tooltip"] = "				\n			",
			["percent_script"] = "				local value, top, total, combat, instance = ...\n				return string.format (\"%.1f\", value/top*100)\n			",
			["desc"] = "Tells how much time each character spent doing damage.",
			["icon"] = "Interface\\ICONS\\Achievement_PVP_H_06",
			["spellid"] = false,
			["name"] = "Damage Activity Time",
			["script"] = "				--init:\n				local combat, instance_container, instance = ...\n				local total, amount = 0, 0\n\n				--get the misc actor container\n				local damage_container = combat:GetActorList ( DETAILS_ATTRIBUTE_DAMAGE )\n				\n				--do the loop:\n				for _, player in ipairs ( damage_container ) do \n					if (player.grupo) then\n						local activity = player:Tempo()\n						total = total + activity\n						amount = amount + 1\n						--add amount to the player \n						instance_container:AddValue (player, activity)\n					end\n				end\n				\n				--return:\n				return total, combat:GetCombatTime(), amount\n			",
			["target"] = false,
			["total_script"] = "				local value, top, total, combat, instance = ...\n				local minutos, segundos = math.floor (value/60), math.floor (value%60)\n				return minutos .. \"m \" .. segundos .. \"s\"\n			",
			["attribute"] = false,
			["script_version"] = 1,
		}, -- [1]
		{
			["source"] = false,
			["author"] = "Details!",
			["tooltip"] = "				\n			",
			["percent_script"] = "				local value, top, total, combat, instance = ...\n				return string.format (\"%.1f\", value/top*100)\n			",
			["desc"] = "Tells how much time each character spent doing healing.",
			["icon"] = "Interface\\ICONS\\Achievement_PVP_G_06",
			["spellid"] = false,
			["name"] = "Healing Activity Time",
			["script"] = "				--init:\n				local combat, instance_container, instance = ...\n				local total, top, amount = 0, 0, 0\n\n				--get the misc actor container\n				local damage_container = combat:GetActorList ( DETAILS_ATTRIBUTE_HEAL )\n				\n				--do the loop:\n				for _, player in ipairs ( damage_container ) do \n					if (player.grupo) then\n						local activity = player:Tempo()\n						total = total + activity\n						amount = amount + 1\n						--add amount to the player \n						instance_container:AddValue (player, activity)\n					end\n				end\n				\n				--return:\n				return total, combat:GetCombatTime(), amount\n			",
			["target"] = false,
			["total_script"] = "				local value, top, total, combat, instance = ...\n				local minutos, segundos = math.floor (value/60), math.floor (value%60)\n				return minutos .. \"m \" .. segundos .. \"s\"\n			",
			["attribute"] = false,
			["script_version"] = 1,
		}, -- [2]
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Show the crowd control amount for each player.",
			["total_script"] = "				local value, top, total, combat, instance = ...\n				return floor (value)\n			",
			["icon"] = "Interface\\ICONS\\Spell_Frost_FreezingBreath",
			["spellid"] = false,
			["name"] = "Crowd Control Done",
			["tooltip"] = "				local actor, combat, instance = ...\n				local spells = {}\n				for spellid, spell in pairs (actor.cc_done_spells._ActorTable) do\n				    tinsert (spells, {spellid, spell.counter})\n				end\n\n				table.sort (spells, _detalhes.Sort2)\n\n				for index, spell in ipairs (spells) do\n				    local name, _, icon = GetSpellInfo (spell [1])\n				    GameCooltip:AddLine (name, spell [2])\n				    _detalhes:AddTooltipBackgroundStatusbar()\n				    GameCooltip:AddIcon (icon, 1, 1, 14, 14)\n				end\n\n				local targets = {}\n				for playername, amount in pairs (actor.cc_done_targets) do\n				    tinsert (targets, {playername, amount})\n				end\n\n				table.sort (targets, _detalhes.Sort2)\n\n				_detalhes:AddTooltipSpellHeaderText (\"Targets\", \"yellow\", #targets)\n				local class, _, _, _, _, r, g, b = _detalhes:GetClass (actor.nome)\n				_detalhes:AddTooltipHeaderStatusbar (1, 1, 1, 0.6)\n\n				for index, target in ipairs (targets) do\n				    GameCooltip:AddLine (target[1], target [2])\n				    _detalhes:AddTooltipBackgroundStatusbar()\n				    \n				    local class, _, _, _, _, r, g, b = _detalhes:GetClass (target [1])\n				    if (class and class ~= \"UNKNOW\") then\n					local texture, l, r, t, b = _detalhes:GetClassIcon (class)\n					GameCooltip:AddIcon (\"Interface\\\\AddOns\\\\Details\\\\images\\\\classes_small_alpha\", 1, 1, 14, 14, l, r, t, b)\n				    else\n					GameCooltip:AddIcon (\"Interface\\\\GossipFrame\\\\IncompleteQuestIcon\", 1, 1, 14, 14)\n				    end\n				    --\n				end\n			",
			["target"] = false,
			["script"] = "				local combat, instance_container, instance = ...\n				local total, top, amount = 0, 0, 0\n\n				local misc_actors = combat:GetActorList (DETAILS_ATTRIBUTE_MISC)\n\n				for index, character in ipairs (misc_actors) do\n					if (character.cc_done and character:IsPlayer()) then\n						local cc_done = floor (character.cc_done)\n						instance_container:AddValue (character, cc_done)\n						total = total + cc_done\n						if (cc_done > top) then\n							top = cc_done\n						end\n						amount = amount + 1\n					end\n				end\n\n				return total, top, amount\n			",
			["attribute"] = false,
			["script_version"] = 9,
		}, -- [3]
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Show the amount of crowd control received for each player.",
			["total_script"] = "				local value, top, total, combat, instance = ...\n				return floor (value)\n			",
			["icon"] = "Interface\\ICONS\\Spell_Mage_IceNova",
			["spellid"] = false,
			["name"] = "Crowd Control Received",
			["tooltip"] = "				local actor, combat, instance = ...\n				local name = actor:name()\n				local spells, from = {}, {}\n				local misc_actors = combat:GetActorList (DETAILS_ATTRIBUTE_MISC)\n\n				for index, character in ipairs (misc_actors) do\n				    if (character.cc_done and character:IsPlayer()) then\n					local on_actor = character.cc_done_targets [name]\n					if (on_actor) then\n					    tinsert (from, {character:name(), on_actor})\n					    \n					    for spellid, spell in pairs (character.cc_done_spells._ActorTable) do\n						\n						local spell_on_actor = spell.targets [name]\n						if (spell_on_actor) then\n						    local has_spell\n						    for index, spell_table in ipairs (spells) do\n							if (spell_table [1] == spellid) then\n							    spell_table [2] = spell_table [2] + spell_on_actor\n							    has_spell = true\n							end\n						    end\n						    if (not has_spell) then\n							tinsert (spells, {spellid, spell_on_actor}) \n						    end\n						end\n						\n					    end            \n					end\n				    end\n				end\n\n				table.sort (from, _detalhes.Sort2)\n				table.sort (spells, _detalhes.Sort2)\n\n				for index, spell in ipairs (spells) do\n				    local name, _, icon = GetSpellInfo (spell [1])\n				    GameCooltip:AddLine (name, spell [2])\n				    _detalhes:AddTooltipBackgroundStatusbar()\n				    GameCooltip:AddIcon (icon, 1, 1, 14, 14)    \n				end\n\n				_detalhes:AddTooltipSpellHeaderText (\"From\", \"yellow\", #from)\n				_detalhes:AddTooltipHeaderStatusbar (1, 1, 1, 0.6)\n\n				for index, t in ipairs (from) do\n				    GameCooltip:AddLine (t[1], t[2])\n				    _detalhes:AddTooltipBackgroundStatusbar()\n				    \n				    local class, _, _, _, _, r, g, b = _detalhes:GetClass (t [1])\n				    if (class and class ~= \"UNKNOW\") then\n					local texture, l, r, t, b = _detalhes:GetClassIcon (class)\n					GameCooltip:AddIcon (\"Interface\\\\AddOns\\\\Details\\\\images\\\\classes_small_alpha\", 1, 1, 14, 14, l, r, t, b)\n				    else\n					GameCooltip:AddIcon (\"Interface\\\\GossipFrame\\\\IncompleteQuestIcon\", 1, 1, 14, 14)\n				    end     \n				    \n				end\n			",
			["target"] = false,
			["script"] = "				local combat, instance_container, instance = ...\n				local total, top, amt = 0, 0, 0\n\n				local misc_actors = combat:GetActorList (DETAILS_ATTRIBUTE_MISC)\n				DETAILS_CUSTOM_CC_RECEIVED_CACHE = DETAILS_CUSTOM_CC_RECEIVED_CACHE or {}\n				wipe (DETAILS_CUSTOM_CC_RECEIVED_CACHE)\n\n				for index, character in ipairs (misc_actors) do\n				    if (character.cc_done and character:IsPlayer()) then\n					\n					for player_name, amount in pairs (character.cc_done_targets) do\n					    local target = combat (1, player_name) or combat (2, player_name)\n					    if (target and target:IsPlayer()) then\n						instance_container:AddValue (target, amount)\n						total = total + amount\n						if (amount > top) then\n						    top = amount\n						end\n						if (not DETAILS_CUSTOM_CC_RECEIVED_CACHE [player_name]) then\n						    DETAILS_CUSTOM_CC_RECEIVED_CACHE [player_name] = true\n						    amt = amt + 1\n						end\n					    end\n					end\n					\n				    end\n				end\n\n				return total, top, amt\n			",
			["attribute"] = false,
			["script_version"] = 1,
		}, -- [4]
		{
			["source"] = false,
			["author"] = "Details!",
			["percent_script"] = "				local value, top, total, combat, instance = ...\n				local dps = _detalhes:ToK (floor (value) / combat:GetCombatTime())\n				local percent = string.format (\"%.1f\", value/total*100)\n				return dps .. \", \" .. percent\n			",
			["desc"] = "Show your spells in the window.",
			["tooltip"] = "			--config:\n			--Background RBG and Alpha:\n			local R, G, B, A = 0, 0, 0, 0.75\n			local R, G, B, A = 0.1960, 0.1960, 0.1960, 0.8697\n\n			--get the parameters passed\n			local spell, combat, instance = ...\n\n			--get the cooltip object (we dont use the convencional GameTooltip here)\n			local GC = GameCooltip\n			GC:SetOption (\"YSpacingMod\", 0)\n\n			local role = UnitGroupRolesAssigned (\"player\")\n\n			if (spell.n_dmg) then\n			    \n			    local spellschool, schooltext = spell.spellschool, \"\"\n			    if (spellschool) then\n				local t = _detalhes.spells_school [spellschool]\n				if (t and t.name) then\n				    schooltext = t.formated\n				end\n			    end\n			    \n			    local total_hits = spell.counter\n			    local combat_time = instance.showing:GetCombatTime()\n			    \n			    local debuff_uptime_total, cast_string = \"\", \"\"\n			    local misc_actor = instance.showing (4, _detalhes.playername)\n			    if (misc_actor) then\n				local debuff_uptime = misc_actor.debuff_uptime_spells and misc_actor.debuff_uptime_spells._ActorTable [spell.id] and misc_actor.debuff_uptime_spells._ActorTable [spell.id].uptime\n				if (debuff_uptime) then\n				    debuff_uptime_total = floor (debuff_uptime / instance.showing:GetCombatTime() * 100)\n				end\n				\n				local spell_cast = misc_actor.spell_cast and misc_actor.spell_cast [spell.id]\n				\n				if (not spell_cast and misc_actor.spell_cast) then\n				    local spellname = GetSpellInfo (spell.id)\n				    for casted_spellid, amount in pairs (misc_actor.spell_cast) do\n					local casted_spellname = GetSpellInfo (casted_spellid)\n					if (casted_spellname == spellname) then\n					    spell_cast = amount .. \" (|cFFFFFF00?|r)\"\n					end\n				    end\n				end\n				if (not spell_cast) then\n				    spell_cast = \"(|cFFFFFF00?|r)\"\n				end\n				cast_string = cast_string .. spell_cast\n			    end\n			    \n			    --Cooltip code\n			    GC:AddLine (\"Casts:\", cast_string or \"?\")\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    if (debuff_uptime_total ~= \"\") then\n				GC:AddLine (\"Uptime:\", (debuff_uptime_total or \"?\") .. \"%\")\n				GC:AddStatusBar (100, 1, R, G, B, A)\n			    end\n			    \n			    GC:AddLine (\"Hits:\", spell.counter)\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    local average = spell.total / total_hits\n			    GC:AddLine (\"Average:\", _detalhes:ToK (average))\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    GC:AddLine (\"E-Dps:\", _detalhes:ToK (spell.total / combat_time))\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    GC:AddLine (\"School:\", schooltext)\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    --GC:AddLine (\" \")\n			    \n			    GC:AddLine (\"Normal Hits: \", spell.n_amt .. \" (\" ..floor ( spell.n_amt/total_hits*100) .. \"%)\")\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    local n_average = spell.n_dmg / spell.n_amt\n			    local T = (combat_time*spell.n_dmg)/spell.total\n			    local P = average/n_average*100\n			    T = P*T/100\n			    \n			    GC:AddLine (\"Average / E-Dps: \",  _detalhes:ToK (n_average) .. \" / \" .. format (\"%.1f\",spell.n_dmg / T ))\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    --GC:AddLine (\" \")\n			    \n			    GC:AddLine (\"Critical Hits: \", spell.c_amt .. \" (\" ..floor ( spell.c_amt/total_hits*100) .. \"%)\")\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    if (spell.c_amt > 0) then\n				local c_average = spell.c_dmg/spell.c_amt\n				local T = (combat_time*spell.c_dmg)/spell.total\n				local P = average/c_average*100\n				T = P*T/100\n				local crit_dps = spell.c_dmg / T\n				\n				GC:AddLine (\"Average / E-Dps: \",  _detalhes:ToK (c_average) .. \" / \" .. _detalhes:comma_value (crit_dps))\n			    else\n				GC:AddLine (\"Average / E-Dps: \",  \"0 / 0\")    \n			    end\n			    \n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    --GC:AddLine (\" \")\n			    \n			    GC:AddLine (\"Multistrike: \", spell.m_amt .. \" (\" ..floor ( spell.m_amt/total_hits*100) .. \"%)\")\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    GC:AddLine (\"On Normal / On Critical:\", spell.m_amt - spell.m_crit .. \"  / \" .. spell.m_crit)\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			elseif (spell.n_curado) then\n			    \n			    local spellschool, schooltext = spell.spellschool, \"\"\n			    if (spellschool) then\n				local t = _detalhes.spells_school [spellschool]\n				if (t and t.name) then\n				    schooltext = t.formated\n				end\n			    end\n			    \n			    local total_hits = spell.counter\n			    local combat_time = instance.showing:GetCombatTime()\n			    \n			    --Cooltip code\n			    GC:AddLine (\"Hits:\", spell.counter)\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    local average = spell.total / total_hits\n			    GC:AddLine (\"Average:\", _detalhes:ToK (average))\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    GC:AddLine (\"E-Hps:\", _detalhes:ToK (spell.total / combat_time))\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    GC:AddLine (\"School:\", schooltext)\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    --GC:AddLine (\" \")\n			    \n			    GC:AddLine (\"Normal Hits: \", spell.n_amt .. \" (\" ..floor ( spell.n_amt/total_hits*100) .. \"%)\")\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    local n_average = spell.n_curado / spell.n_amt\n			    local T = (combat_time*spell.n_curado)/spell.total\n			    local P = average/n_average*100\n			    T = P*T/100\n			    \n			    GC:AddLine (\"Average / E-Dps: \",  _detalhes:ToK (n_average) .. \" / \" .. format (\"%.1f\",spell.n_curado / T ))\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    --GC:AddLine (\" \")\n			    \n			    GC:AddLine (\"Critical Hits: \", spell.c_amt .. \" (\" ..floor ( spell.c_amt/total_hits*100) .. \"%)\")\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    if (spell.c_amt > 0) then\n				local c_average = spell.c_curado/spell.c_amt\n				local T = (combat_time*spell.c_curado)/spell.total\n				local P = average/c_average*100\n				T = P*T/100\n				local crit_dps = spell.c_curado / T\n				\n				GC:AddLine (\"Average / E-Hps: \",  _detalhes:ToK (c_average) .. \" / \" .. _detalhes:comma_value (crit_dps))\n			    else\n				GC:AddLine (\"Average / E-Hps: \",  \"0 / 0\")    \n			    end\n			    \n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    --GC:AddLine (\" \")\n			    \n			    GC:AddLine (\"Multistrike: \", spell.m_amt .. \" (\" ..floor ( spell.m_amt/total_hits*100) .. \"%)\")\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			    \n			    GC:AddLine (\"On Normal / On Critical:\", spell.m_amt - spell.m_crit .. \"  / \" .. spell.m_crit)\n			    GC:AddStatusBar (100, 1, R, G, B, A)\n			end\n			",
			["icon"] = "Interface\\ICONS\\ABILITY_MAGE_ARCANEBARRAGE",
			["name"] = "My Spells",
			["spellid"] = false,
			["target"] = false,
			["script"] = "				--get the parameters passed\n				local combat, instance_container, instance = ...\n				--declade the values to return\n				local total, top, amount = 0, 0, 0\n\n				local player\n				local role = UnitGroupRolesAssigned (\"player\")\n				local pet_attribute\n\n				if (role == \"DAMAGER\") then\n					player = combat (DETAILS_ATTRIBUTE_DAMAGE, _detalhes.playername)\n					pet_attribute = DETAILS_ATTRIBUTE_DAMAGE\n				elseif (role == \"HEALER\") then    \n					player = combat (DETAILS_ATTRIBUTE_HEAL, _detalhes.playername)\n					pet_attribute = DETAILS_ATTRIBUTE_HEAL\n				else\n					player = combat (DETAILS_ATTRIBUTE_DAMAGE, _detalhes.playername)\n					pet_attribute = DETAILS_ATTRIBUTE_DAMAGE\n				end\n\n				--do the loop\n\n				if (player) then\n					local spells = player:GetSpellList()\n					for spellid, spell in pairs (spells) do\n						instance_container:AddValue (spell, spell.total)\n						total = total + spell.total\n						if (top < spell.total) then\n							top = spell.total\n						end\n						amount = amount + 1\n					end\n				    \n					for _, PetName in ipairs (player.pets) do\n						local pet = combat (pet_attribute, PetName)\n						if (pet) then\n							for spellid, spell in pairs (pet:GetSpellList()) do\n								instance_container:AddValue (spell, spell.total, nil, \" (\" .. PetName:gsub ((\" <.*\"), \"\") .. \")\")\n								total = total + spell.total\n								if (top < spell.total) then\n									top = spell.total\n								end\n								amount = amount + 1\n							end\n						end\n					end\n				end\n\n				--return the values\n				return total, top, amount\n			",
			["attribute"] = false,
			["script_version"] = 5,
		}, -- [5]
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Show the amount of damage applied on targets marked with skull.",
			["tooltip"] = "				--get the parameters passed\n				local actor, combat, instance = ...\n\n				--get the cooltip object (we dont use the convencional GameTooltip here)\n				local GameCooltip = GameCooltip\n\n				--Cooltip code\n				local format_func = Details:GetCurrentToKFunction()\n\n				--Cooltip code\n				local RaidTargets = actor.raid_targets\n\n				local DamageOnStar = RaidTargets [128]\n				if (DamageOnStar) then\n				    --RAID_TARGET_8 is the built-in localized word for 'Skull'.\n				    GameCooltip:AddLine (RAID_TARGET_8 .. \":\", format_func (_, DamageOnStar))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_8\", 1, 1, 14, 14)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n			",
			["icon"] = "Interface\\TARGETINGFRAME\\UI-RaidTargetingIcon_8",
			["name"] = "Damage On Skull Marked Targets",
			["spellid"] = false,
			["target"] = false,
			["script"] = "				--get the parameters passed\n				local Combat, CustomContainer, Instance = ...\n				--declade the values to return\n				local total, top, amount = 0, 0, 0\n				\n				--raid target flags: \n				-- 128: skull \n				-- 64: cross\n				-- 32: square\n				-- 16: moon\n				-- 8: triangle\n				-- 4: diamond\n				-- 2: circle\n				-- 1: star\n				\n				--do the loop\n				for _, actor in ipairs (Combat:GetActorList (DETAILS_ATTRIBUTE_DAMAGE)) do\n				    if (actor:IsPlayer()) then\n					if (actor.raid_targets [128]) then\n					    CustomContainer:AddValue (actor, actor.raid_targets [128])\n					end        \n				    end\n				end\n\n				--if not managed inside the loop, get the values of total, top and amount\n				total, top = CustomContainer:GetTotalAndHighestValue()\n				amount = CustomContainer:GetNumActors()\n\n				--return the values\n				return total, top, amount\n			",
			["attribute"] = false,
			["script_version"] = 2,
		}, -- [6]
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Show the amount of damage applied on targets marked with any other mark.",
			["tooltip"] = "				--get the parameters passed\n				local actor, combat, instance = ...\n\n				--get the cooltip object\n				local GameCooltip = GameCooltip\n\n				local format_func = Details:GetCurrentToKFunction()\n\n				--Cooltip code\n				local RaidTargets = actor.raid_targets\n\n				local DamageOnStar = RaidTargets [1]\n				if (DamageOnStar) then\n				    GameCooltip:AddLine (RAID_TARGET_1 .. \":\", format_func (_, DamageOnStar))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_1\", 1, 1, 14, 14)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n\n				local DamageOnCircle = RaidTargets [2]\n				if (DamageOnCircle) then\n				    GameCooltip:AddLine (RAID_TARGET_2 .. \":\", format_func (_, DamageOnCircle))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_2\", 1, 1, 14, 14)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n\n				local DamageOnDiamond = RaidTargets [4]\n				if (DamageOnDiamond) then\n				    GameCooltip:AddLine (RAID_TARGET_3 .. \":\", format_func (_, DamageOnDiamond))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_3\", 1, 1, 14, 14)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n\n				local DamageOnTriangle = RaidTargets [8]\n				if (DamageOnTriangle) then\n				    GameCooltip:AddLine (RAID_TARGET_4 .. \":\", format_func (_, DamageOnTriangle))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_4\", 1, 1, 14, 14)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n\n				local DamageOnMoon = RaidTargets [16]\n				if (DamageOnMoon) then\n				    GameCooltip:AddLine (RAID_TARGET_5 .. \":\", format_func (_, DamageOnMoon))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_5\", 1, 1, 14, 14)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n\n				local DamageOnSquare = RaidTargets [32]\n				if (DamageOnSquare) then\n				    GameCooltip:AddLine (RAID_TARGET_6 .. \":\", format_func (_, DamageOnSquare))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_6\", 1, 1, 14, 14)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n\n				local DamageOnCross = RaidTargets [64]\n				if (DamageOnCross) then\n				    GameCooltip:AddLine (RAID_TARGET_7 .. \":\", format_func (_, DamageOnCross))\n				    GameCooltip:AddIcon (\"Interface\\\\TARGETINGFRAME\\\\UI-RaidTargetingIcon_7\", 1, 1, 14, 14)\n				    Details:AddTooltipBackgroundStatusbar()\n				end\n			",
			["icon"] = "Interface\\TARGETINGFRAME\\UI-RaidTargetingIcon_5",
			["name"] = "Damage On Other Marked Targets",
			["spellid"] = false,
			["target"] = false,
			["script"] = "				--get the parameters passed\n				local Combat, CustomContainer, Instance = ...\n				--declade the values to return\n				local total, top, amount = 0, 0, 0\n\n				--do the loop\n				for _, actor in ipairs (Combat:GetActorList (DETAILS_ATTRIBUTE_DAMAGE)) do\n				    if (actor:IsPlayer()) then\n					local total = (actor.raid_targets [1] or 0) --star\n					total = total + (actor.raid_targets [2] or 0) --circle\n					total = total + (actor.raid_targets [4] or 0) --diamond\n					total = total + (actor.raid_targets [8] or 0) --tiangle\n					total = total + (actor.raid_targets [16] or 0) --moon\n					total = total + (actor.raid_targets [32] or 0) --square\n					total = total + (actor.raid_targets [64] or 0) --cross\n					\n					if (total > 0) then\n					    CustomContainer:AddValue (actor, total)\n					end\n				    end\n				end\n\n				--if not managed inside the loop, get the values of total, top and amount\n				total, top = CustomContainer:GetTotalAndHighestValue()\n				amount = CustomContainer:GetNumActors()\n\n				--return the values\n				return total, top, amount\n			",
			["attribute"] = false,
			["script_version"] = 2,
		}, -- [7]
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Calculates healing done from leech trinket.",
			["tooltip"] = "				\n			",
			["attribute"] = false,
			["name"] = "CalcLeech",
			["script"] = "				--get the parameters passed\n				local Combat, CustomContainer, Instance = ...\n				--declade the values to return\n				local total, top, amount = 0, 0, 0\n				\n				if (Combat.PlayerLeechTrinket) then\n					for playerName, amount in pairs (Combat.PlayerLeechTrinket) do\n						local healActor = Combat:GetActor (2, playerName)\n						if (healActor) then\n							CustomContainer:AddValue (healActor, amount)\n						end\n					end\n				end\n				\n				--if not managed inside the loop, get the values of total, top and amount\n				total, top = CustomContainer:GetTotalAndHighestValue()\n				amount = CustomContainer:GetNumActors()\n\n				--return the values\n				return total, top, amount\n			",
			["target"] = false,
			["spellid"] = false,
			["icon"] = "Interface\\ICONS\\spell_shadow_lifedrain02",
			["script_version"] = 3,
		}, -- [8]
		{
			["source"] = "[all]",
			["author"] = "Serenerivers-Korgath",
			["desc"] = "Who stood in voidstep? I can tell you.",
			["tooltip"] = false,
			["name"] = "Voidstep hits",
			["spellid"] = 188939,
			["target"] = "[raid]",
			["script"] = false,
			["icon"] = "INTERFACE\\ICONS\\ACHIEVEMENT_DUNGEON_SHADOWMOONHIDEOUT",
			["attribute"] = "damagedone",
		}, -- [9]
		{
			["source"] = false,
			["total_script"] = false,
			["author"] = "Details! Team",
			["percent_script"] = false,
			["desc"] = "Show who in your raid group used the healthstone or a heal potion.",
			["icon"] = "Interface\\ICONS\\warlock_ healthstone",
			["spellid"] = false,
			["name"] = "Health Potion & Stone",
			["script"] = "			--get the parameters passed\n			local combat, instance_container, instance = ...\n			--declade the values to return\n			local total, top, amount = 0, 0, 0\n			\n			--do the loop\n			local AllHealCharacters = combat:GetActorList (DETAILS_ATTRIBUTE_HEAL)\n			for index, character in ipairs (AllHealCharacters) do\n				local AllSpells = character:GetSpellList()\n				local found = false\n				for spellid, spell in pairs (AllSpells) do\n					if (DETAILS_HEALTH_POTION_LIST [spellid]) then\n						instance_container:AddValue (character, spell.total)\n						total = total + spell.total\n						if (top < spell.total) then\n							top = spell.total\n						end\n						found = true\n					end\n				end\n			\n				if (found) then\n					amount = amount + 1\n				end\n			end\n			--loop end\n			--return the values\n			return total, top, amount\n			",
			["target"] = false,
			["tooltip"] = "			--get the parameters passed\n			local actor, combat, instance = ...\n			\n			--get the cooltip object (we dont use the convencional GameTooltip here)\n			local GameCooltip = GameCooltip\n			local R, G, B, A = 0, 0, 0, 0.75\n			\n			local hs = actor:GetSpell (6262)\n			if (hs) then\n				GameCooltip:AddLine (select (1, GetSpellInfo(6262)),  _detalhes:ToK(hs.total))\n				GameCooltip:AddIcon (select (3, GetSpellInfo (6262)), 1, 1, 16, 16)\n				GameCooltip:AddStatusBar (100, 1, R, G, B, A)\n			end\n			\n			local pot = actor:GetSpell (DETAILS_HEALTH_POTION_ID)\n			if (pot) then\n				GameCooltip:AddLine (select (1, GetSpellInfo(DETAILS_HEALTH_POTION_ID)),  _detalhes:ToK(pot.total))\n				GameCooltip:AddIcon (select (3, GetSpellInfo (DETAILS_HEALTH_POTION_ID)), 1, 1, 16, 16)\n				GameCooltip:AddStatusBar (100, 1, R, G, B, A)\n			end\n			\n			local pot = actor:GetSpell (DETAILS_REJU_POTION_ID)\n			if (pot) then\n				GameCooltip:AddLine (select (1, GetSpellInfo(DETAILS_REJU_POTION_ID)),  _detalhes:ToK(pot.total))\n				GameCooltip:AddIcon (select (3, GetSpellInfo (DETAILS_REJU_POTION_ID)), 1, 1, 16, 16)\n				GameCooltip:AddStatusBar (100, 1, R, G, B, A)\n			end\n\n			--Cooltip code\n			",
			["attribute"] = false,
			["script_version"] = 13,
		}, -- [10]
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Show who in your raid used a potion during the encounter.",
			["tooltip"] = "			--init:\n			local player, combat, instance = ...\n\n			--get the debuff container for potion of focus\n			local debuff_uptime_container = player.debuff_uptime and player.debuff_uptime_spells and player.debuff_uptime_spells._ActorTable\n			if (debuff_uptime_container) then\n			    local focus_potion = debuff_uptime_container [188030] --Legion\n			    if (focus_potion) then\n				local name, _, icon = GetSpellInfo (188030) --Legion\n				GameCooltip:AddLine (name, 1) --> can use only 1 focus potion (can't be pre-potion)\n				_detalhes:AddTooltipBackgroundStatusbar()\n				GameCooltip:AddIcon (icon, 1, 1, 14, 14)\n			    end\n			end\n\n			--get the buff container for all the others potions\n			local buff_uptime_container = player.buff_uptime and player.buff_uptime_spells and player.buff_uptime_spells._ActorTable\n			if (buff_uptime_container) then\n			    --potion of the jade serpent\n			    local jade_serpent_potion = buff_uptime_container [188027] --Legion\n			    if (jade_serpent_potion) then\n				local name, _, icon = GetSpellInfo (188027) --Legion\n				GameCooltip:AddLine (name, jade_serpent_potion.activedamt)\n				_detalhes:AddTooltipBackgroundStatusbar()\n				GameCooltip:AddIcon (icon, 1, 1, 14, 14)\n			    end\n			    \n			    --potion of mogu power\n			    local mogu_power_potion = buff_uptime_container [188028] --Legion\n			    if (mogu_power_potion) then\n				local name, _, icon = GetSpellInfo (188028) --Legion\n				GameCooltip:AddLine (name, mogu_power_potion.activedamt)\n				_detalhes:AddTooltipBackgroundStatusbar()\n				GameCooltip:AddIcon (icon, 1, 1, 14, 14)\n			    end\n			    \n			    --mana potion\n			    local mana_potion = buff_uptime_container [188017] --Legion\n			    if (mana_potion) then\n				local name, _, icon = GetSpellInfo (188017) --Legion\n				GameCooltip:AddLine (name, mana_potion.activedamt)\n				_detalhes:AddTooltipBackgroundStatusbar()\n				GameCooltip:AddIcon (icon, 1, 1, 14, 14)\n			    end\n			    \n			    --prolongued power\n			    local prolongued_power = buff_uptime_container [229206] --Legion\n			    if (prolongued_power) then\n				local name, _, icon = GetSpellInfo (229206) --Legion\n				GameCooltip:AddLine (name, prolongued_power.activedamt)\n				_detalhes:AddTooltipBackgroundStatusbar()\n				GameCooltip:AddIcon (icon, 1, 1, 14, 14)\n			    end\n			    \n			    --potion of the mountains\n			    local mountains_potion = buff_uptime_container [188029] --Legion\n			    if (mountains_potion) then\n				local name, _, icon = GetSpellInfo (188029) --Legion\n				GameCooltip:AddLine (name, mountains_potion.activedamt)\n				_detalhes:AddTooltipBackgroundStatusbar()\n				GameCooltip:AddIcon (icon, 1, 1, 14, 14)\n			    end\n			end\n		",
			["icon"] = "Interface\\ICONS\\Trade_Alchemy_PotionD4",
			["name"] = "Potion Used",
			["spellid"] = false,
			["target"] = false,
			["script"] = "				--init:\n				local combat, instance_container, instance = ...\n				local total, top, amount = 0, 0, 0\n\n				--get the misc actor container\n				local misc_container = combat:GetActorList ( DETAILS_ATTRIBUTE_MISC )\n\n				--do the loop:\n				for _, player in ipairs ( misc_container ) do \n				    \n				    --only player in group\n				    if (player:IsGroupPlayer()) then\n					\n					local found_potion = false\n					\n					--get the spell debuff uptime container\n					local debuff_uptime_container = player.debuff_uptime and player.debuff_uptime_spells and player.debuff_uptime_spells._ActorTable\n					if (debuff_uptime_container) then\n					    --potion of focus (can't use as pre-potion, so, its amount is always 1\n					    local focus_potion = debuff_uptime_container [188030] --Legion\n					    if (focus_potion) then\n						total = total + 1\n						found_potion = true\n						if (top < 1) then\n						    top = 1\n						end\n						--add amount to the player \n						instance_container:AddValue (player, 1)\n					    end\n					end\n					\n					--get the spell buff uptime container\n					local buff_uptime_container = player.buff_uptime and player.buff_uptime_spells and player.buff_uptime_spells._ActorTable\n					if (buff_uptime_container) then\n					    \n					    --potion of the jade serpent\n					    local jade_serpent_potion = buff_uptime_container [188027] --Legion\n					    if (jade_serpent_potion) then\n						local used = jade_serpent_potion.activedamt\n						if (used > 0) then\n						    total = total + used\n						    found_potion = true\n						    if (used > top) then\n							top = used\n						    end\n						    --add amount to the player \n						    instance_container:AddValue (player, used)\n						end\n					    end\n					    \n					    --potion of mogu power\n					    local mogu_power_potion = buff_uptime_container [188028] --Legion\n					    if (mogu_power_potion) then\n						local used = mogu_power_potion.activedamt\n						if (used > 0) then\n						    total = total + used\n						    found_potion = true\n						    if (used > top) then\n							top = used\n						    end\n						    --add amount to the player \n						    instance_container:AddValue (player, used)\n						end\n					    end\n					    \n					    --mana potion\n					    local mana_potion = buff_uptime_container [188017] --Legion\n					    if (mana_potion) then\n						local used = mana_potion.activedamt\n						if (used > 0) then\n						    total = total + used\n						    found_potion = true\n						    if (used > top) then\n							top = used\n						    end\n						    --add amount to the player \n						    instance_container:AddValue (player, used)\n						end\n					    end\n					    \n					    --potion of prolongued power\n					    local prolongued_power = buff_uptime_container [229206] --Legion\n					    if (prolongued_power) then\n						local used = prolongued_power.activedamt\n						if (used > 0) then\n						    total = total + used\n						    found_potion = true\n						    if (used > top) then\n							top = used\n						    end\n						    --add amount to the player \n						    instance_container:AddValue (player, used)\n						end\n					    end\n					    \n					    --potion of the mountains\n					    local mountains_potion = buff_uptime_container [188029] --Legion\n					    if (mountains_potion) then\n						local used = mountains_potion.activedamt\n						if (used > 0) then\n						    total = total + used\n						    found_potion = true\n						    if (used > top) then\n							top = used\n						    end\n						    --add amount to the player \n						    instance_container:AddValue (player, used)\n						end\n					    end\n					end\n					\n					if (found_potion) then\n					    amount = amount + 1\n					end    \n				    end\n				end\n\n				--return:\n				return total, top, amount\n				",
			["attribute"] = false,
			["script_version"] = 3,
		}, -- [11]
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Show overall damage done on the fly.",
			["total_script"] = "				local value, top, total, combat, instance = ...\n\n				--get the time of overall combat\n				local OverallCombatTime = Details:GetCombat (-1):GetCombatTime()\n\n				--get the time of current combat if the player is in combat\n				if (Details.in_combat) then\n				    local CurrentCombatTime = Details:GetCombat (0):GetCombatTime()\n				    OverallCombatTime = OverallCombatTime + CurrentCombatTime\n				end\n\n				--build the string\n				local ToK = Details:GetCurrentToKFunction()\n				local s = ToK (_, total / OverallCombatTime)\n				s = ToK (_, total) .. \" (\" .. s .. \", \"\n\n				return s\n			",
			["icon"] = "Interface\\ICONS\\Achievement_Quests_Completed_08",
			["spellid"] = false,
			["name"] = "Dynamic Overall Damage",
			["tooltip"] = "				--get the parameters passed\n				local actor, combat, instance = ...\n\n				--get the cooltip object (we dont use the convencional GameTooltip here)\n				local GameCooltip = GameCooltip2\n\n				--Cooltip code\n				--get the overall combat\n				local OverallCombat = Details:GetCombat (-1)\n				--get the current combat\n				local CurrentCombat = Details:GetCombat (0)\n\n				local AllSpells = {}\n\n				--overall\n				local player = OverallCombat [1]:GetActor (actor.nome)\n				local playerSpells = player:GetSpellList()\n				for spellID, spellTable in pairs (playerSpells) do\n				    AllSpells [spellID] = spellTable.total\n				end\n\n				--current\n				local player = CurrentCombat [1]:GetActor (actor.nome)\n				local playerSpells = player:GetSpellList()\n				for spellID, spellTable in pairs (playerSpells) do\n				    AllSpells [spellID] = (AllSpells [spellID] or 0) + (spellTable.total or 0)\n				end\n\n				local sortedList = {}\n				for spellID, total in pairs (AllSpells) do\n				    tinsert (sortedList, {spellID, total})\n				end\n				table.sort (sortedList, Details.Sort2)\n\n				local format_func = Details:GetCurrentToKFunction()\n\n				--build the tooltip\n				for i, t in ipairs (sortedList) do\n				    local spellID, total = unpack (t)\n				    if (total > 1) then\n					local spellName, _, spellIcon = Details.GetSpellInfo (spellID)\n					\n					GameCooltip:AddLine (spellName, format_func (_, total))\n					Details:AddTooltipBackgroundStatusbar()\n					GameCooltip:AddIcon (spellIcon, 1, 1, 14, 14)\n				    end\n				end\n			",
			["target"] = false,
			["script"] = "				--init:\n				local combat, instance_container, instance = ...\n				local total, top, amount = 0, 0, 0\n\n				--get the overall combat\n				local OverallCombat = Details:GetCombat (-1)\n				--get the current combat\n				local CurrentCombat = Details:GetCombat (0)\n\n				if (not OverallCombat.GetActorList or not CurrentCombat.GetActorList) then\n				    return 0, 0, 0\n				end\n\n				--get the damage actor container for overall\n				local damage_container_overall = OverallCombat:GetActorList ( DETAILS_ATTRIBUTE_DAMAGE )\n				--get the damage actor container for current\n				local damage_container_current = CurrentCombat:GetActorList ( DETAILS_ATTRIBUTE_DAMAGE )\n\n				--do the loop:\n				for _, player in ipairs ( damage_container_overall ) do \n				    --only player in group\n				    if (player:IsGroupPlayer()) then\n					instance_container:AddValue (player, player.total)\n				    end\n				end\n\n				if (Details.in_combat) then\n				    for _, player in ipairs ( damage_container_current ) do \n					--only player in group\n					if (player:IsGroupPlayer()) then\n					    instance_container:AddValue (player, player.total)        \n					end\n				    end\n				end\n\n				total, top =  instance_container:GetTotalAndHighestValue()\n				amount =  instance_container:GetNumActors()\n\n				--return:\n				return total, top, amount\n			",
			["attribute"] = false,
			["script_version"] = 2,
		}, -- [12]
		{
			["source"] = false,
			["author"] = "Details!",
			["desc"] = "Damage done to shields",
			["tooltip"] = "				--get the parameters passed\n				local actor, Combat, instance = ...\n\n				--get the cooltip object (we dont use the convencional GameTooltip here)\n				local GameCooltip = GameCooltip\n\n				--Cooltip code\n				--get the actor total damage absorbed\n				local totalAbsorb = actor.totalabsorbed\n				local format_func = Details:GetCurrentToKFunction()\n\n				--get the damage absorbed by all the actor pets\n				for petIndex, petName in ipairs (actor.pets) do\n				    local pet = Combat :GetActor (1, petName)\n				    if (pet) then\n					totalAbsorb = totalAbsorb + pet.totalabsorbed\n				    end\n				end\n\n				GameCooltip:AddLine (actor:Name(), format_func (_, actor.totalabsorbed))\n				Details:AddTooltipBackgroundStatusbar()\n\n				for petIndex, petName in ipairs (actor.pets) do\n				    local pet = Combat :GetActor (1, petName)\n				    if (pet) then\n					totalAbsorb = totalAbsorb + pet.totalabsorbed\n					\n					GameCooltip:AddLine (petName, format_func (_, pet.totalabsorbed))\n					Details:AddTooltipBackgroundStatusbar()        \n					\n				    end\n				end\n			",
			["icon"] = "Interface\\ICONS\\Spell_Holy_PowerWordShield",
			["name"] = "Damage on Shields",
			["spellid"] = false,
			["target"] = false,
			["script"] = "				--get the parameters passed\n				local Combat, CustomContainer, Instance = ...\n				--declade the values to return\n				local total, top, amount = 0, 0, 0\n\n				--do the loop\n				for index, actor in ipairs (Combat:GetActorList(1)) do\n				    if (actor:IsPlayer()) then\n					\n					--get the actor total damage absorbed\n					local totalAbsorb = actor.totalabsorbed\n					\n					--get the damage absorbed by all the actor pets\n					for petIndex, petName in ipairs (actor.pets) do\n					    local pet = Combat :GetActor (1, petName)\n					    if (pet) then\n						totalAbsorb = totalAbsorb + pet.totalabsorbed\n					    end\n					end\n					\n					--add the value to the actor on the custom container\n					CustomContainer:AddValue (actor, totalAbsorb)        \n					\n				    end\n				end\n				--loop end\n\n				--if not managed inside the loop, get the values of total, top and amount\n				total, top = CustomContainer:GetTotalAndHighestValue()\n				amount = CustomContainer:GetNumActors()\n\n				--return the values\n				return total, top, amount\n			",
			["attribute"] = false,
			["script_version"] = 1,
		}, -- [13]
	},
	["performance_profiles"] = {
		["Dungeon"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["RaidFinder"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Battleground15"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Battleground40"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Mythic"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Arena"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Raid30"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
		["Raid15"] = {
			["enabled"] = false,
			["update_speed"] = 1,
			["miscdata"] = true,
			["aura"] = true,
			["heal"] = true,
			["use_row_animations"] = false,
			["energy"] = false,
			["damage"] = true,
		},
	},
	["exit_log"] = {
		"1 - Closing Janela Info.", -- [1]
		"2 - Clearing user place from instances.", -- [2]
		"4 - Reversing switches.", -- [3]
		"6 - Saving Config.", -- [4]
		"7 - Saving Profiles.", -- [5]
		"8 - Saving nicktag cache.", -- [6]
	},
	["item_level_pool"] = {
	},
	["lastUpdateWarning"] = 1518223018,
	["run_code"] = {
		["on_leavecombat"] = "\n-- this code runs when the player leave combat",
		["on_zonechanged"] = "\n-- when the player changes zone, this code will run",
		["on_init"] = "\n-- code to run when Details! initializes, put here code which only will run once\n-- this also will run then the profile is changed\n\n--size of the death log tooltip in the Deaths display (default 350)\nDetails.death_tooltip_width = 350;\n\n--when in arena or battleground, details! silently switch to activity time (goes back to the old setting on leaving, default true)\nDetails.force_activity_time_pvp = true;\n\n--speed of the bar animations (default 33)\nDetails.animation_speed = 33;\n\n--threshold to trigger slow or fast speed (default 0.45)\nDetails.animation_speed_mintravel = 0.45;\n\n--call to update animations\nDetails:RefreshAnimationFunctions();\n\n--max window size, does require a /reload to work (default 480 x 450)\nDetails.max_window_size.width = 480;\nDetails.max_window_size.height = 450;\n\n--use the arena team color as the class color (default true)\nDetails.color_by_arena_team = true;\n\n--use the role icon in the player bar when inside an arena (default false)\nDetails.show_arena_role_icon = false;\n\n--how much time the update warning is shown (default 10)\nDetails.update_warning_timeout = 10;",
		["on_specchanged"] = "\n-- run when the player changes its spec",
		["on_entercombat"] = "\n-- this code runs when the player enters in combat",
	},
}
