
Details_StreamerDB = {
	["characters"] = {
		["Boringrivers - Korgath"] = "Serenerivers - Korgath",
		["Rapidrivers - Arthas"] = "Serenerivers - Korgath",
		["Emptyrivers - Korgath"] = "Serenerivers - Korgath",
		["Naturerivers - Korgath"] = "Serenerivers - Korgath",
		["Crazyrivers - Sargeras"] = "Serenerivers - Korgath",
		["Testrivers - Bleeding Hollow"] = "Serenerivers - Korgath",
		["Beefyrivers - Bleeding Hollow"] = "Serenerivers - Korgath",
		["Beefyrivers - Thrall"] = "Serenerivers - Korgath",
		["Yandanderex - Moon Guard"] = "Serenerivers - Korgath",
		["Mindrivers - Korgath"] = "Serenerivers - Korgath",
		["Serenerivers - Arthas"] = "Serenerivers - Korgath",
		["Sacredrivers - Korgath"] = "Serenerivers - Korgath",
		["Serenerivers - Bleeding Hollow"] = "Serenerivers - Korgath",
		["Greedyrivers - Arthas"] = "Serenerivers - Korgath",
		["Blindrivers - Sargeras"] = "Serenerivers - Korgath",
		["Tinyrivers - Kel'Thuzad"] = "Serenerivers - Korgath",
		["Brightrivers - Korgath"] = "Serenerivers - Korgath",
		["Wildrivers - Korgath"] = "Serenerivers - Korgath",
		["Crazyrivers - Bleeding Hollow"] = "Serenerivers - Korgath",
		["Wildrivers - Bleeding Hollow"] = "Serenerivers - Korgath",
		["Serenerivers - Kel'Thuzad"] = "Serenerivers - Korgath",
		["Deadrivers - Korgath"] = "Serenerivers - Korgath",
		["Blindrivers - Arthas"] = "Serenerivers - Korgath",
		["Edgyrivers - Kel'Thuzad"] = "Serenerivers - Korgath",
		["Hulyon - Kel'Thuzad"] = "Serenerivers - Korgath",
		["Evilrivers - Sargeras"] = "Serenerivers - Korgath",
		["Littlerivers - Kel'Thuzad"] = "Serenerivers - Korgath",
		["Luckyrivers - Sargeras"] = "Serenerivers - Korgath",
		["Beefyrivers - Arthas"] = "Serenerivers - Korgath",
		["Smaz - Mug'thol"] = "Serenerivers - Korgath",
		["Feralrivers - Sargeras"] = "Serenerivers - Korgath",
		["Hiddenrivers - Korgath"] = "Serenerivers - Korgath",
		["Edgyrivers - Arthas"] = "Serenerivers - Korgath",
		["Ragingrivers - Arthas"] = "Serenerivers - Korgath",
		["Shachein - Arthas"] = "Serenerivers - Korgath",
		["Toofattohide - Kel'Thuzad"] = "Serenerivers - Korgath",
		["Wildrivers - Arthas"] = "Serenerivers - Korgath",
		["Notariver - Arthas"] = "Serenerivers - Korgath",
		["Blindrivers - Korgath"] = "Serenerivers - Korgath",
		["Evilrivers - Korgath"] = "Serenerivers - Korgath",
		["Emptyrivers - Sargeras"] = "Serenerivers - Korgath",
		["Boringrivers - Bleeding Hollow"] = "Serenerivers - Korgath",
		["Luckyrivers - Korgath"] = "Serenerivers - Korgath",
		["Tinyrivers - Arthas"] = "Serenerivers - Korgath",
		["Serenerivers - Sargeras"] = "Serenerivers - Korgath",
		["Crazyrivers - Arthas"] = "Serenerivers - Korgath",
		["Angryrivers - Korgath"] = "Serenerivers - Korgath",
		["Mecharivers - Sargeras"] = "Serenerivers - Korgath",
		["Eysta - Sargeras"] = "Serenerivers - Korgath",
		["Holyrivers - Sargeras"] = "Serenerivers - Korgath",
		["Emptyrivers - Bleeding Hollow"] = "Serenerivers - Korgath",
		["Serenerivers - Korgath"] = "Serenerivers - Korgath",
		["Kdajshtlaiuw - Bleeding Hollow"] = "Serenerivers - Korgath",
		["Evilrivers - Kel'Thuzad"] = "Serenerivers - Korgath",
		["Testes - Arthas"] = "Serenerivers - Korgath",
		["Emptyrivers - Arthas"] = "Serenerivers - Korgath",
		["Riversticks - Bleeding Hollow"] = "Serenerivers - Korgath",
		["Magicrivers - Korgath"] = "Serenerivers - Korgath",
		["Sassyrivers - Arthas"] = "Serenerivers - Korgath",
		["Tinyrivers - Sargeras"] = "Serenerivers - Korgath",
		["Skankyrivers - Arthas"] = "Serenerivers - Korgath",
		["Dammedrivers - Exodar"] = "Serenerivers - Korgath",
	},
	["profiles"] = {
		["Serenerivers - Korgath"] = {
			["font_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				1, -- [4]
			},
			["is_first_run"] = false,
			["arrow_color"] = {
				1, -- [1]
				1, -- [2]
				1, -- [3]
				0.5, -- [4]
			},
			["main_frame_size"] = {
				311.999938964844, -- [1]
				206.999969482422, -- [2]
			},
			["minimap"] = {
				["minimapPos"] = 290.246609931569,
				["radius"] = 160,
				["hide"] = true,
			},
			["arrow_anchor_x"] = 0,
			["row_texture"] = "Details Vidro",
			["scale"] = 1,
			["row_height"] = 20,
			["point"] = "LEFT",
			["enabled"] = false,
			["arrow_size"] = 10,
			["main_frame_strata"] = "BACKGROUND",
			["row_spacement"] = 21,
			["main_frame_color"] = {
				0, -- [1]
				0, -- [2]
				0, -- [3]
				0.200000047683716, -- [4]
			},
			["author"] = "Details! Team",
			["arrow_texture"] = "Interface\\CHATFRAME\\ChatFrameExpandArrow",
			["y"] = 66.4558715820313,
			["per_second"] = {
				["enabled"] = false,
				["point"] = "TOP",
				["scale"] = 0.649999976158142,
				["font_shadow"] = true,
				["y"] = -41.8552565847785,
				["x"] = -9.48024726720178,
				["size"] = 32,
				["update_speed"] = 0.05,
				["attribute_type"] = 1,
			},
			["x"] = 0,
			["font_face"] = "Friz Quadrata TT",
			["use_spark"] = true,
			["font_size"] = 10,
			["row_color"] = {
				0.101960784313725, -- [1]
				0.101960784313725, -- [2]
				0.101960784313725, -- [3]
				0.160000026226044, -- [4]
			},
			["main_frame_locked"] = true,
			["arrow_anchor_y"] = 0,
		},
	},
}
